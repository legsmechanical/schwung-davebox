// ui/ui.js
import {
  MoveUp as MoveUp3,
  MoveDown as MoveDown3,
  MoveDelete as MoveDelete3
} from "/data/UserData/schwung/shared/constants.mjs";
import {
  setButtonLED as setButtonLED6,
  isNoiseMessage
} from "/data/UserData/schwung/shared/input_filter.mjs";
import {
  installConsoleOverride
} from "/data/UserData/schwung/shared/logger.mjs";

// ui/ui_constants.mjs
import {
  Red,
  Blue,
  Green,
  DarkBlue,
  Mustard,
  DeepGreen,
  BrightGreen,
  BrightPink,
  RoyalBlue,
  DarkOlive,
  DeepWine
} from "/data/UserData/schwung/shared/constants.mjs";
var MoveNoteSession = 50;
var MoveUndo = 56;
var MoveLoop = 58;
var MoveCopy = 60;
var MoveMainTouch = 9;
var MoveRec = 86;
var MoveCapture = 52;
var MoveSample = 118;
var MoveMainButton = 3;
var MoveMainKnob = 14;
var LED_OFF = 0;
var LED_STEP_CURSOR = 127;
var SCENE_BTN_FLASH_TICKS = 40;
var LEDS_PER_FRAME = 8;
var NUM_TRACKS = 8;
var NUM_CLIPS = 16;
var DRUM_LANES = 32;
var DRUM_BASE_NOTE = 36;
var STATE_VERSION = 36;
var FLAG_JUMP_TO_OVERTAKE = 4;
var FLAG_JUMP_TO_TOOLS = 128;
var SEQ8_NAV_FLAGS = FLAG_JUMP_TO_OVERTAKE | FLAG_JUMP_TO_TOOLS;
var NUM_STEPS = 256;
var TRACK_COLORS = [
  Red,
  Blue,
  BrightGreen,
  Green,
  BrightPink,
  RoyalBlue,
  Mustard,
  DeepGreen
];
var TRACK_DIM_COLORS = [
  66,
  DarkBlue,
  DarkOlive,
  86,
  DeepWine,
  96,
  70,
  86
];
var SCENE_LETTERS = "ABCDEFGHIJKLMNOP";
var TRACK_PAD_BASE = 68;
var TPS_VALUES = [12, 24, 48, 96, 192, 384];
var NOTE_KEYS = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
var SCALE_NAMES = [
  "Major",
  "Minor",
  "Dorian",
  "Phrygian",
  "Lydian",
  "Mixolydian",
  "Locrian",
  "Harmonic Minor",
  "Melodic Minor",
  "Pentatonic Major",
  "Pentatonic Minor",
  "Blues",
  "Whole Tone",
  "Diminished"
];
var SCALE_DISPLAY = [
  "Major",
  "Minor",
  "Dori.",
  "Phryg",
  "Lyd.",
  "Mixo",
  "Locr.",
  "HMin",
  "MMin",
  "PMaj",
  "PMin",
  "Blues",
  "Whole",
  "Dim."
];
var DELAY_LABELS = ["1/64", "1/64D", "1/32", "1/16T", "1/32D", "1/16", "1/8T", "1/16D", "1/8", "1/4T", "1/8D", "1/4", "1/4D", "1/2", "1/2D", "1/1", "1/1D"];
function fmtSign(v) {
  return (v >= 0 ? "+" : "") + v;
}
function fmtStretch(exp) {
  if (exp === 0) return "1x";
  if (exp > 0) return "x" + (1 << exp);
  return "/" + (1 << -exp);
}
var LEN_LABELS = ["--", ".25", ".50", ".75", "1", "2", "4", "8", "16"];
function fmtLen(v) {
  return LEN_LABELS[v | 0] || "--";
}
function fmtLgto() {
  return "->";
}
function fmtRes(v) {
  return ["1/32", "1/16", "1/8", "1/4", "1/2", "1bar"][v] || "1/16";
}
function fmtPct(v) {
  return v + "%";
}
function fmtDly(v) {
  return DELAY_LABELS[v] || "---";
}
function fmtBool(v) {
  return v ? "ON" : "OFF";
}
function fmtPitchRnd(v) {
  return v === 0 ? "OFF" : String(v);
}
var GATE_LABELS = ["Off", "1/64", "1/32", "1/16T", "1/16", "1/8T", "1/8", "1/4T", "1/4", "1/2", "1bar"];
function fmtGateMod(v) {
  return GATE_LABELS[v] || "Off";
}
function fmtRoute(v) {
  return v === 2 ? "Ext" : v === 1 ? "Move" : "Swng";
}
function fmtPlain(v) {
  return String(v);
}
function fmtNA() {
  return "-";
}
function fmtArpStyle(v) {
  return ["Off", "Up", "Dn", "U/D", "D/U", "Cnv", "Div", "Ord", "Rnd", "RnO"][v] || "Off";
}
function fmtArpRate(v) {
  return ["1/32", "1/16", "1/16t", "1/8", "1/8t", "1/4", "1/4t", "1/2", "1/2t", "1bar"][v] || "1/16";
}
function fmtArpSteps(v) {
  return ["Off", "Mute", "Step"][v] || "Mute";
}
function fmtArpOct(v) {
  if (v === 0) return "Off";
  return (v > 0 ? "+" : "") + v;
}
function fmtVelOverride(v) {
  return v === 0 ? "Live" : String(v);
}
function fmtDiq(v) {
  return ["Off", "1/64", "1/32", "1/16", "1/16T", "1/8", "1/8T", "1/4", "1/4T"][v | 0] || "Off";
}
function fmtPlayDir(v) {
  return ["Fwd", "Bwd", "PPf", "PPb"][v | 0] || "Fwd";
}
function fmtRevStyle(v) {
  return v ? "Audio" : "Step";
}
function col4(s) {
  if (s === null || s === void 0) s = "-";
  s = String(s);
  return s.length >= 4 ? s.slice(0, 4) : s + " ".repeat(4 - s.length);
}
function col5(s) {
  if (s === null || s === void 0) s = "-";
  s = String(s);
  return s.length >= 5 ? s.slice(0, 5) : s + " ".repeat(5 - s.length);
}
function parseActionRaw(raw, def) {
  if (!raw || raw === "1x") return 0;
  const pow2 = [1, 2, 4, 8, 16, 32, 64, 128];
  if (raw[0] === "x") {
    const n = parseInt(raw.slice(1), 10);
    const idx = pow2.indexOf(n);
    return idx >= 0 ? idx : def || 0;
  }
  if (raw[0] === "/") {
    const n = parseInt(raw.slice(1), 10);
    const idx = pow2.indexOf(n);
    return idx >= 0 ? -idx : def || 0;
  }
  return parseInt(raw, 10) | 0;
}
var MCUFONT = {
  "A": [14, 17, 31, 17, 17],
  "B": [30, 17, 30, 17, 30],
  "C": [15, 16, 16, 16, 15],
  "D": [30, 17, 17, 17, 30],
  "E": [31, 16, 28, 16, 31],
  "F": [31, 16, 28, 16, 16],
  "G": [15, 16, 19, 17, 15],
  "H": [17, 17, 31, 17, 17],
  "I": [31, 4, 4, 4, 31],
  "J": [31, 2, 2, 18, 12],
  "K": [18, 20, 24, 20, 18],
  "L": [16, 16, 16, 16, 31],
  "M": [31, 21, 21, 17, 17],
  "N": [17, 25, 21, 19, 17],
  "O": [14, 17, 17, 17, 14],
  "P": [30, 17, 30, 16, 16],
  "Q": [14, 17, 17, 18, 13],
  "R": [30, 17, 30, 18, 17],
  "S": [15, 16, 14, 1, 30],
  "T": [31, 4, 4, 4, 4],
  "U": [17, 17, 17, 17, 14],
  "V": [17, 17, 10, 10, 4],
  "W": [17, 17, 21, 21, 27],
  "X": [17, 10, 4, 10, 17],
  "Y": [17, 10, 4, 4, 4],
  "Z": [31, 2, 4, 8, 31],
  "a": [0, 15, 17, 17, 15],
  "b": [16, 30, 17, 17, 30],
  "c": [0, 15, 16, 16, 15],
  "d": [1, 15, 17, 17, 15],
  "e": [0, 14, 31, 16, 15],
  "f": [0, 15, 16, 30, 16],
  "g": [0, 14, 31, 1, 30],
  "h": [16, 16, 30, 17, 17],
  "i": [4, 0, 12, 4, 14],
  "j": [2, 0, 2, 18, 12],
  "k": [16, 16, 22, 24, 22],
  "l": [0, 16, 16, 16, 15],
  "m": [0, 30, 21, 21, 17],
  "n": [0, 30, 17, 17, 17],
  "o": [0, 14, 17, 17, 14],
  "p": [0, 30, 17, 30, 16],
  "q": [0, 15, 17, 15, 1],
  "r": [0, 14, 16, 16, 16],
  "s": [0, 14, 24, 6, 28],
  "t": [0, 31, 4, 4, 4],
  "u": [0, 17, 17, 17, 14],
  "v": [0, 17, 17, 10, 4],
  "w": [0, 17, 21, 21, 14],
  "x": [0, 18, 12, 12, 18],
  "y": [0, 18, 14, 2, 12],
  "z": [0, 30, 4, 8, 30],
  "0": [14, 17, 21, 17, 14],
  "1": [12, 20, 4, 4, 31],
  "2": [14, 17, 6, 8, 31],
  "3": [31, 1, 14, 1, 30],
  "4": [18, 18, 31, 2, 2],
  "5": [31, 16, 14, 1, 30],
  "6": [14, 16, 30, 17, 14],
  "7": [31, 2, 4, 8, 8],
  "8": [14, 17, 14, 17, 14],
  "9": [31, 17, 31, 1, 1],
  "-": [0, 0, 14, 0, 0],
  "+": [0, 4, 14, 4, 0],
  ".": [0, 0, 0, 0, 8],
  ",": [0, 0, 0, 4, 8],
  "?": [14, 17, 6, 0, 4],
  "!": [4, 4, 4, 0, 4],
  ":": [0, 8, 0, 8, 0],
  "=": [0, 14, 0, 14, 0],
  "'": [4, 4, 0, 0, 0],
  "#": [10, 31, 10, 31, 10],
  "/": [1, 2, 4, 8, 16],
  "(": [6, 8, 8, 8, 6],
  ")": [12, 2, 2, 2, 12],
  "<": [2, 4, 8, 4, 2],
  ">": [8, 4, 2, 4, 8]
};
function pixelPrint(x, y, text, color) {
  for (let ci = 0; ci < text.length; ci++) {
    const g = MCUFONT[text[ci]];
    if (g) {
      for (let row = 0; row < 5; row++) {
        const bits = g[row];
        for (let col = 0; col < 5; col++) {
          if (bits & 1 << 4 - col)
            set_pixel(x + ci * 6 + col, y + row, color);
        }
      }
    }
  }
}
function pixelPrintC(cx, y, text, color) {
  pixelPrint(cx - Math.floor((text.length * 6 - 1) / 2), y, text, color);
}
function p(abbrev, full, dspKey, scope, min, max, def, fmt, sens, actionSuffix, lock, step) {
  return {
    abbrev,
    full,
    dspKey,
    scope,
    min,
    max,
    def,
    fmt,
    sens: sens || 1,
    actionSuffix: actionSuffix || "_pos",
    lock: lock || false,
    step: step || 1
  };
}
var _X = p(null, null, null, "stub", 0, 0, 0, fmtNA);
var _XQ = p(null, null, null, "stub", 0, 100, -1, fmtNA);
var _XR = p(null, null, null, "stub", 0, 0, -1, fmtNA);
var BANKS = [
  /* 0 — CLIP (pad 92) — K1=Res, K2=Stch (Beat Stretch), K3=Shft (Clock
   * Shift, Shift+turn=Nudge), K4=Lgto (destructive one-shot — opens
   * confirm dialog on right-turn), K5=InQ (custom handling, mirrors drum
   * ALL LANES K5), K6 unassigned, K7=Dir, K8=SqFl. */
  { name: "CLIP", knobs: [
    p("Res", "Resolution", "clip_resolution", "clip", 0, 5, 1, fmtRes, 8),
    p("Strch", "Beat Stretch", "beat_stretch", "action", 0, 0, 0, fmtStretch, 16, "_factor", true),
    p("Shift", "Clock Shift", "clock_shift", "action", 0, 0, 0, fmtSign, 8),
    p("Lgto", "Apply Legato", "lgto_apply", "action", 0, 0, 0, fmtLgto, 16, "_factor", true),
    p("InQnt", "Input Quantize", "diq", "track", 0, 8, 0, fmtDiq, 5),
    _X,
    p("Dir", "Playback Dir", "clip_playback_dir", "clip", 0, 3, 0, fmtPlayDir, 8),
    p("SeqFl", "Seq Follow", null, "seqfollow", 0, 1, 1, fmtBool, 16)
  ] },
  /* 1 — NOTE FX (pad 93). Layout (melodic, K-cells 1..8):
   * K1=Oct, K2=Ofs, K3=Vel, K4=Qnt, K5=Len, K6=>Gate, K7=blocked, K8=Rnd.
   * Custom render branch widens K6 to fit ">Gate" (5 chars); K7 stub
   * blocks the generic handler and LED ring. Len is a fixed pre-gate
   * length multiplier (non-destructive). Destructive legato lives on
   * CLIP K8 / DRUM LANE K8. */
  { name: "NOTE FX", knobs: [
    p("Oct", "Octave Shift", "noteFX_octave", "track", -4, 4, 0, fmtSign, 8),
    p("Offst", "Note Offset", "noteFX_offset", "track", -24, 24, 0, fmtSign, 8),
    p("Vel", "Velocity Offset", "noteFX_velocity", "track", -127, 127, 0, fmtSign),
    p("Quant", "Quantize", "quantize", "track", 0, 100, 0, fmtPct, 1, void 0, void 0, 2),
    p("Len>", "Note Length", "noteFX_length_mode", "track", 0, 8, 0, fmtLen, 5),
    p("Gate", "Gate Time", "noteFX_gate", "track", 0, 400, 100, fmtPct, 1, void 0, void 0, 2),
    _X,
    p("Rand", "Pitch Random", "noteFX_random", "track", 0, 24, 0, fmtPitchRnd, 4)
  ] },
  /* 2 — HARMZ (pad 94) */
  { name: "HARMONY", knobs: [
    p("Oct", "Octaver", "harm_octaver", "track", -4, 4, 0, fmtSign, 8),
    p("Harm1", "Harmony 1", "harm_interval1", "track", -24, 24, 0, fmtSign, 8),
    p("Harm2", "Harmony 2", "harm_interval2", "track", -24, 24, 0, fmtSign, 8),
    p("Harm3", "Harmony 3", "harm_interval3", "track", -24, 24, 0, fmtSign, 8),
    _X,
    _X,
    _X,
    _X
  ] },
  /* 3 — MIDI DLY (pad 95). K7 = Retrg (delay_retrig); Clock Feedback folded
   * onto Shift+K1 with dynamic label flip "Rate"↔"ClkF". */
  { name: "DELAY", knobs: [
    p("Rate", "Delay Time", "delay_time", "track", 0, 16, 10, fmtDly, 6),
    p("Level", "Delay Level", "delay_level", "track", 0, 127, 127, fmtPlain),
    p("Repts", "Repeats", "delay_repeats", "track", 0, 16, 0, fmtPlain, 16),
    p("VelFb", "Vel Feedback", "delay_vel_fb", "track", -127, 127, 0, fmtSign),
    p("PitFb", "Pitch Feedback", "delay_pitch_fb", "track", -24, 24, 0, fmtSign, 16),
    p("Gate", "Gate", "delay_gate_fb", "track", 0, 10, 0, fmtGateMod, 2),
    p("Retrg", "Retrig", "delay_retrig", "track", 0, 1, 1, fmtBool, 4),
    p("Rand", "Pitch Random", "delay_pitch_random", "track", 0, 24, 0, fmtPitchRnd, 4)
  ] },
  /* 4 — ARP OUT (pad 96) */
  { name: "SEQUENCE ARP", knobs: [
    p("Style", "Arp Style", "seq_arp_style", "track", 0, 9, 0, fmtArpStyle, 8),
    p("Rate", "Arp Rate", "seq_arp_rate", "track", 0, 9, 1, fmtArpRate, 8),
    p("Oct", "Octave Range", "seq_arp_octaves", "track", -4, 4, 0, fmtArpOct, 8),
    p("Gate", "Arp Gate", "seq_arp_gate", "track", 1, 200, 100, fmtPct, 4),
    p("Steps", "Steps Mode", "seq_arp_steps_mode", "track", 1, 2, 1, fmtArpSteps, 8),
    p("Retrg", "Retrigger", "seq_arp_retrigger", "track", 0, 1, 1, fmtBool, 16),
    p("Sync", "Sync to Clock", "seq_arp_sync", "track", 0, 1, 1, fmtBool, 16),
    _X
  ] },
  /* 5 — ARP IN (pad 97) */
  { name: "LIVE ARP", knobs: [
    p("Style", "Arp Style", "tarp_style", "track", 0, 9, 0, fmtArpStyle, 8),
    p("Rate", "Arp Rate", "tarp_rate", "track", 0, 9, 1, fmtArpRate, 8),
    p("Oct", "Octave Range", "tarp_octaves", "track", -4, 4, 0, fmtArpOct, 8),
    p("Gate", "Arp Gate", "tarp_gate", "track", 1, 200, 100, fmtPct, 4),
    p("Steps", "Steps Mode", "tarp_steps_mode", "track", 1, 2, 1, fmtArpSteps, 8),
    p("Retrg", "Retrigger", "tarp_retrigger", "track", 0, 1, 0, fmtBool, 16),
    p("Sync", "Sync to Clock", "tarp_sync", "track", 0, 1, 1, fmtBool, 16),
    p("Latch", "Latch", "tarp_latch", "track", 0, 1, 0, fmtBool, 16)
  ] },
  /* 6 — AUTO (pad 98) — per-clip CC + aftertouch (+ PB later) automation; custom handling, no DSP-wired knobs */
  { name: "AUTOMATION", knobs: [_X, _X, _X, _X, _X, _X, _X, _X] },
  /* 7 — ALL LANES (drum pad 92) — macro controls across all 32 drum lanes.
   * K1=Res (all-lane resolution, custom), K2=Stch, K3=Shft (alt=Nudge),
   * K4=Qnt (custom), K5=VelIn (custom), K6=InQ (custom),
   * K7=Dir (all-lane playback dir, alt=RvSt, custom), K8=SyncRpt. */
  { name: "ALL LANES", knobs: [
    _XR,
    /* K1: Res — all-lane resolution, custom handling, def=-1 */
    p("Strch", "Beat Stretch", "beat_stretch", "action", 0, 0, 0, fmtStretch, 16, "_factor", true),
    p("Shift", "Clock Shift", "clock_shift", "action", 0, 0, 0, fmtSign, 8),
    _XQ,
    /* K4: Qnt — quantize all lanes, custom handling, def=-1 */
    _X,
    /* K5: VelIn — custom handling via trackVelOverride */
    _X,
    /* K6: InQ — per-track drum input quantize, custom handling */
    _XR,
    /* K7: Dir — all-lane playback dir, custom handling, def=-1 */
    p("RSync", "Repeat Sync", "drum_repeat_sync", "track", 0, 1, 1, fmtBool, 16)
  ] },
  /* 8 — RESPONDER (conduct) — per-track on/off, custom render+handler (Task 2.3/2.4) */
  { name: "RESPONDER", knobs: [_X, _X, _X, _X, _X, _X, _X, _X] },
  /* 9 — OCTAVE (conduct) — per-track octave -4..+4, custom render+handler */
  { name: "OCTAVE", knobs: [_X, _X, _X, _X, _X, _X, _X, _X] },
  /* 10 — WHEN (conduct) — per-track Next/Now, custom render+handler */
  { name: "WHEN", knobs: [_X, _X, _X, _X, _X, _X, _X, _X] }
];
var BANK_RESPONDER = 8;
var BANK_OCTAVE = 9;
var BANK_WHEN = 10;
var TICK_HZ = 94;
var ACTION_POPUP_TICKS = 49;
var POLL_INTERVAL = 4;
var CC_GRADIENT_BASE = 59;
var CC_GRADIENT_LEVELS = 3;
var CC_GRADIENT_SCALARS = [0.3, 0.6, 1];
var NO_NOTE_FLASH_TICKS = 56;
var TAP_TEMPO_FLASH_TICKS = 9;
var TAP_TEMPO_RESET_MS = 2e3;
var PARAM_LED_BANKS = [1, 2, 3, 4, 5];
var PAD_MODE_DRUM = 1;
var PAD_MODE_MELODIC_SCALE = 0;
var PAD_MODE_CONDUCT = 2;
var STEP_ITER_LIST = (function() {
  const L = [0];
  for (let cl = 2; cl <= 8; cl++)
    for (let ci = 1; ci <= cl; ci++)
      L.push(cl << 4 | ci);
  return L;
})();

// ui/ui_state.mjs
function conductorTrackIdx() {
  let t;
  for (t = 0; t < 8; t++) if (S.trackPadMode[t] === PAD_MODE_CONDUCT) return t;
  return -1;
}
var PERF_FACTORY_PRESETS = [
  /* bits: 0=Oct↑ 1=Oct↓ 2=Sc↑ 3=Sc↓ 4=5th 5=Triton 6=Drift 7=Storm
           8=Soft 9=Hard 10=Cresc 11=Pulse 12=Sdchn 13=Stac 14=Lgto 15=RmpG
           16=½time 17=3Skip 18=Phnm 19=Sprs 20=Gltch 21=Stggr 22=Shfl 23=Back */
  { name: "Float", mods: 1 << 2 | 1 << 14 },
  /* Sc↑ + Lgto */
  { name: "Sink", mods: 1 << 1 | 1 << 8 | 1 << 13 },
  /* Oct↓ + Decrsc + Stac */
  { name: "Heartbt", mods: 1 << 11 | 1 << 16 },
  /* Pulse + ½time */
  { name: "F.Dust", mods: 1 << 7 | 1 << 9 | 1 << 19 },
  /* Storm + Swell + Sprs */
  { name: "Robot", mods: 1 << 5 | 1 << 11 | 1 << 17 },
  /* Triton + Pulse + 3Skip */
  { name: "Dissolve", mods: 1 << 6 | 1 << 8 | 1 << 18 },
  /* Drift + Decrsc + Phnm */
  { name: "Chaos", mods: 1 << 7 | 1 << 20 | 1 << 23 },
  /* Storm + Gltch + Back */
  { name: "Lift", mods: 1 << 2 | 1 << 10 | 1 << 15 }
  /* Sc↑ + Cresc + RmpG */
];
var CC_ASSIGN_DEFAULTS = [7, 74, 71, 73, 72, 91, 93, 10];
var S = {
  swingAmt: 0,
  swingRes: 0,
  inpQuant: false,
  midiInChannel: 0,
  beatMarkersEnabled: true,
  launchQuant: 0,
  scaleAware: 1,
  ledInitQueue: [],
  ledInitIndex: 0,
  ledInitComplete: false,
  shiftHeld: false,
  altMode: false,
  /* sticky alt-param mode, toggled by jog-click; transient */
  _altPrevBank: -1,
  /* diff-guard mirror for clearing altMode on bank change */
  _altPrevTrack: -1,
  /* diff-guard mirror for clearing altMode on track change */
  _altBlinkPhase: -1,
  /* tick-driven phase (0/1) for the alt-mode arrow flash */
  shiftTrackLEDActive: false,
  loopHeld: false,
  perfSync: true,
  perfStack: [],
  perfStickyLengths: /* @__PURE__ */ new Set(),
  perfHoldPadHeld: false,
  perfModsToggled: 0,
  perfModsHeld: 0,
  perfLatchMode: true,
  perfLatchPressedTick: -1,
  perfSnapshots: PERF_FACTORY_PRESETS.map(function(p2) {
    return p2.mods;
  }).concat(new Array(8).fill(0)),
  /* slots 8-15 empty */
  perfRecalledSlot: -1,
  perfModPopupName: "",
  perfModPopupEndTick: -1,
  perfViewLocked: false,
  loopJogActive: false,
  /* true while jog is turned with loop held (step view vs pages view) */
  loopPressTick: -1,
  loopLastTapEndTick: -999,
  /* Loop+step range gesture: held start page → tap end page → atomic loop_set.
   * Press of step A defers; tap of step B before release fires the new range
   * (and any further taps re-set end without release). Release of A with no
   * second tap falls back to the existing length-set behavior. Cleared on
   * Loop button release too so a partial gesture doesn't leak. */
  loopGestureStart: -1,
  loopGestureFired: false,
  /* Tap-loop-alone unlatch (drum tracks): snapshot taken at Loop press time
   * of "active drum track with no pads/lanes held + no notes live". On tap
   * release, unlatch all Rpt1/Rpt2 latched on that track. -1 = ineligible. */
  loopTapUnlatchTrack: -1,
  loopGestureCtx: 0,
  /* 0 = melodic, 1 = drum lane, 2 = ALL LANES */
  loopGestureTrack: -1,
  loopGestureClip: -1,
  loopGestureLane: -1,
  padKey: 9,
  padScale: 1,
  padOctave: new Array(8).fill(3),
  padNoteMap: new Array(32).fill(60),
  padScaleSet: /* @__PURE__ */ new Set(),
  /* semitones 0-11 in current key+scale; updated by computePadNoteMap */
  clipSteps: Array.from({ length: 8 }, () => Array.from({ length: 16 }, () => new Array(256).fill(0))),
  clipNonEmpty: Array.from({ length: 8 }, () => new Array(16).fill(false)),
  clipLength: Array.from({ length: 8 }, () => new Array(16).fill(16)),
  clipLoopStart: Array.from({ length: 8 }, () => new Array(16).fill(0)),
  clipTPS: Array.from({ length: 8 }, () => new Array(16).fill(24)),
  /* Per-clip playback direction: 0=Fwd, 1=Bwd, 2=PPFwd, 3=PPBwd.
   * Mirrors DSP clip.playback_dir; refreshed on clip switch / sidecar load. */
  clipPlaybackDir: Array.from({ length: 8 }, () => new Array(16).fill(0)),
  /* Per-track-per-lane playback direction for drum (active clip's lane).
   * Mirrors DSP drum lane clip.playback_dir; refreshed on lane / clip switch. */
  drumLanePlaybackDir: Array.from({ length: 8 }, () => new Array(32).fill(0)),
  /* Per-clip playback style: 0=Step, 1=Audio (note-on at note's end in
   * reverse motion). Mirrors DSP clip.playback_audio_reverse. */
  clipPlaybackAudioReverse: Array.from({ length: 8 }, () => new Array(16).fill(0)),
  /* Per-track-per-lane playback style for drum. */
  drumLanePlaybackAudioReverse: Array.from({ length: 8 }, () => new Array(32).fill(0)),
  /* "REC Unavailable / Set Dir to Fwd or Bake" confirm dialog. Set when
   * Record is pressed on a non-Forward / Audio clip. Sel: 0=OK (default,
   * dismiss), 1=BAKE NOW (opens standard bake confirm). Jog turn flips
   * selection; jog click commits. */
  recordBlockedDialog: false,
  recordBlockedDialogSel: 0,
  /* Single-OK info modal shown when Tap Tempo is invoked while Clock Slave is
   * on (tempo is Move's; there's nothing to tap). Dismissed by jog click or Back. */
  bpmMoveInfo: false,
  clipSeqFollow: Array.from({ length: 8 }, () => new Array(16).fill(true)),
  trackCurrentStep: new Array(8).fill(-1),
  trackCurrentPage: new Array(8).fill(0),
  activeDrumLane: new Array(8).fill(0),
  drumLanePage: new Array(8).fill(0),
  drumLaneSteps: Array.from({ length: 8 }, () => Array.from({ length: 32 }, () => new Array(256).fill("0"))),
  drumLaneHasNotes: Array.from({ length: 8 }, () => new Array(32).fill(false)),
  drumLaneNote: Array.from({ length: 8 }, () => Array.from({ length: 32 }, (_, l) => 36 + l)),
  drumLastVelZone: new Array(8).fill(12),
  drumVelZoneArmed: new Array(8).fill(false),
  /* per-track: has a vel-pad been pressed? gates sticky zone for step entry */
  drumLaneLength: new Array(8).fill(16),
  drumLaneLoopStart: new Array(8).fill(0),
  drumLaneTPS: new Array(8).fill(24),
  drumLaneEuclidN: Array.from({ length: 8 }, () => new Array(32).fill(0)),
  drumStepPage: new Array(8).fill(0),
  drumCurrentStep: new Array(8).fill(-1),
  drumLaneFlashTick: Array.from({ length: 8 }, () => new Array(32).fill(-999)),
  drumLaneMute: new Array(8).fill(0),
  drumLaneSolo: new Array(8).fill(0),
  drumLaneQnt: new Array(8).fill(0),
  /* NOTE FX K5 Len: per-track[8] × per-lane[32], 0..8 (0=`--`, 1..8 = fixed). */
  drumLaneLenMode: Array.from({ length: 8 }, () => new Array(32).fill(0)),
  /* CLIP K8 / DRUM LANE K8 "Lgto" destructive confirm dialog. Set when the
   * user right-turns the Lgto knob. Sel: 0=OK (default, apply), 1=CANCEL.
   * Jog turn flips selection; jog click commits. */
  confirmLgto: false,
  confirmLgtoSel: 0,
  confirmLgtoIsDrum: false,
  allLanesQntResetTick: -1,
  /* tick at which to reset bankParams[t][7][3] to -1 after knob release */
  allLanesQntResetTrack: -1,
  allLanesResResetTick: -1,
  allLanesResResetTrack: -1,
  allLanesDirResetTick: -1,
  allLanesDirResetTrack: -1,
  drumPerformMode: new Array(8).fill(0),
  drumRepeatHeldPad: new Array(8).fill(-1),
  drumRepeatHeldPadVel: new Array(8).fill(100),
  drumRepeatHeldPadsStack: Array.from({ length: 8 }, () => []),
  drumRepeatLatched: new Array(8).fill(false),
  pendingRepeatLane: -1,
  pendingRepeatLaneTrack: 0,
  drumRepeat2HeldLanes: Array.from({ length: 8 }, () => /* @__PURE__ */ new Set()),
  drumRepeat2LatchedLanes: Array.from({ length: 8 }, () => /* @__PURE__ */ new Set()),
  drumRepeat2RatePerLane: Array.from({ length: 8 }, () => new Array(32).fill(2)),
  rpt2LoopPadUsed: false,
  drumRepeatGate: Array.from({ length: 8 }, () => new Array(32).fill(255)),
  drumRepeatGateLen: Array.from({ length: 8 }, () => new Array(32).fill(8)),
  drumRepeatVelScale: Array.from({ length: 8 }, () => Array.from({ length: 32 }, () => new Array(8).fill(255))),
  drumRepeatNudge: Array.from({ length: 8 }, () => Array.from({ length: 32 }, () => new Array(8).fill(0))),
  /* Absolute step velocity 0..127 (0 = off), default 100. Pads write the
   * coarse ARP_VEL_CANON values; Shift+knobs in the step editor write fine. */
  seqArpStepVel: Array.from({ length: 8 }, () => Array.from({ length: 16 }, () => new Array(8).fill(255))),
  tarpStepVel: Array.from({ length: 8 }, () => new Array(8).fill(255)),
  /* Per-step scale-degree offset (-14..+14) for SEQ ARP (per-clip) and TARP (per-track).
   * Edited via the Arp Steps interval-mode overlay (jog click on bank 4 or 5). */
  seqArpStepInt: Array.from({ length: 8 }, () => Array.from({ length: 16 }, () => new Array(8).fill(0))),
  tarpStepInt: Array.from({ length: 8 }, () => new Array(8).fill(0)),
  /* Per-pattern step-loop length (1..8, default 8). Governs both step_vel and
   * step_int playback indexing — pattern wraps at this length. */
  seqArpStepLoopLen: Array.from({ length: 8 }, () => new Array(16).fill(8)),
  tarpStepLoopLen: new Array(8).fill(8),
  /* Arp Steps interval-mode overlay flag — true while the user has clicked
   * jog on bank 4 (SEQ ARP) or 5 (TARP). Auto-clears on next jog turn. */
  stepIntervalMode: false,
  /* TARP held-buffer mirror: pitches in DSP tarp.held_pitch[] for each track.
   * Polled from t{n}_tarp_held when tarp_latch is on; used to light source
   * pads in melodic Track View while the chord is latched. */
  tarpHeldNotes: Array.from({ length: 8 }, () => /* @__PURE__ */ new Set()),
  noteFXRandomMode: new Array(8).fill(2),
  midiDlyRandomMode: new Array(8).fill(2),
  allLanesConfirmed: false,
  drumClipNonEmpty: Array.from({ length: 8 }, () => new Array(16).fill(false)),
  trackActiveClip: new Array(8).fill(0),
  lastDspActiveClip: new Array(8).fill(0),
  trackQueuedClip: new Array(8).fill(-1),
  trackChannel: new Array(8).fill(1),
  trackRoute: new Array(8).fill(0),
  schwungCoRunSlot: -1,
  /* -1 = off; 0-3 = Schwung chain editor is co-running on this slot (dAVEBOx skips OLED + suppresses track-button LEDs) */
  _coRunChanSlots: 0,
  /* Schwung co-run: bitmask (bits 0-3) of slots whose receive channel matches the active track; blinked on the side buttons. 0 = none. Refreshed on poll cadence. */
  pendingSchwungCoRunTrack: -1,
  /* -1 = none; t = track queued to enter Schwung co-run; slot resolved in tick (schSlotsForTrack) so shadow_get_slots runs in tick context */
  pendingSchwungCoRunDelay: 0,
  /* >0 = ticks remaining before entering co-run after a no-match "NO SLOT" popup (lets the message show before the editor takes the OLED) */
  moveCoRunTrack: -1,
  /* -1 = off; 0-3 = Move firmware is co-running on this track (dAVEBOx skips OLED; shim filters nav CCs + touch 0-9 from tool, lets them reach Move) */
  moveCoRunDrumHeld: /* @__PURE__ */ new Set(),
  /* d1 notes of drum lane pads currently held in co-run — per-pad Set so a 2nd simultaneous hold doesn't clobber the 1st's tracking (js-input-1). Plain pad note-off (no Shift injection) sent per held pad on physical release / co-run exit */
  trackPadMode: new Array(8).fill(0),
  trackVelOverride: new Array(8).fill(0),
  trackLooper: new Array(8).fill(1),
  /* Per-track pad-pressure (aftertouch) send mode: 0=Off, 1=Poly (0xA0), 2=Channel (0xD0).
   * Move route supports 0/1 only; Schwung/External support 0/1/2. Persisted in UI sidecar (am). */
  trackAtMode: new Array(8).fill(0),
  /* Per-pad last-sent aftertouch value (dedupe live send); -1 = none sent. Transient. */
  atLastSent: new Array(32).fill(-1),
  trackClipPlaying: new Array(8).fill(false),
  trackWillRelaunch: new Array(8).fill(false),
  trackPendingPageStop: new Array(8).fill(false),
  sceneBtnFlashTick: new Array(4).fill(-1),
  playing: false,
  activeTrack: 0,
  sessionView: false,
  hasInitedOnce: false,
  _forceSessionCold: false,
  /* set on the first init() of a fresh runtime (cold load) so restoreUiSidecar opens in Session view regardless of the saved sv; a resume (JS kept in memory) leaves it false. See ui.js init + restoreUiSidecar. */
  sceneRow: 0,
  flashEighth: false,
  flashSixteenth: false,
  masterPos: 0,
  dspLooperState: 0,
  dspMergeState: 0,
  dspMergeDstClip: 0,
  dspMergeTrack: -1,
  pendingMergeArm: false,
  pendingBankRefresh: -1,
  tickCount: 0,
  cachedSceneAllPlaying: new Array(16).fill(false),
  cachedSceneAllQueued: new Array(16).fill(false),
  cachedSceneAnyPlaying: new Array(16).fill(false),
  activeBank: 0,
  /* Per-track snapshot of activeBank. Saved at every track switch, restored
   * on track switch and on sidecar load. activeBank remains the live mirror
   * for the currently-active track; this array is the storage that survives
   * track changes and session reload. Sidecar v=8. */
  trackActiveBank: new Array(8).fill(0),
  /* Latches: track-button LED reclaim after Move-native co-run exit (Move
   * firmware writes CC 40-43 colors during co-run; dAVEBOx must blank them
   * once on exit). Schwung co-run has a parallel _coRunTrackLedsLit latch. */
  _moveCoRunTrackLedsActive: false,
  knobTouched: -1,
  knobAccum: new Array(8).fill(0),
  knobLastDir: new Array(8).fill(0),
  knobLocked: new Array(8).fill(false),
  knobTurnedTick: new Array(8).fill(-1),
  bankSelectTick: -1,
  jogTouched: false,
  stretchBlockedEndTick: -1,
  noNoteFlashEndTick: -1,
  trackOctave: new Array(8).fill(0),
  actionPopupEndTick: -1,
  actionPopupLines: [],
  actionPopupHighlight: -1,
  clockShiftTouchDelta: 0,
  screenDirty: true,
  lastBlinkOn: null,
  bankParams: null,
  /* set in ui.js after BANKS is defined */
  trackCCAssign: Array.from({ length: 8 }, () => CC_ASSIGN_DEFAULTS.slice()),
  /* Per-knob continuous-modulation type: 0 = CC, 1 = Channel Pressure (aftertouch), 2 = Sch (chain knob). Per-track. */
  trackCCType: Array.from({ length: 8 }, () => new Array(8).fill(0)),
  /* Sch label cache: per-track per-lane param name string, null = not fetched. */
  schLabel: Array.from({ length: 8 }, () => new Array(8).fill(null)),
  /* Sch label fetch cursor: -1 = idle, 0-7 = fetching lane N next tick. */
  schLabelFetchLane: -1,
  /* Per-clip resting value ("clip CC") per knob; -1 = "—" (unset, send nothing). */
  clipCCVal: Array.from({ length: 8 }, () => Array.from({ length: 16 }, () => new Array(8).fill(-1))),
  trackCCAutoBits: Array.from({ length: 8 }, () => new Array(16).fill(0)),
  /* Per-clip "has recorded aftertouch automation" (AUTOMATION-bank indicator). */
  clipAtHas: Array.from({ length: 8 }, () => new Array(16).fill(false)),
  trackCCLiveVal: Array.from({ length: 8 }, () => new Array(8).fill(-1)),
  /* Active CC lane (last-touched knob) per track — persistent, drives the
   * step-LED gradient and the always-highlighted overview cell. */
  ccActiveLane: new Array(8).fill(0),
  ccLaneLoopStart: Array.from({ length: 8 }, function() {
    return Array.from({ length: 16 }, function() {
      return new Array(8).fill(0);
    });
  }),
  ccLaneLength: Array.from({ length: 8 }, function() {
    return Array.from({ length: 16 }, function() {
      return new Array(8).fill(0);
    });
  }),
  ccLaneTps: Array.from({ length: 8 }, function() {
    return Array.from({ length: 16 }, function() {
      return new Array(8).fill(0);
    });
  }),
  ccLaneResTps: Array.from({ length: 8 }, function() {
    return Array.from({ length: 16 }, function() {
      return new Array(8).fill(0);
    });
  }),
  /* CC-knob acceleration (fractional accumulator + run-based gain): per knob,
   * last turn time, direction, consecutive-detent run, and the sub-unit
   * accumulator. */
  knobAccelLast: new Array(8).fill(0),
  knobAccelDir: new Array(8).fill(0),
  knobAccelRun: new Array(8).fill(0),
  knobAccelAcc: new Array(8).fill(0),
  /* Clip index needing a CC auto-bits/rest re-read on next tick (-1 = none).
   * Set from MIDI handlers where get_param returns null (e.g. Delete+step). */
  pendingCCBitsRefresh: -1,
  heldStepBtn: -1,
  heldStep: -1,
  heldStepNotes: [],
  stepWasEmpty: false,
  stepWasHeld: false,
  stepEditVel: 100,
  stepEditGate: 12,
  stepEditNudge: 0,
  /* Per-step trig conditions (v=34). All zero = defaults (always play, 100%, no ratchet).
   * stepEditIter:  raw byte 0 or (cycle_len<<4) | cycle_idx
   * stepEditRand:  0 = 100%, 1..100 = probability percent
   * stepEditRatch: 0|1 = no ratchet, 2..4 = sub-hit count */
  stepEditIter: 0,
  stepEditRand: 0,
  stepEditRatch: 0,
  ccStepEditVal: new Array(8).fill(0),
  /* Per-knob: does the held step have a recorded point? (drives "—" vs value) */
  ccStepEditSet: new Array(8).fill(false),
  /* Per-knob: computed output value at the held step (-1 = "—"); what plays there. */
  ccStepEditComputed: new Array(8).fill(-1),
  ccStepEditActive: false,
  /* CC-bank step-LED gradient: cached active-lane output values for the page
   * (255 = "—"), the cache key (track/clip/lane/page), and which track's 6
   * gradient palette entries are currently loaded. */
  ccGradVals: new Array(16).fill(255),
  ccGradHasBP: new Array(16).fill(false),
  ccGradKey: "",
  ccGraphOvData: [],
  ccGraphOvKey: "",
  ccGradPaletteTrack: -1,
  stepBtnPressedTick: new Array(16).fill(-1),
  lastPlayedNote: -1,
  lastPadVelocity: 100,
  liveActiveNotes: /* @__PURE__ */ new Set(),
  seqActiveNotes: /* @__PURE__ */ new Set(),
  seqLastStep: -1,
  seqLastClip: -1,
  seqNoteOnClipTick: -1,
  seqNoteGateTicks: 0,
  deleteHeld: false,
  muteHeld: false,
  muteUsedAsModifier: false,
  captureHeld: false,
  captureUsedAsModifier: false,
  /* set true when a Capture-held gesture consumes the press (scene capture, drum lane select, etc.) — bare-tap clip/scene bake suppresses on release */
  capturePending: 0,
  /* retrospective-capture buffered event count for the active track (DSP capture_pending mirror; gates tap = capture-vs-bake) */
  captureArmed: false,
  /* capturePending>0 AND a tap would actually commit (playing, or stopped in an empty session) — drives the Capture LED blink so it never flashes when a stopped commit would be refused */
  captureCommitAwait: 0,
  /* >0: polls remaining to watch capture_info for the commit toast (set on tap-commit, counts down in pollDSP) */
  captureInfoSeq: void 0,
  /* last seen capture_info commit sequence (toast fires on change) */
  tempoSelectActive: false,
  /* Move-style post-capture chooser is open (DSP cap_select_active mirror) */
  tempoSelectWarp: false,
  /* 0 = tempo chooser (bpm), 1 = warp chooser (bars) */
  tempoSelectIdx: 0,
  /* which candidate is applied */
  tempoSelectBpms: [0, 0, 0],
  /* candidate values (BPMs, or bar counts in warp mode) */
  capturePlaceTrack: -1,
  /* >=0: stopped capture awaiting a destination-clip pick on this track (Session View, empty clips blink) */
  tempoSelectTrack: 0,
  /* track whose take is being tempo-chosen */
  tempoSelectClip: 0,
  /* clip the take was committed into */
  pendingSceneBakePicker: false,
  /* Session-View Capture tap → wait for next row/step press to pick scene → opens scene-bake confirm */
  pendingMergePlacement: false,
  /* multi-track live merge stopped → wait for row/step press to pick destination scene row */
  mergeSingleTrack: -1,
  /* >=0: Track-View single-clip merge armed on this track (DSP merge_solo_track); on CAPTURED → pick-destination mode */
  mergeSoloPlacement: -1,
  /* >=0: single-clip merge captured, awaiting a destination-clip pick on this track (Session View, empty clips blink) */
  mergeNoticePending: false,
  /* Shift+Rec raised the "Rec to start / Back to cancel" notice; count-in has NOT begun */
  mergeNoticeSingleTrack: -1,
  /* view captured at notice time: -1 = scene (all 8), >=0 = solo track for the pending merge */
  mergePlacing: false,
  /* destination picked → DSP committing; shows "Placing…" until CAPTURED→IDLE edge */
  mergePlacingScene: false,
  /* true = scene/all-8 placement (CLIPS), false = single clip (CLIP) — text only */
  _modalSwallowCC: -1,
  /* button CC whose press was consumed by a modal guard in _onCCMsg; its release is swallowed too */
  metronomeOn: 1,
  metronomeOnLast: 1,
  metronomeVol: 100,
  metroPrevBeat: 0,
  metroNoteOffTick: -1,
  copyHeld: false,
  copySrc: null,
  lastSoloBlink: null,
  undoAvailable: false,
  redoAvailable: false,
  undoSeqArpSnapshot: null,
  redoSeqArpSnapshot: null,
  trackMuted: new Array(8).fill(false),
  trackSoloed: new Array(8).fill(false),
  snapshots: new Array(16).fill(null),
  _origClearScreen: null,
  _wasSuspended: false,
  globalMenuOpen: false,
  globalMenuItems: null,
  globalMenuState: null,
  globalMenuStack: null,
  globalMenuBuiltForTrack: -1,
  bpmWasEditing: false,
  lastSentMenuEditValue: null,
  confirmClearSession: false,
  confirmSaveState: false,
  /* Save state Yes/No confirm dialog open */
  /* State version mismatch confirm dialog — shown when DSP detects an
   * old-format state file. Yes = wipe + clean start; No = exit module. */
  confirmStateWipe: false,
  confirmStateWipeSel: 1,
  /* 0=Yes, 1=No (default) */
  /* Keys->Drums track conversion confirm dialog (transient, not persisted). */
  confirmConvertToDrum: false,
  confirmConvertToDrumSel: 1,
  /* 0=Yes, 1=No (default) */
  confirmConvertTrack: 0,
  /* Keys->Conductor track conversion confirm dialog (transient, not persisted). */
  confirmConvertToConduct: false,
  confirmConvertToConductSel: 1,
  /* 0=Yes, 1=No (default) */
  /* Generic menu INFO dialog: array of text lines (empty = closed). Single OK
   * button; any click/Back dismisses. Set via showMenuInfo(). */
  menuInfoLines: [],
  /* Deferred track-type conversion request: {t, toDrum} or null. Drained in
   * tick() so syncClipsFromDsp's get_param round-trips run in tick context. */
  pendingTrackConvert: null,
  /* Deferred Keys/Drums->Conductor convert request: track index or null.
   * Drained in tick() so convertTrackToConduct's get_param runs in context. */
  pendingConductConvert: null,
  /* Post-convert Conductor role readback: {t, prevMode} or null. Drained in
   * tick()/poll (get_param-safe) to detect a one-Conductor refusal. */
  pendingConductReadback: null,
  /* Current Conductor track index mirror (-1 = none). */
  conductorTrack: -1,
  /* Per-Conductor-clip mirrors of the three Conductor banks, indexed
   * [clip][track]. Populated from DSP get_params on sync (Task 2.3); written
   * by the knob handlers (Task 2.4). 16 clips x 8 tracks. */
  condResp: Array.from({ length: 16 }, function() {
    return new Array(8).fill(1);
  }),
  /* responder on/off, default ON */
  condOct: Array.from({ length: 16 }, function() {
    return new Array(8).fill(0);
  }),
  /* octave offset -4..+4 */
  condWhen: Array.from({ length: 16 }, function() {
    return new Array(8).fill(0);
  }),
  /* 0=Next, 1=Now */
  /* CdLk (Conductor Lock) per-clip, indexed [clip]. 0=Off (gate-hold,
   * transposition snaps to zero in note gaps), 1=Lock (sample-and-hold,
   * transposition persists through gaps; only changes on next conductor
   * note). Lives on the Conduct bank (CLIP bank 0) at K6. */
  condLock: new Array(16).fill(0),
  /* Mirror of the Conductor track's active clip index (which clip's bank
   * values the OLED grid renders). */
  condActiveClip: 0,
  confirmBake: false,
  confirmBakeSel: 1,
  confirmBakeIsDrum: false,
  confirmBakeTrack: 0,
  confirmBakeClip: 0,
  confirmBakeDrumLoopOpen: false,
  confirmBakeDrumLoopSel: 0,
  confirmBakeDrumMode: 0,
  confirmBakeScene: false,
  confirmBakeSceneSel: 0,
  confirmBakeSceneClip: 0,
  confirmBakeSceneWrapPhase: false,
  /* mirrors clip-bake wrap phase: after loop count selected, ask wrap yes/no */
  confirmBakeSceneWrapSel: 1,
  /* 0=YES, 1=NO (default), 2=CANCEL */
  confirmBakeSceneLoops: 1,
  /* held loop count while in wrap phase */
  confirmBakeSceneWrap: 0,
  /* held wrap flag while in conductor phase */
  confirmBakeSceneCondPhase: false,
  /* after wrap: ask "Apply Conductor?" when a conductor + responders exist */
  confirmBakeSceneCondSel: 0,
  /* 0=YES, 1=NO (default highlighted via index), 2=CANCEL */
  /* Transpose-on-key/scale-change: live preview override + commit confirm.
   * xposePrevKey/Scale are null unless a preview is armed (browsing Key/Scale
   * with a candidate ≠ committed); committed key/scale stay in padKey/padScale. */
  xposePrevKey: null,
  xposePrevScale: null,
  confirmXpose: false,
  confirmXposeSel: 0,
  /* 0=YES, 1=NO */
  confirmXposeKey: 0,
  /* candidate key/scale captured at the commit click */
  confirmXposeScale: 0,
  sampleHeld: false,
  sampleUsedAsModifier: false,
  pendingSceneBakeResync: 0,
  pendingSceneBakeClip: 0,
  tapTempoOpen: false,
  tapTempoTapTimes: [],
  tapTempoBpm: 120,
  tapTempoFlashTick: -1,
  tapTempoFlashPad: -1,
  confirmClearSel: 1,
  confirmSaveSel: 1,
  /* Save state confirm: 0 = Yes, 1 = No (default) */
  confirmSaveCount: 0,
  /* snapshot count captured when Save confirm opens */
  confirmExport: false,
  /* Ableton export Yes/No dialog open */
  confirmExportSel: 1,
  /* 0 = Yes, 1 = No (default) */
  confirmExportCondPhase: false,
  /* export "Apply Conductor?" stage (after the export Yes) */
  confirmExportCondSel: 1,
  /* 0 = YES, 1 = NO (default), 2 = CANCEL */
  exportApplyConductor: false,
  /* fold the Conductor into responder clips at export time (non-destructive) */
  exportDoneDialog: false,
  /* persistent "Exported to <path>" dialog (OK to dismiss) */
  exportDonePath: "",
  /* full device path shown in the export-done dialog */
  exportDoneMissing: 0,
  /* count of samples that couldn't be bundled */
  noteSessionPressedTick: -1,
  sessionOverlayHeld: false,
  overviewCache: null,
  recordArmed: false,
  /* True between Record-press during playback and the next page boundary
   * where DSP actually flips tr->recording=1. Drives the record-button blink
   * so the user sees the deferred start. */
  recordPendingPage: false,
  recordCountingIn: false,
  mergeCountingIn: false,
  /* Live Merge count-in in progress — drives the same count-in LED flash as recordCountingIn; cleared in pollDSP when the DSP count_in flips 0 */
  recordArmedTrack: -1,
  countInStartTick: -1,
  countInBeatStartTick: -1,
  countInQuarterTicks: 0,
  countInDspPrev: false,
  playingPrev: false,
  transportStartTick: 0,
  _recNoteOns: [],
  _recNoteOffs: [],
  currentSetUuid: "",
  currentSetName: "",
  lastDspInstanceId: "",
  pendingSetLoad: false,
  pendingDspSync: 0,
  stateLoading: false,
  /* Boot splash: shown for ~2s on every fresh JS load (Move reboot or
   * full module re-launch via Shift+Back). Back-suspend → resume keeps the
   * existing module process and JS state, so the counter stays at 0 and
   * the splash does NOT re-show on resume. Decremented in tick(). */
  bootSplashTicks: 188,
  currentSplashIdx: 0,
  /* index into SPLASH_FRAMES — rerolled on each splash entry edge */
  splashWasVisible: false,
  /* previous-tick flag for splash entry-edge detection */
  pendingSuspendSave: false,
  pendingExitAfterSave: false,
  /* drained one tick after pendingSuspendSave fires; calls host_exit_module */
  pendingHideAfterSave: false,
  /* drained one tick after pendingSuspendSave fires; calls host_hide_module */
  pendingSuspendManaged: false,
  /* self-managed Back suspend: drained one tick after pendingSuspendSave fires; calls host_suspend_overtake (needs capabilities.suspend_self_managed + a host ≥ PR #165) */
  /* Self-managed Back button (module.json capabilities.suspend_self_managed). Plain Back now
   * reaches us as CC 51; we distinguish TAP (back out one UI level, resolved on release) from
   * HOLD (~BACK_HOLD_TICKS → suspend from anywhere, fired by checkBackHold() in tick). Shift+Back
   * stays a host-owned full-exit. backPressTick = tick of the current unresolved Back press
   * (-1 = none); backHoldFired = the hold already suspended, so the release must not also tap. */
  backPressTick: -1,
  backHoldFired: false,
  pendingExport: false,
  /* Ableton .ablbundle export — set by menu action, drained in tick() (get_param-safe) */
  pendingExportRun: false,
  /* phase 2 of export: armed after EXPORTING popup renders, does the blocking work */
  pendingPruneOrphans: false,
  nameIndexCache: null,
  /* { name: uuid } map, lazy-loaded on first save */
  pendingInheritPicker: null,
  /* { dstUuid, dstName, candidates: [{uuid,name}], selectedIndex } when picker is open */
  /* Snapshot picker (Save state / Load state). Self-contained modal like the
   * inherit picker. { mode:'load'|'overwrite', snaps:[{id,ts,label,sv}], sel,
   * confirm } where confirm is null or { kind:'load'|'overwrite'|'wipe',
   * sel:1(=No default), targetId, wipeIds }. */
  snapshotPicker: null,
  /* CLEAR AUTOMATION modal (Delete-tap on the AUTO bank). null = closed; else
   * { sel, at, cc } — sel 0..3 (AT/PB/CC/CLEAR), at/cc = checked-to-clear. */
  clearAutoMenu: null,
  /* Armed on Delete-press in the AUTO bank; any other input disarms it. A clean
   * Delete tap (still armed at release) opens the CLEAR AUTOMATION menu. */
  deleteTapArmed: false,
  /* Set one tick after a snapshot Save fires the DSP 'save'; the live state
   * file is on disk by then, so the copy-into-snapshot runs in tick().
   * { id, label } (id reused = overwrite). */
  pendingSnapshotCopy: null,
  pendingEditEntryTrack: -1,
  /* Shift+Step3: deferred co-run entry. -1 = none; track idx = fire on Shift release so Shift state doesn't leak into Move/Schwung */
  pendingUndoSync: 0,
  pendingDefaultSetParams: [],
  clearDrainHold: 0,
  /* clearClip sets this so the next pendingDefaultSetParams drain skips one tick — keeps the queued _clear out of the same buffer as the sync set_param fan-out from clearClip's call site */
  /* Local-edit self-resync suppression. Device-originated clip edits (copy/cut/
   * clear/row ops) bump the DSP's rui_rev — which is the browser-facing REMOTE-edit
   * signal — so pollDSP would otherwise resync the device from the DSP for an edit
   * it JUST applied to its own mirrors. For row-scope ops rui_touch marks the digest
   * FULL → syncClipsFromDsp() = ~1,540 get_params ≈ 4.3s frozen tick. When a flagged
   * (_local) editop command drains to DSP we arm localRevSuppressUntil; a rui_rev bump
   * observed within that tick window is treated as ours (adopt the rev, do only the
   * cheap automation-only re-read below), never the FULL sync. See ui_editops.mjs /
   * pollDSP. */
  localRevSuppressUntil: -1,
  /* tickCount through which a rui_rev bump is OUR own edit */
  localEditTouched: [],
  /* [{t,c}] melodic clips whose automation mirror the editop couldn't fill locally; drained by pollDSP's local-rev path (cc_auto_bits/cc_rest/at_has only — steps/len/tps are already correct from the editop) */
  pendingStepsReread: 0,
  pendingStepsRereadTrack: 0,
  pendingStepsRereadClip: 0,
  pendingChordToStep: null,
  /* pitches[] captured at step-press when pads already held */
  pendingChordPhase2: null,
  /* {t,ac,step,pitches} — set_notes after _toggle activates step */
  pendingAllLanesStretchCheck: -1,
  /* track index, -1 = none pending */
  pendingDrumResync: 0,
  pendingDrumResyncTrack: 0,
  pendingDrumLaneResync: 0,
  pendingDrumLaneResyncTrack: 0,
  pendingDrumLaneResyncLane: 0,
  extMidiRemapActive: false,
  /* Cable-2 remap change-detect edge (was module-scope `var _lastRemap*` in
   * ui.js; hoisted onto S in phase 6b so both init() and the tick-moved
   * applyExtMidiRemap edge-check can reach it). NOT serialized — absent
   * from writeSidecar's whitelist by design, recomputed fresh every init. */
  lastRemapTrack: -1,
  lastRemapRoute: -1,
  lastRemapChannel: -1,
  lastRemapMidiIn: -2,
  lastTarpStyle: new Array(8).fill(1),
  padLayoutChromatic: new Array(8).fill(false),
  drumInpQuant: new Array(8).fill(0),
  /* per-track drum input quantize index 0-8 */
  delayClockFb: new Array(8).fill(0),
  /* per-track delay clock feedback -100..100, accessed via Shift+K1 on DELAY bank (K7 now hosts delay_retrig) */
  delayRetrig: new Array(8).fill(0),
  /* per-track delay retrig 0/1; K7 on DELAY bank */
  clipAdaptiveMode: Array.from({ length: 8 }, () => new Array(16).fill(false)),
  clipLengthManuallySet: Array.from({ length: 8 }, () => new Array(16).fill(false)),
  drumLaneLengthManuallySet: new Array(8).fill(false),
  recordScheduledStop: false,
  recordScheduledStopTarget: -1,
  pendingScheduledDisarm: false,
  pendingPrerollNote: null,
  /* drum only: { track, lane, laneNote, vel, pressedAtTick, countInStart } */
  pendingPrerollNotes: [],
  /* melodic chord: [{track, clip, pitch, vel, pressedAtTick, countInStart, releasedAtTick?}] */
  pendingPrerollToggleQueue: [],
  /* remaining chord notes queued for step_0_toggle, one per tick */
  pendingPrerollGate: null,
  /* { isDrum, track, lane/clip, gate } — sent the tick after last _step_0_toggle */
  pendingClearLengthTrack: -1,
  /* deferred length-reset after clip clear (avoids coalescing with clear cmd) */
  pendingClearLengthClip: -1,
  sessionViewMomentary: false,
  /* true while NoteSession is held and switched view temporarily */
  sessionStepHeld: -1,
  /* step button (0-15) held in session view awaiting tap/hold decision */
  sessionStepHeldCtx: 0,
  /* 1=perf preset, 2=mute snapshot */
  stepSaveFlashStartTick: -1,
  /* tick when hold-save flash began */
  stepSaveFlashEndTick: -1,
  /* step button LEDs double-blink through this tick after save */
  drumHeldReadPending: false,
  /* occupied drum step held: real vel/gate/etc. read deferred to tick (get_param null in MIDI context) */
  bpmMirror: 120
  /* tempo mirror refreshed in pollDSP (tick context) — MIDI handlers read this, not get_param */
};

// ui/ui_pure.mjs
var SCALE_INTERVALS = [
  [0, 2, 4, 5, 7, 9, 11],
  /*  0 Major           */
  [0, 2, 3, 5, 7, 8, 10],
  /*  1 Minor           */
  [0, 2, 3, 5, 7, 9, 10],
  /*  2 Dorian          */
  [0, 1, 3, 5, 7, 8, 10],
  /*  3 Phrygian        */
  [0, 2, 4, 6, 7, 9, 11],
  /*  4 Lydian          */
  [0, 2, 4, 5, 7, 9, 10],
  /*  5 Mixolydian      */
  [0, 1, 3, 5, 6, 8, 10],
  /*  6 Locrian         */
  [0, 2, 3, 5, 7, 8, 11],
  /*  7 Harmonic Minor  */
  [0, 2, 3, 5, 7, 9, 11],
  /*  8 Melodic Minor   */
  [0, 2, 4, 7, 9],
  /*  9 Pentatonic Major*/
  [0, 3, 5, 7, 10],
  /* 10 Pentatonic Minor*/
  [0, 3, 5, 6, 7, 10],
  /* 11 Blues           */
  [0, 2, 4, 6, 8, 10],
  /* 12 Whole Tone      */
  [0, 2, 3, 5, 6, 8, 9, 11]
  /* 13 Diminished      */
];
var BANK_CYCLE_DRUM = [7, 0, 1, 3, 5, 6];
var CONDUCT_BANK_CYCLE = [0, 1, BANK_RESPONDER, BANK_OCTAVE, BANK_WHEN];
function bankCyclePos() {
  if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
    const i = BANK_CYCLE_DRUM.indexOf(S.activeBank);
    return { idx: i < 0 ? 0 : i, count: BANK_CYCLE_DRUM.length };
  }
  if (S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT) {
    const i = CONDUCT_BANK_CYCLE.indexOf(S.activeBank);
    return { idx: i < 0 ? 0 : i, count: CONDUCT_BANK_CYCLE.length };
  }
  return { idx: Math.max(0, Math.min(6, S.activeBank)), count: 7 };
}
function scaleNudgeNote(note, dir, key, scale) {
  if (!S.scaleAware) return Math.max(0, Math.min(127, note + dir));
  const ivls = SCALE_INTERVALS[scale];
  let candidate = note + dir;
  while (candidate >= 0 && candidate <= 127) {
    const pc = ((candidate - key) % 12 + 12) % 12;
    if (ivls.indexOf(pc) >= 0) return candidate;
    candidate += dir;
  }
  return Math.max(0, Math.min(127, note + dir));
}
function _clipIsEmpty(t, c) {
  return S.trackPadMode[t] === PAD_MODE_DRUM ? !S.drumClipNonEmpty[t][c] : !S.clipNonEmpty[t][c];
}
function clipHasContent(t, c) {
  const s = S.clipSteps[t][c];
  for (let i = 0; i < NUM_STEPS; i++) if (s[i]) return true;
  return false;
}
function drumPadToLane(padIdx) {
  const col = padIdx % 8;
  if (col >= 4) return -1;
  const row = Math.floor(padIdx / 8);
  return S.drumLanePage[S.activeTrack] * 16 + row * 4 + col;
}
function drumPadToVelZone(padIdx) {
  const col = padIdx % 8;
  if (col < 4) return -1;
  const row = Math.floor(padIdx / 8);
  return row * 4 + (col - 4);
}
function drumVelZoneToVelocity(zone) {
  return Math.round((zone + 1) * 127 / 16);
}
function effectiveVelocity(rawVel) {
  return rawVel;
}
function stepEntryVelocity(t, liveVel, allowZone) {
  if (allowZone) {
    if (liveVel >= 0) return liveVel;
    if (S.drumVelZoneArmed && S.drumVelZoneArmed[t])
      return drumVelZoneToVelocity(S.drumLastVelZone[t]);
    const tvo2 = S.trackVelOverride[t];
    if (tvo2 > 0) return tvo2;
    return 100;
  }
  const tvo = S.trackVelOverride[t];
  if (tvo > 0) return tvo;
  if (liveVel >= 0) return liveVel;
  return 100;
}
var ARP_VEL_CANON = [0, 32, 64, 96, 127];
var VEL_THRU = 255;
function arpVelLevel(v) {
  v = v | 0;
  if (v <= 0) return 0;
  if (v >= 128) return 4;
  return Math.min(4, 1 + ((v - 1) * 4 >> 7));
}

// ui/ui_persistence.mjs
function uuidToStatePath(uuid) {
  return uuid ? "/data/UserData/schwung/set_state/" + uuid + "/seq8-state.json" : "/data/UserData/schwung/seq8-state.json";
}
function uuidToUiStatePath(uuid) {
  return uuid ? "/data/UserData/schwung/set_state/" + uuid + "/seq8-ui-state.json" : "/data/UserData/schwung/seq8-ui-state.json";
}
var NAME_INDEX_PATH = "/data/UserData/schwung/seq8_name_index.json";
var SET_STATE_DIR = "/data/UserData/schwung/set_state";
var ACTIVE_SET_PATH = "/data/UserData/schwung/active_set.txt";
function readActiveSet() {
  if (typeof host_read_file !== "function") return { uuid: "", name: "" };
  try {
    const raw = host_read_file(ACTIVE_SET_PATH);
    if (!raw) return { uuid: "", name: "" };
    const lines = raw.split("\n");
    return {
      uuid: (lines[0] || "").trim(),
      name: (lines[1] || "").trim()
    };
  } catch (e) {
    return { uuid: "", name: "" };
  }
}
function stripCopySuffix(name) {
  const m = (name || "").match(/^(.*?)\s+Copy(?:\s+\d+)?\s*$/);
  return m ? m[1].trimEnd() : null;
}
function loadNameIndex() {
  if (typeof host_read_file !== "function") return {};
  if (typeof host_file_exists === "function" && !host_file_exists(NAME_INDEX_PATH))
    return {};
  try {
    const raw = host_read_file(NAME_INDEX_PATH);
    if (!raw) return {};
    const obj = JSON.parse(raw);
    return obj && typeof obj === "object" ? obj : {};
  } catch (e) {
    return {};
  }
}
function saveNameIndex(idx) {
  if (typeof host_write_file !== "function") return false;
  return host_write_file(NAME_INDEX_PATH, JSON.stringify(idx));
}
function updateNameIndex() {
  if (!S.currentSetUuid || !S.currentSetName) return;
  if (!S.nameIndexCache) S.nameIndexCache = loadNameIndex();
  if (S.nameIndexCache[S.currentSetName] === S.currentSetUuid) return;
  S.nameIndexCache[S.currentSetName] = S.currentSetUuid;
  saveNameIndex(S.nameIndexCache);
}
function copyStateFiles(srcUuid, dstUuid) {
  if (!srcUuid || !dstUuid) return false;
  if (typeof host_read_file !== "function" || typeof host_write_file !== "function")
    return false;
  if (typeof host_file_exists !== "function") return false;
  const srcSt = uuidToStatePath(srcUuid);
  if (!host_file_exists(srcSt)) return false;
  if (typeof host_ensure_dir === "function")
    host_ensure_dir(SET_STATE_DIR + "/" + dstUuid);
  const stContents = host_read_file(srcSt);
  if (!stContents) return false;
  host_write_file(uuidToStatePath(dstUuid), stContents);
  const srcUi = uuidToUiStatePath(srcUuid);
  if (host_file_exists(srcUi)) {
    const uiContents = host_read_file(srcUi);
    if (uiContents) host_write_file(uuidToUiStatePath(dstUuid), uiContents);
  }
  return true;
}
function escapeForRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
var SETS_BASE_DIR = "/data/UserData/UserLibrary/Sets";
function findInheritCandidates(currentName, idx) {
  const base = stripCopySuffix(currentName);
  if (!base) return [];
  if (typeof host_file_exists !== "function") return [];
  const famRe = new RegExp("^" + escapeForRegex(base) + "(?:\\s+Copy(?:\\s+\\d+)?)?$");
  const out = [];
  for (const name in idx) {
    if (name === currentName) continue;
    if (!famRe.test(name)) continue;
    const uuid = idx[name];
    if (!uuid) continue;
    if (!host_file_exists(uuidToStatePath(uuid))) continue;
    if (!host_file_exists(SETS_BASE_DIR + "/" + uuid)) continue;
    out.push({ uuid, name });
  }
  out.sort(function(a, b) {
    if (a.name === base) return -1;
    if (b.name === base) return 1;
    if (a.name.length !== b.name.length) return a.name.length - b.name.length;
    return a.name < b.name ? -1 : a.name > b.name ? 1 : 0;
  });
  return out;
}
function maybeShowInheritPicker(uuid, name) {
  if (!uuid || !name) return "blank";
  if (typeof host_file_exists !== "function") return "blank";
  if (host_file_exists(uuidToStatePath(uuid))) return "blank";
  const idx = S.nameIndexCache || (S.nameIndexCache = loadNameIndex());
  const candidates = findInheritCandidates(name, idx);
  if (candidates.length === 0) return "blank";
  if (candidates.length === 1) {
    copyStateFiles(candidates[0].uuid, uuid);
    return "auto";
  }
  S.pendingInheritPicker = {
    dstUuid: uuid,
    dstName: name,
    candidates,
    selectedIndex: 0
  };
  S.screenDirty = true;
  return "picker";
}
function showActionPopup(...lines) {
  S.actionPopupHighlight = -1;
  S.actionPopupLines = lines;
  S.actionPopupEndTick = S.tickCount + ACTION_POPUP_TICKS;
  S.screenDirty = true;
}
function writeSidecar() {
  S.trackActiveBank[S.activeTrack] = S.activeBank;
  if (typeof host_write_file === "function")
    host_write_file(uuidToUiStatePath(S.currentSetUuid), JSON.stringify({
      v: 9,
      at: S.activeTrack,
      ac: S.trackActiveClip.slice(),
      sv: S.sessionView ? 1 : 0,
      dl: S.activeDrumLane.slice(),
      pm: S.perfModsToggled,
      lm: S.perfLatchMode ? 1 : 0,
      rs: S.perfRecalledSlot,
      us: S.perfSnapshots.slice(8),
      bm: S.beatMarkersEnabled ? 1 : 0,
      dva: S.drumVelZoneArmed.slice(),
      dleu: S.drumLaneEuclidN.map(function(lane) {
        return lane.slice();
      }),
      to: S.trackOctave.slice(),
      tab: S.trackActiveBank.slice(),
      am: S.trackAtMode.slice(),
      pchr: S.padLayoutChromatic.map(function(b) {
        return b ? 1 : 0;
      })
    }));
}
function saveState() {
  S.altMode = false;
  S.pendingSuspendSave = true;
  writeSidecar();
}
var SNAPSHOT_CAP = 16;
var SNAP_MANIFEST_VER = 1;
function snapBaseDir(uuid) {
  return uuid ? SET_STATE_DIR + "/" + uuid : "/data/UserData/schwung";
}
function snapManifestPath(uuid) {
  return snapBaseDir(uuid) + "/seq8-snap-index.json";
}
function snapStatePath(uuid, id) {
  return snapBaseDir(uuid) + "/seq8-snap-" + id + "-state.json";
}
function snapUiStatePath(uuid, id) {
  return snapBaseDir(uuid) + "/seq8-snap-" + id + "-ui-state.json";
}
function snapshotLabel(d) {
  d = d || /* @__PURE__ */ new Date();
  function p2(n) {
    return n < 10 ? "0" + n : "" + n;
  }
  return p2(d.getMonth() + 1) + "-" + p2(d.getDate()) + " " + p2(d.getHours()) + ":" + p2(d.getMinutes());
}
function parseStateVersion(raw) {
  try {
    const o = JSON.parse(raw);
    return o && typeof o.v === "number" ? o.v : 0;
  } catch (e) {
    return 0;
  }
}
function loadSnapshotManifest(uuid) {
  if (typeof host_read_file !== "function") return [];
  const p2 = snapManifestPath(uuid);
  if (typeof host_file_exists === "function" && !host_file_exists(p2)) return [];
  try {
    const obj = JSON.parse(host_read_file(p2) || "");
    const arr = obj && Array.isArray(obj.snaps) ? obj.snaps : [];
    arr.sort(function(a, b) {
      return (b.ts || 0) - (a.ts || 0);
    });
    return arr;
  } catch (e) {
    return [];
  }
}
function writeSnapshotManifest(uuid, snaps) {
  if (typeof host_write_file !== "function") return false;
  return host_write_file(
    snapManifestPath(uuid),
    JSON.stringify({ v: SNAP_MANIFEST_VER, snaps })
  );
}
function commitSnapshot(uuid, id, label) {
  if (typeof host_read_file !== "function" || typeof host_write_file !== "function")
    return false;
  const srcSt = uuidToStatePath(uuid);
  if (typeof host_file_exists === "function" && !host_file_exists(srcSt)) return false;
  const stContents = host_read_file(srcSt);
  if (!stContents) return false;
  host_write_file(snapStatePath(uuid, id), stContents);
  const srcUi = uuidToUiStatePath(uuid);
  if (typeof host_file_exists === "function" && host_file_exists(srcUi)) {
    const uiContents = host_read_file(srcUi);
    if (uiContents) host_write_file(snapUiStatePath(uuid, id), uiContents);
  }
  let snaps = loadSnapshotManifest(uuid).filter(function(s) {
    return s.id !== id;
  });
  snaps.unshift({
    id,
    ts: Date.now(),
    label,
    sv: parseStateVersion(stContents)
  });
  writeSnapshotManifest(uuid, snaps);
  return true;
}
function applySnapshotToLive(uuid, id) {
  if (typeof host_read_file !== "function" || typeof host_write_file !== "function")
    return false;
  const snSt = snapStatePath(uuid, id);
  if (typeof host_file_exists === "function" && !host_file_exists(snSt)) return false;
  const stContents = host_read_file(snSt);
  if (!stContents) return false;
  host_write_file(uuidToStatePath(uuid), stContents);
  const snUi = snapUiStatePath(uuid, id);
  if (typeof host_file_exists === "function" && host_file_exists(snUi)) {
    const uiContents = host_read_file(snUi);
    if (uiContents) host_write_file(uuidToUiStatePath(uuid), uiContents);
  }
  return true;
}
function dropSnapshots(uuid, ids) {
  const idset = {};
  for (let i = 0; i < ids.length; i++) idset[ids[i]] = true;
  if (typeof host_write_file === "function") {
    for (let i = 0; i < ids.length; i++) {
      host_write_file(snapStatePath(uuid, ids[i]), "{}");
      host_write_file(snapUiStatePath(uuid, ids[i]), "{}");
    }
  }
  const snaps = loadSnapshotManifest(uuid).filter(function(s) {
    return !idset[s.id];
  });
  writeSnapshotManifest(uuid, snaps);
  return snaps;
}
function doClearSession() {
  const sp = uuidToStatePath(S.currentSetUuid);
  if (typeof host_write_file === "function") host_write_file(sp, '{"v":0}');
  if (typeof host_write_file === "function") host_write_file(uuidToUiStatePath(S.currentSetUuid), '{"v":0}');
  S.activeBank = 0;
  for (let _t = 0; _t < NUM_TRACKS; _t++) S.trackActiveBank[_t] = 0;
  S.undoSeqArpSnapshot = null;
  S.redoSeqArpSnapshot = null;
  for (let _t = 0; _t < NUM_TRACKS; _t++) {
    for (let _c = 0; _c < NUM_CLIPS; _c++) S.clipSeqFollow[_t][_c] = true;
    S.trackChannel[_t] = 1;
    S.trackRoute[_t] = 0;
    S.trackPadMode[_t] = 0;
    S.trackVelOverride[_t] = 0;
    S.trackLooper[_t] = 1;
    S.trackOctave[_t] = 0;
    S.drumVelZoneArmed[_t] = false;
    S.trackCCAssign[_t] = CC_ASSIGN_DEFAULTS.slice();
    S.trackCCType[_t] = new Array(8).fill(0);
    S.clipCCVal[_t] = Array.from({ length: NUM_CLIPS }, () => new Array(8).fill(-1));
    S.trackCCAutoBits[_t] = new Array(NUM_CLIPS).fill(0);
    S.trackCCLiveVal[_t] = new Array(8).fill(-1);
    S.ccActiveLane[_t] = 0;
    for (var _c2 = 0; _c2 < NUM_CLIPS; _c2++)
      for (var _k = 0; _k < 8; _k++) {
        S.ccLaneLoopStart[_t][_c2][_k] = 0;
        S.ccLaneLength[_t][_c2][_k] = 0;
        S.ccLaneTps[_t][_c2][_k] = 0;
      }
    for (let _b = 3; _b <= 4; _b++) {
      for (let _k2 = 0; _k2 < 8; _k2++) {
        const _pm = BANKS[_b].knobs[_k2];
        S.bankParams[_t][_b][_k2] = _pm ? _pm.def : 0;
      }
    }
    S.drumPerformMode[_t] = 0;
    S.drumRepeatHeldPad[_t] = -1;
    S.drumRepeatLatched[_t] = false;
    S.drumRepeat2HeldLanes[_t].clear();
    S.drumRepeat2LatchedLanes[_t].clear();
    for (let _l = 0; _l < DRUM_LANES; _l++) S.drumRepeat2RatePerLane[_t][_l] = 0;
    for (let _l = 0; _l < DRUM_LANES; _l++) S.drumLaneEuclidN[_t][_l] = 0;
    for (let _l = 0; _l < DRUM_LANES; _l++) {
      S.drumRepeatGate[_t][_l] = 255;
      for (let _s = 0; _s < 8; _s++) {
        S.drumRepeatVelScale[_t][_l][_s] = 100;
        S.drumRepeatNudge[_t][_l][_s] = 0;
      }
    }
    S.trackAtMode[_t] = 0;
    S.trackMuted[_t] = false;
    S.trackSoloed[_t] = false;
    S.drumLaneMute[_t] = 0;
    S.drumLaneSolo[_t] = 0;
    S.noteFXRandomMode[_t] = 2;
    S.midiDlyRandomMode[_t] = 2;
    S.lastTarpStyle[_t] = 1;
    S.clipAdaptiveMode[_t] = new Array(NUM_CLIPS).fill(false);
    S.clipLengthManuallySet[_t] = new Array(NUM_CLIPS).fill(false);
    S.drumLaneLengthManuallySet[_t] = false;
  }
  S.sessionView = false;
  S.beatMarkersEnabled = true;
  S.perfModsToggled = 0;
  S.perfLatchMode = true;
  S.perfRecalledSlot = -1;
  for (let _i = 8; _i < 16; _i++) S.perfSnapshots[_i] = 0;
  S.swingAmt = 0;
  S.swingRes = 0;
  S.launchQuant = 0;
  S.midiInChannel = 0;
  S.metronomeOn = 1;
  S.inpQuant = false;
  S.pendingSetLoad = true;
  S.globalMenuOpen = false;
  S.confirmClearSession = false;
  showActionPopup("SESSION", "CLEARED");
}

// ui/ui_dialogs.mjs
import {
  drawMenuHeader,
  drawMenuList,
  menuLayoutDefaults
} from "/data/UserData/schwung/shared/menu_layout.mjs";
import { formatItemValue } from "/data/UserData/schwung/shared/menu_items.mjs";

// ui/ui_scene.mjs
import { White, VividYellow, DarkGrey } from "/data/UserData/schwung/shared/constants.mjs";
import { setLED } from "/data/UserData/schwung/shared/input_filter.mjs";
function trackClipHasContent(t, sceneIdx) {
  return S.trackPadMode[t] === PAD_MODE_DRUM ? S.drumClipNonEmpty[t][sceneIdx] : S.clipNonEmpty[t][sceneIdx];
}
function sceneNonEmpty(sceneIdx) {
  for (let t = 0; t < NUM_TRACKS; t++)
    if (trackClipHasContent(t, sceneIdx)) return true;
  return false;
}
function sceneAllQueued(sceneIdx) {
  let hasAny = false;
  for (let t = 0; t < NUM_TRACKS; t++) {
    if (!trackClipHasContent(t, sceneIdx)) continue;
    hasAny = true;
    const isQueued = S.trackQueuedClip[t] === sceneIdx || S.trackPendingPageStop[t] && S.trackActiveClip[t] === sceneIdx;
    if (!isQueued) return false;
  }
  return hasAny;
}
function updateSceneMapLEDs() {
  if (!S.ledInitComplete) return;
  for (let i = 0; i < 16; i++) {
    let color;
    if (S.muteHeld && S.sessionView) {
      color = S.snapshots[i] !== null ? VividYellow : DarkGrey;
    } else {
      const inView = i >= S.sceneRow && i < S.sceneRow + 4;
      const anyPlaying = S.cachedSceneAnyPlaying[i];
      if (inView && anyPlaying) {
        color = S.flashEighth ? LED_STEP_CURSOR : LED_OFF;
      } else if (inView) {
        color = LED_STEP_CURSOR;
      } else if (anyPlaying) {
        color = S.flashEighth ? White : LED_OFF;
      } else if (sceneNonEmpty(i)) {
        color = White;
      } else {
        color = LED_OFF;
      }
    }
    setLED(16 + i, color);
  }
}

// ui/ui_leds.mjs
import {
  White as White2,
  Red as Red2,
  Green as Green2,
  Blue as Blue2,
  DarkBlue as DarkBlue2,
  LightGrey,
  DarkGrey as DarkGrey2,
  Cyan,
  PurpleBlue,
  VividYellow as VividYellow2,
  DeepRed,
  DeepGreen as DeepGreen2,
  DeepMagenta,
  Mustard as Mustard2
} from "/data/UserData/schwung/shared/constants.mjs";
import { setLED as setLED2, setButtonLED } from "/data/UserData/schwung/shared/input_filter.mjs";
var lastSentNoteLED = new Array(128).fill(-1);
var lastSentButtonLED = new Array(128).fill(-1);
function effectiveClip(t) {
  const qc = S.trackQueuedClip[t];
  return !S.playing && qc >= 0 ? qc : S.trackActiveClip[t];
}
function effectiveDrumMute(t, l) {
  const bit = 1 << l;
  if (S.drumLaneMute[t] & bit) return true;
  if (S.drumLaneSolo[t] && !(S.drumLaneSolo[t] & bit)) return true;
  return false;
}
function cachedSetLED(note, color) {
  if (lastSentNoteLED[note] === color) return;
  lastSentNoteLED[note] = color;
  setLED2(note, color);
}
function cachedSetButtonLED(cc, color) {
  if (lastSentButtonLED[cc] === color) return;
  lastSentButtonLED[cc] = color;
  setButtonLED(cc, color);
}
function invalidateLEDCache() {
  lastSentNoteLED.fill(-1);
  lastSentButtonLED.fill(-1);
}
function trackColor(t) {
  return TRACK_COLORS[t];
}
function trackDimColor(t) {
  return TRACK_DIM_COLORS[t];
}
function paintCoRunSideButtons(litMask, force) {
  const blinkOn = Math.floor(Date.now() / 250) % 2 === 1;
  for (let i = 0; i < 4; i++) {
    const lit = litMask >> i & 1;
    setButtonLED(43 - i, lit ? blinkOn ? LightGrey : DarkGrey2 : DarkGrey2, force);
  }
}
function updateStepLEDs() {
  if (!S.ledInitComplete) return;
  if (S.schwungCoRunSlot >= 0 || S.moveCoRunTrack >= 0) {
    const _blinkOn = Math.floor(Date.now() / 250) % 2 === 1;
    const _force = S.tickCount % POLL_INTERVAL === 0;
    for (let i = 0; i < 16; i++) {
      setLED2(16 + i, i === 2 ? _blinkOn ? White2 : DarkGrey2 : LED_OFF, _force);
    }
    return;
  }
  const ac = effectiveClip(S.activeTrack);
  if (S.loopHeld && !S.loopJogActive && !(S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 7 && !S.allLanesConfirmed)) {
    const t = S.activeTrack;
    const tCol = trackColor(t);
    const pulsOn = S.playing ? S.flashSixteenth : Math.floor(S.tickCount / 24) % 2;
    const gestureHeldPage = S.loopGestureStart >= 0 && S.loopGestureTrack === t ? S.loopGestureStart : -1;
    if (S.trackPadMode[t] === PAD_MODE_DRUM && S.activeBank !== 6) {
      const lane = S.activeDrumLane[t];
      const len2 = S.drumLaneLength[t];
      const lsBase2 = S.drumLaneLoopStart[t] | 0;
      const ls = S.drumLaneSteps[t][lane];
      const startPage = lsBase2 >> 4;
      const endPage = startPage + Math.ceil(len2 / 16) - 1;
      for (let p2 = 0; p2 < 16; p2++) {
        let color;
        if (p2 === gestureHeldPage) {
          color = White2;
        } else if (p2 < startPage || p2 > endPage) {
          color = LED_OFF;
        } else {
          const base2 = p2 * 16;
          const end = Math.min(base2 + 16, lsBase2 + len2);
          let hasNotes = false;
          for (let s = base2; s < end; s++) {
            if (ls[s] !== "0") {
              hasNotes = true;
              break;
            }
          }
          color = hasNotes ? pulsOn ? tCol : LED_OFF : tCol;
        }
        setLED2(16 + p2, color);
      }
    } else {
      var _ccLen = 0, _ccLs = 0;
      if (S.activeBank === 6) {
        var _ccL = S.ccActiveLane[t];
        _ccLen = S.ccLaneLength[t][ac][_ccL];
        _ccLs = S.ccLaneLoopStart[t][ac][_ccL] | 0;
      }
      const len2 = _ccLen > 0 ? _ccLen : S.clipLength[t][ac];
      const lsBase2 = _ccLen > 0 ? _ccLs : S.clipLoopStart[t][ac] | 0;
      const steps2 = S.clipSteps[t][ac];
      const startPage = lsBase2 >> 4;
      const endPage = startPage + Math.ceil(len2 / 16) - 1;
      for (let p2 = 0; p2 < 16; p2++) {
        let color;
        if (p2 === gestureHeldPage) {
          color = White2;
        } else if (p2 < startPage || p2 > endPage) {
          color = LED_OFF;
        } else {
          const base2 = p2 * 16;
          const end = Math.min(base2 + 16, lsBase2 + len2);
          let hasNotes = false;
          for (let s = base2; s < end; s++) {
            if (steps2[s] !== 0) {
              hasNotes = true;
              break;
            }
          }
          color = hasNotes ? pulsOn ? tCol : LED_OFF : tCol;
        }
        setLED2(16 + p2, color);
      }
    }
    return;
  }
  const _compoundHeld = S.muteHeld || S.deleteHeld || S.copyHeld || S.loopHeld;
  if (S.shiftHeld && !_compoundHeld) {
    const _kt = S.knobTouched;
    const _knobShiftMode = S.activeBank === 0 && (_kt === 1 || _kt === 2) || S.activeBank === 7 && _kt === 1;
    if (!_knobShiftMode) {
      const isDrum = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM;
      const _allLanesLocked = isDrum && S.activeBank === 7 && !S.allLanesConfirmed;
      for (let i = 0; i < 16; i++) {
        let on = i === 1 || i === 2 || i >= 4 && i <= 6 || i === 8;
        if (i === 7 || i === 9 || i === 10 && !isDrum || i === 14 || i === 15 && S.activeBank !== 6) on = true;
        if (_allLanesLocked && (i === 14 || i === 15)) on = false;
        setLED2(16 + i, on ? LightGrey : LED_OFF);
      }
      return;
    }
  }
  if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank !== 6) {
    const t = S.activeTrack;
    const lane = S.activeDrumLane[t];
    const ls = S.drumLaneSteps[t][lane];
    const cs2 = S.drumCurrentStep[t];
    const page2 = S.drumStepPage[t];
    const base2 = page2 * 16;
    const len2 = S.drumLaneLength[t];
    const lsBase2 = S.drumLaneLoopStart[t] | 0;
    const winEnd2 = lsBase2 + len2;
    for (let i = 0; i < 16; i++) {
      const absStep = base2 + i;
      let color;
      if (absStep < lsBase2 || absStep >= winEnd2) color = DarkGrey2;
      else if (S.playing && absStep === cs2) color = White2;
      else if (ls[absStep] === "1") color = trackColor(t);
      else color = S.beatMarkersEnabled && i % 4 === 0 ? trackDimColor(t) : LED_OFF;
      setLED2(16 + i, color);
    }
    if (S.heldStep >= 0 && S.heldStepNotes.length > 0) {
      const _sTps = S.drumLaneTPS[t] || 24;
      const _sSpan = Math.ceil(S.stepEditGate / _sTps);
      for (let i = 0; i < 16; i++) {
        const absStep = base2 + i;
        if (absStep < lsBase2 || absStep >= winEnd2) continue;
        const offset = (absStep - S.heldStep + len2) % len2;
        if (offset < _sSpan) setLED2(16 + i, 56);
      }
    }
    if (S.heldStep >= 0 && S.knobTouched === 0 && S.heldStepNotes.length > 0) {
      const _dTps = S.drumLaneTPS[t] || 24;
      const _fullSteps = Math.floor(S.stepEditGate / _dTps);
      const _partTicks = S.stepEditGate % _dTps;
      for (let i = 0; i < 16; i++) {
        const absStep = base2 + i;
        if (absStep < lsBase2 || absStep >= winEnd2) continue;
        const offset = (absStep - S.heldStep + len2) % len2;
        if (offset < _fullSteps) {
          setLED2(16 + i, White2);
        } else if (offset === _fullSteps && _partTicks > 0) {
          setLED2(16 + i, DarkGrey2);
        }
      }
    }
    if (S.copyHeld && S.copySrc && (S.copySrc.kind === "step" || S.copySrc.kind === "cut_step") && Math.floor(S.copySrc.absStep / 16) === page2) {
      const btnIdx = S.copySrc.absStep % 16;
      setLED2(16 + btnIdx, Math.floor(S.tickCount / 24) % 2 ? White2 : LED_OFF);
    }
    return;
  }
  if (S.activeBank === 6) {
    const CC_GRAD = [76, 29, 29, 3, 4, 67, 127];
    const t = S.activeTrack;
    const c = ac;
    const lane = S.ccActiveLane[t] | 0;
    const pg = S.trackCurrentPage[t];
    const csCC = S.trackCurrentStep[t];
    var _ccLenCC = S.ccLaneLength[t][c][lane];
    var _ccLsCC = _ccLenCC > 0 ? S.ccLaneLoopStart[t][c][lane] | 0 : S.clipLoopStart[t][c] | 0;
    var _ccWinEnd = _ccLsCC + (_ccLenCC > 0 ? _ccLenCC : S.clipLength[t][c]);
    var _ccPlayStep = -1;
    if (S.playing) {
      var _dispTps = S.ccLaneTps[t][c][lane] || (S.clipTPS[t][c] || 24);
      var _speedTps = S.ccLaneResTps[t][c][lane] || _dispTps;
      var _effLen = _ccLenCC > 0 ? _ccLenCC : S.clipLength[t][c];
      var _lLenTicks = _effLen * _speedTps;
      var _lTickPos = S.masterPos % _lLenTicks;
      var _progress = _lTickPos / _lLenTicks;
      _ccPlayStep = _ccLsCC + Math.floor(_progress * _effLen);
    }
    const key = t + "_" + c + "_" + lane + "_" + pg;
    if (key !== S.ccGradKey || S.tickCount % POLL_INTERVAL === 0) {
      var raw = typeof host_module_get_param === "function" ? host_module_get_param("t" + t + "_c" + c + "_ccsv_" + lane + "_" + pg) : null;
      if (raw) {
        var parts = raw.split(" ");
        for (let s = 0; s < 16; s++) {
          var v = s < parts.length ? parseInt(parts[s], 10) : 255;
          S.ccGradVals[s] = v >= 0 && v <= 127 ? v : 255;
        }
      }
      var bpRaw = typeof host_module_get_param === "function" ? host_module_get_param("t" + t + "_c" + c + "_ccbp_" + lane + "_" + pg) : null;
      if (bpRaw) {
        var bpParts = bpRaw.split(" ");
        for (let s = 0; s < 16; s++)
          S.ccGradHasBP[s] = s < bpParts.length ? bpParts[s] === "1" : false;
      } else {
        for (let s = 0; s < 16; s++) S.ccGradHasBP[s] = false;
      }
      S.ccGradKey = key;
    }
    const _blip = S.tickCount % 47 < 4;
    const baseCC = pg * 16;
    for (let i = 0; i < 16; i++) {
      const absStep = baseCC + i;
      let color;
      if (absStep < _ccLsCC || absStep >= _ccWinEnd) {
        color = DarkGrey2;
      } else if (absStep === _ccPlayStep) {
        color = White2;
      } else {
        const v2 = S.ccGradVals[i];
        if (v2 >= 0 && v2 <= 127) {
          if (_blip && S.ccGradHasBP[i]) {
            color = LED_OFF;
          } else {
            const level = v2 === 0 ? 0 : Math.min(6, 1 + Math.floor((v2 - 1) * 6 / 127));
            color = CC_GRAD[level];
          }
        } else {
          color = LED_OFF;
        }
      }
      setLED2(16 + i, color);
    }
    return;
  }
  const steps = S.clipSteps[S.activeTrack][ac];
  const cs = S.trackCurrentStep[S.activeTrack];
  const page = S.trackCurrentPage[S.activeTrack];
  const base = page * 16;
  const len = S.clipLength[S.activeTrack][ac];
  const lsBase = S.clipLoopStart[S.activeTrack][ac] | 0;
  const winEnd = lsBase + len;
  for (let i = 0; i < 16; i++) {
    const absStep = base + i;
    let color;
    if (absStep < lsBase || absStep >= winEnd) {
      color = DarkGrey2;
    } else if (S.playing && absStep === cs) {
      color = White2;
    } else if (steps[absStep] === 1) {
      color = trackColor(S.activeTrack);
    } else {
      color = S.beatMarkersEnabled && i % 4 === 0 ? trackDimColor(S.activeTrack) : LED_OFF;
    }
    setLED2(16 + i, color);
  }
  if (S.heldStep >= 0 && S.heldStepNotes.length > 0) {
    const _spanTps = S.clipTPS[S.activeTrack][effectiveClip(S.activeTrack)] || 24;
    const spanSteps = Math.ceil(S.stepEditGate / _spanTps);
    for (let i = 0; i < 16; i++) {
      const absStep = base + i;
      if (absStep < lsBase || absStep >= winEnd) continue;
      const offset = (absStep - S.heldStep + len) % len;
      if (offset < spanSteps) setLED2(16 + i, 56);
    }
  }
  if (S.heldStep >= 0 && S.knobTouched === 2 && S.heldStepNotes.length > 0) {
    const _acTps = S.clipTPS[S.activeTrack][effectiveClip(S.activeTrack)] || 24;
    const fullSteps = Math.floor(S.stepEditGate / _acTps);
    const partialTicks = S.stepEditGate % _acTps;
    for (let i = 0; i < 16; i++) {
      const absStep = base + i;
      if (absStep < lsBase || absStep >= winEnd) continue;
      const offset = (absStep - S.heldStep + len) % len;
      if (offset < fullSteps) {
        setLED2(16 + i, White2);
      } else if (offset === fullSteps && partialTicks > 0) {
        setLED2(16 + i, DarkGrey2);
      }
    }
  }
  if (S.copyHeld && S.copySrc && (S.copySrc.kind === "step" || S.copySrc.kind === "cut_step") && Math.floor(S.copySrc.absStep / 16) === page) {
    const btnIdx = S.copySrc.absStep % 16;
    setLED2(16 + btnIdx, Math.floor(S.tickCount / 24) % 2 ? White2 : LED_OFF);
  }
}
function updateSessionLEDs() {
  if (!S.ledInitComplete) return;
  if (S.tapTempoOpen) {
    for (let i = 0; i < 32; i++) {
      const note = TRACK_PAD_BASE + i;
      const flash = S.tapTempoFlashTick >= 0 && S.tickCount - S.tapTempoFlashTick < TAP_TEMPO_FLASH_TICKS;
      cachedSetLED(note, flash ? DarkBlue2 : DarkGrey2);
    }
    return;
  }
  for (let row = 0; row < 4; row++) {
    const sceneIdx = S.sceneRow + row;
    for (let t = 0; t < 8; t++) {
      const note = 92 - row * 8 + t;
      if (t >= NUM_TRACKS) {
        setLED2(note, LED_OFF);
        continue;
      }
      const isActiveClip = S.trackActiveClip[t] === sceneIdx;
      const isPlaying = S.trackClipPlaying[t] && isActiveClip;
      const isPendingStop = S.trackPendingPageStop[t] && isActiveClip;
      const isQueued = S.trackQueuedClip[t] === sceneIdx;
      const isWillRelaunch = S.trackWillRelaunch[t] && isActiveClip;
      const isDrumTrack = S.trackPadMode[t] === PAD_MODE_DRUM;
      const hasContent = isDrumTrack ? S.drumClipNonEmpty[t][sceneIdx] : S.clipNonEmpty[t][sceneIdx];
      const hasActive = hasContent;
      let color;
      if (!hasContent) {
        color = isActiveClip ? DarkGrey2 : LED_OFF;
      } else if (!hasActive) {
        color = DarkGrey2;
      } else if (isPlaying && isPendingStop) {
        color = !S.playing || S.flashSixteenth ? trackDimColor(t) : LED_OFF;
      } else if (isPlaying) {
        color = S.flashEighth ? trackColor(t) : trackDimColor(t);
      } else if (isQueued) {
        color = !S.playing || S.flashSixteenth ? trackColor(t) : trackDimColor(t);
      } else if (isWillRelaunch) {
        color = trackColor(t);
      } else {
        color = trackDimColor(t);
      }
      if (S.copySrc) {
        const isSrcClip = (S.copySrc.kind === "clip" || S.copySrc.kind === "cut_clip") && S.copySrc.track === t && S.copySrc.clip === sceneIdx;
        const isSrcRow = (S.copySrc.kind === "row" || S.copySrc.kind === "cut_row") && S.copySrc.row === sceneIdx;
        const isSrcDrumClip = (S.copySrc.kind === "drum_clip" || S.copySrc.kind === "cut_drum_clip") && S.copySrc.track === t && S.copySrc.clip === sceneIdx;
        if (isSrcClip || isSrcRow || isSrcDrumClip) color = Math.floor(S.tickCount / 24) % 2 ? White2 : LED_OFF;
      }
      const _placeTrack = S.mergeSoloPlacement >= 0 ? S.mergeSoloPlacement : S.capturePlaceTrack >= 0 ? S.capturePlaceTrack : -1;
      if (_placeTrack >= 0 && t === _placeTrack && !hasContent)
        color = Math.floor(S.tickCount / 24) % 2 ? LightGrey : LED_OFF;
      cachedSetLED(note, color);
    }
  }
}
function updateTrackLEDs() {
  if (!S.ledInitComplete) return;
  {
    const inCoRun = S.schwungCoRunSlot >= 0;
    if (inCoRun) {
      paintCoRunSideButtons(S._coRunChanSlots, S.tickCount % POLL_INTERVAL === 0);
      S._coRunTrackLedsLit = true;
    } else if (S._coRunTrackLedsLit) {
      for (let _i = 0; _i < 4; _i++) setButtonLED(40 + _i, LED_OFF, true);
      S._coRunTrackLedsLit = false;
    }
  }
  {
    const inMoveCoRun = (S.moveCoRunTrack | 0) >= 0;
    if (inMoveCoRun) {
      S._moveCoRunTrackLedsActive = true;
    } else if (S._moveCoRunTrackLedsActive) {
      for (let _i = 0; _i < 4; _i++) setButtonLED(40 + _i, LED_OFF, true);
      S._moveCoRunTrackLedsActive = false;
    }
  }
  {
    const isDrum = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM;
    const force = S.tickCount % POLL_INTERVAL === 0;
    const _kt = S.knobTouched;
    const _knobShiftMode = S.activeBank === 0 && (_kt === 1 || _kt === 2) || S.activeBank === 7 && _kt === 1;
    const _compoundHeld = S.muteHeld || S.deleteHeld || S.copyHeld || S.loopHeld;
    const _inCoRun = S.schwungCoRunSlot >= 0 || S.moveCoRunTrack >= 0;
    for (let i = 0; i < 16; i++) {
      let color;
      if (_inCoRun) {
        color = i === 2 ? White2 : LED_OFF;
      } else {
        let on = false;
        if (S.shiftHeld && !_knobShiftMode && !_compoundHeld) {
          if (i === 1 || i >= 4 && i <= 6 || i === 8) on = true;
          if (!S.sessionView) {
            if (i === 2) on = true;
            else if (i === 7) on = true;
            else if (i === 9) on = true;
            else if (i === 10 && !isDrum) on = true;
            else if (i === 14 || i === 15) on = true;
          }
        }
        if (isDrum && S.activeBank === 7 && !S.allLanesConfirmed && (i === 14 || i === 15)) on = false;
        color = on ? LightGrey : LED_OFF;
      }
      if (force) {
        lastSentButtonLED[16 + i] = color;
        setButtonLED(16 + i, color, true);
      } else {
        cachedSetButtonLED(16 + i, color);
      }
    }
  }
  if (S.sessionView && S.shiftHeld && !(S.muteHeld || S.deleteHeld || S.copyHeld || S.loopHeld)) {
    for (let i = 0; i < 16; i++) {
      const on = i === 1 || i >= 4 && i <= 6 || i === 8;
      setLED2(16 + i, on ? LightGrey : LED_OFF);
    }
  }
  if (S.tapTempoOpen) {
    for (let i = 0; i < 32; i++) {
      const note = TRACK_PAD_BASE + i;
      const flash = S.tapTempoFlashTick >= 0 && S.tickCount - S.tapTempoFlashTick < TAP_TEMPO_FLASH_TICKS;
      cachedSetLED(note, flash ? DarkBlue2 : DarkGrey2);
    }
    return;
  }
  if (!S.sessionView && S.stepIntervalMode && S.activeBank === 4) {
    const t = S.activeTrack;
    const ac = effectiveClip(t);
    const sv = S.seqArpStepVel[t][ac];
    const tc = trackColor(t);
    const td = trackDimColor(t);
    const ll = S.seqArpStepLoopLen[t][ac] | 0;
    const loopLen = ll >= 1 && ll <= 8 ? ll : 8;
    for (let i = 0; i < 32; i++) {
      const col = i % 8;
      const row = Math.floor(i / 8);
      let color = LED_OFF;
      if (col < loopLen) {
        const lvl = arpVelLevel(sv[col]);
        if (lvl > 0 && row < lvl) {
          color = row === lvl - 1 ? tc : td;
        }
      }
      cachedSetLED(TRACK_PAD_BASE + i, color);
    }
    return;
  }
  if (!S.sessionView && S.stepIntervalMode && S.activeBank === 5) {
    const t = S.activeTrack;
    const sv = S.tarpStepVel[t];
    const tc = trackColor(t);
    const td = trackDimColor(t);
    const ll = S.tarpStepLoopLen[t] | 0;
    const loopLen = ll >= 1 && ll <= 8 ? ll : 8;
    for (let i = 0; i < 32; i++) {
      const col = i % 8;
      const row = Math.floor(i / 8);
      let color = LED_OFF;
      if (col < loopLen) {
        const lvl = arpVelLevel(sv[col]);
        if (lvl > 0 && row < lvl) {
          color = row === lvl - 1 ? tc : td;
        }
      }
      cachedSetLED(TRACK_PAD_BASE + i, color);
    }
    return;
  }
  if (!S.sessionView) {
    const _inCoRunPad = S.schwungCoRunSlot >= 0 || S.moveCoRunTrack >= 0;
    const isDrum = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM;
    if (isDrum) {
      const t = S.activeTrack;
      const selLane = S.activeDrumLane[t];
      const velZone = S.drumLastVelZone[t];
      const tc = _inCoRunPad ? White2 : trackColor(t);
      const td = _inCoRunPad ? LightGrey : trackDimColor(t);
      const tcReal = trackColor(t);
      const tdReal = trackDimColor(t);
      const flashDur = 2 * POLL_INTERVAL;
      for (let i = 0; i < 32; i++) {
        const col = i % 8;
        const row = Math.floor(i / 8);
        if (S.activeBank === 6) {
          let g6;
          if (col < 4) {
            const lane6 = S.drumLanePage[t] * 16 + row * 4 + col;
            const note6 = S.drumLaneNote[t][lane6];
            if (lane6 === selLane) {
              g6 = trackColor(t);
            } else if (S.liveActiveNotes.has(note6) || S.seqActiveNotes.has(note6)) {
              g6 = trackDimColor(t);
            } else {
              g6 = S.drumLaneHasNotes[t][lane6] ? 118 : 124;
            }
          } else {
            g6 = LED_OFF;
          }
          cachedSetLED(TRACK_PAD_BASE + i, g6);
          continue;
        }
        let color;
        if (col < 4) {
          const lane = S.drumLanePage[t] * 16 + row * 4 + col;
          const isActive = lane === selLane;
          const hasHits = S.drumLaneHasNotes[t][lane];
          const laneNote = S.drumLaneNote[t][lane];
          const sounding = S.liveActiveNotes.has(laneNote);
          const flashing = S.tickCount - S.drumLaneFlashTick[t][lane] < flashDur;
          const isMuted = effectiveDrumMute(t, lane);
          if (sounding) {
            color = White2;
          } else if (flashing) {
            color = isMuted ? DarkGrey2 : tc;
          } else if (isMuted) {
            color = LED_OFF;
          } else if (isActive) {
            color = _inCoRunPad ? hasHits ? tcReal : tdReal : hasHits ? White2 : DarkGrey2;
          } else if (hasHits) {
            color = _inCoRunPad ? White2 : S.playing ? td : tc;
          } else {
            color = td;
          }
          if (S.copySrc && (S.copySrc.kind === "drum_lane" || S.copySrc.kind === "cut_drum_lane") && S.copySrc.track === t && S.copySrc.lane === lane) {
            color = Math.floor(S.tickCount / 24) % 2 ? White2 : LED_OFF;
          }
          const _rpt1Lit = S.drumRepeatLatched[t] && lane === S.activeDrumLane[t];
          const _rpt2Lit = S.drumRepeat2LatchedLanes[t].has(lane) || S.drumPerformMode[t] === 2 && S.drumRepeat2HeldLanes[t].has(lane);
          if (_rpt1Lit || _rpt2Lit) {
            color = Cyan;
          }
        } else if (S.drumPerformMode[t] === 1) {
          if (row < 2) {
            const isHeld = S.drumRepeatHeldPad[t] === i;
            color = isHeld ? White2 : DarkGrey2;
          } else {
            const maskStep = (row - 2) * 4 + (col - 4);
            const gLen = S.drumRepeatGateLen[t][selLane];
            if (maskStep >= gLen) {
              color = DarkGrey2;
            } else {
              const isOn = !!(S.drumRepeatGate[t][selLane] & 1 << maskStep);
              color = isOn ? tc : LED_OFF;
            }
          }
        } else if (S.drumPerformMode[t] === 2) {
          if (row < 2) {
            const rateIdx = row * 4 + (col - 4);
            color = rateIdx === S.drumRepeat2RatePerLane[t][selLane] ? Cyan : PurpleBlue;
          } else {
            const maskStep = (row - 2) * 4 + (col - 4);
            const gLen = S.drumRepeatGateLen[t][selLane];
            if (maskStep >= gLen) {
              color = DarkGrey2;
            } else {
              const isOn = !!(S.drumRepeatGate[t][selLane] & 1 << maskStep);
              color = isOn ? tc : LED_OFF;
            }
          }
        } else {
          const zone = row * 4 + (col - 4);
          color = zone === velZone ? White2 : DarkGrey2;
        }
        cachedSetLED(TRACK_PAD_BASE + i, color);
      }
    } else {
      const _autoGrey = S.activeBank === 6;
      const rootColor = _autoGrey ? 118 : _inCoRunPad ? DarkGrey2 : trackColor(S.activeTrack);
      const nonRootColor = _autoGrey ? 124 : _inCoRunPad ? trackDimColor(S.activeTrack) : DarkGrey2;
      const _tarpActive = (S.bankParams[S.activeTrack][5][7] | 0) !== 0 && (S.bankParams[S.activeTrack][5][0] | 0) !== 0;
      const _tarpHeld = _tarpActive ? S.tarpHeldNotes[S.activeTrack] : null;
      for (let i = 0; i < 32; i++) {
        let color;
        if (S.padNoteMap[i] === 255) {
          cachedSetLED(TRACK_PAD_BASE + i, LED_OFF);
          continue;
        }
        const pitchRaw = S.padNoteMap[i] + S.trackOctave[S.activeTrack] * 12;
        if (pitchRaw < 0 || pitchRaw > 127) {
          cachedSetLED(TRACK_PAD_BASE + i, LED_OFF);
          continue;
        }
        const pitch = pitchRaw;
        const sounding = S.liveActiveNotes.has(pitch) || S.seqActiveNotes.has(pitch);
        const inHeld = S.heldStep >= 0 && S.heldStepNotes.indexOf(pitch) >= 0;
        const inLatch = _tarpHeld && _tarpHeld.has(pitch);
        const _effKey = S.xposePrevKey !== null ? S.xposePrevKey : S.padKey;
        const semitone = (S.padNoteMap[i] % 12 - _effKey + 12) % 12;
        const inScale = S.padScaleSet.has(semitone);
        const chromatic = S.padLayoutChromatic[S.activeTrack];
        color = sounding || inHeld || inLatch ? _autoGrey ? 120 : White2 : chromatic && !inScale ? LED_OFF : S.padNoteMap[i] % 12 === _effKey ? rootColor : nonRootColor;
        cachedSetLED(TRACK_PAD_BASE + i, color);
      }
    }
  }
  if (S.schwungCoRunSlot < 0 && (S.moveCoRunTrack | 0) < 0) {
    for (let idx = 0; idx < 4; idx++) {
      const row = 3 - idx;
      const sceneIdx = S.sceneRow + row;
      let color;
      if (S.sessionView) {
        const sincePress = S.sceneBtnFlashTick[idx] >= 0 ? S.tickCount - S.sceneBtnFlashTick[idx] : 999;
        color = sincePress < SCENE_BTN_FLASH_TICKS ? White2 : LED_OFF;
      } else {
        const t = S.activeTrack;
        const focused = effectiveClip(t);
        const isFocused = sceneIdx === focused;
        const isPlaying = S.trackClipPlaying[t] && S.trackActiveClip[t] === sceneIdx;
        const slowPulse = Math.floor(S.tickCount / 98) % 2;
        const isWillRelaunch = S.trackWillRelaunch[t] && S.trackActiveClip[t] === sceneIdx;
        if (isPlaying) {
          color = S.flashEighth ? trackColor(t) : trackDimColor(t);
        } else if (isFocused && isWillRelaunch && S.playing) {
          color = slowPulse ? trackColor(t) : trackDimColor(t);
        } else if (isFocused) {
          color = trackColor(t);
        } else if (!trackClipHasContent(t, sceneIdx)) {
          color = DarkGrey2;
        } else {
          color = trackDimColor(t);
        }
      }
      if (S.copySrc) {
        const isSrcRow = (S.copySrc.kind === "row" || S.copySrc.kind === "cut_row") && S.copySrc.row === sceneIdx;
        const isSrcClip = (S.copySrc.kind === "clip" || S.copySrc.kind === "cut_clip") && S.copySrc.track === S.activeTrack && S.copySrc.clip === sceneIdx;
        const isSrcDrumClip = (S.copySrc.kind === "drum_clip" || S.copySrc.kind === "cut_drum_clip") && S.copySrc.track === S.activeTrack && S.copySrc.clip === sceneIdx;
        if (isSrcRow || isSrcClip || isSrcDrumClip) color = Math.floor(S.tickCount / 24) % 2 ? White2 : LED_OFF;
      }
      cachedSetButtonLED(40 + idx, color);
    }
  }
  for (let k = 0; k < NUM_TRACKS; k++) {
    let ledVal = LED_OFF;
    if (S.perfViewLocked) {
      ledVal = S.trackLooper[k] !== 0 ? trackColor(k) : LED_OFF;
    } else if (S.sessionView) {
      ledVal = k === S.activeTrack ? White2 : LED_OFF;
    } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 5) {
      const lane = S.activeDrumLane[S.activeTrack];
      const isDirty = S.drumRepeatVelScale[S.activeTrack][lane][k] !== 100 || S.drumRepeatNudge[S.activeTrack][lane][k] !== 0;
      ledVal = isDirty ? White2 : LED_OFF;
    } else if (S.activeBank === 6) {
      const _t6 = S.activeTrack, _c6 = effectiveClip(_t6);
      const _autoHas = S.trackCCAutoBits[_t6][_c6] >> k & 1;
      if (S.recordArmed) {
        ledVal = Red2;
      } else if (S.playing && _autoHas) {
        ledVal = Green2;
      } else if (_autoHas) {
        ledVal = VividYellow2;
      } else {
        ledVal = S.clipCCVal[_t6][_c6][k] >= 0 ? White2 : LED_OFF;
      }
    } else if (PARAM_LED_BANKS.indexOf(S.activeBank) >= 0) {
      const pm = BANKS[S.activeBank].knobs[k];
      if (pm && pm.abbrev && pm.scope !== "stub") {
        ledVal = S.bankParams[S.activeTrack][S.activeBank][k] !== pm.def ? White2 : LED_OFF;
      }
    }
    if (S._forceKnobReemit) setButtonLED(71 + k, ledVal, true);
    else cachedSetButtonLED(71 + k, ledVal);
  }
  if (S._forceKnobReemit) S._forceKnobReemit = false;
  if (!S.sessionView && S.shiftHeld && S.shiftTrackLEDActive) {
    const _ttPhase = Math.floor(S.tickCount / 24) % 2 === 1;
    for (let i = 0; i < NUM_TRACKS; i++) {
      const color = i === S.activeTrack ? trackColor(i) : _ttPhase ? DarkGrey2 : trackDimColor(i);
      cachedSetLED(TRACK_PAD_BASE + i, color);
    }
  }
  if (S.stepSaveFlashEndTick >= 0 && S.tickCount < S.stepSaveFlashEndTick && S.stepSaveFlashStartTick >= 0) {
    const elapsed = S.tickCount - S.stepSaveFlashStartTick;
    if (Math.floor(elapsed / 10) % 2 === 0) {
      for (let i = 0; i < 16; i++) setLED2(16 + i, White2);
    }
  }
}
function flashAtRate(rateTicks) {
  if (rateTicks <= 0) return false;
  return (Math.floor(S.masterPos / rateTicks) & 1) === 1;
}
function drawPositionBar(t) {
  const ac = effectiveClip(t);
  const lsBase = S.clipLoopStart[t][ac] | 0;
  const len = S.clipLength[t][ac];
  const startPage = lsBase >> 4;
  const winPages = Math.max(1, Math.ceil(len / 16));
  const viewPage = Math.max(0, Math.min(S.trackCurrentPage[t] - startPage, winPages - 1));
  const cs = S.trackCurrentStep[t];
  const playPage = S.playing && S.trackClipPlaying[t] && cs >= lsBase && cs < lsBase + len ? Math.floor((cs - lsBase) / 16) : -1;
  const barY = 57, barH = 5, segGap = 1;
  const segW = Math.max(2, Math.floor((120 - (winPages - 1) * segGap) / winPages));
  const startX = 4;
  for (let pg = 0; pg < winPages; pg++) {
    const x = startX + pg * (segW + segGap);
    if (pg === viewPage) {
      fill_rect(x, barY, segW, barH, 1);
    } else if (pg === playPage) {
      fill_rect(x, barY, segW, 1, 1);
      fill_rect(x, barY + barH - 1, segW, 1, 1);
      fill_rect(x, barY, 1, barH, 1);
      fill_rect(x + segW - 1, barY, 1, barH, 1);
    } else {
      fill_rect(x, barY + barH - 1, segW, 1, 1);
    }
  }
  if (S.playing && S.trackClipPlaying[t] && cs >= lsBase && cs < lsBase + len) {
    const winPxW = winPages * (segW + segGap) - segGap;
    const dotX = startX + Math.floor((cs - lsBase) * winPxW / Math.max(1, len));
    const viewSegStart = startX + viewPage * (segW + segGap);
    const onSolid = dotX >= viewSegStart && dotX < viewSegStart + segW;
    fill_rect(dotX, barY, 1, barH, onSolid ? 0 : 1);
  }
  const steps = S.clipSteps[t][ac];
  let hasLeft = false, hasRight = false;
  for (let s = 0; s < lsBase; s++) if (steps[s] !== 0) {
    hasLeft = true;
    break;
  }
  for (let s = lsBase + len; s < NUM_STEPS; s++) if (steps[s] !== 0) {
    hasRight = true;
    break;
  }
  if (hasLeft) fill_rect(startX - 2, barY + 1, 1, barH - 2, 1);
  if (hasRight) {
    const xRight = startX + winPages * (segW + segGap) - segGap + 1;
    fill_rect(xRight, barY + 1, 1, barH - 2, 1);
  }
}
function _sysexPkts(bytes) {
  const out = [];
  for (let i = 0; i < bytes.length; i += 3) {
    const rem = bytes.length - i;
    const cin = rem >= 3 ? rem === 3 ? 7 : 4 : rem === 2 ? 6 : 5;
    out.push(cin, bytes[i], rem > 1 ? bytes[i + 1] : 0, rem > 2 ? bytes[i + 2] : 0);
  }
  return out;
}
var _CC_REAPPLY_PKT = _sysexPkts([240, 0, 33, 29, 1, 1, 5, 247]);
function setPaletteEntryRGB(idx, r, g, b) {
  move_midi_internal_send(_sysexPkts([
    240,
    0,
    33,
    29,
    1,
    1,
    3,
    idx & 127,
    r & 127,
    r >> 7,
    g & 127,
    g >> 7,
    b & 127,
    b >> 7,
    0,
    0,
    /* white channel = 0 */
    247
  ]));
}
function reapplyPalette() {
  move_midi_internal_send(_CC_REAPPLY_PKT);
}
function buildLedInitQueue() {
  const q = [];
  for (let n = 68; n <= 99; n++) q.push({ kind: "note", id: n });
  for (let n = 16; n <= 31; n++) q.push({ kind: "note", id: n });
  for (let c = 16; c <= 31; c++) q.push({ kind: "cc", id: c });
  for (let c = 40; c <= 43; c++) q.push({ kind: "cc", id: c });
  for (const c of [49, 50, 51, 52, 54, 55, 56, 58, 60, 62, 63])
    q.push({ kind: "cc", id: c });
  for (let c = 71; c <= 78; c++) q.push({ kind: "cc", id: c });
  for (const c of [85, 86, 88, 118, 119]) q.push({ kind: "cc", id: c });
  return q;
}
function drainLedInit() {
  const end = Math.min(S.ledInitIndex + LEDS_PER_FRAME, S.ledInitQueue.length);
  for (let i = S.ledInitIndex; i < end; i++) {
    const led = S.ledInitQueue[i];
    if (led.kind === "cc") setButtonLED(led.id, LED_OFF);
    else setLED2(led.id, LED_OFF);
  }
  S.ledInitIndex = end;
  if (S.ledInitIndex >= S.ledInitQueue.length) {
    S.ledInitComplete = true;
    setPaletteEntryRGB(60, 32, 32, 32);
    reapplyPalette();
  }
}
var PERF_MOD_PAD_MAP = Object.freeze({
  76: 0,
  /* Oct↑    */
  77: 1,
  /* Oct↓    */
  78: 2,
  /* Sc↑     */
  79: 3,
  /* Sc↓     */
  80: 4,
  /* 5th     */
  81: 5,
  /* Triton  */
  82: 6,
  /* Drift   */
  83: 7,
  /* Storm   */
  84: 8,
  /* Soft    */
  85: 9,
  /* Hard    */
  86: 10,
  /* Cresc   */
  87: 11,
  /* Pulse   */
  88: 12,
  /* Sdchn   */
  89: 13,
  /* Stac    */
  90: 14,
  /* Lgto    */
  91: 15,
  /* RmpG    */
  92: 16,
  /* ½time   */
  93: 17,
  /* 3Skip   */
  94: 18,
  /* Phnm    */
  95: 19,
  /* Sprs    */
  96: 20,
  /* Gltch   */
  97: 21,
  /* Stggr   */
  98: 22,
  /* Shfl    */
  99: 23
  /* Back    */
});
function updatePerfModeLEDs() {
  if (!S.ledInitComplete) return;
  const activeMods = S.perfModsToggled | S.perfModsHeld;
  for (let i = 0; i < 16; i++) {
    if (i === S.perfRecalledSlot) setLED2(16 + i, White2);
    else if (S.perfSnapshots[i] !== 0) setLED2(16 + i, PurpleBlue);
    else setLED2(16 + i, LightGrey);
  }
  for (let i = 0; i < 5; i++) {
    const rateActive = S.perfStickyLengths.has(i) || S.perfStack.some(function(e) {
      return e.idx === i;
    });
    setLED2(68 + i, rateActive ? White2 : DarkGrey2);
  }
  setLED2(73, S.perfHoldPadHeld ? Red2 : DeepRed);
  setLED2(74, S.perfSync ? Green2 : DeepGreen2);
  setLED2(75, S.perfLatchMode ? TRACK_COLORS[2] : TRACK_DIM_COLORS[2]);
  for (let i = 0; i < 8; i++) {
    const note = 76 + i;
    const modIdx = PERF_MOD_PAD_MAP[note];
    if (modIdx !== void 0)
      setLED2(note, activeMods >> modIdx & 1 ? White2 : DeepMagenta);
    else
      setLED2(note, LED_OFF);
  }
  for (let i = 0; i < 8; i++) {
    const note = 84 + i;
    const modIdx = PERF_MOD_PAD_MAP[note];
    if (modIdx !== void 0)
      setLED2(note, activeMods >> modIdx & 1 ? White2 : Mustard2);
    else
      setLED2(note, LED_OFF);
  }
  for (let i = 0; i < 8; i++) {
    const note = 92 + i;
    const modIdx = PERF_MOD_PAD_MAP[note];
    if (modIdx !== void 0)
      setLED2(note, activeMods >> modIdx & 1 ? White2 : DarkBlue2);
    else
      setLED2(note, LED_OFF);
  }
}
function forceRedraw() {
  S.screenDirty = true;
  if (!S.ledInitComplete) return;
  if (S.sessionView) {
    updateSessionLEDs();
    if (S.loopHeld || S.perfViewLocked) updatePerfModeLEDs();
    else {
      updateSceneMapLEDs();
      for (let i = 0; i < 16; i++) setLED2(16 + i, LED_OFF);
    }
  } else {
    updateStepLEDs();
  }
  updateTrackLEDs();
}
function bankHasAltParams(t, bank) {
  if (S.trackPadMode[t] === PAD_MODE_DRUM) return bank === 0 || bank === 5 || bank === 6 || bank === 7;
  return bank === 0 || bank === 1 || bank === 3 || bank === 4 || bank === 5 || bank === 6;
}
function altIndicatorActive(t, bank) {
  if (S.trackPadMode[t] !== PAD_MODE_DRUM && (bank === 4 || bank === 5)) {
    return S.stepIntervalMode;
  }
  return S.altMode;
}
function clearAllLEDs() {
  let n, c;
  for (n = 68; n <= 99; n++) setLED2(n, LED_OFF);
  for (n = 16; n <= 31; n++) setLED2(n, LED_OFF);
  for (c = 16; c <= 31; c++) setButtonLED(c, LED_OFF);
  for (c = 40; c <= 43; c++) setButtonLED(c, LED_OFF);
  for (const cc of [49, 50, 51, 52, 54, 55, 56, 58, 60, 62, 63])
    setButtonLED(cc, LED_OFF);
  for (c = 71; c <= 78; c++) setButtonLED(c, LED_OFF);
  for (const cc of [85, 86, 88, 118, 119]) setButtonLED(cc, LED_OFF);
}
function installFlagsWrap() {
  if (typeof shadow_get_ui_flags !== "function") return;
  if (globalThis.shadow_get_ui_flags._seq8) {
    globalThis.shadow_get_ui_flags._active = true;
    return;
  }
  const orig = globalThis.shadow_get_ui_flags;
  const wrap = function() {
    const f = orig();
    const hit = f & SEQ8_NAV_FLAGS;
    if (hit && wrap._active) {
      S.ledInitComplete = false;
      invalidateLEDCache();
      clearAllLEDs();
      if (typeof shadow_clear_ui_flags === "function") shadow_clear_ui_flags(hit);
      return f & ~SEQ8_NAV_FLAGS;
    }
    return f;
  };
  wrap._seq8 = true;
  wrap._orig = orig;
  wrap._active = true;
  globalThis.shadow_get_ui_flags = wrap;
}
function removeFlagsWrap() {
  const cur = globalThis.shadow_get_ui_flags;
  if (typeof cur === "function" && cur._seq8) {
    cur._active = false;
    globalThis.shadow_get_ui_flags = cur._orig;
  }
}
function sendPerfMods() {
  if (typeof host_module_set_param === "function")
    host_module_set_param("perf_mods", String(S.perfModsToggled | S.perfModsHeld));
}

// ui/ui_dialogs.mjs
function pixelPrintMcu(x, y, text, scale, color) {
  const charW = 5 * scale + scale;
  for (let ci = 0; ci < text.length; ci++) {
    const g = MCUFONT[text[ci]];
    if (!g) continue;
    for (let row = 0; row < 5; row++) {
      const bits = g[row];
      for (let col = 0; col < 5; col++) {
        if (bits & 1 << 4 - col)
          fill_rect(x + ci * charW + col * scale, y + row * scale, scale, scale, color);
      }
    }
  }
}
function triLeft(x, y, w, h) {
  const mid = (h - 1) / 2;
  for (let r = 0; r < h; r++) {
    const c0 = Math.round(Math.abs(r - mid) / mid * (w - 1));
    for (let c = c0; c < w; c++) set_pixel(x + c, y + r, 1);
  }
}
function triRight(x, y, w, h) {
  const mid = (h - 1) / 2;
  for (let r = 0; r < h; r++) {
    const c1 = Math.round((1 - Math.abs(r - mid) / mid) * (w - 1));
    for (let c = 0; c <= c1; c++) set_pixel(x + c, y + r, 1);
  }
}
function drawBpmLine(cx, topY, value, unit) {
  const num = String(Math.round(value || 0));
  const u = unit || "bpm";
  const nS = 2, uS = 1;
  const nCW = 5 * nS + nS, uCW = 5 * uS + uS;
  const nW = num.length * nCW - nS;
  const uW = u.length * uCW - uS;
  const aW = 5, aH = 9, aGap = 5, uGap = 3;
  const total = aW + aGap + nW + uGap + uW + aGap + aW;
  let x = cx - Math.round(total / 2);
  if (x < 1) x = 1;
  const nH = 5 * nS;
  triLeft(x, topY + Math.round((nH - aH) / 2), aW, aH);
  x += aW + aGap;
  pixelPrintMcu(x, topY, num, nS, 1);
  x += nW + uGap;
  pixelPrintMcu(x, topY + (nH - 5 * uS), u, uS, 1);
  x += uW + aGap;
  triRight(x, topY + Math.round((nH - aH) / 2), aW, aH);
}
function drawTapTempoScreen() {
  clear_screen();
  drawMenuHeader("TAP TEMPO");
  drawBpmLine(64, 24, S.tapTempoBpm);
  pixelPrintC(64, 50, "Tap any pad", 1);
}
function drawClearSessionConfirm() {
  clear_screen();
  drawMenuHeader("CLEAR SESSION");
  print(4, 16, "This will clear the", 1);
  print(4, 25, "entire project and", 1);
  print(4, 34, "cannot be undone.", 1);
  const noX = 6, yesX = 74, btnY = 46, btnW = 46, btnH = 13;
  if (S.confirmClearSel === 1) {
    fill_rect(noX, btnY, btnW, btnH, 1);
    print(noX + 17, btnY + 3, "No", 0);
  } else {
    fill_rect(noX, btnY, btnW, 1, 1);
    fill_rect(noX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(noX, btnY, 1, btnH, 1);
    fill_rect(noX + btnW - 1, btnY, 1, btnH, 1);
    print(noX + 17, btnY + 3, "No", 1);
  }
  if (S.confirmClearSel === 0) {
    fill_rect(yesX, btnY, btnW, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 0);
  } else {
    fill_rect(yesX, btnY, btnW, 1, 1);
    fill_rect(yesX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(yesX, btnY, 1, btnH, 1);
    fill_rect(yesX + btnW - 1, btnY, 1, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 1);
  }
}
function drawSaveStateConfirm() {
  clear_screen();
  drawMenuHeader("SAVE STATE");
  print(4, 20, "Save current session?", 1);
  print(4, 32, S.confirmSaveCount + " of " + SNAPSHOT_CAP + " saved", 1);
  const noX = 6, yesX = 74, btnY = 46, btnW = 46, btnH = 13;
  if (S.confirmSaveSel === 1) {
    fill_rect(noX, btnY, btnW, btnH, 1);
    print(noX + 17, btnY + 3, "No", 0);
  } else {
    fill_rect(noX, btnY, btnW, 1, 1);
    fill_rect(noX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(noX, btnY, 1, btnH, 1);
    fill_rect(noX + btnW - 1, btnY, 1, btnH, 1);
    print(noX + 17, btnY + 3, "No", 1);
  }
  if (S.confirmSaveSel === 0) {
    fill_rect(yesX, btnY, btnW, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 0);
  } else {
    fill_rect(yesX, btnY, btnW, 1, 1);
    fill_rect(yesX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(yesX, btnY, 1, btnH, 1);
    fill_rect(yesX + btnW - 1, btnY, 1, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 1);
  }
}
function drawConvertToDrumConfirm() {
  clear_screen();
  drawMenuHeader("CONVERT");
  print(4, 16, "Warning:", 1);
  print(4, 25, "Existing notes may", 1);
  print(4, 34, "be lost. Proceed?", 1);
  const noX = 6, yesX = 74, btnY = 46, btnW = 46, btnH = 13;
  if (S.confirmConvertToDrumSel === 1) {
    fill_rect(noX, btnY, btnW, btnH, 1);
    print(noX + 17, btnY + 3, "No", 0);
  } else {
    fill_rect(noX, btnY, btnW, 1, 1);
    fill_rect(noX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(noX, btnY, 1, btnH, 1);
    fill_rect(noX + btnW - 1, btnY, 1, btnH, 1);
    print(noX + 17, btnY + 3, "No", 1);
  }
  if (S.confirmConvertToDrumSel === 0) {
    fill_rect(yesX, btnY, btnW, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 0);
  } else {
    fill_rect(yesX, btnY, btnW, 1, 1);
    fill_rect(yesX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(yesX, btnY, 1, btnH, 1);
    fill_rect(yesX + btnW - 1, btnY, 1, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 1);
  }
}
function drawConvertToConductConfirm() {
  clear_screen();
  drawMenuHeader("CONVERT");
  print(4, 16, "Make Conductor?", 1);
  print(4, 25, "Clears FX/ARP/Auto.", 1);
  print(4, 34, "Keeps notes.", 1);
  const noX = 6, yesX = 74, btnY = 46, btnW = 46, btnH = 13;
  if (S.confirmConvertToConductSel === 1) {
    fill_rect(noX, btnY, btnW, btnH, 1);
    print(noX + 17, btnY + 3, "No", 0);
  } else {
    fill_rect(noX, btnY, btnW, 1, 1);
    fill_rect(noX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(noX, btnY, 1, btnH, 1);
    fill_rect(noX + btnW - 1, btnY, 1, btnH, 1);
    print(noX + 17, btnY + 3, "No", 1);
  }
  if (S.confirmConvertToConductSel === 0) {
    fill_rect(yesX, btnY, btnW, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 0);
  } else {
    fill_rect(yesX, btnY, btnW, 1, 1);
    fill_rect(yesX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(yesX, btnY, 1, btnH, 1);
    fill_rect(yesX + btnW - 1, btnY, 1, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 1);
  }
}
function drawMenuInfo() {
  clear_screen();
  drawMenuHeader("INFO");
  const lines = S.menuInfoLines || [];
  let y = 16;
  for (let i = 0; i < lines.length && i < 4; i++) {
    print(4, y, lines[i], 1);
    y += 9;
  }
  const okX = 49, btnY = 46, btnW = 30, btnH = 13;
  fill_rect(okX, btnY, btnW, btnH, 1);
  print(okX + 10, btnY + 3, "OK", 0);
}
function drawExportConfirm() {
  clear_screen();
  drawMenuHeader("EXPORT");
  if (S.confirmExportCondPhase) {
    let _ebtn = function(x, y, w, h, sel, label, labelOff) {
      if (sel) {
        fill_rect(x, y, w, h, 1);
        print(x + labelOff, y + 3, label, 0);
      } else {
        fill_rect(x, y, w, 1, 1);
        fill_rect(x, y + h - 1, w, 1, 1);
        fill_rect(x, y, 1, h, 1);
        fill_rect(x + w - 1, y, 1, h, 1);
        print(x + labelOff, y + 3, label, 1);
      }
    };
    print(4, 22, "Apply Conductor?", 1);
    const bY = 47, bW = 36, mH = 11;
    _ebtn(4, bY, bW, mH, S.confirmExportCondSel === 0, "YES", 9);
    _ebtn(45, bY, bW, mH, S.confirmExportCondSel === 1, "NO", 14);
    _ebtn(86, bY, bW, mH, S.confirmExportCondSel === 2, "CANCEL", 1);
    return;
  }
  print(4, 16, "Export this set as", 1);
  print(4, 25, "an Ableton bundle?", 1);
  print(4, 34, "(transport stopped)", 1);
  const noX = 6, yesX = 74, btnY = 46, btnW = 46, btnH = 13;
  if (S.confirmExportSel === 1) {
    fill_rect(noX, btnY, btnW, btnH, 1);
    print(noX + 17, btnY + 3, "No", 0);
  } else {
    fill_rect(noX, btnY, btnW, 1, 1);
    fill_rect(noX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(noX, btnY, 1, btnH, 1);
    fill_rect(noX + btnW - 1, btnY, 1, btnH, 1);
    print(noX + 17, btnY + 3, "No", 1);
  }
  if (S.confirmExportSel === 0) {
    fill_rect(yesX, btnY, btnW, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 0);
  } else {
    fill_rect(yesX, btnY, btnW, 1, 1);
    fill_rect(yesX, btnY + btnH - 1, btnW, 1, 1);
    fill_rect(yesX, btnY, 1, btnH, 1);
    fill_rect(yesX + btnW - 1, btnY, 1, btnH, 1);
    print(yesX + 14, btnY + 3, "Yes", 1);
  }
}
function drawExportDoneDialog() {
  clear_screen();
  drawMenuHeader(S.exportDoneMissing > 0 ? "EXPORTED -" + S.exportDoneMissing : "EXPORTED TO");
  const path = S.exportDonePath || "";
  const W = 21;
  let y = 14, lines = 0;
  for (let i = 0; i < path.length && lines < 4; i += W, lines++) {
    print(2, y, path.slice(i, i + W), 1);
    y += 9;
  }
  const okX = 49, btnY = 52, btnW = 30, btnH = 11;
  fill_rect(okX, btnY, btnW, btnH, 1);
  print(okX + 10, btnY + 2, "OK", 0);
}
function drawGlobalMenu() {
  if (S.tapTempoOpen) {
    drawTapTempoScreen();
    return;
  }
  if (S.exportDoneDialog) {
    drawExportDoneDialog();
    return;
  }
  if (S.confirmClearSession) {
    drawClearSessionConfirm();
    return;
  }
  if (S.confirmSaveState) {
    drawSaveStateConfirm();
    return;
  }
  if (S.confirmConvertToDrum) {
    drawConvertToDrumConfirm();
    return;
  }
  if (S.confirmConvertToConduct) {
    drawConvertToConductConfirm();
    return;
  }
  if (S.menuInfoLines.length > 0) {
    drawMenuInfo();
    return;
  }
  if (S.confirmExport || S.confirmExportCondPhase) {
    drawExportConfirm();
    return;
  }
  clear_screen();
  const _inTrackSection = S.globalMenuState.selectedIndex < 5;
  const _hTitle = _inTrackSection ? "Track " + (S.activeTrack + 1) : "Global";
  fill_rect(0, 1, 128, 10, 1);
  pixelPrintMcu(2, 4, _hTitle, 1, 0);
  fill_rect(0, 12, 128, 1, 1);
  drawMenuList({
    items: S.globalMenuItems,
    selectedIndex: S.globalMenuState.selectedIndex,
    listArea: { topY: menuLayoutDefaults.listTopY, bottomY: menuLayoutDefaults.listBottomNoFooter },
    valueX: 76,
    valueAlignRight: true,
    prioritizeSelectedValue: true,
    selectedMinLabelChars: 5,
    getLabel: function(item) {
      return item ? item.label || "" : "";
    },
    getValue: function(item, index) {
      if (!item) return "";
      const isEditing = S.globalMenuState.editing && index === S.globalMenuState.selectedIndex;
      return formatItemValue(item, isEditing, S.globalMenuState.editValue);
    }
  });
}
function drawStateWipeConfirm() {
  clear_screen();
  function _btn(x, y, w, h, sel, label, labelOff) {
    if (sel) {
      fill_rect(x, y, w, h, 1);
      print(x + labelOff, y + 3, label, 0);
    } else {
      fill_rect(x, y, w, 1, 1);
      fill_rect(x, y + h - 1, w, 1, 1);
      fill_rect(x, y, 1, h, 1);
      fill_rect(x + w - 1, y, 1, h, 1);
      print(x + labelOff, y + 3, label, 1);
    }
  }
  drawMenuHeader("Incompatible State");
  print(4, 16, "Session incompatible", 1);
  print(4, 25, "with current dB ver.", 1);
  print(4, 34, "Erase and proceed?", 1);
  _btn(6, 46, 46, 13, S.confirmStateWipeSel === 0, "Yes", 14);
  _btn(74, 46, 46, 13, S.confirmStateWipeSel === 1, "No", 17);
}
function drawRecordBlockedDialog() {
  clear_screen();
  function _btn(x, y, w, h, sel, label, labelOff) {
    if (sel) {
      fill_rect(x, y, w, h, 1);
      print(x + labelOff, y + 3, label, 0);
    } else {
      fill_rect(x, y, w, 1, 1);
      fill_rect(x, y + h - 1, w, 1, 1);
      fill_rect(x, y, 1, h, 1);
      fill_rect(x + w - 1, y, 1, h, 1);
      print(x + labelOff, y + 3, label, 1);
    }
  }
  drawMenuHeader("REC Unavailable");
  print(4, 16, "Set Dir to Fwd", 1);
  print(4, 25, "or Bake", 1);
  _btn(6, 46, 46, 13, S.recordBlockedDialogSel === 0, "OK", 19);
  _btn(58, 46, 64, 13, S.recordBlockedDialogSel === 1, "BAKE NOW", 6);
}
function drawBpmMoveInfo() {
  clear_screen();
  drawMenuHeader("Tempo");
  print(4, 20, "BPM controlled", 1);
  print(4, 30, "by Move", 1);
  fill_rect(49, 52, 30, 11, 1);
  print(59, 54, "OK", 0);
}
function drawLgtoConfirm() {
  clear_screen();
  function _btn(x, y, w, h, sel, label, labelOff) {
    if (sel) {
      fill_rect(x, y, w, h, 1);
      print(x + labelOff, y + 3, label, 0);
    } else {
      fill_rect(x, y, w, 1, 1);
      fill_rect(x, y + h - 1, w, 1, 1);
      fill_rect(x, y, 1, h, 1);
      fill_rect(x + w - 1, y, 1, h, 1);
      print(x + labelOff, y + 3, label, 1);
    }
  }
  drawMenuHeader(S.confirmLgtoIsDrum ? "Lgto (lane)" : "Lgto (clip)");
  print(4, 16, "Destructive", 1);
  print(4, 25, "Proceed?", 1);
  _btn(6, 46, 46, 13, S.confirmLgtoSel === 0, "OK", 19);
  _btn(58, 46, 64, 13, S.confirmLgtoSel === 1, "CANCEL", 14);
}
function drawBakeConfirm() {
  clear_screen();
  function _btn(x, y, w, h, sel, label, labelOff) {
    if (sel) {
      fill_rect(x, y, w, h, 1);
      print(x + labelOff, y + 3, label, 0);
    } else {
      fill_rect(x, y, w, 1, 1);
      fill_rect(x, y + h - 1, w, 1, 1);
      fill_rect(x, y, 1, h, 1);
      fill_rect(x + w - 1, y, 1, h, 1);
      print(x + labelOff, y + 3, label, 1);
    }
  }
  if (S.confirmBakeWrapPhase) {
    drawMenuHeader("WRAP TAILS?");
    print(4, 16, "Wrap delay echoes", 1);
    print(4, 25, "past clip end back", 1);
    print(4, 34, "to the beginning?", 1);
    const bW = 38, bH = 13, bY = 50;
    _btn(4, bY, bW, bH, S.confirmBakeWrapSel === 0, "YES", 9);
    _btn(45, bY, bW, bH, S.confirmBakeWrapSel === 1, "NO", 14);
    _btn(86, bY, bW, bH, S.confirmBakeWrapSel === 2, "CANCEL", 1);
  } else if (S.confirmBakeIsMultiLoop) {
    drawMenuHeader("BAKE FX?");
    print(4, 14, "Bake N loops of FX", 1);
    print(4, 23, "chain to clip?", 1);
    const bH = 12, bY = 38;
    _btn(2, bY, 27, bH, S.confirmBakeSel === 1, "1x", 9);
    _btn(31, bY, 27, bH, S.confirmBakeSel === 2, "2x", 9);
    _btn(60, bY, 27, bH, S.confirmBakeSel === 3, "4x", 9);
    _btn(89, bY, 37, bH, S.confirmBakeSel === 0, "CANCEL", 3);
  } else if (!S.confirmBakeIsDrum) {
    drawMenuHeader("BAKE FX?");
    print(4, 16, "Apply effects chain", 1);
    print(4, 25, "to clip notes and", 1);
    print(4, 34, "clear the settings.", 1);
    _btn(6, 46, 46, 13, S.confirmBakeSel === 1, "No", 17);
    _btn(74, 46, 46, 13, S.confirmBakeSel === 0, "Yes", 14);
  } else if (S.confirmBakeDrumLoopOpen) {
    const modeLabel = S.confirmBakeDrumMode === 1 ? "LANE" : "CLIP";
    drawMenuHeader("BAKE DRUMS?");
    print(4, 13, modeLabel + " \u2014 loop count:", 1);
    const mH = 11;
    _btn(14, 33, 100, mH, S.confirmBakeDrumLoopSel === 0, "CANCEL", 31);
    _btn(4, 47, 36, mH, S.confirmBakeDrumLoopSel === 1, "1x", 12);
    _btn(46, 47, 36, mH, S.confirmBakeDrumLoopSel === 2, "2x", 12);
    _btn(88, 47, 36, mH, S.confirmBakeDrumLoopSel === 3, "4x", 12);
  } else {
    drawMenuHeader("BAKE DRUMS?");
    print(4, 16, "Bake FX to clip", 1);
    print(4, 25, "(all lanes) or lane?", 1);
    const bW = 38, bH = 13, bY = 50;
    _btn(4, bY, bW, bH, S.confirmBakeSel === 0, "CLIP", 7);
    _btn(45, bY, bW, bH, S.confirmBakeSel === 1, "LANE", 7);
    _btn(86, bY, bW, bH, S.confirmBakeSel === 2, "CANCEL", 1);
  }
}
function drawInheritPicker() {
  clear_screen();
  const p2 = S.pendingInheritPicker;
  if (!p2) return;
  print(2, 2, "Copied Move set", 1);
  print(2, 10, "detected", 1);
  fill_rect(0, 18, 128, 1, 1);
  print(2, 20, "Inherit dAVEBOx", 1);
  print(2, 28, "state from?", 1);
  fill_rect(0, 36, 128, 1, 1);
  const total = p2.candidates.length + 1;
  const visible = 3;
  const sel = p2.selectedIndex;
  let top = Math.max(0, Math.min(sel - 1, total - visible));
  if (total <= visible) top = 0;
  const lineH = 9;
  const listTopY = 39;
  for (let i = 0; i < visible && top + i < total; i++) {
    const idx = top + i;
    const y = listTopY + i * lineH;
    const isBlank = idx === p2.candidates.length;
    const label = isBlank ? "Start blank" : p2.candidates[idx].name;
    const truncated = label.length > 20 ? label.substring(0, 19) + "\u2026" : label;
    if (idx === sel) {
      fill_rect(2, y - 1, 124, lineH - 1, 1);
      print(5, y, truncated, 0);
    } else {
      print(5, y, truncated, 1);
    }
  }
  if (top > 0) print(120, listTopY, "^", 1);
  if (top + visible < total) print(120, listTopY + (visible - 1) * lineH, "v", 1);
}
function snapById(p2, id) {
  for (let i = 0; i < p2.snaps.length; i++) if (p2.snaps[i].id === id) return p2.snaps[i];
  return null;
}
function drawSnapYesNo(sel) {
  const noX = 6, yesX = 74, btnY = 46, btnW = 46, btnH = 13;
  function btn(x, on, label, off) {
    if (on) {
      fill_rect(x, btnY, btnW, btnH, 1);
      print(x + off, btnY + 3, label, 0);
    } else {
      fill_rect(x, btnY, btnW, 1, 1);
      fill_rect(x, btnY + btnH - 1, btnW, 1, 1);
      fill_rect(x, btnY, 1, btnH, 1);
      fill_rect(x + btnW - 1, btnY, 1, btnH, 1);
      print(x + off, btnY + 3, label, 1);
    }
  }
  btn(noX, sel === 1, "No", 17);
  btn(yesX, sel === 0, "Yes", 14);
}
function drawSnapshotPicker() {
  clear_screen();
  const p2 = S.snapshotPicker;
  if (!p2) return;
  if (p2.confirm) {
    const c = p2.confirm;
    if (c.kind === "wipe") {
      drawMenuHeader("STATES UPDATED");
      print(4, 18, "Delete " + c.wipeIds.length + " snapshot(s)", 1);
      print(4, 27, "from an older", 1);
      print(4, 36, "version?", 1);
    } else if (c.kind === "load") {
      const s = snapById(p2, c.targetId);
      drawMenuHeader("LOAD STATE");
      print(4, 18, "Load " + (s ? s.label : ""), 1);
      print(4, 27, "Unsaved changes", 1);
      print(4, 36, "will be lost.", 1);
    } else {
      const s = snapById(p2, c.targetId);
      drawMenuHeader("OVERWRITE");
      print(4, 18, "Replace", 1);
      print(4, 27, (s ? s.label : "") + "?", 1);
    }
    drawSnapYesNo(c.sel);
    return;
  }
  drawMenuHeader(p2.mode === "overwrite" ? "OVERWRITE WHICH?" : "LOAD STATE");
  const total = p2.snaps.length;
  const visible = 4;
  const sel = p2.sel;
  let top = Math.max(0, Math.min(sel - 1, total - visible));
  if (total <= visible) top = 0;
  const lineH = 9;
  const listTopY = 20;
  for (let i = 0; i < visible && top + i < total; i++) {
    const idx = top + i;
    const y = listTopY + i * lineH;
    const s = p2.snaps[idx];
    let label = s.label || "";
    if (p2.mode === "load" && s.sv !== STATE_VERSION) label += " (old)";
    const truncated = label.length > 20 ? label.substring(0, 19) + "\u2026" : label;
    if (idx === sel) {
      fill_rect(2, y - 1, 124, lineH - 1, 1);
      print(5, y, truncated, 0);
    } else {
      print(5, y, truncated, 1);
    }
  }
  if (top > 0) print(120, listTopY, "^", 1);
  if (top + visible < total) print(120, listTopY + (visible - 1) * lineH, "v", 1);
}
function drawClearAutoMenu() {
  clear_screen();
  const m = S.clearAutoMenu;
  if (!m) return;
  drawMenuHeader("CLEAR AUTOMATION");
  const rows = [
    { label: "Aftertouch (AT)", box: m.at ? "[x]" : "[ ]" },
    { label: "Pitch bend (PB)", box: "( )" },
    /* placeholder, not selectable */
    { label: "Control Change (CC)", box: m.cc ? "[x]" : "[ ]" },
    { label: "CLEAR", action: true },
    { label: "Cancel", action: true }
  ];
  const lineH = 9, topY = 18;
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const y = topY + i * lineH;
    const seld = m.sel === i;
    if (seld) fill_rect(2, y - 1, 124, lineH - 1, 1);
    const txt = r.action ? r.label : r.box + " " + r.label;
    print(5, y, txt, seld ? 0 : 1);
  }
}
function drawBakeSceneConfirm() {
  clear_screen();
  function _btn(x, y, w, h, sel, label, labelOff) {
    if (sel) {
      fill_rect(x, y, w, h, 1);
      print(x + labelOff, y + 3, label, 0);
    } else {
      fill_rect(x, y, w, 1, 1);
      fill_rect(x, y + h - 1, w, 1, 1);
      fill_rect(x, y, 1, h, 1);
      fill_rect(x + w - 1, y, 1, h, 1);
      print(x + labelOff, y + 3, label, 1);
    }
  }
  drawMenuHeader("BAKE SCENE?");
  const mH = 11;
  if (S.confirmBakeSceneCondPhase) {
    print(4, 22, "Apply Conductor?", 1);
    const bY = 47, bW = 36;
    _btn(4, bY, bW, mH, S.confirmBakeSceneCondSel === 0, "YES", 9);
    _btn(45, bY, bW, mH, S.confirmBakeSceneCondSel === 1, "NO", 14);
    _btn(86, bY, bW, mH, S.confirmBakeSceneCondSel === 2, "CANCEL", 1);
  } else if (S.confirmBakeSceneWrapPhase) {
    print(4, 22, "Wrap tails?", 1);
    const bY = 47, bW = 36;
    _btn(4, bY, bW, mH, S.confirmBakeSceneWrapSel === 0, "YES", 9);
    _btn(45, bY, bW, mH, S.confirmBakeSceneWrapSel === 1, "NO", 14);
    _btn(86, bY, bW, mH, S.confirmBakeSceneWrapSel === 2, "CANCEL", 1);
  } else {
    print(4, 22, "Loop count:", 1);
    _btn(14, 33, 100, mH, S.confirmBakeSceneSel === 0, "CANCEL", 31);
    _btn(4, 47, 36, mH, S.confirmBakeSceneSel === 1, "1x", 12);
    _btn(46, 47, 36, mH, S.confirmBakeSceneSel === 2, "2x", 12);
    _btn(88, 47, 36, mH, S.confirmBakeSceneSel === 3, "4x", 12);
  }
}
function drawXposeConfirm() {
  clear_screen();
  function _btn(x, y, w, h, sel, label, labelOff) {
    if (sel) {
      fill_rect(x, y, w, h, 1);
      print(x + labelOff, y + 3, label, 0);
    } else {
      fill_rect(x, y, w, 1, 1);
      fill_rect(x, y + h - 1, w, 1, 1);
      fill_rect(x, y, 1, h, 1);
      fill_rect(x + w - 1, y, 1, h, 1);
      print(x + labelOff, y + 3, label, 1);
    }
  }
  drawMenuHeader("TRANSPOSE CLIPS?");
  const tgt = NOTE_KEYS[S.confirmXposeKey] + " " + (SCALE_DISPLAY[S.confirmXposeScale] || "?");
  print(4, 22, "To " + tgt, 1);
  print(4, 33, "All melodic clips", 1);
  const mH = 11, bY = 50, bW = 50;
  _btn(4, bY, bW, mH, S.confirmXposeSel === 0, "YES", 17);
  _btn(74, bY, bW, mH, S.confirmXposeSel === 1, "NO", 20);
}
function beginSnapshotSave(id) {
  S.pendingSnapshotCopy = { id, label: snapshotLabel() };
  saveState();
}
function openSaveSnapshot() {
  if (S.pendingSuspendSave || S.pendingSnapshotCopy) return;
  const snaps = loadSnapshotManifest(S.currentSetUuid);
  if (snaps.length >= SNAPSHOT_CAP) {
    S.snapshotPicker = { mode: "overwrite", snaps, sel: 0, confirm: null };
    S.globalMenuOpen = false;
    S.screenDirty = true;
    return;
  }
  beginSnapshotSave(String(Date.now()));
  S.globalMenuOpen = false;
  showActionPopup("STATE", "SAVED");
}
function openLoadSnapshot() {
  const snaps = loadSnapshotManifest(S.currentSetUuid);
  if (snaps.length === 0) {
    S.globalMenuOpen = false;
    showActionPopup("NO", "SNAPSHOTS");
    return;
  }
  const stale = [];
  for (let i = 0; i < snaps.length; i++)
    if (snaps[i].sv !== STATE_VERSION) stale.push(snaps[i].id);
  S.snapshotPicker = { mode: "load", snaps, sel: 0, confirm: null };
  if (stale.length > 0)
    S.snapshotPicker.confirm = { kind: "wipe", sel: 1, wipeIds: stale };
  S.globalMenuOpen = false;
  S.screenDirty = true;
}
function closeSnapshotPicker() {
  S.snapshotPicker = null;
  S.screenDirty = true;
}
function snapshotPickerRotate(delta) {
  const p2 = S.snapshotPicker;
  if (!p2 || delta === 0) return;
  if (p2.confirm) {
    p2.confirm.sel = p2.confirm.sel === 0 ? 1 : 0;
  } else {
    const n = p2.snaps.length;
    if (n > 0) p2.sel = (p2.sel + (delta > 0 ? 1 : n - 1)) % n;
  }
  S.screenDirty = true;
}
function snapshotPickerClick() {
  const p2 = S.snapshotPicker;
  if (!p2) return;
  if (p2.confirm) {
    const yes = p2.confirm.sel === 0;
    const kind = p2.confirm.kind;
    if (kind === "wipe") {
      if (yes) {
        p2.snaps = dropSnapshots(S.currentSetUuid, p2.confirm.wipeIds);
        p2.sel = 0;
      }
      p2.confirm = null;
      if (p2.snaps.length === 0) closeSnapshotPicker();
      else S.screenDirty = true;
      return;
    }
    const id = p2.confirm.targetId;
    closeSnapshotPicker();
    if (kind === "load" && yes) {
      applySnapshotToLive(S.currentSetUuid, id);
      S.pendingSetLoad = true;
      showActionPopup("STATE", "LOADED");
    } else if (kind === "overwrite" && yes) {
      beginSnapshotSave(id);
      showActionPopup("STATE", "SAVED");
    }
    return;
  }
  const snap = p2.snaps[p2.sel];
  if (!snap) return;
  if (p2.mode === "load") {
    if (snap.sv !== STATE_VERSION) return;
    p2.confirm = { kind: "load", sel: 1, targetId: snap.id };
  } else {
    p2.confirm = { kind: "overwrite", sel: 1, targetId: snap.id };
  }
  S.screenDirty = true;
}
function openClearAutoMenu() {
  S.clearAutoMenu = { sel: 0, at: false, cc: false };
  S.screenDirty = true;
}
function closeClearAutoMenu() {
  S.clearAutoMenu = null;
  S.screenDirty = true;
}
function clearAutoMenuRotate(delta) {
  const m = S.clearAutoMenu;
  if (!m || delta === 0) return;
  m.sel = (m.sel + (delta > 0 ? 1 : 4)) % 5;
  S.screenDirty = true;
}
function clearAutoMenuClick() {
  const m = S.clearAutoMenu;
  if (!m) return;
  if (m.sel === 0) {
    m.at = !m.at;
  } else if (m.sel === 1) {
  } else if (m.sel === 2) {
    m.cc = !m.cc;
  } else if (m.sel === 4) {
    closeClearAutoMenu();
    return;
  } else {
    const t = S.activeTrack, c = effectiveClip(t);
    if (m.cc) {
      S.trackCCAutoBits[t][c] = 0;
      S.trackCCLiveVal[t] = new Array(8).fill(-1);
      S.clipCCVal[t][c] = new Array(8).fill(-1);
      S.pendingDefaultSetParams.push({ key: "t" + t + "_cc_auto_clear", val: String(c) });
    }
    if (m.at) {
      S.clipAtHas[t][c] = false;
      S.pendingDefaultSetParams.push({ key: "t" + t + "_c" + c + "_at_clear", val: "1" });
    }
    const done = [];
    if (m.at) done.push("AT");
    if (m.cc) done.push("CC");
    if (done.length) {
      S.undoAvailable = true;
      S.redoAvailable = false;
      S.undoSeqArpSnapshot = null;
    }
    closeClearAutoMenu();
    invalidateLEDCache();
    showActionPopup("CLEARED", done.length ? done.join(" ") : "NOTHING");
    return;
  }
  S.screenDirty = true;
}
function showMenuInfo() {
  S.menuInfoLines = Array.prototype.slice.call(arguments);
  S.screenDirty = true;
}
function closeConvertConfirm() {
  S.confirmConvertToDrum = false;
  S.confirmConvertToConduct = false;
  S.menuInfoLines = [];
  if (S.globalMenuState) S.globalMenuState.editing = false;
  if (S.globalMenuState) S.globalMenuState.editValue = null;
  S.lastSentMenuEditValue = null;
  S.bpmWasEditing = false;
}
function resolveInheritPicker(action) {
  const p2 = S.pendingInheritPicker;
  if (!p2) return;
  if (action >= 0 && action < p2.candidates.length) {
    copyStateFiles(p2.candidates[action].uuid, p2.dstUuid);
  }
  S.pendingSetLoad = true;
  S.pendingInheritPicker = null;
  S.screenDirty = true;
}

// ui/ui_drummodel.mjs
function _padDispatchMutedNow() {
  if (S.sessionView) return true;
  if (S.shiftHeld || S.deleteHeld || S.muteHeld || S.copyHeld || S.loopHeld || S.tapTempoOpen) return true;
  if ((S.activeBank === 4 || S.activeBank === 5) && S.knobTouched === 4 && S.bankParams[S.activeTrack] && ((S.bankParams[S.activeTrack][S.activeBank] || [])[4] | 0) !== 0) return true;
  if (S.stepIntervalMode && (S.activeBank === 4 || S.activeBank === 5)) return true;
  return false;
}
function computePadNoteMap() {
  const t = S.activeTrack;
  if (S.trackPadMode[t] === PAD_MODE_DRUM) {
    const page = S.drumLanePage[t] | 0;
    const coRunSilentLeft = S.moveCoRunTrack >= 0;
    for (let i = 0; i < 32; i++) {
      const col = i % 8;
      if (col >= 4) {
        S.padNoteMap[i] = 255;
        continue;
      }
      if (coRunSilentLeft) {
        S.padNoteMap[i] = 255;
        continue;
      }
      const row = Math.floor(i / 8);
      const lane = page * 16 + row * 4 + col;
      const note = lane >= 0 && lane < DRUM_LANES ? S.drumLaneNote[t][lane] | 0 || DRUM_BASE_NOTE + lane : 255;
      S.padNoteMap[i] = note & 255;
    }
  } else {
    const effKey = S.xposePrevKey !== null ? S.xposePrevKey : S.padKey;
    const effScale = S.xposePrevScale !== null ? S.xposePrevScale : S.padScale;
    const root = S.padOctave[t] * 12 + effKey;
    const intervals = SCALE_INTERVALS[effScale] || SCALE_INTERVALS[0];
    S.padScaleSet.clear();
    for (let i = 0; i < intervals.length; i++) S.padScaleSet.add(intervals[i]);
    if (S.padLayoutChromatic[t]) {
      for (let i = 0; i < 32; i++) {
        const col = i % 8;
        const row = Math.floor(i / 8);
        const p2 = root + col + row * 8;
        S.padNoteMap[i] = p2 < 0 || p2 > 127 ? 255 : p2;
      }
    } else {
      const n = intervals.length;
      for (let i = 0; i < 32; i++) {
        const col = i % 8;
        const row = Math.floor(i / 8);
        const deg = col + row * 3;
        const oct = Math.floor(deg / n);
        const semitone = oct * 12 + intervals[deg % n];
        const p2 = root + semitone;
        S.padNoteMap[i] = p2 < 0 || p2 > 127 ? 255 : p2;
      }
    }
  }
  if (S.dspInboundEnabled && typeof host_module_set_param === "function") {
    const padDispatchMuted = _padDispatchMutedNow();
    const isDrum = S.trackPadMode[t] === PAD_MODE_DRUM;
    const octShift = isDrum ? 0 : (S.trackOctave[t] | 0) * 12;
    let payload = "";
    for (let i = 0; i < 32; i++) {
      let out;
      if (padDispatchMuted && S.sessionView) {
        out = 255;
      } else if (padDispatchMuted) {
        const p2 = S.padNoteMap[i];
        out = p2 === 255 ? 255 : Math.max(0, Math.min(127, p2 + octShift));
      } else {
        const p2 = S.padNoteMap[i];
        out = p2 === 255 ? 255 : Math.max(0, Math.min(127, p2 + octShift));
      }
      payload += (i ? " " : "") + out;
    }
    payload += " " + (padDispatchMuted ? 1 : 0);
    payload += " " + (S.deleteHeld ? 1 : 0);
    payload += " " + (isDrum && S.moveCoRunTrack >= 0 ? 1 : 0);
    host_module_set_param("t" + t + "_padmap", payload);
    S.lastPushedMuted = padDispatchMuted;
  }
}
function syncDrumLaneSteps(t, l) {
  if (typeof host_module_get_param !== "function") return;
  const raw = host_module_get_param("t" + t + "_l" + l + "_steps");
  if (raw) {
    for (let s = 0; s < 256; s++) S.drumLaneSteps[t][l][s] = raw[s] || "0";
    S.drumLaneHasNotes[t][l] = raw.indexOf("1") >= 0;
  }
  if (l === S.activeDrumLane[t]) {
    const lenRaw = host_module_get_param("t" + t + "_l" + l + "_length");
    if (lenRaw !== null) S.drumLaneLength[t] = parseInt(lenRaw, 10) || 16;
    const lsRaw = host_module_get_param("t" + t + "_l" + l + "_loop_start");
    if (lsRaw !== null) S.drumLaneLoopStart[t] = parseInt(lsRaw, 10) | 0;
    const lsPage = Math.floor(S.drumLaneLoopStart[t] / 16);
    const winPages = Math.max(1, Math.ceil(S.drumLaneLength[t] / 16));
    if (S.drumStepPage[t] < lsPage) S.drumStepPage[t] = lsPage;
    else if (S.drumStepPage[t] > lsPage + winPages - 1) S.drumStepPage[t] = lsPage + winPages - 1;
    const tpsRaw = host_module_get_param("t" + t + "_l" + l + "_tps");
    if (tpsRaw !== null) S.drumLaneTPS[t] = parseInt(tpsRaw, 10) || 24;
  }
}
function syncDrumLanesMeta(t) {
  if (typeof host_module_get_param !== "function") return;
  const raw = host_module_get_param("t" + t + "_drum_meta");
  if (!raw) return;
  const v = raw.split(" ");
  if (v.length < DRUM_LANES * 2 + 2) return;
  for (let l = 0; l < DRUM_LANES; l++) {
    const note = parseInt(v[l * 2], 10);
    S.drumLaneNote[t][l] = note >= 0 ? note : DRUM_BASE_NOTE + l;
    S.drumLaneHasNotes[t][l] = v[l * 2 + 1] === "1";
  }
  S.drumLaneMute[t] = parseInt(v[DRUM_LANES * 2], 10) >>> 0;
  S.drumLaneSolo[t] = parseInt(v[DRUM_LANES * 2 + 1], 10) >>> 0;
}
function setActiveDrumLane(t, lane) {
  if (S.activeDrumLane[t] === lane) return;
  const arr = S.activeDrumLane;
  arr[t] = lane;
  if (typeof host_module_set_param === "function")
    host_module_set_param("t" + t + "_active_drum_lane", String(lane));
}
function setDrumPerformMode(t, mode) {
  if (S.drumPerformMode[t] === mode) return;
  const arrPm = S.drumPerformMode;
  arrPm[t] = mode;
  if (typeof host_module_set_param === "function")
    host_module_set_param("t" + t + "_drum_perform_mode", String(mode));
}
function setDrumLanePage(t, page) {
  if (S.drumLanePage[t] === page) return;
  const arrLp = S.drumLanePage;
  arrLp[t] = page;
  if (typeof host_module_set_param === "function")
    host_module_set_param("t" + t + "_drum_lane_page", String(page));
}
function syncDrumClipContent(t) {
  if (typeof host_module_get_param !== "function") return;
  for (let c = 0; c < NUM_CLIPS; c++) {
    const raw = host_module_get_param("t" + t + "_c" + c + "_drum_has_content");
    S.drumClipNonEmpty[t][c] = raw === "1";
  }
}
function syncDrumRepeatState(t, lane) {
  if (typeof host_module_get_param !== "function") return;
  const raw = host_module_get_param("t" + t + "_l" + lane + "_repeat_state");
  if (!raw) return;
  const v = raw.split(" ");
  if (v.length < 18) return;
  S.drumRepeatGate[t][lane] = parseInt(v[0], 10) & 255;
  for (let s = 0; s < 8; s++) S.drumRepeatVelScale[t][lane][s] = parseInt(v[1 + s], 10) | 0;
  for (let s = 0; s < 8; s++) S.drumRepeatNudge[t][lane][s] = parseInt(v[9 + s], 10) | 0;
  if (v.length >= 19) S.drumRepeatGateLen[t][lane] = parseInt(v[18], 10) || 8;
}

// ui/ui_corun.mjs
var CORUN_TARGET_CHAIN_EDIT = 1;
var CORUN_TARGET_MOVE_NATIVE = 2;
var CORUN_GRP_PADS = 1 << 1;
var CORUN_GRP_STEPS = 1 << 2;
var CORUN_GRP_TRANSPORT = 1 << 3;
var CORUN_GRP_MENU = 1 << 10;
var DAVEBOX_CORUN_KEEP_DEFAULT = CORUN_GRP_PADS | CORUN_GRP_STEPS | CORUN_GRP_TRANSPORT | CORUN_GRP_MENU;
var CORUN_KEEP_BACK_BIT = 1 << 15;
var DAVEBOX_CORUN_KEEP_MASK = DAVEBOX_CORUN_KEEP_DEFAULT | CORUN_KEEP_BACK_BIT;
var CORUN_GRP_JOG = 1 << 4;
var CORUN_GRP_TRACK = 1 << 5;
var CORUN_GRP_KNOBS = 1 << 6;
var CORUN_GRP_SHIFT = 1 << 8;
var CORUN_GRP_BACK = 1 << 9;
var CORUN_GRP_TOUCH = 1 << 11;
var CORUN_GRP_MUTE = 1 << 12;
var DAVEBOX_CORUN_LED_KEEP_MASK = DAVEBOX_CORUN_KEEP_MASK | CORUN_GRP_TRACK;
var DAVEBOX_CHAIN_KEEP_MASK = DAVEBOX_CORUN_KEEP_MASK | CORUN_GRP_MUTE;
var DAVEBOX_CHAIN_LED_KEEP_MASK = DAVEBOX_CORUN_LED_KEEP_MASK | CORUN_GRP_MUTE;
var DAVEBOX_PICKER_KEEP_MASK = DAVEBOX_CORUN_KEEP_MASK | CORUN_GRP_JOG | CORUN_GRP_BACK | CORUN_GRP_KNOBS | CORUN_GRP_TOUCH | CORUN_GRP_SHIFT;
function schSlotForTrack(t) {
  const m = schSlotsForTrack(t);
  if (m === 0) return -1;
  let i = 0;
  while (!(m & 1 << i)) i++;
  return i;
}
function schSlotsForTrack(t) {
  if (typeof shadow_get_slots !== "function") return 0;
  const ch = S.trackChannel[t];
  const slots = shadow_get_slots();
  if (!slots) return 0;
  let mask = 0;
  for (let i = 0; i < slots.length && i < 4; i++) {
    if (slots[i].channel === ch || slots[i].channel === 0) mask |= 1 << i;
  }
  return mask;
}
function openSchwungSlotEditor(t) {
  if (S.trackRoute[t] !== 0) {
    showActionPopup("NOT", "SCHWUNG-ROUTED");
    return;
  }
  S.globalMenuOpen = false;
  S.lastSentMenuEditValue = null;
  S.pendingSchwungCoRunTrack = t;
  S.screenDirty = true;
}
function enterSchwungCoRun(t, slot) {
  S.schwungCoRunSlot = slot;
  if (typeof shadow_corun_begin === "function")
    shadow_corun_begin(CORUN_TARGET_CHAIN_EDIT, slot, DAVEBOX_CHAIN_KEEP_MASK);
  if (typeof shadow_corun_set_led_keep_mask === "function")
    shadow_corun_set_led_keep_mask(DAVEBOX_CHAIN_LED_KEEP_MASK);
  S.screenDirty = true;
}
function exitSchwungCoRun() {
  if (S.schwungCoRunSlot < 0) return;
  S.schwungCoRunSlot = -1;
  S._coRunChanSlots = 0;
  if (typeof shadow_corun_end === "function")
    shadow_corun_end();
  S.shiftHeld = false;
  S.deleteHeld = false;
  S.muteHeld = false;
  S.copyHeld = false;
  S.loopHeld = false;
  S.loopJogActive = false;
  S.captureHeld = false;
  S.shiftTrackLEDActive = false;
  assertOvertakeSysexSuppress();
  reapplyPalette();
  invalidateLEDCache();
  S._forceKnobReemit = true;
  forceRedraw();
}
function enterMoveNativeCoRun(t) {
  if (typeof shadow_corun_begin !== "function") return;
  if (typeof move_midi_inject_to_move !== "function") return;
  S.moveCoRunTrack = t;
  computePadNoteMap();
  S.pendingPadNoteMapRecompute = true;
  shadow_corun_begin(CORUN_TARGET_MOVE_NATIVE, t, DAVEBOX_CORUN_KEEP_MASK);
  if (typeof shadow_corun_set_led_keep_mask === "function")
    shadow_corun_set_led_keep_mask(DAVEBOX_CORUN_LED_KEEP_MASK);
  if (typeof shadow_set_skip_led_clear === "function") shadow_set_skip_led_clear(1);
  S.pendingMoveCoRunInject = 12;
  S.globalMenuOpen = false;
  S.lastSentMenuEditValue = null;
  S.screenDirty = true;
}
function exitMoveNativeCoRun() {
  if (S.moveCoRunTrack < 0) return;
  S.moveCoRunTrack = -1;
  S.pendingMoveCoRunInject = 0;
  S.moveCoRunPressQueue = null;
  computePadNoteMap();
  S.pendingPadNoteMapRecompute = true;
  if (typeof shadow_corun_end === "function")
    shadow_corun_end();
  if (typeof shadow_set_skip_led_clear === "function") shadow_set_skip_led_clear(0);
  if (S.moveCoRunDrumHeld.size > 0 && typeof move_midi_inject_to_move === "function") {
    for (const _heldPad of S.moveCoRunDrumHeld)
      move_midi_inject_to_move([8, 128, _heldPad, 0]);
  }
  S.moveCoRunDrumHeld.clear();
  S.shiftHeld = false;
  S.deleteHeld = false;
  S.muteHeld = false;
  S.copyHeld = false;
  S.loopHeld = false;
  S.loopJogActive = false;
  S.captureHeld = false;
  S.shiftTrackLEDActive = false;
  assertOvertakeSysexSuppress();
  reapplyPalette();
  invalidateLEDCache();
  S._forceKnobReemit = true;
  forceRedraw();
}
function assertOvertakeSysexSuppress() {
  if (typeof shadow_set_overtake_suppress_sysex === "function")
    shadow_set_overtake_suppress_sysex(1);
}

// ui/ui_dsp_bridge.mjs
import {
  setButtonLED as setButtonLED3
} from "/data/UserData/schwung/shared/input_filter.mjs";
import { Red as Red3 } from "/data/UserData/schwung/shared/constants.mjs";

// ui/ui_record.mjs
import { setButtonLED as setButtonLED2 } from "/data/UserData/schwung/shared/input_filter.mjs";
var _recordingNoteTrack = /* @__PURE__ */ new Map();
var extHeldNotes = /* @__PURE__ */ new Map();
function disarmRecord() {
  if (!S.recordArmed) return;
  const t = S.recordArmedTrack;
  const _wasCountingIn = S.recordCountingIn;
  S.recordArmed = false;
  S.recordPendingPage = false;
  S.recordCountingIn = false;
  S.recordArmedTrack = -1;
  S.countInStartTick = -1;
  S.countInQuarterTicks = 0;
  _recordingNoteTrack.clear();
  S._recNoteOns.length = 0;
  S._recNoteOffs.length = 0;
  _drumRecNoteOns.length = 0;
  _drumRecNoteOffs.length = 0;
  S.pendingPrerollNote = null;
  S.pendingPrerollNotes = [];
  S.pendingPrerollToggleQueue = [];
  S.pendingPrerollGate = null;
  if (t >= 0) {
    const _dat = S.trackActiveClip[t];
    S.clipAdaptiveMode[t][_dat] = false;
    if (S.trackPadMode[t] === PAD_MODE_DRUM) {
      S.pendingDrumResync = 2;
      S.pendingDrumResyncTrack = t;
    }
  }
  S.recordScheduledStop = false;
  S.recordScheduledStopTarget = -1;
  S.pendingScheduledDisarm = false;
  if (typeof host_module_set_param === "function") {
    if (_wasCountingIn) {
      host_module_set_param("record_count_in_cancel", "1");
    } else {
      if (t >= 0) {
        host_module_set_param("t" + t + "_recording", "0");
        S.recOffTrack = t;
        S.recOffTicks = 5;
      }
    }
  }
  setButtonLED2(MoveRec, LED_OFF);
}
function handoffRecordingToTrack(newTrack) {
  if (!S.recordArmed || S.recordCountingIn || newTrack === S.recordArmedTrack) return;
  const old = S.recordArmedTrack;
  _recordingNoteTrack.clear();
  S.recordArmedTrack = newTrack;
  if (typeof host_module_set_param === "function") {
    if (old >= 0) host_module_set_param("t" + old + "_recording", "0");
    host_module_set_param("t" + newTrack + "_recording", "1");
  }
}
function recordNoteOn(pitch, velocity, rt, ext) {
  _recordingNoteTrack.set(pitch, rt);
  S._recNoteOns.push({ pitch, vel: velocity, rt, ext: !!ext });
}
function recordNoteOff(pitch, ext) {
  const rt = _recordingNoteTrack.get(pitch);
  if (rt === void 0) return;
  _recordingNoteTrack.delete(pitch);
  S._recNoteOffs.push({ pitch, rt, ext: !!ext });
}
function extCountInCapture() {
  if (!S.recordCountingIn) return true;
  if (S.countInQuarterTicks <= 0 || S.countInStartTick < 0) return true;
  const endTick = S.countInStartTick + 4 * S.countInQuarterTicks;
  return endTick - S.tickCount <= S.countInQuarterTicks >> 1;
}
function openTapTempo() {
  S.tapTempoOpen = true;
  S.tapTempoTapTimes = [];
  S.tapTempoBpm = Math.max(40, Math.min(250, Math.round(parseFloat(host_module_get_param("bpm")) || 120)));
  S.tapTempoFlashTick = -1;
  S.tapTempoFlashPad = -1;
  computePadNoteMap();
  invalidateLEDCache();
  S.screenDirty = true;
}
function closeTapTempo() {
  S.tapTempoOpen = false;
  if (typeof host_module_set_param === "function")
    host_module_set_param("bpm", String(S.tapTempoBpm));
  computePadNoteMap();
  invalidateLEDCache();
  S.screenDirty = true;
}
function registerTapTempo(padNote) {
  const nowMs = Date.now();
  const taps = S.tapTempoTapTimes;
  const last = taps.length > 0 ? taps[taps.length - 1] : -1;
  const intvl = last >= 0 ? nowMs - last : -1;
  if (intvl > TAP_TEMPO_RESET_MS) {
    S.tapTempoTapTimes = [nowMs];
  } else if (intvl > 0 && taps.length >= 2) {
    const prevIntvl = taps[taps.length - 1] - taps[taps.length - 2];
    const ratio = intvl / prevIntvl;
    if (ratio > 1.8 || ratio < 0.55) {
      S.tapTempoTapTimes = [last, nowMs];
    } else {
      taps.push(nowMs);
      if (taps.length > 9) S.tapTempoTapTimes = taps.slice(-9);
    }
  } else {
    taps.push(nowMs);
  }
  if (S.tapTempoTapTimes.length >= 2) {
    const t = S.tapTempoTapTimes;
    const n = t.length;
    const avgInterval = (t[n - 1] - t[0]) / (n - 1);
    if (avgInterval > 0) {
      S.tapTempoBpm = Math.max(40, Math.min(250, Math.round(6e4 / avgInterval)));
      host_module_set_param("bpm", String(S.tapTempoBpm));
    }
  }
  S.tapTempoFlashTick = S.tickCount;
  S.tapTempoFlashPad = padNote;
  S.screenDirty = true;
}
function flushHeldMoveExtNotes() {
  if (extHeldNotes.size === 0) return;
  for (const [pitch, info] of extHeldNotes) {
    if (S.trackRoute[info.track] !== 1) continue;
    const ch = S.trackChannel[info.track] - 1 & 15;
    if (typeof move_midi_inject_to_move === "function")
      move_midi_inject_to_move([40, 128 | ch, pitch, 0]);
    if (info.recording) recordNoteOff(pitch, true);
    extHeldNotes.delete(pitch);
  }
}
function extNoteOffAll() {
  if (extHeldNotes.size === 0) return;
  for (const [pitch, info] of extHeldNotes) {
    liveSendNote(info.track, 128, pitch, 0, false, S.trackRoute[info.track] !== 1);
    if (info.recording) recordNoteOff(pitch, true);
  }
  extHeldNotes.clear();
}

// ui/ui_dsp_bridge.mjs
var pendingLiveNotes = Array.from({ length: NUM_TRACKS }, () => []);
var pendingDrumNoteOffs = Array.from({ length: NUM_TRACKS }, () => []);
var _drumRecNoteOns = [];
var _drumRecNoteOffs = [];
var PER_CLIP_BANKS = [1, 2, 3, 4];
function refreshSeqNotesIfCurrent(t, ac, absIdx) {
  if (absIdx !== S.trackCurrentStep[t] || ac !== S.trackActiveClip[t]) return;
  S.seqActiveNotes.clear();
  S.seqLastStep = -1;
  S.seqNoteOnClipTick = -1;
  if (S.clipSteps[t][ac][absIdx] && typeof host_module_get_param === "function") {
    const r = host_module_get_param("t" + t + "_c" + ac + "_step_" + absIdx + "_notes");
    if (r && r.trim().length > 0)
      r.trim().split(" ").forEach(function(sn) {
        const p2 = parseInt(sn, 10);
        if (p2 >= 0 && p2 <= 127) S.seqActiveNotes.add(p2);
      });
  }
}
function refreshDrumLaneBankParams(t, lane) {
  if (typeof host_module_get_param !== "function") return;
  const snap = host_module_get_param("t" + t + "_l" + lane + "_pfx_snapshot");
  if (snap) {
    const v = snap.split(" ");
    if (v.length >= 9) {
      S.bankParams[t][1][0] = parseInt(v[0], 10) | 0;
      S.bankParams[t][1][1] = parseInt(v[1], 10) | 0;
      S.bankParams[t][1][2] = parseInt(v[2], 10) | 0;
      S.drumLaneQnt[t] = S.bankParams[t][1][2];
      for (let k = 0; k < 6; k++) S.bankParams[t][3][k] = parseInt(v[3 + k], 10) | 0;
      if (v.length >= 10) S.bankParams[t][3][6] = parseInt(v[9], 10) | 0;
      if (v.length >= 11) S.drumLaneLenMode[t][lane] = parseInt(v[10], 10) | 0;
    }
  }
  const tpsIdx = TPS_VALUES.indexOf(S.drumLaneTPS[t]);
  S.bankParams[t][0][0] = tpsIdx >= 0 ? tpsIdx : 1;
  S.bankParams[t][0][4] = S.drumLaneEuclidN[t][lane] | 0;
  {
    const _pd = host_module_get_param("t" + t + "_l" + lane + "_playback_dir");
    const _pdv = parseInt(_pd, 10);
    const _pdvi = isFinite(_pdv) && _pdv >= 0 && _pdv <= 3 ? _pdv : 0;
    S.drumLanePlaybackDir[t][lane] = _pdvi;
    S.bankParams[t][0][6] = _pdvi;
    const _par = host_module_get_param("t" + t + "_l" + lane + "_playback_audio_reverse");
    const _parv = parseInt(_par, 10);
    S.drumLanePlaybackAudioReverse[t][lane] = isFinite(_parv) && _parv === 1 ? 1 : 0;
  }
  S.bankParams[t][0][7] = S.clipSeqFollow[t][S.trackActiveClip[t]] ? 1 : 0;
  syncDrumRepeatState(t, lane);
  S.screenDirty = true;
}
function resyncDrumTrack(t) {
  syncDrumLanesMeta(t);
  syncDrumLaneSteps(t, S.activeDrumLane[t]);
  syncDrumClipContent(t);
  refreshDrumLaneBankParams(t, S.activeDrumLane[t]);
}
function refreshPerClipBankParams(t) {
  if (typeof host_module_get_param !== "function") return;
  if (S.trackPadMode[t] === PAD_MODE_DRUM) {
    refreshDrumLaneBankParams(t, S.activeDrumLane[t]);
    return;
  }
  const ac = S.trackActiveClip[t];
  const snap = host_module_get_param("t" + t + "_c" + ac + "_pfx_snapshot");
  if (!snap) return;
  const v = snap.split(" ");
  if (v.length < 17) return;
  S.bankParams[t][1][0] = parseInt(v[0], 10) | 0;
  S.bankParams[t][1][1] = parseInt(v[1], 10) | 0;
  S.bankParams[t][1][2] = parseInt(v[3], 10) | 0;
  S.bankParams[t][1][3] = parseInt(v[4], 10) | 0;
  S.bankParams[t][1][4] = v.length >= 44 ? parseInt(v[43], 10) | 0 : 0;
  S.bankParams[t][1][5] = parseInt(v[2], 10) | 0;
  S.bankParams[t][1][7] = v.length >= 32 ? parseInt(v[31], 10) | 0 : 0;
  S.noteFXRandomMode[t] = v.length >= 33 ? parseInt(v[32], 10) | 0 : 2;
  S.midiDlyRandomMode[t] = v.length >= 34 ? parseInt(v[33], 10) | 0 : 2;
  for (let k = 0; k < 4; k++) S.bankParams[t][2][k] = parseInt(v[5 + k], 10) | 0;
  for (let k = 0; k < 8; k++) S.bankParams[t][3][k] = parseInt(v[9 + k], 10) | 0;
  if (v.length >= 23) {
    for (let k = 0; k < 6; k++) S.bankParams[t][4][k] = parseInt(v[17 + k], 10) | 0;
  }
  if (v.length >= 31) {
    for (let s = 0; s < 8; s++) S.seqArpStepVel[t][ac][s] = parseInt(v[23 + s], 10) | 0;
  }
  if (v.length >= 42) {
    for (let s = 0; s < 8; s++) S.seqArpStepInt[t][ac][s] = parseInt(v[34 + s], 10) | 0;
  }
  if (v.length >= 43) {
    const _ll = parseInt(v[42], 10) | 0;
    S.seqArpStepLoopLen[t][ac] = _ll >= 1 && _ll <= 8 ? _ll : 8;
  }
  const tps = S.clipTPS[t][ac] || 24;
  const tpsIdx = TPS_VALUES.indexOf(tps);
  S.bankParams[t][0][0] = tpsIdx >= 0 ? tpsIdx : 1;
  {
    const _pd = host_module_get_param("t" + t + "_clip_playback_dir");
    const _pdv = parseInt(_pd, 10);
    const _pdvi = isFinite(_pdv) && _pdv >= 0 && _pdv <= 3 ? _pdv : 0;
    S.clipPlaybackDir[t][ac] = _pdvi;
    S.bankParams[t][0][6] = _pdvi;
    const _par = host_module_get_param("t" + t + "_clip_playback_audio_reverse");
    const _parv = parseInt(_par, 10);
    S.clipPlaybackAudioReverse[t][ac] = isFinite(_parv) && _parv === 1 ? 1 : 0;
  }
  S.bankParams[t][0][7] = S.clipSeqFollow[t][ac] ? 1 : 0;
  S.screenDirty = true;
}
function readTarpStepVel(t) {
  if (typeof host_module_get_param !== "function") return;
  const raw = host_module_get_param("t" + t + "_tarp_sv");
  if (!raw) return;
  const v = raw.split(" ");
  for (let s = 0; s < 8; s++)
    S.tarpStepVel[t][s] = parseInt(v[s], 10) | 0;
  const rawI = host_module_get_param("t" + t + "_tarp_si");
  if (rawI) {
    const vi = rawI.split(" ");
    for (let s = 0; s < 8; s++)
      S.tarpStepInt[t][s] = parseInt(vi[s], 10) | 0;
  }
  const rawL = host_module_get_param("t" + t + "_tarp_sll");
  if (rawL !== null && rawL !== void 0) {
    const _ll = parseInt(rawL, 10) | 0;
    S.tarpStepLoopLen[t] = _ll >= 1 && _ll <= 8 ? _ll : 8;
  }
}
function readDrumRepeatRates(t) {
  if (typeof host_module_get_param !== "function") return;
  const r2 = host_module_get_param("t" + t + "_drum_r2rt");
  if (r2) {
    const v = r2.split(" ");
    for (let l = 0; l < 32 && l < v.length; l++)
      S.drumRepeat2RatePerLane[t][l] = parseInt(v[l], 10) | 0;
  }
}
function resetPerClipBankParamsToDefault(t) {
  for (let bi = 0; bi < PER_CLIP_BANKS.length; bi++) {
    const b = PER_CLIP_BANKS[bi];
    for (let k = 0; k < 8; k++) {
      const pm = BANKS[b].knobs[k];
      if (pm) S.bankParams[t][b][k] = pm.def;
    }
  }
  const _ac = S.trackActiveClip[t];
  S.pendingDefaultSetParams.push({
    key: "t" + t + "_c" + _ac + "_pfx_set",
    val: "delay_level 127"
  });
  S.screenDirty = true;
}
function localAutomationResync() {
  const touched = S.localEditTouched;
  if (!touched || touched.length === 0) return;
  if (typeof host_module_get_param === "function") {
    for (let i = 0; i < touched.length; i++) {
      const t = touched[i].t, c = touched[i].c;
      if (t < 0 || t >= NUM_TRACKS || c < 0 || c >= NUM_CLIPS) continue;
      const _abits = host_module_get_param("t" + t + "_c" + c + "_cc_auto_bits");
      S.trackCCAutoBits[t][c] = _abits !== null ? parseInt(_abits, 10) || 0 : 0;
      const _arest = host_module_get_param("t" + t + "_c" + c + "_cc_rest");
      if (_arest) {
        const _arp = _arest.split(" ");
        for (let k = 0; k < 8; k++) {
          const rv = parseInt(_arp[k], 10);
          S.clipCCVal[t][c][k] = rv >= 0 && rv <= 127 ? rv : -1;
        }
      }
      const _ath = host_module_get_param("t" + t + "_c" + c + "_at_has");
      S.clipAtHas[t][c] = _ath !== null && parseInt(_ath, 10) === 1;
    }
  }
  S.localEditTouched = [];
}
function pollDSP() {
  if (typeof host_module_get_param === "function") {
    const _bv = parseFloat(host_module_get_param("bpm"));
    if (_bv > 0 && isFinite(_bv)) S.bpmMirror = _bv;
  }
  if (typeof shadow_corun_state === "function") {
    const _st = shadow_corun_state();
    const _slot = _st && _st.target === CORUN_TARGET_CHAIN_EDIT ? _st.id : -1;
    const _track = _st && _st.target === CORUN_TARGET_MOVE_NATIVE ? _st.id : -1;
    if (_slot < 0 && S.schwungCoRunSlot >= 0) {
      exitSchwungCoRun();
      S.globalMenuOpen = false;
      S.lastSentMenuEditValue = null;
    }
    if (_track < 0 && S.moveCoRunTrack >= 0) {
      exitMoveNativeCoRun();
    }
    if (S.coRunOverlayScreen === void 0) {
      let _scr = null;
      if (typeof shadow_corun_entries === "function") {
        const _ents = shadow_corun_entries();
        if (_ents.indexOf("fx_picker") >= 0) _scr = "fx_picker";
        else if (_ents.indexOf("master_fx") >= 0) _scr = "master_fx";
      }
      S.coRunOverlayScreen = _scr;
    }
  }
  if (typeof host_module_get_param !== "function") return;
  {
    const _rr = host_module_get_param("rui_rev");
    if (_rr !== null && _rr !== void 0) {
      const _rev = parseInt(_rr, 10) | 0;
      if (S.lastRemoteRev === void 0) {
        S.lastRemoteRev = _rev;
      } else if (_rev !== S.lastRemoteRev) {
        S.lastRemoteRev = _rev;
        if (S.tickCount <= S.localRevSuppressUntil) {
          host_module_get_param("rui_dirty");
          localAutomationResync();
        } else {
          syncClipsTargeted(host_module_get_param("rui_dirty"));
        }
        S.screenDirty = true;
      }
    }
  }
  if (S.activeBank === 6) {
    const _at = S.activeTrack, _ac = effectiveClip(_at);
    const _ah = host_module_get_param("t" + _at + "_c" + _ac + "_at_has");
    if (_ah !== null) S.clipAtHas[_at][_ac] = parseInt(_ah, 10) === 1;
  }
  {
    const _cs2 = host_module_get_param("clock_follow_on");
    if (_cs2 !== null) S.clockFollowOn = _cs2 === "1";
    const _co = host_module_get_param("clock_send_on");
    if (_co !== null) S.clockSendOn = _co === "1";
    if (host_module_get_param("clock_follow_fallback") === "1")
      showActionPopup("CLOCK FOLLOW", "Move didn't start", "Last-known tempo");
  }
  {
    const _cp = host_module_get_param("capture_pending");
    if (_cp !== null) {
      const _n = parseInt(_cp, 10) | 0;
      if (_n > 0 !== S.capturePending > 0) S.screenDirty = true;
      S.capturePending = _n;
    }
    S.captureArmed = S.capturePending > 0;
    const _ci = host_module_get_param("capture_info");
    if (_ci) {
      const _p = _ci.split(" ");
      const _seq = parseInt(_p[0], 10) | 0;
      const _len = _p[2];
      const _sel = _p[3] === "1";
      const _sidx = parseInt(_p[4], 10) | 0;
      const _cnt = parseInt(_p[5], 10) | 0;
      const _warp = _p[6] === "1";
      const _vals = [];
      for (let k = 0; k < _cnt && 7 + k < _p.length; k++)
        _vals.push(parseFloat(_p[7 + k]));
      if (S.captureCommitAwait > 0 && _seq > 0 && _seq !== S.captureInfoSeq) {
        S.captureInfoSeq = _seq;
        S.captureCommitAwait = 0;
        if (_sel) {
          S.tempoSelectActive = true;
          S.tempoSelectWarp = _warp;
          S.tempoSelectIdx = _sidx;
          S.tempoSelectBpms = _vals;
          S.tempoSelectTrack = S.activeTrack;
          S.tempoSelectClip = S.trackActiveClip[S.activeTrack];
          S.screenDirty = true;
        } else if (_p[1] === "1") {
          showActionPopup(
            "CAPTURED",
            _warp ? (_vals[_sidx] | 0) + " bars" : Math.round(_vals[_sidx] || 0) + " BPM",
            _len + " steps"
          );
        } else {
          showActionPopup("CAPTURED", "Added to clip");
        }
      } else if (S.captureCommitAwait > 0) {
        S.captureCommitAwait--;
      }
      if (S.tempoSelectActive) {
        if (!_sel) {
          S.tempoSelectActive = false;
          S.screenDirty = true;
        } else {
          S.tempoSelectWarp = _warp;
          S.tempoSelectIdx = _sidx;
          if (_vals.length) S.tempoSelectBpms = _vals;
          S.tempoSelectClip = S.trackActiveClip[S.tempoSelectTrack];
        }
      }
    }
  }
  const snap = host_module_get_param("state_snapshot");
  if (!snap) return;
  const v = snap.split(" ");
  if (v.length < 53) return;
  S.playing = v[0] === "1";
  for (let t2 = 0; t2 < NUM_TRACKS; t2++) {
    const newStep = parseInt(v[1 + t2], 10) | 0;
    S.trackCurrentStep[t2] = newStep;
    if (S.playing) {
      const newClip = parseInt(v[9 + t2], 10) | 0;
      S.trackActiveClip[t2] = newClip;
      if (newClip !== S.lastDspActiveClip[t2]) {
        S.lastDspActiveClip[t2] = newClip;
        refreshPerClipBankParams(t2);
        if (S.trackPadMode[t2] === PAD_MODE_DRUM) {
          syncDrumLanesMeta(t2);
          if (t2 === S.activeTrack)
            syncDrumLaneSteps(t2, S.activeDrumLane[t2]);
        }
      }
    }
    const _newQ = parseInt(v[17 + t2], 10) | 0;
    if (_newQ !== S.trackQueuedClip[t2]) S.screenDirty = true;
    S.trackQueuedClip[t2] = _newQ;
  }
  const countInDspActive = v[25] === "1";
  for (let t2 = 0; t2 < NUM_TRACKS; t2++) {
    const _newPlaying = v[26 + t2] === "1";
    const _newWR = v[34 + t2] === "1";
    if (_newPlaying !== S.trackClipPlaying[t2] || _newWR !== S.trackWillRelaunch[t2]) {
      S.screenDirty = true;
    }
    S.trackClipPlaying[t2] = _newPlaying;
    S.trackWillRelaunch[t2] = _newWR;
    S.trackPendingPageStop[t2] = v[42 + t2] === "1";
  }
  S.flashEighth = v[50] === "1";
  S.flashSixteenth = v[51] === "1";
  if (v.length >= 54) S.masterPos = (parseInt(v[53], 10) | 0) >>> 0;
  if (v.length >= 55) S.dspLooperState = parseInt(v[54], 10) | 0;
  const _prevMergeState = S.dspMergeState;
  if (v.length >= 56) S.dspMergeState = parseInt(v[55], 10) | 0;
  const _dspSolo = v.length >= 57 ? parseInt(v[56], 10) | 0 : 255;
  const _soloTrack = _dspSolo !== 255 ? _dspSolo : S.mergeSingleTrack >= 0 ? S.mergeSingleTrack : -1;
  if (S.pendingMergeArm) S.pendingMergeArm = false;
  if (_prevMergeState !== 4 && S.dspMergeState === 4) {
    if (S.playing)
      S.pendingDefaultSetParams.push({ key: "transport", val: "stop" });
    if (_soloTrack >= 0) {
      S.mergeSoloPlacement = _soloTrack;
      if (!S.sessionView) {
        S.sessionView = true;
        S.heldStep = -1;
        S.heldStepBtn = -1;
        S.heldStepNotes = [];
        S.stepWasEmpty = false;
        S.stepWasHeld = false;
        S.sessionStepHeld = -1;
        S.sessionStepHeldCtx = 0;
        invalidateLEDCache();
      }
    } else {
      S.pendingMergePlacement = true;
    }
    S.screenDirty = true;
  }
  if (_prevMergeState !== 0 && S.dspMergeState === 0) {
    setButtonLED3(MoveRec, S.recordArmed ? Red3 : LED_OFF);
    const _wasSolo = S.mergeSingleTrack >= 0 || S.mergeSoloPlacement >= 0;
    const _wrote = S.mergePlacing || _prevMergeState === 2;
    S.mergeSingleTrack = -1;
    S.mergeSoloPlacement = -1;
    S.mergePlacing = false;
    if (_wrote) {
      if (_prevMergeState === 2) showActionPopup("MAX LENGTH", "REACHED");
      else if (_wasSolo) showActionPopup("LIVE MERGE", "Printed to clip");
      syncClipsFromDsp();
    }
    S.screenDirty = true;
  }
  if (S.pendingBankRefresh >= 0) {
    refreshPerClipBankParams(S.pendingBankRefresh);
    S.pendingBankRefresh = -1;
    S.screenDirty = true;
  }
  if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
    const _dl = S.activeDrumLane[S.activeTrack];
    const _dcRaw = host_module_get_param("t" + S.activeTrack + "_l" + _dl + "_current_step");
    if (_dcRaw !== null) {
      const _newDcs = parseInt(_dcRaw, 10) | 0;
      if (_newDcs !== S.drumCurrentStep[S.activeTrack]) {
        S.drumCurrentStep[S.activeTrack] = _newDcs;
        S.screenDirty = true;
      }
    }
    if (S.playing && S.trackClipPlaying[S.activeTrack] && S.clipSeqFollow[S.activeTrack][effectiveClip(S.activeTrack)]) {
      const _dcs = S.drumCurrentStep[S.activeTrack];
      if (_dcs >= 0) {
        const _newPage = Math.floor(_dcs / 16);
        if (_newPage !== S.drumStepPage[S.activeTrack]) {
          S.drumStepPage[S.activeTrack] = _newPage;
          S.screenDirty = true;
        }
      }
    }
    if (S.drumLaneMute[S.activeTrack]) S.screenDirty = true;
    if (S.playing && S.trackClipPlaying[S.activeTrack]) {
      const _maskRaw = host_module_get_param("t" + S.activeTrack + "_drum_active_lanes");
      if (_maskRaw !== null) {
        const _mask = parseInt(_maskRaw, 10) | 0;
        S.seqActiveNotes.clear();
        for (let _fl = 0; _fl < DRUM_LANES; _fl++) {
          if (_mask & 1 << _fl) {
            S.drumLaneFlashTick[S.activeTrack][_fl] = S.tickCount;
            S.seqActiveNotes.add(S.drumLaneNote[S.activeTrack][_fl]);
            S.screenDirty = true;
          }
        }
      }
    }
  } else {
    const _tat = S.activeTrack;
    const _tLatch = (S.bankParams[_tat][5][7] | 0) !== 0 && (S.bankParams[_tat][5][0] | 0) !== 0;
    if (_tLatch) {
      const _hRaw = host_module_get_param("t" + _tat + "_tarp_held");
      const _set = S.tarpHeldNotes[_tat];
      _set.clear();
      if (_hRaw) {
        const _parts = _hRaw.split(" ");
        for (let _i = 0; _i < _parts.length; _i++) {
          const _p = parseInt(_parts[_i], 10);
          if (_p >= 0 && _p <= 127) _set.add(_p);
        }
      }
    } else if (S.tarpHeldNotes[_tat].size > 0) {
      S.tarpHeldNotes[_tat].clear();
    }
  }
  if (S.playing) {
    const _sft = S.activeTrack;
    const _sfac = effectiveClip(_sft);
    if (S.clipSeqFollow[_sft][_sfac] && S.trackClipPlaying[_sft]) {
      var newPage;
      if (S.activeBank === 6) {
        var _ccLsf = S.ccActiveLane[_sft];
        var _dispTpsSf = S.ccLaneTps[_sft][_sfac][_ccLsf] || (S.clipTPS[_sft][_sfac] || 24);
        var _lTpsSf = S.ccLaneResTps[_sft][_sfac][_ccLsf] || _dispTpsSf;
        var _effLenSf = S.ccLaneLength[_sft][_sfac][_ccLsf] || S.clipLength[_sft][_sfac];
        var _lLenTicksSf = _effLenSf * _lTpsSf;
        var _progressSf = S.masterPos % _lLenTicksSf / _lLenTicksSf;
        var _laneStep = Math.floor(_progressSf * _effLenSf);
        newPage = Math.floor(_laneStep / 16);
      } else {
        var _cs = S.trackCurrentStep[_sft];
        if (_cs >= 0) newPage = Math.floor(_cs / 16);
      }
      if (newPage !== void 0 && newPage !== S.trackCurrentPage[_sft]) {
        S.trackCurrentPage[_sft] = newPage;
        S.screenDirty = true;
      }
    }
  }
  if (S.recordPendingPage && S.recordArmedTrack >= 0 && typeof host_module_get_param === "function") {
    const _rpp = host_module_get_param("t" + S.recordArmedTrack + "_recording_pending_page");
    if (_rpp === "0") S.recordPendingPage = false;
  }
  if (S.countInDspPrev && !countInDspActive) {
    if (S.playing) {
      S.recordCountingIn = false;
      S.countInStartTick = -1;
      S.countInQuarterTicks = 0;
    }
    S.mergeCountingIn = false;
  }
  S.countInDspPrev = countInDspActive;
  if (!S.playingPrev && S.playing) {
    S.transportStartTick = S.tickCount;
    if (!S.sessionView) {
      const _at = S.activeTrack;
      if (!S.trackClipPlaying[_at] && !S.trackWillRelaunch[_at] && S.trackQueuedClip[_at] === -1 && _focusedClipIsEmpty(_at)) {
        const _tac = S.trackActiveClip[_at];
        S.pendingDefaultSetParams.push({ key: "t" + _at + "_launch_clip", val: String(_tac) });
        S.trackQueuedClip[_at] = _tac;
      }
    }
    if (S.recordArmed) {
      const _rT = S.recordArmedTrack >= 0 ? S.recordArmedTrack : S.activeTrack;
      const _rAc = S.trackActiveClip[_rT];
      if (S.clipNonEmpty[_rT][_rAc] && !S.trackClipPlaying[_rT] && !S.trackWillRelaunch[_rT] && S.trackQueuedClip[_rT] !== _rAc) {
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + _rT + "_launch_clip", String(_rAc));
        S.trackQueuedClip[_rT] = _rAc;
      }
      if (!S.clipAdaptiveMode[_rT][_rAc]) {
        const _isDrumAdapt = S.trackPadMode[_rT] === PAD_MODE_DRUM;
        if (_isDrumAdapt ? !S.drumClipNonEmpty[_rT][_rAc] && !S.drumLaneLengthManuallySet[_rT] : !S.clipNonEmpty[_rT][_rAc] && !S.clipLengthManuallySet[_rT][_rAc])
          S.clipAdaptiveMode[_rT][_rAc] = true;
      }
    }
  }
  if (S.playingPrev && !S.playing) {
    disarmRecord();
    unlatchAllTracks();
  }
  S.playingPrev = S.playing;
  if (S.recordArmed && S.playing || S.heldStep >= 0) {
    const rt = S.activeTrack;
    const rac = effectiveClip(rt);
    const bulk = host_module_get_param("t" + rt + "_c" + rac + "_steps");
    if (bulk && bulk.length >= NUM_STEPS) {
      for (let rs = 0; rs < NUM_STEPS; rs++)
        S.clipSteps[rt][rac][rs] = bulk[rs] === "1" ? 1 : bulk[rs] === "2" ? 2 : 0;
      S.clipNonEmpty[rt][rac] = clipHasContent(rt, rac);
      S.screenDirty = true;
    }
  }
  const t = S.activeTrack;
  const ac = S.trackActiveClip[t];
  const cs = S.trackCurrentStep[t];
  if (!S.playing) {
    S.seqActiveNotes.clear();
    S.seqLastStep = -1;
    S.seqLastClip = -1;
    S.seqNoteOnClipTick = -1;
    S.seqNoteGateTicks = 0;
  } else if (cs !== S.seqLastStep || ac !== S.seqLastClip) {
    const newHasNote = cs >= 0 && S.clipSteps[t][ac][cs] === 1;
    let prevStillSounding = false;
    if (!newHasNote && S.seqActiveNotes.size > 0 && S.seqNoteOnClipTick >= 0 && S.seqNoteGateTicks > 0 && ac === S.seqLastClip) {
      const ctChk = host_module_get_param("t" + t + "_current_clip_tick");
      if (ctChk !== null && ctChk !== void 0) {
        const ctv = parseInt(ctChk, 10) | 0;
        const clipTks = S.clipLength[t][ac] * (S.clipTPS[t][ac] || 24);
        const elapsed = ctv >= S.seqNoteOnClipTick ? ctv - S.seqNoteOnClipTick : clipTks - S.seqNoteOnClipTick + ctv;
        prevStillSounding = elapsed < S.seqNoteGateTicks;
      }
    }
    S.seqLastStep = cs;
    S.seqLastClip = ac;
    if (newHasNote) {
      S.seqActiveNotes.clear();
      S.seqNoteOnClipTick = -1;
      S.seqNoteGateTicks = 0;
      const raw = host_module_get_param("t" + t + "_c" + ac + "_step_" + cs + "_notes");
      if (raw && raw.trim().length > 0) {
        raw.trim().split(" ").forEach(function(sn) {
          const pitch = parseInt(sn, 10);
          if (pitch >= 0 && pitch <= 127) S.seqActiveNotes.add(pitch);
        });
      }
      const ctStr = host_module_get_param("t" + t + "_current_clip_tick");
      const gStr = host_module_get_param("t" + t + "_c" + ac + "_step_" + cs + "_gate");
      if (ctStr !== null && ctStr !== void 0) S.seqNoteOnClipTick = parseInt(ctStr, 10) | 0;
      if (gStr !== null && gStr !== void 0) S.seqNoteGateTicks = parseInt(gStr, 10) | 0;
    } else if (!prevStillSounding) {
      S.seqActiveNotes.clear();
      S.seqNoteOnClipTick = -1;
      S.seqNoteGateTicks = 0;
    }
  } else if (S.seqActiveNotes.size > 0 && S.seqNoteOnClipTick >= 0 && S.seqNoteGateTicks > 0) {
    const ctStr = host_module_get_param("t" + t + "_current_clip_tick");
    if (ctStr !== null && ctStr !== void 0) {
      const ct = parseInt(ctStr, 10) | 0;
      const clipTicks = S.clipLength[t][ac] * (S.clipTPS[t][ac] || 24);
      const elapsed = ct >= S.seqNoteOnClipTick ? ct - S.seqNoteOnClipTick : clipTicks - S.seqNoteOnClipTick + ct;
      if (elapsed >= S.seqNoteGateTicks) {
        S.seqActiveNotes.clear();
        S.seqNoteOnClipTick = -1;
        S.seqNoteGateTicks = 0;
      }
    }
  }
  if (typeof host_write_file === "function" && S.currentSetUuid) {
    const _st = host_module_get_param("state_full");
    if (_st && _st.length > 2) {
      host_write_file(uuidToStatePath(S.currentSetUuid), _st);
      updateNameIndex();
    }
  }
}
function readBankParams(t, bankIdx) {
  if (typeof host_module_get_param !== "function") return;
  if (S.trackPadMode[t] === PAD_MODE_DRUM && (bankIdx === 0 || bankIdx === 1 || bankIdx === 3)) {
    refreshDrumLaneBankParams(t, S.activeDrumLane[t]);
    return;
  }
  if (bankIdx === 4) {
    const ac = S.trackActiveClip[t];
    const snap = host_module_get_param("t" + t + "_c" + ac + "_pfx_snapshot");
    if (snap) {
      const v = snap.split(" ");
      if (v.length >= 24) {
        for (let k = 0; k < 7; k++) S.bankParams[t][4][k] = parseInt(v[17 + k], 10) | 0;
      }
    }
    return;
  }
  if (bankIdx === 6) {
    const raw = host_module_get_param("t" + t + "_cc_assigns");
    if (raw) {
      const parts = raw.split(" ");
      for (let k = 0; k < 8; k++)
        S.trackCCAssign[t][k] = parseInt(parts[k], 10) || CC_ASSIGN_DEFAULTS[k];
    }
    const typs = host_module_get_param("t" + t + "_cc_types");
    if (typs) {
      const tp = typs.split(" ");
      for (let k = 0; k < 8; k++) S.trackCCType[t][k] = parseInt(tp[k], 10) || 0;
    }
    if (S.trackRoute[t] === 0 && typeof shadow_set_param === "function" && S.trackCCType[t].every(function(tp) {
      return tp === 0;
    })) {
      for (let k = 0; k < 8; k++) {
        S.trackCCType[t][k] = 2;
        S.trackCCAssign[t][k] = k + 1;
        S.schLabel[t][k] = null;
        S.pendingDefaultSetParams.push({ key: "t" + t + "_cc_type_assign", val: k + " 2 " + (k + 1) });
      }
    }
    for (let c = 0; c < NUM_CLIPS; c++) {
      const bits = host_module_get_param("t" + t + "_c" + c + "_cc_auto_bits");
      S.trackCCAutoBits[t][c] = bits !== null ? parseInt(bits, 10) || 0 : 0;
      const rest = host_module_get_param("t" + t + "_c" + c + "_cc_rest");
      if (rest) {
        const rp = rest.split(" ");
        for (let k = 0; k < 8; k++) {
          const rv = parseInt(rp[k], 10);
          S.clipCCVal[t][c][k] = rv >= 0 && rv <= 127 ? rv : -1;
        }
      }
      const ath = host_module_get_param("t" + t + "_c" + c + "_at_has");
      S.clipAtHas[t][c] = ath !== null && parseInt(ath, 10) === 1;
    }
    return;
  }
  const knobs = BANKS[bankIdx].knobs;
  for (let k = 0; k < 8; k++) {
    const pm = knobs[k];
    if (!pm || !pm.abbrev || pm.scope === "stub") {
      S.bankParams[t][bankIdx][k] = pm ? pm.def : 0;
      continue;
    }
    if (pm.scope === "seqfollow") {
      S.bankParams[t][bankIdx][k] = S.clipSeqFollow[t][S.trackActiveClip[t]] ? 1 : 0;
      continue;
    }
    if (pm.scope === "clip") {
      const ac = S.trackActiveClip[t];
      if (pm.dspKey === "clip_resolution") {
        const tps = S.clipTPS[t][ac] || 24;
        const idx = TPS_VALUES.indexOf(tps);
        S.bankParams[t][bankIdx][k] = idx >= 0 ? idx : 1;
      } else if (pm.dspKey === "clip_playback_dir") {
        S.bankParams[t][bankIdx][k] = S.clipPlaybackDir[t][ac] | 0;
      } else {
        S.bankParams[t][bankIdx][k] = pm.def;
      }
      continue;
    }
    if (pm.scope === "action") {
      if (pm.dspKey === "beat_stretch" || pm.dspKey === "clock_shift") {
        S.bankParams[t][bankIdx][k] = 0;
        continue;
      }
      const stateKey = "t" + t + "_" + pm.dspKey + pm.actionSuffix;
      const raw2 = host_module_get_param(stateKey);
      S.bankParams[t][bankIdx][k] = parseActionRaw(raw2, pm.def);
      continue;
    }
    const key = pm.scope === "global" ? pm.dspKey : "t" + t + "_" + pm.dspKey;
    const raw = host_module_get_param(key);
    if (raw === null || raw === void 0) {
      S.bankParams[t][bankIdx][k] = pm.def;
      continue;
    }
    if (pm.dspKey === "route") {
      S.bankParams[t][bankIdx][k] = raw === "external" ? 2 : raw === "move" ? 1 : 0;
    } else {
      S.bankParams[t][bankIdx][k] = parseInt(raw, 10) || 0;
    }
  }
  if (bankIdx === 1 && S.trackPadMode[t] === PAD_MODE_DRUM)
    S.bankParams[t][1][2] = S.drumLaneQnt[t];
  if (bankIdx === 3 && S.trackPadMode[t] !== PAD_MODE_DRUM) {
    const _cf = host_module_get_param("t" + t + "_delay_clock_fb");
    if (_cf !== null && _cf !== void 0)
      S.delayClockFb[t] = Math.max(-100, Math.min(100, parseInt(_cf, 10) | 0));
  }
}
function readTrackConfig(t) {
  if (typeof host_module_get_param !== "function") return;
  const ch = host_module_get_param("t" + t + "_channel");
  if (ch !== null && ch !== void 0) S.trackChannel[t] = parseInt(ch, 10) || 1;
  const rt = host_module_get_param("t" + t + "_route");
  if (rt !== null && rt !== void 0) S.trackRoute[t] = rt === "external" ? 2 : rt === "move" ? 1 : 0;
  const pm = host_module_get_param("t" + t + "_pad_mode");
  if (pm !== null && pm !== void 0) S.trackPadMode[t] = parseInt(pm, 10) | 0;
  const tvo = host_module_get_param("t" + t + "_track_vel_override");
  if (tvo !== null && tvo !== void 0) S.trackVelOverride[t] = parseInt(tvo, 10) | 0;
  const lpr = host_module_get_param("t" + t + "_track_looper");
  if (lpr !== null && lpr !== void 0) S.trackLooper[t] = parseInt(lpr, 10) | 0;
  const diq = host_module_get_param("t" + t + "_diq");
  if (diq !== null && diq !== void 0) {
    S.drumInpQuant[t] = Math.max(0, Math.min(8, parseInt(diq, 10) | 0));
    S.bankParams[t][7][5] = S.drumInpQuant[t];
  }
}
function applyTrackConfig(t, key, val) {
  if (typeof host_module_set_param !== "function") return;
  let strVal;
  if (key === "route") strVal = val === 2 ? "external" : val === 1 ? "move" : "schwung";
  else strVal = String(val);
  host_module_set_param("t" + t + "_" + key, strVal);
  if (key === "channel") S.trackChannel[t] = val;
  else if (key === "route") {
    S.trackRoute[t] = val;
    if (val === 1 && S.trackAtMode[t] === 2) {
      S.trackAtMode[t] = 1;
      writeSidecar();
    }
  } else if (key === "pad_mode") {
    S.trackPadMode[t] = val;
    if (val === PAD_MODE_DRUM) {
      if (t === S.activeTrack && (S.activeBank === 2 || S.activeBank === 4)) S.activeBank = 0;
      syncDrumLanesMeta(t);
      syncDrumLaneSteps(t, S.activeDrumLane[t]);
      syncDrumClipContent(t);
    } else {
      if (t === S.activeTrack && S.activeBank === 7) S.activeBank = 0;
      S.drumVelZoneArmed[t] = false;
      S.drumLastVelZone[t] = 0;
      S.pendingDefaultSetParams.push({ key: "t" + t + "_active_drum_lane", val: "0" });
      S.pendingDefaultSetParams.push({ key: "t" + t + "_drum_perform_mode", val: "0" });
      if (t === S.activeTrack) {
        S.pendingPadNoteMapRecompute = true;
        forceRedraw();
      }
    }
    if (t === S.activeTrack && val === PAD_MODE_DRUM) {
      computePadNoteMap();
      forceRedraw();
    }
  } else if (key === "track_vel_override") S.trackVelOverride[t] = val;
  else if (key === "track_looper") S.trackLooper[t] = val;
}
function applyBankParam(t, bankIdx, knobIdx, val) {
  const pm = BANKS[bankIdx].knobs[knobIdx];
  if (!pm || pm.scope === "stub") return;
  if (pm.scope === "seqfollow") {
    S.clipSeqFollow[t][S.trackActiveClip[t]] = val !== 0;
    return;
  }
  if (!pm.dspKey) return;
  if (typeof host_module_set_param !== "function") return;
  if (pm.scope === "global") {
    host_module_set_param(pm.dspKey, String(val));
    if (pm.dspKey === "key") {
      S.padKey = val;
      computePadNoteMap();
    }
  } else if (pm.scope === "track") {
    let strVal;
    if (pm.dspKey === "route") strVal = val === 2 ? "external" : val === 1 ? "move" : "schwung";
    else strVal = String(val);
    if ([1, 2, 3].indexOf(bankIdx) >= 0 && S.trackPadMode[t] === PAD_MODE_DRUM) {
      const lane = S.activeDrumLane[t];
      let dKey = pm.dspKey;
      if (bankIdx === 3) {
        if (knobIdx === 4) dKey = "delay_gate_fb";
        else if (knobIdx === 5) dKey = "delay_clock_fb";
        else if (knobIdx === 7) return;
      }
      host_module_set_param("t" + t + "_l" + lane + "_pfx_set", dKey + " " + strVal);
      return;
    }
    if (pm.dspKey === "seq_arp_steps_mode" || pm.dspKey === "tarp_steps_mode" || pm.dspKey === "delay_retrig") {
      S.pendingDefaultSetParams.push({ key: "t" + t + "_" + pm.dspKey, val: strVal });
      return;
    }
    host_module_set_param("t" + t + "_" + pm.dspKey, strVal);
  } else if (pm.scope === "clip") {
    const ac = S.trackActiveClip[t];
    if (pm.dspKey === "clip_resolution") {
      if (S.recordArmed && !S.recordCountingIn && S.recordArmedTrack === t) return;
      const idx = Math.max(0, Math.min(5, val));
      S.clipTPS[t][ac] = TPS_VALUES[idx];
      host_module_set_param("t" + t + "_clip_resolution", String(idx));
    } else if (pm.dspKey === "clip_playback_dir") {
      const dv = Math.max(0, Math.min(3, val | 0));
      S.clipPlaybackDir[t][ac] = dv;
      host_module_set_param("t" + t + "_clip_playback_dir", String(dv));
    }
  }
}
function _drainLiveNotes() {
  if (typeof host_module_set_param !== "function") return;
  for (let _t = 0; _t < NUM_TRACKS; _t++) {
    if (pendingLiveNotes[_t].length === 0) continue;
    const evts = pendingLiveNotes[_t];
    pendingLiveNotes[_t] = [];
    const parts = [];
    for (const e of evts) {
      if (e.isOff) parts.push((e.ext ? "eoff " : "off ") + e.pitch);
      else parts.push((e.ext ? "eon " : "on ") + e.pitch + " " + e.vel);
    }
    host_module_set_param("t" + _t + "_live_notes", parts.join(" "));
  }
}
function queueLiveNoteOn(t, pitch, vel, ext) {
  pendingLiveNotes[t].push({ isOff: false, pitch, vel, ext: !!ext });
}
function queueLiveNoteOff(t, pitch, ext) {
  pendingLiveNotes[t].push({ isOff: true, pitch, ext: !!ext });
}
function liveSendNote(t, type, pitch, vel, rawVel, ext) {
  const ch = S.trackChannel[t] - 1 & 15;
  const route = S.trackRoute[t];
  const status = type | ch;
  if (!rawVel && type === 144 && vel > 0) {
    const tvo = S.trackVelOverride[t];
    if (tvo > 0) vel = tvo;
  }
  if (route === 2) {
    if (type === 144 || type === 128) {
      const isOff = type === 128 || type === 144 && vel === 0;
      if (isOff) {
        queueLiveNoteOff(t, pitch, ext);
      } else {
        queueLiveNoteOn(t, pitch, vel, ext);
      }
    } else {
      const cin = status >> 4 & 15;
      if (typeof move_midi_external_send === "function")
        move_midi_external_send([cin, status, pitch, vel]);
    }
  } else if (route === 1) {
    if (type === 144 || type === 128) {
      const activelyRecording = S.recordArmed && !S.recordCountingIn && S.recordArmedTrack === t;
      const isOff = type === 128 || type === 144 && vel === 0;
      if (isOff) {
        queueLiveNoteOff(t, pitch, ext);
      } else if (!activelyRecording) {
        queueLiveNoteOn(t, pitch, vel, ext);
      }
    }
  } else {
    if (type === 144 || type === 128) {
      const isOff = type === 128 || vel === 0;
      if (isOff) {
        queueLiveNoteOff(t, pitch, ext);
      } else {
        queueLiveNoteOn(t, pitch, vel, ext);
      }
    } else {
      if (typeof shadow_send_midi_to_dsp === "function") shadow_send_midi_to_dsp([status, pitch, vel]);
    }
  }
}
function restoreUiSidecar(applyDefaultsNow) {
  const uiSp = uuidToUiStatePath(S.currentSetUuid);
  let us = null;
  if (typeof host_read_file === "function" && typeof host_file_exists === "function" && host_file_exists(uiSp)) {
    try {
      us = JSON.parse(host_read_file(uiSp));
    } catch (e) {
    }
  }
  if (us && us.v >= 1) {
    if (typeof us.at === "number" && us.at >= 0 && us.at < NUM_TRACKS)
      S.activeTrack = us.at;
    if (Array.isArray(us.ac)) {
      for (let _t = 0; _t < NUM_TRACKS; _t++) {
        const _c = us.ac[_t];
        if (typeof _c === "number" && _c >= 0 && _c < NUM_CLIPS)
          S.trackActiveClip[_t] = _c;
      }
    }
    S.sessionView = us.sv === 1;
    if (Array.isArray(us.dl)) {
      for (let _t = 0; _t < NUM_TRACKS; _t++) {
        const _l = us.dl[_t];
        if (typeof _l === "number" && _l >= 0 && _l < DRUM_LANES)
          setActiveDrumLane(_t, _l);
      }
    }
    if (typeof host_module_set_param === "function") {
      for (let _t = 0; _t < NUM_TRACKS; _t++)
        host_module_set_param("t" + _t + "_drum_lane_page", String(S.drumLanePage[_t]));
    }
    if (typeof us.bm === "number") S.beatMarkersEnabled = us.bm !== 0;
    if (us.v >= 2) {
      if (typeof us.pm === "number") S.perfModsToggled = us.pm & 16777215;
      S.perfLatchMode = us.lm === 1;
      if (typeof us.rs === "number" && us.rs >= 0 && us.rs < 16)
        S.perfRecalledSlot = us.rs;
      if (Array.isArray(us.us)) {
        for (let _i = 0; _i < 8; _i++) {
          if (typeof us.us[_i] === "number")
            S.perfSnapshots[8 + _i] = us.us[_i];
        }
      }
      const _pm = S.perfModsToggled | S.perfModsHeld;
      if (_pm) S.pendingDefaultSetParams.push({ key: "perf_mods", val: String(_pm) });
    }
    if (us.v >= 5 && Array.isArray(us.dva)) {
      for (let _t = 0; _t < NUM_TRACKS; _t++)
        S.drumVelZoneArmed[_t] = us.dva[_t] === true;
    }
    if (us.v >= 6 && Array.isArray(us.dleu)) {
      for (let _t = 0; _t < NUM_TRACKS; _t++) {
        const _row = us.dleu[_t];
        if (!Array.isArray(_row)) continue;
        for (let _l = 0; _l < DRUM_LANES; _l++) {
          const _n = _row[_l];
          S.drumLaneEuclidN[_t][_l] = typeof _n === "number" && _n >= 0 ? _n | 0 : 0;
        }
      }
    }
    if (us.v >= 7 && Array.isArray(us.to)) {
      for (let _t = 0; _t < NUM_TRACKS; _t++) {
        const _o = us.to[_t];
        if (typeof _o === "number")
          S.trackOctave[_t] = Math.max(-4, Math.min(4, _o | 0));
      }
    }
    if (us.v >= 8 && Array.isArray(us.tab)) {
      for (let _t = 0; _t < NUM_TRACKS; _t++) {
        const _b = us.tab[_t];
        S.trackActiveBank[_t] = typeof _b === "number" && _b >= 0 && _b <= 7 ? _b | 0 : 0;
      }
      S.activeBank = S.trackActiveBank[S.activeTrack] | 0;
      if (S.activeBank === 7) S.allLanesConfirmed = false;
    }
    if (us.v >= 9 && Array.isArray(us.am)) {
      for (let _t = 0; _t < NUM_TRACKS; _t++) {
        const _m = us.am[_t];
        S.trackAtMode[_t] = typeof _m === "number" && _m >= 0 && _m <= 2 ? _m | 0 : 0;
      }
    }
    if (Array.isArray(us.pchr)) {
      for (let _t = 0; _t < NUM_TRACKS; _t++)
        S.padLayoutChromatic[_t] = !!us.pchr[_t];
    }
  } else {
    S.scaleAware = 1;
    S.metronomeVol = 100;
    S.trackPadMode[0] = PAD_MODE_DRUM;
    if (applyDefaultsNow && typeof host_module_get_param === "function") {
      syncDrumClipContent(0);
      syncDrumLanesMeta(0);
      syncDrumLaneSteps(0, S.activeDrumLane[0] | 0);
    }
    if (applyDefaultsNow) {
      S.pendingDefaultSetParams.push(
        { key: "scale_aware", val: "1" },
        { key: "metro_vol", val: "100" },
        { key: "t0_pad_mode", val: String(PAD_MODE_DRUM) }
      );
    }
  }
  if (S._forceSessionCold) {
    S.sessionView = true;
    if (applyDefaultsNow) S._forceSessionCold = false;
  }
}
function syncClipsFromDsp() {
  if (typeof host_module_get_param !== "function") return;
  for (let t = 0; t < NUM_TRACKS; t++) {
    for (let c = 0; c < NUM_CLIPS; c++) {
      const bulk = host_module_get_param("t" + t + "_c" + c + "_steps");
      if (bulk && bulk.length >= NUM_STEPS) {
        for (let s = 0; s < NUM_STEPS; s++)
          S.clipSteps[t][c][s] = bulk[s] === "1" ? 1 : 0;
        S.clipNonEmpty[t][c] = clipHasContent(t, c);
      }
      const len = host_module_get_param("t" + t + "_c" + c + "_length");
      if (len !== null && len !== void 0)
        S.clipLength[t][c] = parseInt(len, 10) || 16;
      const ls = host_module_get_param("t" + t + "_c" + c + "_loop_start");
      if (ls !== null && ls !== void 0)
        S.clipLoopStart[t][c] = parseInt(ls, 10) | 0;
      const tpsRaw = host_module_get_param("t" + t + "_c" + c + "_tps");
      if (tpsRaw !== null && tpsRaw !== void 0) {
        const tpsVal = parseInt(tpsRaw, 10);
        S.clipTPS[t][c] = TPS_VALUES.indexOf(tpsVal) >= 0 ? tpsVal : 24;
      }
      var ccll = host_module_get_param("t" + t + "_c" + c + "_cc_lane_loops");
      if (ccll) {
        var _vals = ccll.split(" ");
        for (var _k = 0; _k < 8 && _k * 4 + 3 < _vals.length; _k++) {
          S.ccLaneLoopStart[t][c][_k] = parseInt(_vals[_k * 4], 10) | 0;
          S.ccLaneLength[t][c][_k] = parseInt(_vals[_k * 4 + 1], 10) | 0;
          S.ccLaneTps[t][c][_k] = parseInt(_vals[_k * 4 + 2], 10) | 0;
          S.ccLaneResTps[t][c][_k] = parseInt(_vals[_k * 4 + 3], 10) | 0;
        }
      }
    }
    const ac2 = host_module_get_param("t" + t + "_active_clip");
    if (ac2 !== null && ac2 !== void 0) {
      S.trackActiveClip[t] = parseInt(ac2, 10) | 0;
      S.lastDspActiveClip[t] = S.trackActiveClip[t];
    }
    const po = host_module_get_param("t" + t + "_pad_octave");
    if (po !== null && po !== void 0) S.padOctave[t] = parseInt(po, 10) | 0;
    readTrackConfig(t);
    for (let b = 0; b < 7; b++) readBankParams(t, b);
    readTarpStepVel(t);
    readDrumRepeatRates(t);
    if (S.trackPadMode[t] === PAD_MODE_DRUM) {
      syncDrumClipContent(t);
      syncDrumLanesMeta(t);
      syncDrumLaneSteps(t, S.activeDrumLane[t]);
      refreshDrumLaneBankParams(t, S.activeDrumLane[t]);
    }
    {
      const _ac = S.trackActiveClip[t];
      const _ls = S.trackPadMode[t] === PAD_MODE_DRUM ? S.drumLaneLoopStart[t] | 0 : S.clipLoopStart[t][_ac] | 0;
      const _ln = S.trackPadMode[t] === PAD_MODE_DRUM ? S.drumLaneLength[t] | 0 : S.clipLength[t][_ac] | 0;
      if (_ln > 0) {
        const _startPage = Math.floor(_ls / 16);
        const _lastPage = Math.floor((_ls + _ln - 1) / 16);
        if (S.trackCurrentPage[t] < _startPage || S.trackCurrentPage[t] > _lastPage)
          S.trackCurrentPage[t] = _startPage;
      }
    }
  }
  const kp = host_module_get_param("key");
  if (kp !== null && kp !== void 0) S.padKey = parseInt(kp, 10) | 0;
  const sp = host_module_get_param("scale");
  if (sp !== null && sp !== void 0) S.padScale = parseInt(sp, 10) | 0;
  const lqp = host_module_get_param("launch_quant");
  if (lqp !== null && lqp !== void 0) S.launchQuant = parseInt(lqp, 10) | 0;
  const iqp = host_module_get_param("inp_quant");
  if (iqp !== null && iqp !== void 0) S.inpQuant = iqp === "1";
  const micp = host_module_get_param("midi_in_channel");
  if (micp !== null && micp !== void 0) S.midiInChannel = parseInt(micp, 10) | 0;
  const monRaw = host_module_get_param("metro_on");
  if (monRaw !== null && monRaw !== void 0) {
    S.metronomeOn = parseInt(monRaw, 10) | 0;
    if (S.metronomeOn !== 0) S.metronomeOnLast = S.metronomeOn;
  }
  const mvolRaw = host_module_get_param("metro_vol");
  if (mvolRaw !== null && mvolRaw !== void 0) S.metronomeVol = parseInt(mvolRaw, 10) | 0;
  const swaRaw = host_module_get_param("swing_amt");
  if (swaRaw !== null && swaRaw !== void 0) S.swingAmt = parseInt(swaRaw, 10) | 0;
  const swrRaw = host_module_get_param("swing_res");
  if (swrRaw !== null && swrRaw !== void 0) S.swingRes = parseInt(swrRaw, 10) | 0;
}
function syncClipsTargeted(infoStr) {
  if (!infoStr || typeof host_module_get_param !== "function") {
    syncClipsFromDsp();
    return;
  }
  const parts = infoStr.split(" ");
  if (parts.length < 3) {
    syncClipsFromDsp();
    return;
  }
  const isDrum = parts[0] === "d";
  let i = 1;
  while (i + 1 < parts.length) {
    if (parts[i] === "DR") break;
    const t = parseInt(parts[i], 10), c = parseInt(parts[i + 1], 10);
    i += 2;
    if (t < 0 || t >= NUM_TRACKS || c < 0 || c >= NUM_CLIPS) continue;
    if (isDrum) {
      syncDrumClipContent(t);
      syncDrumLanesMeta(t);
      syncDrumLaneSteps(t, S.activeDrumLane[t]);
      refreshDrumLaneBankParams(t, S.activeDrumLane[t]);
    } else {
      const bulk = host_module_get_param("t" + t + "_c" + c + "_steps");
      if (bulk && bulk.length >= NUM_STEPS) {
        for (let s = 0; s < NUM_STEPS; s++)
          S.clipSteps[t][c][s] = bulk[s] === "1" ? 1 : 0;
        S.clipNonEmpty[t][c] = clipHasContent(t, c);
      }
      const len = host_module_get_param("t" + t + "_c" + c + "_length");
      if (len !== null && len !== void 0) S.clipLength[t][c] = parseInt(len, 10) || 16;
      const tpsRaw = host_module_get_param("t" + t + "_c" + c + "_tps");
      if (tpsRaw !== null && tpsRaw !== void 0) {
        const tpsVal = parseInt(tpsRaw, 10);
        S.clipTPS[t][c] = TPS_VALUES.indexOf(tpsVal) >= 0 ? tpsVal : 24;
      }
      if (c === S.trackActiveClip[t]) refreshPerClipBankParams(t);
    }
    const _abits = host_module_get_param("t" + t + "_c" + c + "_cc_auto_bits");
    S.trackCCAutoBits[t][c] = _abits !== null ? parseInt(_abits, 10) || 0 : 0;
    const _arest = host_module_get_param("t" + t + "_c" + c + "_cc_rest");
    if (_arest) {
      const _arp = _arest.split(" ");
      for (let k = 0; k < 8; k++) {
        const rv = parseInt(_arp[k], 10);
        S.clipCCVal[t][c][k] = rv >= 0 && rv <= 127 ? rv : -1;
      }
    }
    const _ath = host_module_get_param("t" + t + "_c" + c + "_at_has");
    S.clipAtHas[t][c] = _ath !== null && parseInt(_ath, 10) === 1;
  }
  while (i + 1 < parts.length) {
    if (parts[i] !== "DR") {
      i += 2;
      continue;
    }
    const rowIdx = parseInt(parts[i + 1], 10);
    i += 2;
    if (rowIdx < 0 || rowIdx >= NUM_CLIPS) continue;
    for (let t2 = 0; t2 < NUM_TRACKS; t2++) {
      syncDrumClipContent(t2);
      if (rowIdx === S.trackActiveClip[t2]) {
        syncDrumLanesMeta(t2);
        syncDrumLaneSteps(t2, S.activeDrumLane[t2]);
        refreshDrumLaneBankParams(t2, S.activeDrumLane[t2]);
      }
    }
  }
  S.screenDirty = true;
}
function syncMuteSoloFromDsp() {
  if (typeof host_module_get_param !== "function") return;
  const muteStr = host_module_get_param("mute_state");
  const soloStr = host_module_get_param("solo_state");
  if (muteStr) for (let _t = 0; _t < NUM_TRACKS; _t++) S.trackMuted[_t] = muteStr[_t] === "1";
  if (soloStr) for (let _t = 0; _t < NUM_TRACKS; _t++) S.trackSoloed[_t] = soloStr[_t] === "1";
  for (let _n = 0; _n < 16; _n++) {
    const snap = host_module_get_param("snap_" + _n);
    if (snap && snap.length >= 17) {
      S.snapshots[_n] = {
        mute: Array.from(snap.substring(0, 8)).map(function(c) {
          return c === "1";
        }),
        solo: Array.from(snap.substring(9, 17)).map(function(c) {
          return c === "1";
        })
      };
    } else {
      S.snapshots[_n] = null;
    }
  }
  const saRaw = host_module_get_param("scale_aware");
  if (saRaw !== null && saRaw !== void 0) S.scaleAware = saRaw === "1" ? 1 : 0;
  S.screenDirty = true;
}
function _focusedClipIsEmpty(t) {
  return _clipIsEmpty(t, S.trackActiveClip[t]);
}
function unlatchAllTracks() {
  for (let t = 0; t < NUM_TRACKS; t++) {
    if (S.drumRepeatLatched[t]) {
      S.drumRepeatLatched[t] = false;
      S.drumRepeatHeldPad[t] = -1;
      S.drumRepeatHeldPadsStack[t].length = 0;
      S.pendingDefaultSetParams.push({ key: "t" + t + "_drum_repeat_stop", val: "1" });
    }
    if (S.drumRepeat2LatchedLanes[t].size > 0) {
      S.drumRepeat2LatchedLanes[t].forEach(function(lane) {
        S.pendingDefaultSetParams.push({ key: "t" + t + "_drum_repeat2_lane_off", val: String(lane) });
      });
      S.drumRepeat2LatchedLanes[t].clear();
    }
    if (S.bankParams[t] && S.bankParams[t][5] && S.bankParams[t][5][7]) {
      S.bankParams[t][5][7] = 0;
      S.pendingDefaultSetParams.push({ key: "t" + t + "_tarp_latch", val: "0" });
    }
  }
}

// ui/ui_menu.mjs
import {
  createValue,
  createEnum,
  createToggle,
  createAction,
  createDivider
} from "/data/UserData/schwung/shared/menu_items.mjs";
import {
  createMenuState
} from "/data/UserData/schwung/shared/menu_nav.mjs";
import {
  createMenuStack
} from "/data/UserData/schwung/shared/menu_stack.mjs";

// ui/ui_export.mjs
var EXPORT_MODULE_DIR = "/data/UserData/schwung/modules/tools/davebox";
var EXPORT_OUT_DIR = "/data/UserData/schwung/davebox-exports";
var EXPORT_STAGING = EXPORT_OUT_DIR + "/staging";
var EXPORT_SCENES = NUM_CLIPS;
var EXPORT_RENDER_PATH = EXPORT_STAGING + "/render.txt";
var EXPORT_SETS_BASE_DIR = "/data/UserData/UserLibrary/Sets";
var CHAIN_CONFIG_PATH = "/data/UserData/schwung/shadow_chain_config.json";
var ROUTE_SCHWUNG = 0;
var ROUTE_MOVE = 1;
var ROUTE_EXT = 2;
var DB_TRACK_COLORS = [1, 17, 7, 10, 25, 15, 6, 12];
function readJsonAsset(name) {
  if (typeof host_read_file !== "function") return null;
  const raw = host_read_file(EXPORT_MODULE_DIR + "/" + name);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}
function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}
function removeStagingDir() {
  if (typeof host_system_cmd === "function")
    host_system_cmd("rm -rf '" + EXPORT_STAGING + "'");
}
function loadMoveSong() {
  if (typeof host_read_file !== "function" || !S.currentSetUuid || !S.currentSetName)
    return null;
  const path = EXPORT_SETS_BASE_DIR + "/" + S.currentSetUuid + "/" + S.currentSetName + "/Song.abl";
  if (typeof host_file_exists === "function" && !host_file_exists(path)) return null;
  const raw = host_read_file(path);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}
function loadChainConfig() {
  if (typeof host_read_file !== "function") return null;
  if (typeof host_file_exists === "function" && !host_file_exists(CHAIN_CONFIG_PATH)) return null;
  const raw = host_read_file(CHAIN_CONFIG_PATH);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}
function buildMoveChannelMap(moveSong) {
  const map = {};
  if (!moveSong || !Array.isArray(moveSong.tracks)) return map;
  for (const mt of moveSong.tracks) {
    const mim = mt && mt.midiInputMode;
    if (Array.isArray(mim) && mim.length >= 1 && typeof mim[0] === "number")
      map[mim[0]] = mt;
  }
  return map;
}
function resolveSampleUri(uri) {
  const CORE = "ableton:/packs/abl-core-library/";
  const USER = "ableton:/user-library/";
  let root, rest;
  if (uri.indexOf(CORE) === 0) {
    root = "/data/CoreLibrary/";
    rest = uri.slice(CORE.length);
  } else if (uri.indexOf(USER) === 0) {
    root = "/data/UserData/UserLibrary/";
    rest = uri.slice(USER.length);
  } else return null;
  let dec;
  try {
    dec = decodeURIComponent(rest);
  } catch (e) {
    dec = rest;
  }
  return root + dec;
}
function assignSampleDest(ctx, src) {
  if (ctx.sampleBySrc[src]) return ctx.sampleBySrc[src];
  const base = src.split("/").pop();
  let dest = base;
  if (ctx.usedDest[dest]) {
    const dot = base.lastIndexOf(".");
    const stem = dot > 0 ? base.slice(0, dot) : base;
    const ext = dot > 0 ? base.slice(dot) : "";
    let i = 2;
    while (ctx.usedDest[stem + " " + i + ext]) i++;
    dest = stem + " " + i + ext;
  }
  ctx.usedDest[dest] = true;
  ctx.sampleBySrc[src] = dest;
  ctx.samples.push({ src, dest });
  return dest;
}
function collectSamples(node, ctx) {
  if (Array.isArray(node)) {
    for (let i = 0; i < node.length; i++) collectSamples(node[i], ctx);
    return;
  }
  if (node && typeof node === "object") {
    for (const k in node) {
      const v = node[k];
      if (k === "sampleUri" && typeof v === "string") {
        const abs = resolveSampleUri(v);
        if (abs) node[k] = "Samples/" + encodeURIComponent(assignSampleDest(ctx, abs));
      } else {
        collectSamples(v, ctx);
      }
    }
  }
}
function resolveTrack(t, ctx) {
  const route = S.trackRoute && S.trackRoute[t] !== void 0 ? S.trackRoute[t] : ROUTE_SCHWUNG;
  const ch = S.trackChannel && S.trackChannel[t] ? S.trackChannel[t] : t + 1;
  const dbName = "dB " + (t + 1);
  const defaultColor = DB_TRACK_COLORS[t % DB_TRACK_COLORS.length];
  function dummy(name, color) {
    const dev = deepClone(ctx.drift);
    dev.name = name;
    return {
      devices: [dev],
      name,
      color: typeof color === "number" ? color : defaultColor,
      mixer: null
      /* use default track mixer */
    };
  }
  if (S.trackPadMode && S.trackPadMode[t] === PAD_MODE_CONDUCT) {
    return dummy("Conductor", defaultColor);
  }
  if (route === ROUTE_MOVE) {
    const mt = ctx.moveMap[ch - 1];
    if (mt && Array.isArray(mt.devices) && mt.devices.length >= 1 && mt.devices[0] && mt.devices[0].kind) {
      const preset = mt.devices[0].name || dbName;
      let mixer = null;
      if (mt.mixer) {
        mixer = deepClone(mt.mixer);
        mixer.sends = [];
      }
      const movDevices = deepClone(mt.devices);
      collectSamples(movDevices, ctx);
      return {
        devices: movDevices,
        name: preset,
        color: defaultColor,
        /* dB track color (not the Move track's own color) */
        mixer
      };
    }
    return dummy(dbName, defaultColor);
  }
  if (route === ROUTE_SCHWUNG) {
    let name = dbName;
    if (ctx.chainCfg && Array.isArray(ctx.chainCfg.patches)) {
      for (const p2 of ctx.chainCfg.patches) {
        if (p2 && p2.channel === ch) {
          name = "SCH-" + (p2.name || "");
          break;
        }
      }
    }
    return dummy(name, defaultColor);
  }
  if (route === ROUTE_EXT) {
    return dummy("Ext ch " + ch, defaultColor);
  }
  return dummy(dbName, defaultColor);
}
function showStopTransportNotice() {
  showActionPopup("STOP TRANSPORT", "FOR EXPORT");
  S.actionPopupEndTick = S.tickCount + ACTION_POPUP_TICKS * 2;
}
function defaultMixer() {
  return { pan: 0, "solo-cue": false, speakerOn: true, volume: 0.6137250661849976, sends: [] };
}
function legalizeNotes(notes) {
  const EPS = 1e-4;
  const byPitch = {};
  for (let i = 0; i < notes.length; i++) {
    const p2 = notes[i].noteNumber;
    (byPitch[p2] || (byPitch[p2] = [])).push(notes[i]);
  }
  const out = [];
  for (const p2 in byPitch) {
    const ns = byPitch[p2].sort(function(a, b) {
      return a.startTime - b.startTime;
    });
    for (let i = 0; i < ns.length; i++) {
      const cur = ns[i];
      if (i > 0 && Math.abs(ns[i - 1].startTime - cur.startTime) < EPS) continue;
      let nextStart = Infinity;
      for (let j = i + 1; j < ns.length; j++) {
        if (ns[j].startTime > cur.startTime + EPS) {
          nextStart = ns[j].startTime;
          break;
        }
      }
      if (cur.startTime + cur.duration > nextStart - EPS)
        cur.duration = nextStart - cur.startTime - EPS;
      if (cur.duration > 0) out.push(cur);
    }
  }
  out.sort(function(a, b) {
    return a.startTime - b.startTime;
  });
  return out;
}
function buildClip(t, c, isDrum) {
  if (typeof host_module_get_param !== "function" || typeof host_read_file !== "function")
    return null;
  const useCond = S.exportApplyConductor && !isDrum && t !== conductorTrackIdx();
  const key = "t" + t + "_c" + c + (isDrum ? "_export_drum" : useCond ? "_export_cond" : "_export");
  const hdr = host_module_get_param(key);
  if (!hdr) return null;
  const parts = hdr.split(" ");
  const span = parseInt(parts[0], 10) || 0;
  const count = parseInt(parts[1], 10);
  let cycle = parseInt(parts[2], 10);
  if (!isFinite(cycle) || cycle <= 0) cycle = span;
  if (!isFinite(count) || count <= 0) return null;
  const body = host_read_file(EXPORT_RENDER_PATH);
  if (!body) return null;
  const notes = [];
  const toks = body.split(";");
  for (let i = 0; i < toks.length; i++) {
    if (!toks[i]) continue;
    const f = toks[i].split(":");
    if (f.length < 4) continue;
    const tick = parseInt(f[0], 10), pitch = parseInt(f[1], 10), vel = parseInt(f[2], 10), gate = parseInt(f[3], 10);
    if (!isFinite(tick) || !isFinite(pitch)) continue;
    notes.push({
      noteNumber: pitch,
      startTime: tick / 96,
      duration: Math.max(1, isFinite(gate) ? gate : 1) / 96,
      velocity: isFinite(vel) ? vel : 100,
      offVelocity: 0
    });
  }
  if (notes.length < count)
    showActionPopup("EXPORT WARN", "CLIP TRUNCATED");
  const legal = legalizeNotes(notes);
  if (legal.length === 0) return null;
  const endBeats = (span > 0 ? span : 96) / 96;
  const loopBeats = (cycle > 0 ? cycle : span) / 96;
  return {
    isPlaying: false,
    name: "",
    color: null,
    isEnabled: true,
    timeSignature: { upper: 4, lower: 4 },
    region: { start: 0, end: endBeats, loop: { start: 0, end: loopBeats, isEnabled: true } },
    grooveId: null,
    stepEditorScrollPosition: 0,
    notes: legal,
    envelopes: []
  };
}
function buildTrack(t, ctx) {
  const r = resolveTrack(t, ctx);
  const isConductor = S.trackPadMode && S.trackPadMode[t] === PAD_MODE_CONDUCT;
  const isDrum = !isConductor && !!(S.trackPadMode && S.trackPadMode[t] !== 0);
  const clipSlots = [];
  for (let i = 0; i < EXPORT_SCENES; i++) {
    const clip = isConductor ? null : buildClip(t, i, isDrum);
    clipSlots.push({ hasStop: true, clip });
  }
  return {
    kind: "midi",
    name: r.name,
    color: r.color,
    isSelected: t === 0,
    clipSlots,
    isNoteRepeatOn: false,
    noteRepeatRate: "1/16",
    noteRepeatArpeggio: { style: "chordRepeat" },
    uiOctaveIndex: 4,
    midiInputMode: "auto",
    midiOutputEndpoint: null,
    devices: r.devices,
    mixer: r.mixer || defaultMixer()
  };
}
function buildSong(bpm, ctx) {
  const tracks = [];
  for (let t = 0; t < NUM_TRACKS; t++) tracks.push(buildTrack(t, ctx));
  const scenes = [];
  for (let i = 0; i < EXPORT_SCENES; i++) scenes.push({ name: "", color: null });
  return {
    "$schema": "http://tech.ableton.com/schema/song/1.8.2/song.json",
    stepEditorResolution: "1/16",
    tempo: bpm,
    globalGrooveAmount: 0,
    rootNote: S.padKey | 0,
    scale: "Major",
    /* TODO Phase 3: map S.padScale -> Ableton scale-name vocab */
    melodicLayout: "inKey",
    tracks,
    returnTracks: [],
    masterTrack: ctx.master,
    scenes,
    grooves: [],
    metadata: { usedFeatures: [] }
  };
}
function pad2(n) {
  return n < 10 ? "0" + n : "" + n;
}
function dateStamp() {
  const d = /* @__PURE__ */ new Date();
  return "" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate());
}
function sanitizeName(name) {
  const s = (name || "").replace(/[^A-Za-z0-9 _-]/g, "").replace(/\s+/g, " ").trim();
  return s || "davebox";
}
function uniqueOutPath(base) {
  let p2 = EXPORT_OUT_DIR + "/" + base + ".ablbundle";
  if (typeof host_file_exists !== "function" || !host_file_exists(p2)) return p2;
  for (let i = 2; i < 1e3; i++) {
    p2 = EXPORT_OUT_DIR + "/" + base + "-" + i + ".ablbundle";
    if (!host_file_exists(p2)) return p2;
  }
  return p2;
}
function requestExport() {
  if (S.playing) {
    S.globalMenuOpen = false;
    showStopTransportNotice();
    return;
  }
  S.confirmExport = true;
  S.confirmExportSel = 1;
  S.screenDirty = true;
}
function confirmExportStart() {
  S.confirmExport = false;
  if (S.playing) {
    S.globalMenuOpen = false;
    showStopTransportNotice();
    return;
  }
  if (conductorTrackIdx() >= 0) {
    S.confirmExportCondPhase = true;
    S.confirmExportCondSel = 1;
    S.screenDirty = true;
    return;
  }
  S.exportApplyConductor = false;
  armExport();
}
function armExport() {
  S.pendingExport = true;
  S.confirmExportCondPhase = false;
  S.globalMenuOpen = false;
  showActionPopup("EXPORTING", "...");
}
function confirmExportCondClick() {
  if (S.confirmExportCondSel === 2) {
    S.confirmExportCondPhase = false;
    S.screenDirty = true;
    return;
  }
  if (S.playing) {
    S.confirmExportCondPhase = false;
    S.globalMenuOpen = false;
    showStopTransportNotice();
    return;
  }
  S.exportApplyConductor = S.confirmExportCondSel === 0;
  armExport();
}
function pollPendingExport() {
  if (S.pendingExport) {
    S.pendingExport = false;
    S.pendingExportRun = true;
    showActionPopup("EXPORTING", "...");
    S.screenDirty = true;
    return;
  }
  if (!S.pendingExportRun) return;
  S.pendingExportRun = false;
  if (typeof host_flush_display === "function") host_flush_display();
  if (typeof host_write_file !== "function" || typeof host_system_cmd !== "function" || typeof host_ensure_dir !== "function") {
    showActionPopup("EXPORT FAIL", "NO HOST API");
    return;
  }
  let bpm = 120;
  if (typeof host_module_get_param === "function") {
    const v = parseFloat(host_module_get_param("bpm"));
    if (v > 0 && isFinite(v)) bpm = v;
  }
  const drift = readJsonAsset("drift-dummy.json");
  const master = readJsonAsset("ableton-master.json");
  if (!drift || !master) {
    showActionPopup("EXPORT FAIL", "NO TEMPLATE");
    return;
  }
  const ctx = {
    drift,
    master,
    moveMap: buildMoveChannelMap(loadMoveSong()),
    chainCfg: loadChainConfig(),
    samples: [],
    /* {src,dest} manifest → pack.py copies into Samples/ */
    sampleBySrc: {},
    /* src → dest (dedupe shared samples) */
    usedDest: {}
    /* dest names taken (avoid basename collisions) */
  };
  host_ensure_dir(EXPORT_OUT_DIR);
  removeStagingDir();
  host_ensure_dir(EXPORT_STAGING);
  let songJson;
  try {
    songJson = JSON.stringify(buildSong(bpm, ctx));
  } catch (e) {
    showActionPopup("EXPORT FAIL", "BUILD");
    return;
  }
  if (!host_write_file(EXPORT_STAGING + "/Song.abl", songJson)) {
    showActionPopup("EXPORT FAIL", "WRITE SONG");
    return;
  }
  const base = sanitizeName(S.currentSetName) + "-" + dateStamp();
  const outPath = uniqueOutPath(base);
  const statusP = EXPORT_STAGING + "/pack-status.json";
  const args = {
    staging: EXPORT_STAGING,
    out: outPath,
    samples: ctx.samples,
    /* {src,dest} resolved from Move instrument sampleUris */
    status: statusP
  };
  host_write_file(EXPORT_STAGING + "/pack-args.json", JSON.stringify(args));
  const cmd = "sh -c '/usr/bin/python3 " + EXPORT_MODULE_DIR + "/pack.py " + EXPORT_STAGING + "/pack-args.json'";
  const rc = host_system_cmd(cmd);
  let okStatus = null, errMsg = null;
  const st = host_read_file(statusP);
  if (st) {
    try {
      const s = JSON.parse(st);
      if (s && s.ok) okStatus = s;
      else errMsg = s && s.error ? String(s.error) : "PACK ERR";
    } catch (e) {
      errMsg = "BAD STATUS";
    }
  } else {
    errMsg = "NO STATUS rc=" + rc;
  }
  removeStagingDir();
  if (okStatus) {
    S.exportDonePath = String(okStatus.out || outPath);
    S.exportDoneMissing = okStatus.missing && okStatus.missing.length ? okStatus.missing.length : 0;
    S.exportDoneDialog = true;
    S.globalMenuOpen = true;
    S.screenDirty = true;
  } else {
    showActionPopup("EXPORT FAIL", String(errMsg).slice(0, 18));
  }
}

// ui/ui_xpose.mjs
function sceneBakeHasConductor(clipIdx) {
  const ct = conductorTrackIdx();
  if (ct < 0) return false;
  const mask = S.condResp[clipIdx | 0];
  if (!mask) return false;
  let t;
  for (t = 0; t < 8; t++) {
    if (t === ct) continue;
    if (S.trackPadMode[t] !== PAD_MODE_MELODIC_SCALE) continue;
    if (mask[t]) return true;
  }
  return false;
}
function commitSceneBake(clipIdx, loops, wrap, apply) {
  S.pendingDefaultSetParams.push({
    key: "bake_scene",
    val: clipIdx + " " + loops + " " + (wrap ? 1 : 0) + " " + (apply ? 1 : 0)
  });
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  showActionPopup("SCENE", "BAKED");
  S.pendingSceneBakeResync = 2;
  S.pendingSceneBakeClip = clipIdx;
  const ct = conductorTrackIdx();
  if (apply && ct >= 0) {
    const mask = S.condResp[clipIdx | 0];
    if (mask) {
      for (let t = 0; t < 8; t++) {
        if (t === ct) continue;
        if (S.trackPadMode[t] !== PAD_MODE_MELODIC_SCALE) continue;
        mask[t] = 0;
      }
    }
  }
}
function anyMelodicClipHasContent() {
  for (let t = 0; t < NUM_TRACKS; t++) {
    if (S.trackPadMode[t] === PAD_MODE_DRUM) continue;
    for (let c = 0; c < NUM_CLIPS; c++) if (S.clipNonEmpty[t][c]) return true;
  }
  return false;
}
function xposePreviewSet(candK, candS) {
  if (candK === S.padKey && candS === S.padScale) {
    xposeCancelPreview();
    return;
  }
  S.xposePrevKey = candK;
  S.xposePrevScale = candS;
  computePadNoteMap();
  if (typeof host_module_set_param === "function")
    host_module_set_param(
      "t0_xpose_prev",
      S.padKey + " " + S.padScale + " " + candK + " " + candS
    );
  S.screenDirty = true;
}
function xposeCancelPreview() {
  if (S.xposePrevKey === null && S.xposePrevScale === null) return;
  S.xposePrevKey = null;
  S.xposePrevScale = null;
  S.pendingDefaultSetParams.push({
    key: "t0_xpose_apply",
    val: S.padKey + " " + S.padScale + " " + S.padKey + " " + S.padScale + " 0"
  });
  computePadNoteMap();
  S.screenDirty = true;
}
function xposeCommit(candK, candS) {
  S.pendingDefaultSetParams.push({
    key: "t0_xpose_apply",
    val: S.padKey + " " + S.padScale + " " + candK + " " + candS + " 1"
  });
  S.padKey = candK;
  S.padScale = candS;
  S.xposePrevKey = null;
  S.xposePrevScale = null;
  computePadNoteMap();
  forceRedraw();
  S.screenDirty = true;
}

// ui/ui_menu.mjs
function buildGlobalMenuItems() {
  return [
    createValue("Channel", {
      get: function() {
        return S.trackChannel[S.activeTrack];
      },
      /* Conductor has no MIDI channel — inert + shows '-'. */
      set: function(v) {
        if (S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT) return;
        applyTrackConfig(S.activeTrack, "channel", v);
      },
      min: 1,
      max: 16,
      step: 1,
      format: function(v) {
        return S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT ? fmtNA() : String(v);
      }
    }),
    createEnum("Route", {
      get: function() {
        return S.trackRoute[S.activeTrack];
      },
      /* Conductor routes nowhere (drives transposition) — inert + shows '-'. */
      set: function(v) {
        if (S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT) return;
        applyTrackConfig(S.activeTrack, "route", v);
      },
      options: [0, 1, 2],
      format: function(v) {
        return S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT ? fmtNA() : fmtRoute(v);
      }
    }),
    createEnum("Mode", {
      get: function() {
        return S.trackPadMode[S.activeTrack];
      },
      /* DEFERRED COMMIT: scrolling only previews the selected type — set()
       * is a no-op, so passing over Drums/Cond while scrolling never fires
       * a conversion or confirm. The conversion (behind its confirm) is
       * triggered by the commit CLICK, intercepted in the jog-click handler
       * (search: label === 'Mode'). Mirrors the Key/Scale commit-on-click
       * pattern. Keys/Drums/Cond = PAD_MODE_MELODIC_SCALE/DRUM/CONDUCT. */
      set: function() {
      },
      options: [0, 1, 2],
      format: function(v) {
        return v === PAD_MODE_CONDUCT ? "Conduct" : v ? "Drums" : "Keys";
      }
    }),
    createEnum("Layout", {
      get: function() {
        return S.padLayoutChromatic[S.activeTrack] ? 1 : 0;
      },
      set: function(v) {
        if (S.trackPadMode[S.activeTrack] !== 0) return;
        S.padLayoutChromatic[S.activeTrack] = v !== 0;
        computePadNoteMap();
        forceRedraw();
      },
      options: [0, 1],
      format: function(v) {
        if (S.trackPadMode[S.activeTrack] !== 0) return fmtNA();
        return v ? "Chrom" : "Scale";
      }
    }),
    createValue("VelIn", {
      get: function() {
        return S.trackVelOverride[S.activeTrack];
      },
      set: function(v) {
        applyTrackConfig(S.activeTrack, "track_vel_override", v);
      },
      min: 0,
      max: 127,
      step: 1,
      format: function(v) {
        return fmtVelOverride(v);
      }
    }),
    createToggle("Looper", {
      get: function() {
        return S.trackLooper[S.activeTrack] !== 0;
      },
      set: function(v) {
        applyTrackConfig(S.activeTrack, "track_looper", v ? 1 : 0);
      },
      onLabel: "On",
      offLabel: "Off"
    }),
    /* Pad-pressure (aftertouch) send mode — melodic tracks only. On drum
     * tracks pad pressure is owned by the repeat-velocity system, so the
     * item is hidden there. Move route supports Off/Poly only (Move
     * instruments take poly AT); Schwung/External also offer Channel.
     * Options recompute each menu open (buildGlobalMenuItems re-runs). Mode is
     * JS-side (carried per-message in tN_live_at) → persisted in the sidecar. */
    ...S.trackPadMode[S.activeTrack] !== PAD_MODE_DRUM ? [
      createEnum("AftTch", {
        get: function() {
          return S.trackAtMode[S.activeTrack] | 0;
        },
        set: function(v) {
          S.trackAtMode[S.activeTrack] = v | 0;
          writeSidecar();
        },
        options: S.trackRoute[S.activeTrack] === 1 ? [0, 1] : [0, 1, 2],
        format: function(v) {
          return v === 2 ? "Chan" : v === 1 ? "Poly" : "Off";
        }
      })
    ] : [],
    /* Co-run capability gate. The chain-editor co-run feature gates on
     * shadow_corun_begin — the co-run framework merged upstream as #94,
     * shipped in Schwung 0.9.18. On Schwung older than 0.9.18 the API is
     * undefined and the menu entry isn't built, so the feature is invisible.
     * All other co-run code is dormant unless this entry triggers it. Also
     * hidden on non-Schwung-routed tracks (symmetric with Edit Synth below). */
    ...S.trackRoute[S.activeTrack] === 0 && typeof shadow_corun_begin === "function" ? [
      createAction("Edit Slot...", function() {
        openSchwungSlotEditor(S.activeTrack);
      })
    ] : [],
    /* Move-native co-run entry — visible only when (a) active track is
     * ROUTE_MOVE, (b) the co-run API (shadow_corun_begin, Schwung >= 0.9.18)
     * is present, and (c) the cable-0 MIDI inject API is present (Schwung
     * >= v0.7.0). On older Schwung or non-Move-routed tracks the entry isn't built. */
    ...S.trackRoute[S.activeTrack] === 1 && typeof shadow_corun_begin === "function" && typeof move_midi_inject_to_move === "function" ? [
      createAction("Edit Synth...", function() {
        enterMoveNativeCoRun(S.activeTrack);
      })
    ] : [],
    createDivider("Global"),
    /* Clock Follow: follow Move's MIDI clock + transport. Default off =
     * unchanged internal free-run. When on, BPM is read-only (EXT) and Play
     * drives Move (single source of truth). */
    createToggle("Clock Follow", {
      get: function() {
        return S.clockFollowOn === true;
      },
      set: function(v) {
        S.clockFollowOn = v ? true : false;
        if (typeof host_module_set_param === "function")
          host_module_set_param("clock_follow_on", S.clockFollowOn ? "1" : "0");
      },
      onLabel: "Move",
      offLabel: "Off"
    }),
    /* Clock Out: db emits MIDI clock (start/stop + 24-PPQN) to external gear
     * over USB-A when free-running (db is master at its own tempo). Suppressed
     * while Clock Follow = Move (Move's own MIDI Clock Out owns external sync,
     * so db relaying would double the clock on the shared port). The toggle
     * stays a stored preference even while following; the value shows "—"
     * then. Uses createEnum (not createToggle) so the "—" format applies. */
    createEnum("Clock Out", {
      get: function() {
        return S.clockSendOn ? 1 : 0;
      },
      set: function(v) {
        S.clockSendOn = v ? true : false;
        if (typeof host_module_set_param === "function")
          host_module_set_param("clock_send_on", S.clockSendOn ? "1" : "0");
      },
      options: [0, 1],
      format: function(v) {
        return S.clockFollowOn ? "\u2014" : v ? "On" : "Off";
      }
    }),
    createValue("BPM", {
      get: function() {
        const v = parseFloat(host_module_get_param("bpm"));
        return v > 0 && isFinite(v) ? Math.round(v) : 120;
      },
      /* Read-only while following — Move owns tempo (DSP also ignores writes). */
      set: function(v) {
        if (S.clockFollowOn) return;
        host_module_set_param("bpm", String(Math.round(v)));
      },
      min: 40,
      max: 250,
      step: 1,
      format: function(v) {
        return S.clockFollowOn ? "Move" : String(Math.round(v));
      }
    }),
    createAction("Tap Tempo", function() {
      if (S.clockFollowOn) {
        showActionPopup("TEMPO: MOVE");
        return;
      }
      openTapTempo();
    }),
    /* Key/Scale: turning the knob previews a transpose of all melodic clips
     * (live, uncommitted); the click commits behind a confirm (see the
     * jog-click intercept + xpose* helpers). set() runs as the menu-edit
     * live preview AND on edit-exit (set(get()) → candidate==committed →
     * cancel), so back-out cleanly drops the preview. */
    createEnum("Key", {
      get: function() {
        return S.padKey;
      },
      set: function(v) {
        xposePreviewSet(v, S.padScale);
      },
      options: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
      format: function(v) {
        return NOTE_KEYS[((v | 0) % 12 + 12) % 12];
      }
    }),
    createEnum("Scale", {
      get: function() {
        return S.padScale;
      },
      set: function(v) {
        xposePreviewSet(S.padKey, v);
      },
      options: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
      format: function(v) {
        return SCALE_NAMES[v] || "Major";
      }
    }),
    createToggle("Scale Aware", {
      get: function() {
        return S.scaleAware !== 0;
      },
      set: function(v) {
        S.scaleAware = v ? 1 : 0;
        if (typeof host_module_set_param === "function")
          host_module_set_param("scale_aware", S.scaleAware ? "1" : "0");
      },
      onLabel: "On",
      offLabel: "Off"
    }),
    createEnum("Launch", {
      get: function() {
        return S.launchQuant;
      },
      set: function(v) {
        S.launchQuant = v;
        if (typeof host_module_set_param === "function")
          host_module_set_param("launch_quant", String(v));
      },
      options: [0, 1, 2, 3, 4, 5],
      format: function(v) {
        return ["Now", "1/16", "1/8", "1/4", "1/2", "1-bar"][v] || "1-bar";
      }
    }),
    createValue("Swing Amt", {
      get: function() {
        return S.swingAmt;
      },
      set: function(v) {
        S.swingAmt = v;
        host_module_set_param("swing_amt", String(v));
      },
      min: 0,
      max: 100,
      format: function(v) {
        return Math.round(50 + v * 0.25) + "%";
      }
    }),
    createEnum("Swing Res", {
      get: function() {
        return S.swingRes;
      },
      set: function(v) {
        S.swingRes = v;
        host_module_set_param("swing_res", String(v));
      },
      options: [0, 1],
      format: function(v) {
        return ["1/16", "1/8"][v] || "1/16";
      }
    }),
    createEnum("MIDI In", {
      get: function() {
        return S.midiInChannel;
      },
      set: function(v) {
        S.midiInChannel = v;
        if (typeof host_module_set_param === "function")
          host_module_set_param("midi_in_channel", String(v));
      },
      options: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
      format: function(v) {
        return v === 0 ? "All" : String(v);
      }
    }),
    createEnum("Metro", {
      get: function() {
        return S.metronomeOn;
      },
      set: function(v) {
        S.metronomeOn = v | 0;
        if (typeof host_module_set_param === "function")
          host_module_set_param("metro_on", String(S.metronomeOn));
      },
      options: [0, 1, 2, 3],
      format: function(v) {
        return ["Off", "Cnt-In", "Play", "Always"][v | 0];
      }
    }),
    createValue("Metro Vol", {
      get: function() {
        return S.metronomeVol;
      },
      set: function(v) {
        S.metronomeVol = v | 0;
        if (typeof host_module_set_param === "function")
          host_module_set_param("metro_vol", String(S.metronomeVol));
      },
      min: 0,
      max: 150,
      step: 1,
      format: function(v) {
        return String(v | 0) + "%";
      }
    }),
    createToggle("Beat Marks", {
      get: function() {
        return S.beatMarkersEnabled;
      },
      set: function(v) {
        S.beatMarkersEnabled = v;
        forceRedraw();
      },
      onLabel: "On",
      offLabel: "Off"
    }),
    createAction("Export to Ableton", function() {
      requestExport();
    }),
    createAction("Save state", function() {
      S.confirmSaveCount = loadSnapshotManifest(S.currentSetUuid).length;
      S.confirmSaveState = true;
      S.confirmSaveSel = 1;
    }),
    createAction("Load state", function() {
      openLoadSnapshot();
    }),
    createAction("Clear Sess", function() {
      S.confirmClearSession = true;
      S.confirmClearSel = 1;
      S.screenDirty = true;
    }),
    createAction("Suspend session", function() {
      saveState();
      S.pendingSuspendManaged = true;
      S.globalMenuOpen = false;
    }),
    createAction("Quit", function() {
      saveState();
      S.pendingExitAfterSave = true;
      S.globalMenuOpen = false;
    })
  ];
}
function openGlobalMenu() {
  if (S.schwungCoRunSlot >= 0) exitSchwungCoRun();
  if (S.moveCoRunTrack >= 0) exitMoveNativeCoRun();
  S.globalMenuItems = buildGlobalMenuItems();
  S.globalMenuState = createMenuState();
  S.globalMenuStack = createMenuStack();
  S.globalMenuOpen = true;
  S.globalMenuBuiltForTrack = S.activeTrack;
  S.lastSentMenuEditValue = null;
  S.screenDirty = true;
  S.jogTouched = false;
}
function ensureGlobalMenuFresh() {
  if (!S.globalMenuOpen) return;
  if (S.globalMenuBuiltForTrack === S.activeTrack) return;
  let prevLabel = null;
  if (S.globalMenuItems && S.globalMenuState) {
    const _cur = S.globalMenuItems[S.globalMenuState.selectedIndex];
    if (_cur) prevLabel = _cur.label || null;
  }
  S.globalMenuItems = buildGlobalMenuItems();
  if (prevLabel && S.globalMenuState) {
    let idx = -1;
    for (let i = 0; i < S.globalMenuItems.length; i++) {
      const _it = S.globalMenuItems[i];
      if (_it && _it.label === prevLabel) {
        idx = i;
        break;
      }
    }
    if (idx >= 0) S.globalMenuState.selectedIndex = idx;
    else S.globalMenuState.selectedIndex = Math.min(
      S.globalMenuState.selectedIndex,
      Math.max(0, S.globalMenuItems.length - 1)
    );
  }
  S.globalMenuBuiltForTrack = S.activeTrack;
}

// ui/ui_editops.mjs
function _markLocalTouch(t, c) {
  if (S.trackPadMode[t] === PAD_MODE_DRUM) return;
  S.localEditTouched.push({ t, c });
}
function setTrackMute(t, on) {
  S.trackMuted[t] = on;
  if (on && S.trackSoloed[t]) {
    S.trackSoloed[t] = false;
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + t + "_solo", "0");
  }
  if (typeof host_module_set_param === "function")
    host_module_set_param("t" + t + "_mute", on ? "1" : "0");
  S.screenDirty = true;
}
function setTrackSolo(t, on) {
  if (S.trackPadMode[t] === PAD_MODE_CONDUCT) return;
  S.trackSoloed[t] = on;
  if (on && S.trackMuted[t]) {
    S.trackMuted[t] = false;
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + t + "_mute", "0");
  }
  if (typeof host_module_set_param === "function")
    host_module_set_param("t" + t + "_solo", on ? "1" : "0");
  S.screenDirty = true;
}
function clearAllMuteSolo() {
  for (let _t = 0; _t < NUM_TRACKS; _t++) {
    S.trackMuted[_t] = false;
    S.trackSoloed[_t] = false;
  }
  if (typeof host_module_set_param === "function")
    host_module_set_param("mute_all_clear", "1");
  S.screenDirty = true;
}
function clearStep(t, ac, absIdx) {
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "t" + t + "_c" + ac + "_step_" + absIdx + "_clear", val: "1", _local: true });
  S.clipSteps[t][ac][absIdx] = 0;
  if (S.clipNonEmpty[t][ac]) S.clipNonEmpty[t][ac] = clipHasContent(t, ac);
  refreshSeqNotesIfCurrent(t, ac, absIdx);
}
function showModePopup(title, items, activeIdx) {
  S.actionPopupLines = [title, ...items];
  S.actionPopupHighlight = activeIdx + 1;
  S.actionPopupEndTick = S.tickCount + ACTION_POPUP_TICKS;
  S.screenDirty = true;
}
function clearClip(t, ac, keepPlaying) {
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  if (S.trackPadMode[t] === PAD_MODE_DRUM) {
    const keep = keepPlaying && S.trackClipPlaying[t] && ac === S.trackActiveClip[t] ? "1" : "0";
    S.pendingDefaultSetParams.unshift({ key: "t" + t + "_c" + ac + "_drum_clear", val: keep, _local: true });
    S.clearDrainHold = 1;
    for (let l = 0; l < DRUM_LANES; l++) {
      for (let s = 0; s < 256; s++) S.drumLaneSteps[t][l][s] = "0";
      S.drumLaneHasNotes[t][l] = false;
    }
    S.drumClipNonEmpty[t][ac] = false;
    S.drumLaneLengthManuallySet[t] = false;
    if (ac === S.trackActiveClip[t]) {
      S.drumLaneLength[t] = 16;
      S.drumLaneLoopStart[t] = 0;
      S.seqActiveNotes.clear();
    }
    return;
  }
  const cmd = keepPlaying && S.trackClipPlaying[t] && ac === S.trackActiveClip[t] ? "t" + t + "_c" + ac + "_clear_keep" : "t" + t + "_c" + ac + "_clear";
  S.pendingDefaultSetParams.unshift({ key: cmd, val: "1", _local: true });
  S.clearDrainHold = 1;
  const len = S.clipLength[t][ac];
  for (let s = 0; s < len; s++) S.clipSteps[t][ac][s] = 0;
  S.clipNonEmpty[t][ac] = false;
  S.clipLength[t][ac] = 16;
  S.clipLoopStart[t][ac] = 0;
  S.clipLengthManuallySet[t][ac] = false;
  S.clipAdaptiveMode[t][ac] = false;
  S.trackCCAutoBits[t][ac] = 0;
  S.clipCCVal[t][ac] = new Array(8).fill(-1);
  S.clipAtHas[t][ac] = false;
  invalidateLEDCache();
  S.pendingStepsReread = 2;
  S.pendingStepsRereadTrack = t;
  S.pendingStepsRereadClip = ac;
  if (ac === S.trackActiveClip[t]) {
    S.seqActiveNotes.clear();
    S.seqLastStep = -1;
    S.seqNoteOnClipTick = -1;
    if (S.playing && !S.trackClipPlaying[t] && !S.trackWillRelaunch[t] && S.trackQueuedClip[t] === -1) {
      S.pendingDefaultSetParams.push({ key: "t" + t + "_launch_clip", val: String(ac) });
      S.trackQueuedClip[t] = ac;
    }
  }
}
function hardResetClip(t, ac) {
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  if (S.trackPadMode[t] === PAD_MODE_DRUM) {
    S.pendingDefaultSetParams.unshift({ key: "t" + t + "_c" + ac + "_drum_reset", val: "1", _local: true });
    S.clearDrainHold = 1;
    for (let l = 0; l < DRUM_LANES; l++) {
      for (let s = 0; s < 256; s++) S.drumLaneSteps[t][l][s] = "0";
      S.drumLaneHasNotes[t][l] = false;
    }
    S.drumClipNonEmpty[t][ac] = false;
    S.clipLengthManuallySet[t][ac] = false;
    S.drumLaneLengthManuallySet[t] = false;
    if (ac === S.trackActiveClip[t]) {
      S.drumLaneLength[t] = 16;
      S.drumLaneLoopStart[t] = 0;
      S.drumLaneTPS[t] = 24;
      S.drumStepPage[t] = 0;
      S.trackCurrentPage[t] = 0;
      S.seqActiveNotes.clear();
    }
    return;
  }
  S.pendingDefaultSetParams.unshift({ key: "t" + t + "_c" + ac + "_hard_reset", val: "1", _local: true });
  S.clearDrainHold = 1;
  _markLocalTouch(t, ac);
  const defaultLen = 16;
  for (let s = 0; s < NUM_STEPS; s++) S.clipSteps[t][ac][s] = 0;
  S.clipLength[t][ac] = defaultLen;
  S.clipLoopStart[t][ac] = 0;
  S.clipNonEmpty[t][ac] = false;
  S.clipTPS[t][ac] = 24;
  S.clipLengthManuallySet[t][ac] = false;
  for (var _k = 0; _k < 8; _k++) {
    S.ccLaneLoopStart[t][ac][_k] = 0;
    S.ccLaneLength[t][ac][_k] = 0;
    S.ccLaneTps[t][ac][_k] = 0;
  }
  if (ac === S.trackActiveClip[t]) {
    S.trackCurrentPage[t] = 0;
    S.seqActiveNotes.clear();
    S.seqLastStep = -1;
    S.seqNoteOnClipTick = -1;
    resetPerClipBankParamsToDefault(t);
  }
}
function copyClip(srcT, srcC, dstT, dstC) {
  if (srcT === dstT && srcC === dstC) return;
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "clip_copy", val: `${srcT} ${srcC} ${dstT} ${dstC}`, _local: true });
  _markLocalTouch(dstT, dstC);
  S.clipSteps[dstT][dstC] = S.clipSteps[srcT][srcC].slice();
  S.clipLength[dstT][dstC] = S.clipLength[srcT][srcC];
  S.clipLoopStart[dstT][dstC] = S.clipLoopStart[srcT][srcC];
  S.clipNonEmpty[dstT][dstC] = S.clipNonEmpty[srcT][srcC];
  S.clipTPS[dstT][dstC] = S.clipTPS[srcT][srcC];
  for (var _k = 0; _k < 8; _k++) {
    S.ccLaneLoopStart[dstT][dstC][_k] = S.ccLaneLoopStart[srcT][srcC][_k];
    S.ccLaneLength[dstT][dstC][_k] = S.ccLaneLength[srcT][srcC][_k];
    S.ccLaneTps[dstT][dstC][_k] = S.ccLaneTps[srcT][srcC][_k];
  }
  if (dstC === S.trackActiveClip[dstT]) {
    S.seqActiveNotes.clear();
    S.seqLastStep = -1;
    refreshPerClipBankParams(dstT);
  }
}
function cutClip(srcT, srcC, dstT, dstC) {
  if (srcT === dstT && srcC === dstC) return;
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "clip_cut", val: `${srcT} ${srcC} ${dstT} ${dstC}`, _local: true });
  _markLocalTouch(dstT, dstC);
  _markLocalTouch(srcT, srcC);
  S.clipSteps[dstT][dstC] = S.clipSteps[srcT][srcC].slice();
  S.clipLength[dstT][dstC] = S.clipLength[srcT][srcC];
  S.clipLoopStart[dstT][dstC] = S.clipLoopStart[srcT][srcC];
  S.clipNonEmpty[dstT][dstC] = S.clipNonEmpty[srcT][srcC];
  S.clipTPS[dstT][dstC] = S.clipTPS[srcT][srcC];
  for (var _k = 0; _k < 8; _k++) {
    S.ccLaneLoopStart[dstT][dstC][_k] = S.ccLaneLoopStart[srcT][srcC][_k];
    S.ccLaneLength[dstT][dstC][_k] = S.ccLaneLength[srcT][srcC][_k];
    S.ccLaneTps[dstT][dstC][_k] = S.ccLaneTps[srcT][srcC][_k];
  }
  if (dstC === S.trackActiveClip[dstT]) {
    S.seqActiveNotes.clear();
    S.seqLastStep = -1;
    refreshPerClipBankParams(dstT);
  }
  for (let s = 0; s < NUM_STEPS; s++) S.clipSteps[srcT][srcC][s] = 0;
  S.clipLength[srcT][srcC] = 16;
  S.clipLoopStart[srcT][srcC] = 0;
  S.clipNonEmpty[srcT][srcC] = false;
  S.clipTPS[srcT][srcC] = 24;
  for (var _k2 = 0; _k2 < 8; _k2++) {
    S.ccLaneLoopStart[srcT][srcC][_k2] = 0;
    S.ccLaneLength[srcT][srcC][_k2] = 0;
    S.ccLaneTps[srcT][srcC][_k2] = 0;
  }
  if (srcC === S.trackActiveClip[srcT]) {
    S.seqActiveNotes.clear();
    S.seqLastStep = -1;
    S.seqNoteOnClipTick = -1;
    resetPerClipBankParamsToDefault(srcT);
  }
}
function copyRow(srcRow, dstRow) {
  if (srcRow === dstRow) return;
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "row_copy", val: `${srcRow} ${dstRow}`, _local: true });
  for (let t = 0; t < NUM_TRACKS; t++) {
    _markLocalTouch(t, dstRow);
    S.clipSteps[t][dstRow] = S.clipSteps[t][srcRow].slice();
    S.clipLength[t][dstRow] = S.clipLength[t][srcRow];
    S.clipLoopStart[t][dstRow] = S.clipLoopStart[t][srcRow];
    S.clipNonEmpty[t][dstRow] = S.clipNonEmpty[t][srcRow];
    S.clipTPS[t][dstRow] = S.clipTPS[t][srcRow];
    S.drumClipNonEmpty[t][dstRow] = S.drumClipNonEmpty[t][srcRow];
    for (var _k = 0; _k < 8; _k++) {
      S.ccLaneLoopStart[t][dstRow][_k] = S.ccLaneLoopStart[t][srcRow][_k];
      S.ccLaneLength[t][dstRow][_k] = S.ccLaneLength[t][srcRow][_k];
      S.ccLaneTps[t][dstRow][_k] = S.ccLaneTps[t][srcRow][_k];
    }
    if (dstRow === S.trackActiveClip[t]) {
      S.seqActiveNotes.clear();
      S.seqLastStep = -1;
      refreshPerClipBankParams(t);
      if (S.trackPadMode[t] === PAD_MODE_DRUM) {
        S.pendingDrumResync = 2;
        S.pendingDrumResyncTrack = t;
      }
    }
  }
}
function cutRow(srcRow, dstRow) {
  if (srcRow === dstRow) return;
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "row_cut", val: `${srcRow} ${dstRow}`, _local: true });
  for (let t = 0; t < NUM_TRACKS; t++) {
    _markLocalTouch(t, dstRow);
    _markLocalTouch(t, srcRow);
    S.clipSteps[t][dstRow] = S.clipSteps[t][srcRow].slice();
    S.clipLength[t][dstRow] = S.clipLength[t][srcRow];
    S.clipLoopStart[t][dstRow] = S.clipLoopStart[t][srcRow];
    S.clipNonEmpty[t][dstRow] = S.clipNonEmpty[t][srcRow];
    S.clipTPS[t][dstRow] = S.clipTPS[t][srcRow];
    S.drumClipNonEmpty[t][dstRow] = S.drumClipNonEmpty[t][srcRow];
    for (var _k = 0; _k < 8; _k++) {
      S.ccLaneLoopStart[t][dstRow][_k] = S.ccLaneLoopStart[t][srcRow][_k];
      S.ccLaneLength[t][dstRow][_k] = S.ccLaneLength[t][srcRow][_k];
      S.ccLaneTps[t][dstRow][_k] = S.ccLaneTps[t][srcRow][_k];
    }
    if (dstRow === S.trackActiveClip[t]) {
      S.seqActiveNotes.clear();
      S.seqLastStep = -1;
      refreshPerClipBankParams(t);
      if (S.trackPadMode[t] === PAD_MODE_DRUM) {
        S.pendingDrumResync = 2;
        S.pendingDrumResyncTrack = t;
      }
    }
    for (let s = 0; s < NUM_STEPS; s++) S.clipSteps[t][srcRow][s] = 0;
    S.clipLength[t][srcRow] = 16;
    S.clipLoopStart[t][srcRow] = 0;
    S.clipNonEmpty[t][srcRow] = false;
    S.clipTPS[t][srcRow] = 24;
    S.drumClipNonEmpty[t][srcRow] = false;
    for (var _k2 = 0; _k2 < 8; _k2++) {
      S.ccLaneLoopStart[t][srcRow][_k2] = 0;
      S.ccLaneLength[t][srcRow][_k2] = 0;
      S.ccLaneTps[t][srcRow][_k2] = 0;
    }
    if (srcRow === S.trackActiveClip[t]) {
      S.seqActiveNotes.clear();
      S.seqLastStep = -1;
      S.seqNoteOnClipTick = -1;
      resetPerClipBankParamsToDefault(t);
      if (S.trackPadMode[t] === PAD_MODE_DRUM) {
        S.pendingDrumResync = 2;
        S.pendingDrumResyncTrack = t;
      }
    }
  }
}
function copyStep(t, ac, srcAbs, dstAbs) {
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  if (S.trackPadMode[t] === PAD_MODE_DRUM) {
    const lane = S.activeDrumLane[t];
    S.pendingDefaultSetParams.push({ key: "t" + t + "_l" + lane + "_step_" + srcAbs + "_copy_to", val: String(dstAbs), _local: true });
    S.drumLaneSteps[t][lane][dstAbs] = S.drumLaneSteps[t][lane][srcAbs];
    if (S.drumLaneSteps[t][lane][srcAbs] !== "0") S.drumLaneHasNotes[t][lane] = true;
    S.pendingDrumLaneResync = 2;
    S.pendingDrumLaneResyncTrack = t;
    S.pendingDrumLaneResyncLane = lane;
  } else {
    S.pendingDefaultSetParams.push({ key: "t" + t + "_c" + ac + "_step_" + srcAbs + "_copy_to", val: String(dstAbs), _local: true });
    S.clipSteps[t][ac][dstAbs] = S.clipSteps[t][ac][srcAbs];
    if (S.clipSteps[t][ac][srcAbs] !== 0) S.clipNonEmpty[t][ac] = true;
    S.pendingStepsReread = 2;
    S.pendingStepsRereadTrack = t;
    S.pendingStepsRereadClip = ac;
  }
}
function cutStep(t, ac, srcAbs, dstAbs) {
  if (typeof host_module_set_param !== "function") return;
  copyStep(t, ac, srcAbs, dstAbs);
  if (S.trackPadMode[t] === PAD_MODE_DRUM) {
    const lane = S.activeDrumLane[t];
    S.pendingDefaultSetParams.push({ key: "t" + t + "_l" + lane + "_step_" + srcAbs + "_clear", val: "1", _local: true });
    S.drumLaneSteps[t][lane][srcAbs] = "0";
    S.drumLaneHasNotes[t][lane] = S.drumLaneSteps[t][lane].some((c) => c !== "0");
  } else {
    S.pendingDefaultSetParams.push({ key: "t" + t + "_c" + ac + "_step_" + srcAbs + "_clear", val: "1", _local: true });
    S.clipSteps[t][ac][srcAbs] = 0;
    if (S.clipNonEmpty[t][ac]) S.clipNonEmpty[t][ac] = clipHasContent(t, ac);
  }
}
function copyDrumLane(t, srcLane, dstLane) {
  if (srcLane === dstLane) return;
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "t" + t + "_l" + srcLane + "_copy_to", val: String(dstLane), _local: true });
  const steps = S.drumLaneSteps[t];
  for (let s = 0; s < 256; s++) steps[dstLane][s] = steps[srcLane][s];
  S.drumLaneHasNotes[t][dstLane] = S.drumLaneHasNotes[t][srcLane];
  if (S.drumLaneHasNotes[t][srcLane]) S.drumClipNonEmpty[t][S.trackActiveClip[t]] = true;
  S.drumRepeatGate[t][dstLane] = S.drumRepeatGate[t][srcLane];
  S.drumRepeatGateLen[t][dstLane] = S.drumRepeatGateLen[t][srcLane];
  for (let s = 0; s < 8; s++) {
    S.drumRepeatVelScale[t][dstLane][s] = S.drumRepeatVelScale[t][srcLane][s];
    S.drumRepeatNudge[t][dstLane][s] = S.drumRepeatNudge[t][srcLane][s];
  }
  S.pendingDrumLaneResync = 2;
  S.pendingDrumLaneResyncTrack = t;
  S.pendingDrumLaneResyncLane = dstLane;
}
function cutDrumLane(t, srcLane, dstLane) {
  if (srcLane === dstLane) return;
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "t" + t + "_l" + srcLane + "_cut_to", val: String(dstLane), _local: true });
  const steps = S.drumLaneSteps[t];
  for (let s = 0; s < 256; s++) {
    steps[dstLane][s] = steps[srcLane][s];
    steps[srcLane][s] = "0";
  }
  S.drumLaneHasNotes[t][dstLane] = S.drumLaneHasNotes[t][srcLane];
  S.drumLaneHasNotes[t][srcLane] = false;
  let anyHits = false;
  for (let l = 0; l < DRUM_LANES; l++) if (S.drumLaneHasNotes[t][l]) {
    anyHits = true;
    break;
  }
  S.drumClipNonEmpty[t][S.trackActiveClip[t]] = anyHits;
  S.drumRepeatGate[t][dstLane] = S.drumRepeatGate[t][srcLane];
  S.drumRepeatGateLen[t][dstLane] = S.drumRepeatGateLen[t][srcLane];
  for (let s = 0; s < 8; s++) {
    S.drumRepeatVelScale[t][dstLane][s] = S.drumRepeatVelScale[t][srcLane][s];
    S.drumRepeatNudge[t][dstLane][s] = S.drumRepeatNudge[t][srcLane][s];
  }
  S.drumRepeatGate[t][srcLane] = 255;
  S.drumRepeatGateLen[t][srcLane] = 8;
  for (let s = 0; s < 8; s++) {
    S.drumRepeatVelScale[t][srcLane][s] = 100;
    S.drumRepeatNudge[t][srcLane][s] = 0;
  }
  S.pendingDrumLaneResync = 2;
  S.pendingDrumLaneResyncTrack = t;
  S.pendingDrumLaneResyncLane = dstLane;
}
function copyDrumClip(srcT, srcC, dstT, dstC) {
  if (srcT === dstT && srcC === dstC) return;
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "drum_clip_copy", val: `${srcT} ${srcC} ${dstT} ${dstC}`, _local: true });
  S.drumClipNonEmpty[dstT][dstC] = S.drumClipNonEmpty[srcT][srcC];
  if (dstC === S.trackActiveClip[dstT]) {
    S.pendingDrumResync = 2;
    S.pendingDrumResyncTrack = dstT;
  }
}
function cutDrumClip(srcT, srcC, dstT, dstC) {
  if (srcT === dstT && srcC === dstC) return;
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "drum_clip_cut", val: `${srcT} ${srcC} ${dstT} ${dstC}`, _local: true });
  S.drumClipNonEmpty[dstT][dstC] = S.drumClipNonEmpty[srcT][srcC];
  S.drumClipNonEmpty[srcT][srcC] = false;
  if (srcC === S.trackActiveClip[srcT]) {
    for (let l = 0; l < DRUM_LANES; l++) {
      for (let s = 0; s < 256; s++) S.drumLaneSteps[srcT][l][s] = "0";
      S.drumLaneHasNotes[srcT][l] = false;
    }
    S.drumLaneLength[srcT] = 16;
    S.drumLaneTPS[srcT] = 24;
  }
  if (dstC === S.trackActiveClip[dstT]) {
    S.pendingDrumResync = 2;
    S.pendingDrumResyncTrack = dstT;
  }
}
function clearRow(rowIdx) {
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.pendingDefaultSetParams.push({ key: "row_clear", val: String(rowIdx), _local: true });
  for (let t = 0; t < NUM_TRACKS; t++) {
    _markLocalTouch(t, rowIdx);
    const len = S.clipLength[t][rowIdx];
    for (let s = 0; s < len; s++) S.clipSteps[t][rowIdx][s] = 0;
    S.clipNonEmpty[t][rowIdx] = false;
    S.drumClipNonEmpty[t][rowIdx] = false;
    S.clipLoopStart[t][rowIdx] = 0;
    if (rowIdx === S.trackActiveClip[t]) {
      S.seqActiveNotes.clear();
      S.seqLastStep = -1;
      S.trackCurrentPage[t] = 0;
      if (S.trackPadMode[t] === PAD_MODE_DRUM) S.drumLaneLoopStart[t] = 0;
      resetPerClipBankParamsToDefault(t);
      if (S.trackPadMode[t] === PAD_MODE_DRUM) {
        S.pendingDrumResync = 2;
        S.pendingDrumResyncTrack = t;
      }
    }
  }
}
function _switchActiveTrack(newT) {
  S.trackActiveBank[S.activeTrack] = S.activeBank;
  S.activeTrack = newT | 0;
  S.activeBank = S.trackActiveBank[S.activeTrack] | 0;
  if (S.activeBank === 7) S.allLanesConfirmed = false;
  if (S.playing && !S.sessionView && !S.trackClipPlaying[S.activeTrack] && !S.trackWillRelaunch[S.activeTrack] && S.trackQueuedClip[S.activeTrack] === -1 && _focusedClipIsEmpty(S.activeTrack)) {
    const _ac = S.trackActiveClip[S.activeTrack];
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + S.activeTrack + "_launch_clip", String(_ac));
    S.trackQueuedClip[S.activeTrack] = _ac;
  }
}
function allLanesGate() {
  if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 7 && !S.allLanesConfirmed) {
    S.screenDirty = true;
    forceRedraw();
    return true;
  }
  return false;
}
function doDoubleFill() {
  const _t = S.activeTrack;
  if (S.trackPadMode[_t] === PAD_MODE_DRUM && S.activeBank === 7) {
    if (allLanesGate()) return;
    S.undoAvailable = true;
    S.redoAvailable = false;
    S.undoSeqArpSnapshot = null;
    host_module_set_param("t" + _t + "_all_lanes_double_fill", "1");
    S.pendingDrumResync = 2;
    S.pendingDrumResyncTrack = _t;
    showActionPopup("LOOP", "DOUBLED");
    forceRedraw();
  } else if (S.trackPadMode[_t] === PAD_MODE_DRUM) {
    const _l = S.activeDrumLane[_t];
    const _len = S.drumLaneLength[_t];
    if (_len * 2 > 256) {
      showActionPopup("CLIP FULL");
    } else {
      S.undoAvailable = true;
      S.redoAvailable = false;
      S.undoSeqArpSnapshot = null;
      host_module_set_param("t" + _t + "_l" + _l + "_loop_double_fill", "1");
      S.drumLaneLength[_t] = _len * 2;
      S.pendingDrumResync = 2;
      S.pendingDrumResyncTrack = _t;
      showActionPopup("LOOP", "DOUBLED");
      forceRedraw();
    }
  } else {
    const _ac = effectiveClip(_t);
    const _len = S.clipLength[_t][_ac];
    if (_len * 2 > 256) {
      showActionPopup("CLIP FULL");
    } else {
      S.undoAvailable = true;
      S.redoAvailable = false;
      S.undoSeqArpSnapshot = null;
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + _t + "_loop_double_fill", "1");
      S.clipLength[_t][_ac] = _len * 2;
      S.pendingStepsReread = 2;
      S.pendingStepsRereadTrack = _t;
      S.pendingStepsRereadClip = _ac;
      refreshPerClipBankParams(_t);
      showActionPopup("LOOP", "DOUBLED");
      forceRedraw();
    }
  }
}
function doLaneDoubleFill() {
  var _t = S.activeTrack, _ac = effectiveClip(_t), _l = S.ccActiveLane[_t];
  var _len = S.ccLaneLength[_t][_ac][_l] || S.clipLength[_t][_ac];
  if (_len * 2 > 256) {
    showActionPopup("LANE FULL");
    return;
  }
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.undoSeqArpSnapshot = null;
  S.ccLaneLength[_t][_ac][_l] = _len * 2;
  var _pre = "t" + _t + "_c" + _ac + "_k" + _l;
  S.pendingDefaultSetParams.push({ key: _pre + "_cc_lane_double_fill", val: "1" });
  showActionPopup("LANE LOOP", "DOUBLED");
  forceRedraw();
}
function resetFxBanks(t) {
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  if (S.trackPadMode[t] === PAD_MODE_DRUM) {
    const lane = S.activeDrumLane[t];
    S.pendingDefaultSetParams.push({ key: "t" + t + "_l" + lane + "_pfx_reset", val: "1" });
    S.pendingDefaultSetParams.push({
      key: "t" + t + "_l" + lane + "_pfx_set",
      val: "delay_level 127"
    });
  } else {
    S.pendingDefaultSetParams.push({ key: "t" + t + "_pfx_reset", val: "1" });
    const _ac = S.trackActiveClip[t];
    S.pendingDefaultSetParams.push({
      key: "t" + t + "_c" + _ac + "_pfx_set",
      val: "delay_level 127"
    });
    for (let s = 0; s < 8; s++) {
      S.seqArpStepVel[t][_ac][s] = 4;
      S.seqArpStepInt[t][_ac][s] = 0;
    }
    S.seqArpStepLoopLen[t][_ac] = 8;
  }
  const targets = [1, 2, 3, 4];
  for (let bi = 0; bi < targets.length; bi++) {
    const b = targets[bi];
    for (let k = 0; k < 8; k++) {
      const pm = BANKS[b].knobs[k];
      if (!pm) continue;
      S.bankParams[t][b][k] = pm.def;
    }
  }
  S.screenDirty = true;
}
function resetTarp(t) {
  if (typeof host_module_set_param !== "function") return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  S.pendingDefaultSetParams.push({ key: "t" + t + "_tarp_reset", val: "1" });
  for (let k = 0; k < 8; k++) {
    const pm = BANKS[5].knobs[k];
    if (pm) S.bankParams[t][5][k] = pm.def;
  }
  for (let s = 0; s < 8; s++) {
    S.tarpStepVel[t][s] = 4;
    S.tarpStepInt[t][s] = 0;
  }
  S.tarpStepLoopLen[t] = 8;
  S.tarpHeldNotes[t].clear();
  S.screenDirty = true;
}
function resetSingleFxBank(t, bankIdx) {
  if (typeof host_module_set_param !== "function") return;
  const dspCmd = { 1: "pfx_noteFx_reset", 2: "pfx_harm_reset", 3: "pfx_delay_reset" }[bankIdx];
  if (!dspCmd) return;
  S.undoAvailable = true;
  S.redoAvailable = false;
  if (S.trackPadMode[t] === PAD_MODE_DRUM) {
    const lane = S.activeDrumLane[t];
    S.pendingDefaultSetParams.push({ key: "t" + t + "_l" + lane + "_pfx_set", val: dspCmd + " 1" });
    if (bankIdx === 3) {
      S.pendingDefaultSetParams.push({
        key: "t" + t + "_l" + lane + "_pfx_set",
        val: "delay_level 127"
      });
    }
  } else {
    S.pendingDefaultSetParams.push({ key: "t" + t + "_" + dspCmd, val: "1" });
    if (bankIdx === 3) {
      const _ac = S.trackActiveClip[t];
      S.pendingDefaultSetParams.push({
        key: "t" + t + "_c" + _ac + "_pfx_set",
        val: "delay_level 127"
      });
    }
  }
  for (let k = 0; k < 8; k++) {
    const pm = BANKS[bankIdx].knobs[k];
    if (!pm) continue;
    S.bankParams[t][bankIdx][k] = pm.def;
  }
  S.screenDirty = true;
}
function applyConductGridKnob(bank, k, delta) {
  if (delta === 0) return;
  const N = S.activeTrack, c = S.trackActiveClip[N] | 0;
  if (N < 0 || S.trackPadMode[N] !== PAD_MODE_CONDUCT) return;
  if (k === N) return;
  if (S.trackPadMode[k] === PAD_MODE_DRUM) return;
  if (bank === BANK_RESPONDER) {
    S.condResp[c][k] = S.condResp[c][k] ? 0 : 1;
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + N + "_c" + c + "_cond_resp", k + " " + S.condResp[c][k]);
  } else if (bank === BANK_OCTAVE) {
    const nv = Math.max(-4, Math.min(4, (S.condOct[c][k] | 0) + (delta > 0 ? 1 : -1)));
    S.condOct[c][k] = nv;
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + N + "_c" + c + "_cond_oct", k + " " + nv);
  } else if (bank === BANK_WHEN) {
    S.condWhen[c][k] = S.condWhen[c][k] ? 0 : 1;
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + N + "_c" + c + "_cond_when", k + " " + S.condWhen[c][k]);
  }
  S.screenDirty = true;
  forceRedraw();
}

// ui/ui_input_pads.mjs
var LOOPER_RATES_STRAIGHT = [12, 24, 48, 96, 192];
var PERF_MOD_FULL_NAMES = [
  "Octave Up",
  "Octave Down",
  "Scale Up",
  "Scale Down",
  "Fifth",
  "Tritone",
  "Drift",
  "Storm",
  "Decrescendo",
  "Swell",
  "Crescendo",
  "Pulse",
  "Sidechain",
  "Staccato",
  "Legato",
  "Ramp Gate",
  "Half Time",
  "3 Skip",
  "Phantom",
  "Sparse",
  "Glitch",
  "Stagger",
  "Shuffle",
  "Backwards"
];
var PERF_MOD_POPUP_TICKS = 47;
var padPitch = new Array(32).fill(-1);
var padPressTick = new Array(32).fill(-1);
var DRUM_TAP_TICKS = 10;
function _onPadPressTrackView(status, d1, d2) {
  if (d1 >= TRACK_PAD_BASE && d1 < TRACK_PAD_BASE + 32) {
    const padIdx = d1 - TRACK_PAD_BASE;
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.shiftHeld && S.deleteHeld) {
      const t = S.activeTrack;
      const lane = drumPadToLane(padIdx);
      if (lane >= 0 && lane < DRUM_LANES) {
        S.undoAvailable = true;
        S.redoAvailable = false;
        S.undoSeqArpSnapshot = null;
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_l" + lane + "_hard_reset", "1");
        setActiveDrumLane(t, lane);
        S.drumLaneLength[t] = 16;
        for (let s = 0; s < 256; s++) S.drumLaneSteps[t][lane][s] = "0";
        S.drumLaneHasNotes[t][lane] = false;
        S.drumRepeatGate[t][lane] = 255;
        for (let _s = 0; _s < 8; _s++) {
          S.drumRepeatVelScale[t][lane][_s] = 100;
          S.drumRepeatNudge[t][lane][_s] = 0;
        }
        S.drumRepeat2RatePerLane[t][lane] = 0;
        const ac = S.trackActiveClip[t];
        S.drumClipNonEmpty[t][ac] = false;
        for (let ol = 0; ol < DRUM_LANES; ol++) {
          if (S.drumLaneHasNotes[t][ol]) {
            S.drumClipNonEmpty[t][ac] = true;
            break;
          }
        }
        S.pendingDrumLaneResync = 2;
        S.pendingDrumLaneResyncTrack = t;
        S.pendingDrumLaneResyncLane = lane;
        showActionPopup("LANE", "RESET");
        forceRedraw();
      }
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && !S.shiftHeld && S.deleteHeld) {
      const t = S.activeTrack;
      const lane = drumPadToLane(padIdx);
      if (lane >= 0 && lane < DRUM_LANES) {
        S.undoAvailable = true;
        S.redoAvailable = false;
        S.undoSeqArpSnapshot = null;
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_l" + lane + "_clear", "1");
        setActiveDrumLane(t, lane);
        for (let s = 0; s < 256; s++) S.drumLaneSteps[t][lane][s] = "0";
        S.drumLaneHasNotes[t][lane] = false;
        const ac = S.trackActiveClip[t];
        S.drumClipNonEmpty[t][ac] = false;
        for (let ol = 0; ol < DRUM_LANES; ol++) {
          if (S.drumLaneHasNotes[t][ol]) {
            S.drumClipNonEmpty[t][ac] = true;
            break;
          }
        }
        showActionPopup("LANE", "CLEARED");
        forceRedraw();
      }
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.drumPerformMode[S.activeTrack] === 1 && !S.shiftHeld && !S.copyHeld && !S.muteHeld) {
      const t = S.activeTrack;
      const col = padIdx % 8;
      const row = Math.floor(padIdx / 8);
      if (col >= 4 && row < 2) {
        const rateIdx = row * 4 + (col - 4);
        const lane = S.activeDrumLane[t];
        const vel = d2;
        if (S.drumRepeatLatched[t] && S.drumRepeatHeldPad[t] === padIdx) {
          S.drumRepeatLatched[t] = false;
          S.drumRepeatHeldPad[t] = -1;
          S.drumRepeatHeldPadsStack[t].length = 0;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_drum_repeat_stop", "1");
        } else {
          if (S.drumRepeatHeldPad[t] >= 0 && !S.drumRepeatLatched[t]) {
            const _pp = S.drumRepeatHeldPad[t];
            const _pr = Math.floor(_pp / 8) * 4 + _pp % 8 - 4;
            S.drumRepeatHeldPadsStack[t].push({ padIdx: _pp, rateIdx: _pr, vel: S.drumRepeatHeldPadVel[t] });
          }
          S.drumRepeatHeldPad[t] = padIdx;
          S.drumRepeatHeldPadVel[t] = vel;
          S.drumRepeatLatched[t] = S.loopHeld;
          if (typeof host_module_set_param === "function") {
            if (!S.dspInboundEnabled)
              host_module_set_param("t" + t + "_drum_repeat_start", lane + " " + rateIdx + " " + vel);
            host_module_set_param("t" + t + "_drum_repeat_latched", S.loopHeld ? "1" : "0");
          }
        }
        S.screenDirty = true;
        return;
      } else if (col >= 4 && row >= 2) {
        const lane = S.activeDrumLane[t];
        const step = (row - 2) * 4 + (col - 4);
        if (S.deleteHeld) {
          S.drumRepeatVelScale[t][lane][step] = 100;
          S.drumRepeatNudge[t][lane][step] = 0;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_repeat_defaults", String(step));
        } else if (S.loopHeld) {
          const gLen = step + 1;
          const fillMask = (1 << gLen) - 1;
          S.drumRepeatGate[t][lane] = fillMask;
          S.drumRepeatGateLen[t][lane] = gLen;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_repeat_gate_and_len", fillMask + " " + gLen);
        } else {
          S.drumRepeatGate[t][lane] = (S.drumRepeatGate[t][lane] ^ 1 << step) & 255;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_repeat_gate_toggle", String(step));
        }
        forceRedraw();
        return;
      }
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.drumPerformMode[S.activeTrack] === 2 && !S.shiftHeld && !S.copyHeld && !S.muteHeld) {
      const t = S.activeTrack;
      const col = padIdx % 8;
      const row = Math.floor(padIdx / 8);
      if (col >= 4 && row < 2) {
        const rateIdx = row * 4 + (col - 4);
        const lane = S.activeDrumLane[t];
        S.drumRepeat2RatePerLane[t][lane] = rateIdx;
        if (typeof host_module_set_param === "function" && !S.dspInboundEnabled)
          host_module_set_param("t" + t + "_drum_repeat2_rate", lane + " " + rateIdx);
        S.screenDirty = true;
        return;
      } else if (col >= 4 && row >= 2) {
        const lane = S.activeDrumLane[t];
        const step = (row - 2) * 4 + (col - 4);
        if (S.deleteHeld) {
          S.drumRepeatVelScale[t][lane][step] = 100;
          S.drumRepeatNudge[t][lane][step] = 0;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_repeat_defaults", String(step));
        } else if (S.loopHeld) {
          const gLen = step + 1;
          const fillMask = (1 << gLen) - 1;
          S.drumRepeatGate[t][lane] = fillMask;
          S.drumRepeatGateLen[t][lane] = gLen;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_repeat_gate_and_len", fillMask + " " + gLen);
        } else {
          S.drumRepeatGate[t][lane] = (S.drumRepeatGate[t][lane] ^ 1 << step) & 255;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_repeat_gate_toggle", String(step));
        }
        forceRedraw();
        return;
      } else if (col < 4 && !S.deleteHeld) {
        const lane = drumPadToLane(padIdx);
        if (lane >= 0 && lane < DRUM_LANES) {
          setActiveDrumLane(t, lane);
          syncDrumLaneSteps(t, lane);
          refreshDrumLaneBankParams(t, lane);
          if (S.drumRepeat2LatchedLanes[t].has(lane)) {
            S.drumRepeat2LatchedLanes[t].delete(lane);
            if (typeof host_module_set_param === "function" && !S.dspInboundEnabled)
              host_module_set_param("t" + t + "_drum_repeat2_lane_off", String(lane));
            if (S.loopHeld) S.rpt2LoopPadUsed = true;
          } else {
            S.drumRepeat2HeldLanes[t].add(lane);
            if (S.loopHeld) {
              S.drumRepeat2LatchedLanes[t].add(lane);
              S.rpt2LoopPadUsed = true;
            }
            padPitch[padIdx] = -1;
            if (typeof host_module_set_param === "function") {
              if (!S.dspInboundEnabled)
                host_module_set_param("t" + t + "_drum_repeat2_lane_on", lane + " " + d2);
              if (S.loopHeld)
                host_module_set_param("t" + t + "_drum_repeat2_latch_held", "1");
            }
          }
          forceRedraw();
        }
        return;
      }
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && (!S.shiftHeld || S.muteHeld || S.copyHeld)) {
      const t = S.activeTrack;
      const lane = drumPadToLane(padIdx);
      const velZone = drumPadToVelZone(padIdx);
      if (velZone >= 0) {
        S.drumLastVelZone[t] = velZone;
        S.drumVelZoneArmed[t] = true;
        const zoneVel = drumVelZoneToVelocity(velZone);
        const lane_vp = S.activeDrumLane[t];
        const laneNote = S.drumLaneNote[t][lane_vp];
        liveSendNote(t, 144, laneNote, zoneVel, true);
        padPitch[padIdx] = laneNote;
        padPressTick[padIdx] = S.tickCount;
        S.liveActiveNotes.add(laneNote);
        if (S.heldStep >= 0 && S.heldStepNotes.length > 0) {
          const _heldWriteVel = stepEntryVelocity(t, zoneVel, true);
          S.stepEditVel = _heldWriteVel;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane_vp + "_step_" + S.heldStep + "_vel", String(_heldWriteVel));
          S.stepBtnPressedTick[S.heldStepBtn] = -1;
        }
        if (S.recordArmed && !S.recordCountingIn && t === S.recordArmedTrack) {
          _drumRecNoteOns.push({ track: t, laneNote, vel: zoneVel });
          S.pendingDrumLaneResync = 3;
          S.pendingDrumLaneResyncTrack = t;
          S.pendingDrumLaneResyncLane = lane_vp;
        }
        S.screenDirty = true;
      } else if (lane >= 0 && lane < DRUM_LANES && S.copyHeld && !S.muteHeld) {
        if (!S.copySrc) {
          S.copySrc = S.shiftHeld ? { kind: "cut_drum_lane", track: t, lane } : { kind: "drum_lane", track: t, lane };
          invalidateLEDCache();
          showActionPopup(S.shiftHeld ? "CUT" : "COPIED");
        } else if (S.copySrc.kind === "drum_lane" && S.copySrc.track === t) {
          copyDrumLane(t, S.copySrc.lane, lane);
          setActiveDrumLane(t, lane);
          refreshDrumLaneBankParams(t, lane);
          invalidateLEDCache();
          forceRedraw();
          showActionPopup("PASTED");
        } else if (S.copySrc.kind === "cut_drum_lane" && S.copySrc.track === t) {
          cutDrumLane(t, S.copySrc.lane, lane);
          S.copySrc = { kind: "drum_lane", track: t, lane };
          setActiveDrumLane(t, lane);
          refreshDrumLaneBankParams(t, lane);
          invalidateLEDCache();
          forceRedraw();
          showActionPopup("PASTED");
        }
      } else if (lane >= 0 && lane < DRUM_LANES && S.muteHeld) {
        S.muteUsedAsModifier = true;
        const bit = 1 << lane;
        if (S.shiftHeld) {
          const wasOn = !!(S.drumLaneSolo[t] & bit);
          if (wasOn) {
            S.drumLaneSolo[t] &= ~bit;
          } else {
            S.drumLaneSolo[t] |= bit;
            if (S.drumLaneMute[t] & bit) {
              S.drumLaneMute[t] &= ~bit;
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_l" + lane + "_mute", "0");
            }
          }
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_solo", wasOn ? "0" : "1");
        } else {
          const wasOn = !!(S.drumLaneMute[t] & bit);
          if (wasOn) {
            S.drumLaneMute[t] &= ~bit;
          } else {
            S.drumLaneMute[t] |= bit;
            if (S.drumLaneSolo[t] & bit) {
              S.drumLaneSolo[t] &= ~bit;
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_l" + lane + "_solo", "0");
            }
          }
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_mute", wasOn ? "0" : "1");
        }
        forceRedraw();
      } else if (lane >= 0 && lane < DRUM_LANES) {
        if (S.deleteHeld) {
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_clear", "1");
          setActiveDrumLane(t, lane);
          for (let s = 0; s < 256; s++) S.drumLaneSteps[t][lane][s] = "0";
          S.drumLaneHasNotes[t][lane] = false;
          const ac = S.trackActiveClip[t];
          S.drumClipNonEmpty[t][ac] = false;
          for (let ol = 0; ol < DRUM_LANES; ol++) {
            if (S.drumLaneHasNotes[t][ol]) {
              S.drumClipNonEmpty[t][ac] = true;
              break;
            }
          }
          refreshDrumLaneBankParams(t, lane);
          showActionPopup("LANE CLEARED");
          forceRedraw();
        } else {
          if (S.activeBank !== 6) {
            setActiveDrumLane(t, lane);
            syncDrumLaneSteps(t, lane);
            refreshDrumLaneBankParams(t, lane);
          }
          if (S.moveCoRunTrack >= 0) {
            padPitch[padIdx] = 255;
            forceRedraw();
          } else {
            const vel = effectiveVelocity(d2);
            const laneNote = S.drumLaneNote[t][lane];
            liveSendNote(t, 144, laneNote, vel);
            padPitch[padIdx] = laneNote;
            padPressTick[padIdx] = S.tickCount;
            S.liveActiveNotes.add(laneNote);
            if (S.recordArmed && !S.recordCountingIn && t === S.recordArmedTrack) {
              const tvo = S.trackVelOverride[t];
              const recVel = tvo > 0 ? tvo : vel;
              _drumRecNoteOns.push({ track: t, laneNote, vel: recVel });
              S.pendingDrumLaneResync = 3;
              S.pendingDrumLaneResyncTrack = t;
              S.pendingDrumLaneResyncLane = lane;
            }
            if (S.recordArmed && S.recordCountingIn && t === S.recordArmedTrack) {
              const tvo = S.trackVelOverride[t];
              const recVel = tvo > 0 ? tvo : vel;
              S.pendingPrerollNote = {
                track: t,
                lane,
                laneNote,
                vel: recVel,
                isDrum: true,
                pressedAtTick: S.tickCount,
                countInStart: S.countInStartTick
              };
            }
            if (S.drumPerformMode[t] === 1 && (S.drumRepeatHeldPad[t] >= 0 || S.drumRepeatLatched[t])) {
              if (typeof host_module_set_param === "function" && !S.dspInboundEnabled)
                host_module_set_param("t" + t + "_drum_repeat_lane", String(lane));
            }
            forceRedraw();
          }
        }
      }
    } else if (S.heldStep >= 0 && !S.shiftHeld) {
      if (S.padNoteMap[padIdx] === 255) return;
      const ac = effectiveClip(S.activeTrack);
      const _pitchRaw = S.padNoteMap[padIdx] + S.trackOctave[S.activeTrack] * 12;
      if (_pitchRaw < 0 || _pitchRaw > 127) return;
      const pitch = _pitchRaw;
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + S.activeTrack + "_c" + ac + "_step_" + S.heldStep + "_toggle", pitch + " " + stepEntryVelocity(S.activeTrack, effectiveVelocity(d2), false));
      const raw = typeof host_module_get_param === "function" ? host_module_get_param("t" + S.activeTrack + "_c" + ac + "_step_" + S.heldStep + "_notes") : null;
      S.heldStepNotes = raw && raw.trim().length > 0 ? raw.trim().split(" ").map(Number).filter((n) => n >= 0 && n <= 127) : [];
      S.clipSteps[S.activeTrack][ac][S.heldStep] = S.heldStepNotes.length > 0 ? 1 : 0;
      if (S.heldStepNotes.length > 0) {
        S.clipNonEmpty[S.activeTrack][ac] = true;
      } else if (S.clipNonEmpty[S.activeTrack][ac]) {
        S.clipNonEmpty[S.activeTrack][ac] = clipHasContent(S.activeTrack, ac);
      }
      refreshSeqNotesIfCurrent(S.activeTrack, ac, S.heldStep);
      padPitch[padIdx] = pitch;
      S.liveActiveNotes.add(pitch);
      liveSendNote(S.activeTrack, 144, pitch, effectiveVelocity(d2));
      forceRedraw();
    } else if (S.shiftHeld && padIdx >= 24 && padIdx <= 31) {
      const _padOff = padIdx - 24;
      const _isDrum = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM;
      const _isConduct = S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT;
      let bankIdx;
      if (_isDrum) {
        const DRUM_PAD_MAP = [7, 0, 1, 3, 5, -1, 6, -1];
        bankIdx = DRUM_PAD_MAP[_padOff];
      } else if (_isConduct) {
        const CONDUCT_PAD_MAP = [0, 1, BANK_RESPONDER, BANK_OCTAVE, BANK_WHEN, -1, -1, -1];
        bankIdx = CONDUCT_PAD_MAP[_padOff];
      } else {
        bankIdx = _padOff;
      }
      if (bankIdx >= 0 && bankIdx < BANKS.length && BANKS[bankIdx]) {
        if (S.activeBank === bankIdx) {
          S.bankSelectTick = -1;
        } else {
          S.activeBank = bankIdx;
          S.trackActiveBank[S.activeTrack] = bankIdx;
          if (bankIdx === 7) S.allLanesConfirmed = false;
          if (bankIdx === 6) S.schLabelFetchLane = 0;
          readBankParams(S.activeTrack, bankIdx);
          S.bankSelectTick = S.tickCount;
          writeSidecar();
        }
        S.screenDirty = true;
      }
    } else if (S.shiftHeld && padIdx < NUM_TRACKS) {
      extNoteOffAll();
      handoffRecordingToTrack(padIdx);
      _switchActiveTrack(padIdx);
      refreshPerClipBankParams(padIdx);
      computePadNoteMap();
      S.seqActiveNotes.clear();
      S.seqLastStep = -1;
      S.seqLastClip = -1;
      if (S.trackPadMode[padIdx] === PAD_MODE_DRUM) {
        if (S.activeBank === 2 || S.activeBank === 4) S.activeBank = 0;
        resyncDrumTrack(padIdx);
      } else {
        if (S.activeBank === 7) S.activeBank = 0;
      }
      S.screenDirty = true;
    } else if (!S.shiftHeld) {
      const basePitch = S.padNoteMap[padIdx];
      if (basePitch === 255) return;
      const _pitchRaw = basePitch + S.trackOctave[S.activeTrack] * 12;
      if (_pitchRaw < 0 || _pitchRaw > 127) return;
      const pitch = _pitchRaw;
      padPitch[padIdx] = pitch;
      S.atLastSent[padIdx] = -1;
      S.lastPlayedNote = pitch;
      S.lastPadVelocity = effectiveVelocity(d2);
      S.liveActiveNotes.add(pitch);
      liveSendNote(S.activeTrack, 144, pitch, effectiveVelocity(d2));
      if (S.recordArmed && S.activeTrack === S.recordArmedTrack)
        recordNoteOn(pitch, effectiveVelocity(d2), S.recordArmedTrack);
    }
  }
}
function _onPadPress(status, d1, d2) {
  if (S.mergeNoticePending) return;
  if (S.moveCoRunTrack >= 0 && S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && d1 >= 68 && d1 <= 99 && (d1 - 68) % 8 < 4 && (status & 240) === 144 && d2 > 0 && typeof move_midi_inject_to_move === "function") {
    move_midi_inject_to_move([9, 144, d1, d2 & 127]);
    S.moveCoRunDrumHeld.add(d1);
  }
  if (S.tapTempoOpen && d1 >= 68 && d1 <= 99) {
    registerTapTempo(d1);
    return;
  }
  if (!S.sessionView && S.stepIntervalMode && S.activeBank === 4 && d1 >= 68 && d1 <= 99) {
    const idx = d1 - 68;
    const col = idx % 8;
    const t = S.activeTrack;
    const ac = effectiveClip(t);
    if (S.loopHeld) {
      const newLen = col + 1;
      if (S.seqArpStepLoopLen[t][ac] !== newLen) {
        S.seqArpStepLoopLen[t][ac] = newLen;
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_seq_arp_step_loop_len", String(newLen));
        forceRedraw();
      }
      return;
    }
    const row = Math.floor(idx / 8);
    const cur = S.seqArpStepVel[t][ac][col] | 0;
    const curLvl = arpVelLevel(cur);
    const newVel = S.deleteHeld ? VEL_THRU : row === 0 && curLvl === 1 ? 0 : ARP_VEL_CANON[row + 1];
    if (newVel !== cur) {
      S.seqArpStepVel[t][ac][col] = newVel;
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + t + "_seq_arp_step_vel", col + " " + newVel);
      forceRedraw();
    }
    return;
  }
  if (!S.sessionView && S.stepIntervalMode && S.activeBank === 5 && d1 >= 68 && d1 <= 99) {
    const idx = d1 - 68;
    const col = idx % 8;
    const t = S.activeTrack;
    if (S.loopHeld) {
      const newLen = col + 1;
      if (S.tarpStepLoopLen[t] !== newLen) {
        S.tarpStepLoopLen[t] = newLen;
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_tarp_step_loop_len", String(newLen));
        forceRedraw();
      }
      return;
    }
    const row = Math.floor(idx / 8);
    const cur = S.tarpStepVel[t][col] | 0;
    const curLvl = arpVelLevel(cur);
    const newVel = S.deleteHeld ? VEL_THRU : row === 0 && curLvl === 1 ? 0 : ARP_VEL_CANON[row + 1];
    if (newVel !== cur) {
      S.tarpStepVel[t][col] = newVel;
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + t + "_tarp_step_vel", col + " " + newVel);
      forceRedraw();
    }
    return;
  }
  if (S.sessionView && (S.loopHeld || S.perfViewLocked) && d1 >= 68 && d1 <= 99) {
    if (d1 >= 68 && d1 <= 75) {
      const subIdx = d1 - 68;
      if (subIdx === 7) {
        S.perfLatchPressedTick = S.tickCount;
      } else if (subIdx === 6) {
        S.perfSync = !S.perfSync;
        if (typeof host_module_set_param === "function")
          host_module_set_param("looper_sync", S.perfSync ? "1" : "0");
      } else if (subIdx === 5) {
        if (S.perfStickyLengths.size > 0) {
          S.perfStickyLengths = /* @__PURE__ */ new Set();
          S.perfStack = [];
          if (!S.loopHeld) S.perfViewLocked = false;
          if (typeof host_module_set_param === "function")
            host_module_set_param("looper_stop", "1");
        } else {
          S.perfHoldPadHeld = true;
        }
      } else {
        const ticks = LOOPER_RATES_STRAIGHT[subIdx];
        if (S.shiftHeld) {
          if (S.perfStickyLengths.has(subIdx)) {
            S.perfStickyLengths.delete(subIdx);
            const sIdx = S.perfStack.findIndex(function(e) {
              return e.idx === subIdx;
            });
            if (sIdx >= 0) S.perfStack.splice(sIdx, 1);
            if (typeof host_module_set_param === "function") {
              if (S.perfStack.length === 0) host_module_set_param("looper_stop", "1");
              else host_module_set_param("looper_arm", String(S.perfStack[S.perfStack.length - 1].ticks));
            }
            if (S.perfStickyLengths.size === 0 && !S.loopHeld) S.perfViewLocked = false;
          } else {
            S.perfStickyLengths.add(subIdx);
            if (S.perfStack.findIndex(function(e) {
              return e.idx === subIdx;
            }) < 0) {
              S.perfStack.push({ idx: subIdx, ticks });
              if (typeof host_module_set_param === "function")
                host_module_set_param("looper_arm", String(ticks));
            }
            S.perfViewLocked = true;
          }
        } else {
          const inStack = S.perfStack.findIndex(function(e) {
            return e.idx === subIdx;
          }) >= 0;
          const inHeld = S.perfStickyLengths.has(subIdx) || S.perfHoldPadHeld;
          if (!inStack) {
            S.perfStack.push({ idx: subIdx, ticks });
            if (typeof host_module_set_param === "function")
              host_module_set_param("looper_arm", String(ticks));
          } else if (inHeld) {
            if (typeof host_module_set_param === "function")
              host_module_set_param("looper_retrigger", String(ticks));
          }
        }
      }
    } else {
      const modIdx = PERF_MOD_PAD_MAP[d1];
      if (modIdx !== void 0) {
        const bit = 1 << modIdx;
        if (S.perfLatchMode) {
          S.perfModsToggled ^= bit;
        } else if (S.perfModsToggled & bit) {
          S.perfModsToggled &= ~bit;
        } else {
          S.perfModsHeld |= bit;
        }
        S.perfModPopupName = PERF_MOD_FULL_NAMES[modIdx] || "";
        S.perfModPopupEndTick = S.tickCount + PERF_MOD_POPUP_TICKS;
        sendPerfMods();
      }
    }
    forceRedraw();
    return;
  }
  if (S.sessionView) {
    for (let row = 0; row < 4; row++) {
      const rowBase = 92 - row * 8;
      if (d1 >= rowBase && d1 < rowBase + NUM_TRACKS) {
        const t = d1 - rowBase;
        if (S.mergeSoloPlacement >= 0) {
          const clipIdx = S.sceneRow + row;
          if (t === S.mergeSoloPlacement && !clipHasContent(t, clipIdx)) {
            S.mergePlacing = true;
            S.mergePlacingScene = false;
            S.pendingDefaultSetParams.push(
              { key: "merge_place_row", val: String(clipIdx) }
            );
          }
          forceRedraw();
          return;
        }
        if (S.capturePlaceTrack >= 0) {
          const clipIdx = S.sceneRow + row;
          if (t === S.capturePlaceTrack && !clipHasContent(t, clipIdx)) {
            S.pendingDefaultSetParams.push(
              { key: "t" + t + "_capture_commit", val: String(clipIdx) }
            );
            S.captureCommitAwait = 40;
            S.capturePending = 0;
            S.capturePlaceTrack = -1;
          }
          forceRedraw();
          return;
        }
        if (S.muteHeld) {
          if (S.shiftHeld) setTrackSolo(t, !S.trackSoloed[t]);
          else setTrackMute(t, !S.trackMuted[t]);
        } else if (S.copyHeld) {
          const clipIdx = S.sceneRow + row;
          const isDrumT = S.trackPadMode[t] === PAD_MODE_DRUM;
          if (S.copySrc && (S.copySrc.kind === "step" || S.copySrc.kind === "cut_step")) {
          } else if (!S.copySrc) {
            if (isDrumT) {
              S.copySrc = S.shiftHeld ? { kind: "cut_drum_clip", track: t, clip: clipIdx } : { kind: "drum_clip", track: t, clip: clipIdx };
            } else {
              S.copySrc = S.shiftHeld ? { kind: "cut_clip", track: t, clip: clipIdx } : { kind: "clip", track: t, clip: clipIdx };
            }
            invalidateLEDCache();
            showActionPopup(S.shiftHeld ? "CUT" : "COPIED");
          } else if (S.copySrc.kind === "clip") {
            copyClip(S.copySrc.track, S.copySrc.clip, t, clipIdx);
            invalidateLEDCache();
            forceRedraw();
            showActionPopup("PASTED");
          } else if (S.copySrc.kind === "cut_clip") {
            cutClip(S.copySrc.track, S.copySrc.clip, t, clipIdx);
            S.copySrc = { kind: "clip", track: t, clip: clipIdx };
            invalidateLEDCache();
            forceRedraw();
            showActionPopup("PASTED");
          } else if (S.copySrc.kind === "drum_clip" && isDrumT) {
            copyDrumClip(S.copySrc.track, S.copySrc.clip, t, clipIdx);
            invalidateLEDCache();
            forceRedraw();
            showActionPopup("PASTED");
          } else if (S.copySrc.kind === "cut_drum_clip" && isDrumT) {
            cutDrumClip(S.copySrc.track, S.copySrc.clip, t, clipIdx);
            S.copySrc = { kind: "drum_clip", track: t, clip: clipIdx };
            invalidateLEDCache();
            forceRedraw();
            showActionPopup("PASTED");
          }
        } else if (S.shiftHeld && S.deleteHeld) {
          const clipIdx = S.sceneRow + row;
          hardResetClip(t, clipIdx);
          forceRedraw();
          showActionPopup("CLIP", "CLEARED");
        } else if (S.deleteHeld) {
          const clipIdx = S.sceneRow + row;
          clearClip(t, clipIdx, true);
          forceRedraw();
          showActionPopup("SEQUENCE", "CLEARED");
        } else {
          const clipIdx = S.sceneRow + row;
          const isActiveClip = S.trackActiveClip[t] === clipIdx;
          if (S.shiftHeld) {
            const isPlaying = S.trackClipPlaying[t] && isActiveClip;
            const isWR = S.trackWillRelaunch[t] && isActiveClip;
            const isQueued = S.trackQueuedClip[t] === clipIdx;
            if (!isPlaying && !isWR && !isQueued) {
              if (!S.playing) {
                const prevClip = S.trackActiveClip[t];
                S.trackActiveClip[t] = clipIdx;
                S.trackCurrentPage[t] = S.trackPadMode[t] === PAD_MODE_DRUM ? 0 : Math.floor((S.clipLoopStart[t][clipIdx] | 0) / 16);
                refreshPerClipBankParams(t);
                if (S.trackPadMode[t] === PAD_MODE_DRUM && prevClip !== clipIdx) {
                  S.pendingDrumResync = 2;
                  S.pendingDrumResyncTrack = t;
                }
              }
              if ((S.playing || _clipIsEmpty(t, clipIdx)) && typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_launch_clip", String(clipIdx));
            }
            handoffRecordingToTrack(t);
            _switchActiveTrack(t);
            refreshPerClipBankParams(t);
            S.sessionView = false;
            S.shiftTrackLEDActive = false;
            invalidateLEDCache();
            forceRedraw();
          } else if (S.trackClipPlaying[t] && isActiveClip) {
            handoffRecordingToTrack(t);
            _switchActiveTrack(t);
            refreshPerClipBankParams(t);
            if (S.trackPendingPageStop[t]) {
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_launch_clip", String(clipIdx));
            } else {
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_stop_at_end", "1");
            }
          } else if (S.trackWillRelaunch[t] && isActiveClip) {
            handoffRecordingToTrack(t);
            _switchActiveTrack(t);
            refreshPerClipBankParams(t);
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_deactivate", "1");
          } else if (S.trackQueuedClip[t] === clipIdx) {
            handoffRecordingToTrack(t);
            _switchActiveTrack(t);
            refreshPerClipBankParams(t);
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_deactivate", "1");
          } else {
            handoffRecordingToTrack(t);
            _switchActiveTrack(t);
            if (!S.playing) {
              const prevClip = S.trackActiveClip[t];
              S.trackActiveClip[t] = clipIdx;
              S.trackCurrentPage[t] = 0;
              if (S.trackPadMode[t] === PAD_MODE_DRUM && prevClip !== clipIdx) {
                S.pendingDrumResync = 2;
                S.pendingDrumResyncTrack = t;
              }
            }
            refreshPerClipBankParams(t);
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_launch_clip", String(clipIdx));
          }
        }
        break;
      }
    }
  } else {
    _onPadPressTrackView(status, d1, d2);
  }
}
function _jumpToMenuLabel(label) {
  openGlobalMenu();
  if (!S.globalMenuItems || !S.globalMenuState) return;
  for (let i = 0; i < S.globalMenuItems.length; i++) {
    const it = S.globalMenuItems[i];
    if (it && it.label === label) {
      S.globalMenuState.selectedIndex = i;
      return;
    }
  }
}
function _doShiftStepCommon(idx) {
  if (idx === 1) _jumpToMenuLabel("Global");
  else if (idx === 2 && !S.sessionView) {
    S.pendingEditEntryTrack = S.activeTrack;
  } else if (idx === 4) {
    if (S.clockFollowOn) {
      S.bpmMoveInfo = true;
      forceRedraw();
    } else openTapTempo();
  } else if (idx === 5) {
    S.metronomeOn = S.metronomeOn === 1 ? 3 : 1;
    if (typeof host_module_set_param === "function")
      host_module_set_param("metro_on", String(S.metronomeOn));
    showActionPopup(["Off", "Cnt-In", "Play", "Always"][S.metronomeOn]);
  } else if (idx === 6) _jumpToMenuLabel("Swing Amt");
  else if (idx === 8) _jumpToMenuLabel("Scale");
}
function _fireLoopWindowSet(track, ctx, startStep, lenSteps) {
  if (typeof host_module_set_param !== "function") return;
  if (ctx === 3) {
    _fireLoopWindowSetCC(track, startStep, lenSteps);
    return;
  }
  const packed = startStep << 16 | lenSteps & 65535;
  if (ctx === 0) {
    const ac = effectiveClip(track);
    S.clipLength[track][ac] = lenSteps;
    S.clipLoopStart[track][ac] = startStep;
    S.clipLengthManuallySet[track][ac] = true;
    const startPage = startStep >> 4;
    const lastPage = startPage + (lenSteps + 15 >> 4) - 1;
    if (S.trackCurrentPage[track] < startPage) S.trackCurrentPage[track] = startPage;
    else if (S.trackCurrentPage[track] > lastPage) S.trackCurrentPage[track] = lastPage;
    host_module_set_param("t" + track + "_c" + ac + "_loop_set", String(packed));
  } else if (ctx === 1) {
    const lane = S.activeDrumLane[track];
    S.drumLaneLength[track] = lenSteps;
    S.drumLaneLoopStart[track] = startStep;
    S.drumLaneLengthManuallySet[track] = true;
    const startPage = startStep >> 4;
    const lastPage = startPage + (lenSteps + 15 >> 4) - 1;
    if (S.drumStepPage[track] < startPage) S.drumStepPage[track] = startPage;
    else if (S.drumStepPage[track] > lastPage) S.drumStepPage[track] = lastPage;
    host_module_set_param("t" + track + "_l" + lane + "_loop_set", String(packed));
  } else {
    if (allLanesGate()) return;
    S.drumLaneLength[track] = lenSteps;
    S.drumLaneLoopStart[track] = startStep;
    S.drumLaneLengthManuallySet[track] = true;
    const startPage = startStep >> 4;
    const lastPage = startPage + (lenSteps + 15 >> 4) - 1;
    if (S.drumStepPage[track] < startPage) S.drumStepPage[track] = startPage;
    else if (S.drumStepPage[track] > lastPage) S.drumStepPage[track] = lastPage;
    S.pendingDrumResync = 2;
    S.pendingDrumResyncTrack = track;
    host_module_set_param("t" + track + "_all_lanes_loop_set", String(packed));
  }
}
function _fireLoopWindowSetCC(track, startStep, lenSteps) {
  if (typeof host_module_set_param !== "function") return;
  var ac = effectiveClip(track);
  var lane = S.ccActiveLane[track];
  S.ccLaneLoopStart[track][ac][lane] = startStep;
  S.ccLaneLength[track][ac][lane] = lenSteps;
  var packed = startStep << 16 | lenSteps & 65535;
  host_module_set_param("t" + track + "_c" + ac + "_k" + lane + "_cc_loop_set", String(packed));
  var startPage = startStep >> 4;
  var lastPage = startPage + (lenSteps + 15 >> 4) - 1;
  if (S.trackCurrentPage[track] < startPage) S.trackCurrentPage[track] = startPage;
  else if (S.trackCurrentPage[track] > lastPage) S.trackCurrentPage[track] = lastPage;
}
function _loopGestureCtxFor(track) {
  if (S.activeBank === 6) return 3;
  if (S.trackPadMode[track] !== PAD_MODE_DRUM) return 0;
  return S.activeBank === 7 ? 2 : 1;
}
function _resolveLoopGesture(fireFallback) {
  const a = S.loopGestureStart;
  if (a < 0) return;
  const ctx = S.loopGestureCtx;
  const trk = S.loopGestureTrack;
  const clip = S.loopGestureClip;
  const fired = S.loopGestureFired;
  S.loopGestureStart = -1;
  S.loopGestureFired = false;
  S.loopGestureTrack = -1;
  S.loopGestureClip = -1;
  S.loopGestureLane = -1;
  if (fired) {
    forceRedraw();
    return;
  }
  if (fireFallback) {
    var currentLs, currentLen;
    if (ctx === 3) {
      var _ccLane = S.ccActiveLane[trk];
      currentLs = S.ccLaneLoopStart[trk][clip][_ccLane] | 0;
      currentLen = S.ccLaneLength[trk][clip][_ccLane] | 0;
      if (currentLen === 0) {
        var _cTps = S.clipTPS[trk][clip] || 24;
        var _lTps = S.ccLaneTps[trk][clip][_ccLane] || _cTps;
        currentLs = Math.round((S.clipLoopStart[trk][clip] | 0) * _cTps / _lTps);
        currentLen = Math.max(1, Math.round(S.clipLength[trk][clip] * _cTps / _lTps));
      }
    } else if (ctx === 0) {
      currentLs = S.clipLoopStart[trk][clip] | 0;
      currentLen = S.clipLength[trk][clip] | 0;
    } else {
      currentLs = S.drumLaneLoopStart[trk] | 0;
      currentLen = S.drumLaneLength[trk] | 0;
    }
    const startPage = currentLs >> 4;
    let newLs, newLen;
    if (currentLs === 0 || a < startPage) {
      newLs = 0;
      newLen = (a + 1) * 16;
    } else {
      newLs = currentLs;
      newLen = (a - startPage + 1) * 16;
    }
    if (newLen === currentLen && currentLen === 32) {
      newLen = 16;
    }
    _fireLoopWindowSet(trk, ctx, newLs, newLen);
  }
  forceRedraw();
}
function _onStepButtons(d1, d2) {
  if (S.mergeNoticePending) return;
  if (S.schwungCoRunSlot >= 0 || S.moveCoRunTrack >= 0) {
    if (d1 - 16 === 2) {
      if (S.moveCoRunTrack >= 0) exitMoveNativeCoRun();
      else {
        exitSchwungCoRun();
        forceRedraw();
      }
    }
    return;
  }
  if (S.tapTempoOpen) return;
  if (d2 > 0 && S.shiftTrackLEDActive) {
    S.shiftTrackLEDActive = false;
    S.screenDirty = true;
  }
  const idx = d1 - 16;
  if (S.sessionView && S.deleteHeld) {
    if (S.loopHeld || S.perfViewLocked) {
      S.perfSnapshots[idx] = 0;
      if (S.perfRecalledSlot === idx) {
        S.perfRecalledSlot = -1;
        S.perfModsToggled = 0;
        sendPerfMods();
      }
      showActionPopup("PERF PRESET", "CLEARED");
    } else if (S.muteHeld) {
      S.snapshots[idx] = null;
      S.pendingDefaultSetParams.push({ key: "snap_delete", val: String(idx) });
      showActionPopup("MUTE STATE", "CLEARED");
    }
    forceRedraw();
    return;
  }
  if (S.sessionView && (S.loopHeld || S.perfViewLocked)) {
    S.stepBtnPressedTick[idx] = S.tickCount;
    S.sessionStepHeld = idx;
    S.sessionStepHeldCtx = 1;
    return;
  }
  if (S.sessionView) {
    if (S.pendingSceneBakePicker) {
      S.pendingSceneBakePicker = false;
      S.confirmBakeScene = true;
      S.confirmBakeSceneWrapPhase = false;
      S.confirmBakeSceneCondPhase = false;
      S.confirmBakeSceneSel = 1;
      S.confirmBakeSceneClip = idx;
      S.screenDirty = true;
      return;
    }
    if (S.pendingMergePlacement) {
      S.pendingMergePlacement = false;
      S.mergePlacing = true;
      S.mergePlacingScene = true;
      S.pendingDefaultSetParams.push({ key: "merge_place_row", val: String(idx) });
      S.screenDirty = true;
      return;
    }
    if (S.muteHeld) {
      S.stepBtnPressedTick[idx] = S.tickCount;
      S.sessionStepHeld = idx;
      S.sessionStepHeldCtx = 2;
      return;
    } else if (S.shiftHeld) {
      _doShiftStepCommon(idx);
      forceRedraw();
    } else if (!S.deleteHeld) {
      S.pendingDefaultSetParams.push({ key: "launch_scene", val: String(idx) });
    }
  } else if (S.loopHeld) {
    if (S.recordArmed && !S.recordCountingIn) {
    } else if (S.loopGestureStart < 0) {
      const t3 = S.activeTrack;
      S.loopGestureStart = idx;
      S.loopGestureFired = false;
      S.loopGestureCtx = _loopGestureCtxFor(t3);
      S.loopGestureTrack = t3;
      S.loopGestureClip = S.loopGestureCtx === 0 || S.loopGestureCtx === 3 ? effectiveClip(t3) : -1;
      S.loopGestureLane = S.loopGestureCtx === 1 ? S.activeDrumLane[t3] : -1;
      forceRedraw();
    } else if (idx !== S.loopGestureStart) {
      const a = Math.min(S.loopGestureStart, idx);
      const b = Math.max(S.loopGestureStart, idx);
      const startStep = a * 16;
      const lenSteps = (b - a + 1) * 16;
      _fireLoopWindowSet(S.loopGestureTrack, S.loopGestureCtx, startStep, lenSteps);
      S.loopGestureFired = true;
      forceRedraw();
    }
  } else if (S.copyHeld) {
    const ac2 = effectiveClip(S.activeTrack);
    const absIdx2 = S.trackCurrentPage[S.activeTrack] * 16 + idx;
    if (!S.copySrc) {
      S.copySrc = S.shiftHeld ? { kind: "cut_step", absStep: absIdx2 } : { kind: "step", absStep: absIdx2 };
      if (S.shiftHeld) showActionPopup("CUT STEP");
      invalidateLEDCache();
    } else if (S.copySrc.kind === "step") {
      if (S.copySrc.absStep !== absIdx2) copyStep(S.activeTrack, ac2, S.copySrc.absStep, absIdx2);
      invalidateLEDCache();
      forceRedraw();
    } else if (S.copySrc.kind === "cut_step") {
      if (S.copySrc.absStep !== absIdx2) {
        cutStep(S.activeTrack, ac2, S.copySrc.absStep, absIdx2);
        S.copySrc = { kind: "step", absStep: absIdx2 };
      }
      invalidateLEDCache();
      forceRedraw();
    }
  } else if (S.deleteHeld) {
    if (S.activeBank === 6) {
      var t = S.activeTrack, ac = effectiveClip(t);
      var absIdx = S.trackCurrentPage[t] * 16 + idx;
      var _ccL_d = S.ccActiveLane[t];
      var _ltps_d = S.ccLaneTps[t][ac][_ccL_d];
      var tps = _ltps_d > 0 ? _ltps_d : S.clipTPS[t][ac] || 24;
      var t1 = absIdx * tps, t2 = Math.min(65535, t1 + tps - 1);
      S.undoAvailable = true;
      S.redoAvailable = false;
      S.undoSeqArpSnapshot = null;
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + t + "_cc_auto_clear_step", ac + " " + t1 + " " + t2);
      S.pendingCCBitsRefresh = ac;
      showActionPopup("CC STEP", "CLEAR");
      invalidateLEDCache();
      forceRedraw();
    } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
      const t3 = S.activeTrack;
      const lane = S.activeDrumLane[t3];
      const absStep = S.drumStepPage[t3] * 16 + idx;
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + t3 + "_l" + lane + "_step_" + absStep + "_clear", "1");
      S.drumLaneSteps[t3][lane][absStep] = "0";
      S.drumLaneHasNotes[t3][lane] = S.drumLaneSteps[t3][lane].some((c) => c !== "0");
      forceRedraw();
    } else {
      const ac2 = effectiveClip(S.activeTrack);
      const absIdx2 = S.trackCurrentPage[S.activeTrack] * 16 + idx;
      clearStep(S.activeTrack, ac2, absIdx2);
      forceRedraw();
    }
  } else if (S.shiftHeld) {
    _doShiftStepCommon(idx);
    const t3 = S.activeTrack;
    const isDrum = S.trackPadMode[t3] === PAD_MODE_DRUM;
    if (idx === 7) {
      if (isDrum) {
        if (S.drumPerformMode[t3] === 1) {
          host_module_set_param("t" + t3 + "_drum_repeat_stop", "1");
          S.drumRepeatHeldPad[t3] = -1;
          S.drumRepeatHeldPadsStack[t3].length = 0;
        }
        if (S.drumPerformMode[t3] === 2) {
          S.drumRepeat2HeldLanes[t3].clear();
          S.drumRepeat2LatchedLanes[t3].clear();
          host_module_set_param("t" + t3 + "_drum_repeat2_stop", "1");
        }
        S.drumRepeatLatched[t3] = false;
        setDrumPerformMode(t3, (S.drumPerformMode[t3] + 1) % 3);
        if (S.drumPerformMode[t3] > 0) S.activeBank = 5;
        showModePopup(
          "PERFORMANCE PADS",
          ["Velocity", "Repeat Play (Rpt1)", "Repeat Set (Rpt2)"],
          S.drumPerformMode[t3]
        );
      } else {
        S.padLayoutChromatic[t3] = !S.padLayoutChromatic[t3];
        computePadNoteMap();
        showActionPopup(S.padLayoutChromatic[t3] ? "CHROMATIC" : "IN-SCALE");
      }
    } else if (idx === 9) {
      const curVel = S.trackVelOverride[t3];
      const nextVel = curVel === 0 ? 100 : 0;
      applyTrackConfig(t3, "track_vel_override", nextVel);
    } else if (idx === 10 && !isDrum) {
      const curStyle = S.bankParams[t3][5][0] | 0;
      const nextStyle = curStyle !== 0 ? 0 : S.lastTarpStyle[t3];
      S.bankParams[t3][5][0] = nextStyle;
      applyBankParam(t3, 5, 0, nextStyle);
    } else if (idx === 14) {
      if (S.activeBank === 6) {
        doLaneDoubleFill();
      } else {
        doDoubleFill();
      }
    } else if (idx === 15 && S.activeBank !== 6) {
      if (isDrum) {
        if (S.activeBank === 7) {
          if (allLanesGate()) return;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t3 + "_drum_lanes_qnt", "100");
          S.bankParams[t3][7][3] = 100;
          S.drumLaneQnt[t3] = 100;
          S.bankParams[t3][1][2] = 100;
        } else {
          const lane = S.activeDrumLane[t3];
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t3 + "_l" + lane + "_pfx_set", "quantize 100");
          S.drumLaneQnt[t3] = 100;
          S.bankParams[t3][1][2] = 100;
        }
      } else {
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t3 + "_quantize", "100");
      }
      if (!isDrum) S.bankParams[t3][1][3] = 100;
      showActionPopup("QUANT 100%");
    }
    forceRedraw();
  } else if (!S.shiftHeld && S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank !== 6) {
    const t3 = S.activeTrack;
    const lane = S.activeDrumLane[t3];
    const absStep = S.drumStepPage[t3] * 16 + idx;
    S.stepBtnPressedTick[idx] = S.tickCount;
    if (S.heldStep < 0) {
      S.heldStepBtn = idx;
      S.heldStep = absStep;
      const cur = S.drumLaneSteps[t3][lane][absStep];
      if (cur !== "0") {
        S.stepWasEmpty = false;
        S.heldStepNotes = [S.drumLaneNote[t3][lane]];
        S.drumHeldReadPending = true;
        S.stepEditVel = 100;
        S.stepEditGate = S.drumLaneTPS[t3] || 24;
        S.stepEditNudge = 0;
        S.stepEditIter = 0;
        S.stepEditRand = 0;
        S.stepEditRatch = 0;
      } else {
        S.stepWasEmpty = true;
        S.drumHeldReadPending = false;
        S.heldStepNotes = [];
        S.stepEditVel = stepEntryVelocity(t3, -1, true);
        S.stepEditGate = S.drumLaneTPS[t3] || 24;
        S.stepEditNudge = 0;
        S.stepEditIter = 0;
        S.stepEditRand = 0;
        S.stepEditRatch = 0;
      }
      forceRedraw();
    } else if (S.stepBtnPressedTick[S.heldStepBtn] >= 0) {
      const absStep2 = S.drumStepPage[t3] * 16 + idx;
      const cur2 = S.drumLaneSteps[t3][lane][absStep2];
      if (typeof host_module_set_param === "function") {
        if (cur2 !== "1") {
          host_module_set_param("t" + t3 + "_l" + lane + "_step_" + absStep2 + "_toggle", String(stepEntryVelocity(t3, -1, true)));
          S.drumLaneSteps[t3][lane][absStep2] = "1";
          S.drumLaneHasNotes[t3][lane] = true;
        } else {
          host_module_set_param("t" + t3 + "_l" + lane + "_step_" + absStep2 + "_clear", "1");
          S.drumLaneSteps[t3][lane][absStep2] = "0";
          S.drumLaneHasNotes[t3][lane] = S.drumLaneSteps[t3][lane].some((c) => c !== "0");
        }
      }
      S.stepBtnPressedTick[idx] = -1;
      forceRedraw();
    } else if (S.heldStepNotes.length > 0) {
      S.stepBtnPressedTick[S.heldStepBtn] = -1;
      S.stepWasHeld = true;
      const tappedStep = S.drumStepPage[t3] * 16 + idx;
      if (tappedStep !== S.heldStep) {
        const len = S.drumLaneLength[t3];
        const tps2 = S.drumLaneTPS[t3] || 24;
        const dist = tappedStep > S.heldStep ? tappedStep - S.heldStep + 1 : len - S.heldStep + tappedStep + 1;
        const newGate = Math.max(1, Math.min(dist * tps2, 65535));
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t3 + "_l" + lane + "_step_" + S.heldStep + "_gate", String(newGate));
        S.stepEditGate = newGate;
        forceRedraw();
      }
    }
  } else if (!S.shiftHeld) {
    S.stepBtnPressedTick[idx] = S.tickCount;
    if (S.heldStep < 0) {
      const ac_p = effectiveClip(S.activeTrack);
      const absP = S.trackCurrentPage[S.activeTrack] * 16 + idx;
      S.heldStepBtn = idx;
      S.heldStep = absP;
      const pref_p = "t" + S.activeTrack + "_c" + ac_p + "_step_" + absP;
      const _stepState = S.clipSteps[S.activeTrack][ac_p][absP];
      if (_stepState === 0) {
        S.stepWasEmpty = true;
        S.heldStepNotes = [];
        if (S.activeBank === 6) {
          S.ccStepEditActive = true;
        } else {
          S.stepEditVel = 100;
          S.stepEditGate = 12;
          S.stepEditNudge = 0;
          S.stepEditIter = 0;
          S.stepEditRand = 0;
          S.stepEditRatch = 0;
        }
      } else {
        S.stepWasEmpty = false;
        S.heldStepNotes = [];
        if (S.activeBank === 6) {
          S.ccStepEditActive = true;
        } else {
          S.stepEditVel = 100;
          S.stepEditGate = 12;
          S.stepEditNudge = 0;
          S.stepEditIter = 0;
          S.stepEditRand = 0;
          S.stepEditRatch = 0;
        }
      }
      if (S.liveActiveNotes.size > 0 && S.activeBank !== 6 && S.trackPadMode[S.activeTrack] !== PAD_MODE_DRUM) {
        S.pendingChordToStep = {
          t: S.activeTrack,
          ac: ac_p,
          step: absP,
          wasEmpty: _stepState === 0,
          pitches: [...S.liveActiveNotes].sort(function(a, b) {
            return a - b;
          }),
          vel: stepEntryVelocity(S.activeTrack, effectiveVelocity(S.lastPadVelocity), false)
        };
        S.stepBtnPressedTick[idx] = -1;
        S.stepWasHeld = true;
      }
      forceRedraw();
    } else if (S.stepBtnPressedTick[S.heldStepBtn] >= 0 && S.activeBank !== 6) {
      const ac_mp = effectiveClip(S.activeTrack);
      const absStep2 = S.trackCurrentPage[S.activeTrack] * 16 + idx;
      const pref_mp = "t" + S.activeTrack + "_c" + ac_mp + "_step_" + absStep2;
      const state_mp = S.clipSteps[S.activeTrack][ac_mp][absStep2];
      if (state_mp === 0) {
        const assignNote3 = S.lastPlayedNote >= 0 ? S.lastPlayedNote : -1;
        if (assignNote3 >= 0 && typeof host_module_set_param === "function") {
          host_module_set_param(pref_mp + "_toggle", assignNote3 + " " + stepEntryVelocity(S.activeTrack, -1, false));
          S.clipSteps[S.activeTrack][ac_mp][absStep2] = 1;
          S.clipNonEmpty[S.activeTrack][ac_mp] = true;
          refreshSeqNotesIfCurrent(S.activeTrack, ac_mp, absStep2);
        }
      } else if (state_mp === 1) {
        if (typeof host_module_set_param === "function")
          host_module_set_param(pref_mp, "0");
        S.clipSteps[S.activeTrack][ac_mp][absStep2] = 2;
        if (S.clipNonEmpty[S.activeTrack][ac_mp]) S.clipNonEmpty[S.activeTrack][ac_mp] = clipHasContent(S.activeTrack, ac_mp);
        refreshSeqNotesIfCurrent(S.activeTrack, ac_mp, absStep2);
      } else {
        if (typeof host_module_set_param === "function")
          host_module_set_param(pref_mp, "1");
        S.clipSteps[S.activeTrack][ac_mp][absStep2] = 1;
        S.clipNonEmpty[S.activeTrack][ac_mp] = true;
        refreshSeqNotesIfCurrent(S.activeTrack, ac_mp, absStep2);
      }
      S.stepBtnPressedTick[idx] = -1;
      forceRedraw();
    } else if (S.heldStepNotes.length > 0 && S.activeBank !== 6) {
      S.stepBtnPressedTick[S.heldStepBtn] = -1;
      S.stepWasHeld = true;
      const ac_tap = effectiveClip(S.activeTrack);
      const tappedStep = S.trackCurrentPage[S.activeTrack] * 16 + idx;
      if (tappedStep !== S.heldStep) {
        const len = S.clipLength[S.activeTrack][ac_tap];
        const tps2 = S.clipTPS[S.activeTrack][ac_tap] || 24;
        const dist = tappedStep > S.heldStep ? tappedStep - S.heldStep + 1 : len - S.heldStep + tappedStep + 1;
        const spanGate = dist * tps2;
        const newGate = Math.max(1, Math.min(
          S.stepEditGate >= spanGate ? (dist - 1) * tps2 : spanGate,
          65535
        ));
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + S.activeTrack + "_c" + ac_tap + "_step_" + S.heldStep + "_gate", String(newGate));
        S.stepEditGate = newGate;
        forceRedraw();
      }
    }
  }
}
function _onPadRelease(status, d1, d2) {
  if (S.mergeNoticePending) return;
  if (S.tapTempoOpen && d1 >= 68 && d1 <= 99) return;
  if (S.moveCoRunTrack >= 0 && S.moveCoRunDrumHeld.has(d1) && typeof move_midi_inject_to_move === "function") {
    move_midi_inject_to_move([8, 128, d1, 0]);
    S.moveCoRunDrumHeld.delete(d1);
  }
  if (d1 >= 16 && d1 <= 31 && S.loopGestureStart >= 0) {
    const idx = d1 - 16;
    if (idx === S.loopGestureStart) _resolveLoopGesture(true);
    return;
  }
  if (!S.sessionView && S.activeBank === 4 && S.knobTouched === 4 && (S.bankParams[S.activeTrack][4][4] | 0) !== 0 && d1 >= 68 && d1 <= 99) {
    const _pi = d1 - TRACK_PAD_BASE;
    if (_pi >= 0 && _pi < 32 && padPitch[_pi] >= 0) {
      liveSendNote(S.activeTrack, 128, padPitch[_pi], 0);
      S.liveActiveNotes.delete(padPitch[_pi]);
      padPitch[_pi] = -1;
    }
    return;
  }
  if (!S.sessionView && S.activeBank === 5 && S.knobTouched === 4 && (S.bankParams[S.activeTrack][5][4] | 0) !== 0 && d1 >= 68 && d1 <= 99) {
    const _pi = d1 - TRACK_PAD_BASE;
    if (_pi >= 0 && _pi < 32 && padPitch[_pi] >= 0) {
      liveSendNote(S.activeTrack, 128, padPitch[_pi], 0);
      S.liveActiveNotes.delete(padPitch[_pi]);
      padPitch[_pi] = -1;
    }
    return;
  }
  if (S.sessionView && (S.loopHeld || S.perfViewLocked) && d1 >= 68 && d1 <= 99) {
    if (d1 >= 68 && d1 <= 75) {
      const subIdx = d1 - 68;
      if (subIdx === 7) {
        S.perfLatchMode = !S.perfLatchMode;
      } else if (subIdx === 5) {
        if (S.perfHoldPadHeld) {
          S.perfHoldPadHeld = false;
          if (S.perfStack.length > 0) {
            S.perfStack = [];
            if (typeof host_module_set_param === "function")
              host_module_set_param("looper_stop", "1");
          }
        }
      } else if (subIdx < 5) {
        if (!S.perfStickyLengths.has(subIdx) && !S.perfHoldPadHeld) {
          const sIdx = S.perfStack.findIndex(function(e) {
            return e.idx === subIdx;
          });
          if (sIdx >= 0) {
            S.perfStack.splice(sIdx, 1);
            if (S.perfStack.length === 0) {
              if (typeof host_module_set_param === "function")
                host_module_set_param("looper_stop", "1");
            } else {
              const top = S.perfStack[S.perfStack.length - 1];
              if (typeof host_module_set_param === "function")
                host_module_set_param("looper_arm", String(top.ticks));
            }
          }
        }
      }
    } else {
      const modIdx = PERF_MOD_PAD_MAP[d1];
      if (modIdx !== void 0) {
        S.perfModsHeld &= ~(1 << modIdx);
        sendPerfMods();
      }
    }
    forceRedraw();
    return;
  }
  if (d1 >= 16 && d1 <= 31) {
    const btn = d1 - 16;
    if (S.sessionStepHeld === btn) {
      const ctx = S.sessionStepHeldCtx;
      S.sessionStepHeld = -1;
      S.sessionStepHeldCtx = 0;
      S.stepBtnPressedTick[btn] = -1;
      if (ctx === 1) {
        if (S.perfRecalledSlot === btn) {
          S.perfRecalledSlot = -1;
          S.perfModsToggled = 0;
        } else {
          S.perfRecalledSlot = btn;
          S.perfModsToggled = S.perfSnapshots[btn];
        }
        sendPerfMods();
      } else {
        if (S.snapshots[btn] !== null) {
          const snap = S.snapshots[btn];
          for (let _t = 0; _t < NUM_TRACKS; _t++) {
            S.trackMuted[_t] = snap.mute[_t];
            S.trackSoloed[_t] = snap.solo[_t];
            if (snap.drumEffMute) {
              S.drumLaneMute[_t] = snap.drumEffMute[_t];
              S.drumLaneSolo[_t] = 0;
            }
          }
          S.pendingDefaultSetParams.push({ key: "snap_load", val: String(btn) });
        }
      }
      forceRedraw();
      return;
    }
    if (btn === S.heldStepBtn) {
      if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank !== 6) {
        const t = S.activeTrack;
        const lane = S.activeDrumLane[t];
        let drumStepCleared = false;
        if (S.stepBtnPressedTick[btn] >= 0) {
          S.stepBtnPressedTick[btn] = -1;
          if (S.stepWasEmpty) {
            const _writeVel = stepEntryVelocity(t, -1, true);
            S.stepEditVel = _writeVel;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_toggle", String(_writeVel));
            S.drumLaneSteps[t][lane][S.heldStep] = "1";
            S.drumLaneHasNotes[t][lane] = true;
          } else {
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_clear", "1");
            S.drumLaneSteps[t][lane][S.heldStep] = "0";
            S.drumLaneHasNotes[t][lane] = S.drumLaneSteps[t][lane].some((c) => c !== "0");
            drumStepCleared = true;
          }
          if (typeof host_module_get_param === "function") {
            const ac = S.trackActiveClip[t];
            const hcRaw = host_module_get_param("t" + t + "_c" + ac + "_drum_has_content");
            S.drumClipNonEmpty[t][ac] = hcRaw === "1";
          }
        }
        let drumDidReassign = false;
        if (S.stepWasHeld && S.heldStepNotes.length > 0) {
          const _tpsMid = Math.floor((S.drumLaneTPS[t] || 24) / 2);
          let dstStep = -1;
          if (S.stepEditNudge >= _tpsMid)
            dstStep = (S.heldStep + 1) % S.drumLaneLength[t];
          else if (S.stepEditNudge < -_tpsMid)
            dstStep = (S.heldStep - 1 + S.drumLaneLength[t]) % S.drumLaneLength[t];
          if (dstStep >= 0) {
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_reassign", String(dstStep));
            S.drumLaneSteps[t][lane][S.heldStep] = "0";
            S.pendingDrumLaneResync = 3;
            S.pendingDrumLaneResyncTrack = t;
            S.pendingDrumLaneResyncLane = lane;
            drumDidReassign = true;
          }
        }
        if (!drumStepCleared && !drumDidReassign && S.heldStepNotes.length > 0 && !S.drumHeldReadPending) {
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_vel", String(S.stepEditVel));
        }
        S.drumHeldReadPending = false;
      } else {
        if (S.stepBtnPressedTick[btn] >= 0 && S.activeBank !== 6) {
          const ac_t = effectiveClip(S.activeTrack);
          const absIdx = S.heldStep;
          S.stepBtnPressedTick[btn] = -1;
          if (S.stepWasEmpty) {
            if (S.lastPlayedNote >= 0) {
              const assignNote_t = S.lastPlayedNote;
              const assignVel_t = stepEntryVelocity(S.activeTrack, -1, false);
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + S.activeTrack + "_c" + ac_t + "_step_" + absIdx + "_toggle", assignNote_t + " " + assignVel_t);
              S.clipSteps[S.activeTrack][ac_t][absIdx] = 1;
              S.clipNonEmpty[S.activeTrack][ac_t] = true;
              refreshSeqNotesIfCurrent(S.activeTrack, ac_t, absIdx);
            } else {
              S.noNoteFlashEndTick = S.tickCount + NO_NOTE_FLASH_TICKS;
              S.screenDirty = true;
            }
          } else {
            clearStep(S.activeTrack, ac_t, absIdx);
            refreshSeqNotesIfCurrent(S.activeTrack, ac_t, absIdx);
          }
        }
        if (S.stepWasHeld && S.heldStep >= 0 && S.heldStepNotes.length > 0 && S.activeBank !== 6) {
          const ac_ra = effectiveClip(S.activeTrack);
          const lenRa = S.clipLength[S.activeTrack][ac_ra];
          let dstStep = -1;
          if (S.stepEditNudge >= 12)
            dstStep = (S.heldStep + 1) % lenRa;
          else if (S.stepEditNudge <= -13)
            dstStep = (S.heldStep - 1 + lenRa) % lenRa;
          if (dstStep >= 0) {
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + S.activeTrack + "_c" + ac_ra + "_step_" + S.heldStep + "_reassign", String(dstStep));
            S.clipSteps[S.activeTrack][ac_ra][S.heldStep] = 0;
          }
          S.pendingStepsReread = 2;
          S.pendingStepsRereadTrack = S.activeTrack;
          S.pendingStepsRereadClip = ac_ra;
        }
      }
      S.heldStepBtn = -1;
      S.heldStep = -1;
      S.heldStepNotes = [];
      S.stepWasEmpty = false;
      S.stepWasHeld = false;
      forceRedraw();
    }
  }
  if (d1 >= TRACK_PAD_BASE && d1 < TRACK_PAD_BASE + 32) {
    const padIdx = d1 - TRACK_PAD_BASE;
    const t = S.activeTrack;
    if (S.trackPadMode[t] === PAD_MODE_DRUM && S.drumPerformMode[t] === 1 && padIdx % 8 >= 4) {
      if (S.drumRepeatHeldPad[t] === padIdx && !S.drumRepeatLatched[t]) {
        const _prev = S.drumRepeatHeldPadsStack[t].length > 0 ? S.drumRepeatHeldPadsStack[t].pop() : null;
        if (_prev) {
          S.drumRepeatHeldPad[t] = _prev.padIdx;
          if (typeof host_module_set_param === "function")
            host_module_set_param(
              "t" + t + "_drum_repeat_start",
              S.activeDrumLane[t] + " " + _prev.rateIdx + " " + _prev.vel
            );
        } else {
          S.drumRepeatHeldPad[t] = -1;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_drum_repeat_stop", "1");
        }
      } else if (S.drumRepeatHeldPad[t] !== padIdx) {
        const _si = S.drumRepeatHeldPadsStack[t].findIndex((e) => e.padIdx === padIdx);
        if (_si >= 0) S.drumRepeatHeldPadsStack[t].splice(_si, 1);
      }
      S.screenDirty = true;
      return;
    }
    if (S.trackPadMode[t] === PAD_MODE_DRUM && S.drumPerformMode[t] === 2 && padIdx % 8 < 4) {
      const lane = drumPadToLane(padIdx);
      if (lane >= 0 && lane < DRUM_LANES && S.drumRepeat2HeldLanes[t].has(lane)) {
        S.drumRepeat2HeldLanes[t].delete(lane);
        if (!S.drumRepeat2LatchedLanes[t].has(lane)) {
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_drum_repeat2_lane_off", String(lane));
        }
        S.screenDirty = true;
      }
      return;
    }
    if (S.trackPadMode[t] === PAD_MODE_DRUM && S.drumPerformMode[t] === 2 && padIdx % 8 >= 4) {
      S.screenDirty = true;
      return;
    }
    const pitch = padPitch[padIdx] >= 0 ? padPitch[padIdx] : S.padNoteMap[padIdx];
    if (pitch === 255) return;
    S.liveActiveNotes.delete(pitch);
    if (S.pendingPrerollNote !== null) {
      const _prRelPitch = S.pendingPrerollNote.laneNote;
      if (_prRelPitch === pitch)
        S.pendingPrerollNote.releasedAtTick = S.tickCount;
    }
    for (let _pri = 0; _pri < S.pendingPrerollNotes.length; _pri++) {
      if (S.pendingPrerollNotes[_pri].pitch === pitch) {
        S.pendingPrerollNotes[_pri].releasedAtTick = S.tickCount;
        break;
      }
    }
    padPitch[padIdx] = -1;
    if (!S.sessionView) {
      const t2 = S.activeTrack;
      if (S.trackPadMode[t2] === PAD_MODE_DRUM && S.tickCount - padPressTick[padIdx] < DRUM_TAP_TICKS)
        pendingDrumNoteOffs[t2].push(pitch);
      else
        liveSendNote(t2, 128, pitch, 0);
    }
    padPressTick[padIdx] = -1;
    if (S.recordArmed) {
      const _t = S.activeTrack;
      if (S.trackPadMode[_t] === PAD_MODE_DRUM) {
        if (_t === S.recordArmedTrack)
          _drumRecNoteOffs.push({ track: _t, laneNote: pitch });
      } else {
        recordNoteOff(pitch);
      }
    }
  }
}
function _onPadAftertouch(d1, d2) {
  if (S.mergeNoticePending) return;
  const t = S.activeTrack;
  const padIdx = d1 - TRACK_PAD_BASE;
  if (S.trackPadMode[t] !== PAD_MODE_DRUM) {
    let mode = S.trackAtMode[t] | 0;
    if (mode === 0) return;
    if (S.trackRoute[t] === 1 && mode === 2) mode = 1;
    if (padIdx < 0 || padIdx >= 32) return;
    const pitch = padPitch[padIdx];
    if (pitch < 0) return;
    if (S.atLastSent[padIdx] === d2) return;
    S.atLastSent[padIdx] = d2;
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + t + "_live_at", pitch + " " + d2 + " " + mode);
    return;
  }
  if (S.trackPadMode[t] === PAD_MODE_DRUM && S.drumPerformMode[t] === 1 && S.drumRepeatHeldPad[t] === padIdx && d2 > 0) {
    S.drumRepeatHeldPadVel[t] = d2;
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + t + "_drum_repeat_vel", String(d2));
  }
  if (S.trackPadMode[t] === PAD_MODE_DRUM && S.drumPerformMode[t] === 2 && d2 > 0) {
    const col2 = padIdx % 8;
    if (col2 < 4) {
      const lane = drumPadToLane(padIdx);
      if (lane >= 0 && S.drumRepeat2HeldLanes[t].has(lane)) {
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_drum_repeat2_vel", lane + " " + d2);
      }
    }
  }
}

// ui/ui_input_cc.mjs
import {
  MoveShift,
  MoveBack,
  MovePlay,
  MoveLeft,
  MoveRight,
  MoveUp,
  MoveDown,
  MoveMute,
  MoveDelete,
  Red as Red4
} from "/data/UserData/schwung/shared/constants.mjs";
import {
  setLED as setLED3,
  setButtonLED as setButtonLED4,
  decodeDelta
} from "/data/UserData/schwung/shared/input_filter.mjs";
import {
  handleMenuInput
} from "/data/UserData/schwung/shared/menu_nav.mjs";
var LOOP_TAP_TICKS = 40;
var STRETCH_BLOCKED_TICKS = 141;
var NOTE_SESSION_HOLD_TICKS = 19;
var BACK_HOLD_TICKS = 42;
function _onCC_jog(d1, d2) {
  if (S.shiftTrackLEDActive) {
    S.shiftTrackLEDActive = false;
    S.screenDirty = true;
  }
  if (d1 === 3 && d2 === 127 && S.tempoSelectActive) {
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + S.tempoSelectTrack + "_capture_confirm", "");
    S.tempoSelectActive = false;
    showActionPopup(
      "TEMPO SET",
      Math.round(S.tempoSelectBpms[S.tempoSelectIdx]) + " BPM"
    );
    S.screenDirty = true;
    return;
  }
  if (d1 === 3 && d2 === 127 && S.pendingInheritPicker) {
    const p2 = S.pendingInheritPicker;
    const action = p2.selectedIndex === p2.candidates.length ? -1 : p2.selectedIndex;
    resolveInheritPicker(action);
    return;
  }
  if (d1 === 3 && d2 === 127 && S.snapshotPicker) {
    snapshotPickerClick();
    return;
  }
  if (d1 === 3 && d2 === 127 && S.clearAutoMenu) {
    clearAutoMenuClick();
    return;
  }
  if (d1 === 3 && d2 === 127 && S.confirmBakeScene) {
    if (S.confirmBakeSceneCondPhase) {
      if (S.confirmBakeSceneCondSel === 2) {
        S.confirmBakeSceneCondPhase = false;
        S.confirmBakeScene = false;
        S.screenDirty = true;
        return;
      }
      const _apply = S.confirmBakeSceneCondSel === 0 ? 1 : 0;
      commitSceneBake(
        S.confirmBakeSceneClip,
        S.confirmBakeSceneLoops,
        S.confirmBakeSceneWrap,
        _apply
      );
      S.confirmBakeSceneCondPhase = false;
      S.confirmBakeScene = false;
      S.screenDirty = true;
      return;
    }
    if (S.confirmBakeSceneWrapPhase) {
      if (S.confirmBakeSceneWrapSel < 2) {
        const _wrap = S.confirmBakeSceneWrapSel === 0 ? 1 : 0;
        if (sceneBakeHasConductor(S.confirmBakeSceneClip)) {
          S.confirmBakeSceneWrap = _wrap;
          S.confirmBakeSceneWrapPhase = false;
          S.confirmBakeSceneCondPhase = true;
          S.confirmBakeSceneCondSel = 1;
          S.screenDirty = true;
          return;
        }
        commitSceneBake(S.confirmBakeSceneClip, S.confirmBakeSceneLoops, _wrap, 0);
      }
      S.confirmBakeSceneWrapPhase = false;
      S.confirmBakeScene = false;
      S.screenDirty = true;
      return;
    }
    if (S.confirmBakeSceneSel > 0) {
      S.confirmBakeSceneLoops = [1, 2, 4][S.confirmBakeSceneSel - 1];
      S.confirmBakeSceneWrapPhase = true;
      S.confirmBakeSceneWrapSel = 1;
      S.screenDirty = true;
      return;
    }
    S.confirmBakeScene = false;
    S.screenDirty = true;
    return;
  }
  if (d1 === 3 && d2 === 127 && S.confirmLgto) {
    const _sel = S.confirmLgtoSel | 0;
    S.confirmLgto = false;
    if (_sel === 0 && typeof host_module_set_param === "function") {
      const _t = S.activeTrack;
      if (S.confirmLgtoIsDrum) {
        const _l = S.activeDrumLane[_t];
        host_module_set_param("t" + _t + "_l" + _l + "_lgto_apply", "1");
        S.pendingDrumResync = 2;
        S.pendingDrumResyncTrack = _t;
      } else {
        host_module_set_param("t" + _t + "_lgto_apply", "1");
        S.pendingStepsReread = 2;
        S.pendingStepsRereadTrack = _t;
        S.pendingStepsRereadClip = S.trackActiveClip[_t];
      }
      S.undoAvailable = true;
      S.redoAvailable = false;
      S.undoSeqArpSnapshot = null;
      showActionPopup("LGTO", "APPLIED");
    }
    S.screenDirty = true;
    forceRedraw();
    return;
  }
  if (d1 === 3 && d2 === 127 && S.confirmStateWipe) {
    S.confirmStateWipe = false;
    if (S.confirmStateWipeSel === 0) {
      S.pendingSetLoad = true;
    } else {
      removeFlagsWrap();
      clearAllLEDs();
      if (typeof host_exit_module === "function") host_exit_module();
    }
    S.screenDirty = true;
    forceRedraw();
    return;
  }
  if (d1 === 3 && d2 === 127 && S.bpmMoveInfo) {
    S.bpmMoveInfo = false;
    forceRedraw();
    return;
  }
  if (d1 === 3 && d2 === 127 && S.recordBlockedDialog) {
    const _sel = S.recordBlockedDialogSel | 0;
    S.recordBlockedDialog = false;
    if (_sel === 1) {
      const _bt = S.activeTrack, _bc = S.trackActiveClip[_bt];
      const _isDrum = S.trackPadMode[_bt] === PAD_MODE_DRUM;
      S.confirmBake = true;
      S.confirmBakeIsDrum = _isDrum;
      S.confirmBakeIsMultiLoop = !_isDrum;
      S.confirmBakeSel = _isDrum ? 2 : 1;
      S.confirmBakeTrack = _bt;
      S.confirmBakeClip = _bc;
      S.confirmBakeDrumLoopOpen = false;
      S.confirmBakeWrapPhase = false;
    }
    S.screenDirty = true;
    forceRedraw();
    return;
  }
  if (d1 === 3 && d2 === 127 && S.confirmBake) {
    if (S.confirmBakeWrapPhase) {
      if (S.confirmBakeWrapSel < 2) {
        const _wrap = S.confirmBakeWrapSel === 0 ? 1 : 0;
        const _loops = S.confirmBakeLoops;
        if (S.confirmBakeIsDrum) {
          const _laneArg = S.confirmBakeDrumMode === 1 ? " " + S.activeDrumLane[S.confirmBakeTrack] : " 0";
          S.pendingDefaultSetParams.push({
            key: "bake",
            val: S.confirmBakeTrack + " " + S.confirmBakeClip + " " + S.confirmBakeDrumMode + " " + _loops + _laneArg + " " + _wrap
          });
          S.undoAvailable = true;
          S.redoAvailable = false;
          S.undoSeqArpSnapshot = null;
          showActionPopup("BAKED", _loops + "x");
          S.pendingBankRefresh = S.confirmBakeTrack;
          if (S.confirmBakeClip === S.trackActiveClip[S.confirmBakeTrack]) {
            S.pendingDrumResync = 2;
            S.pendingDrumResyncTrack = S.confirmBakeTrack;
          }
        } else {
          S.pendingDefaultSetParams.push({
            key: "bake",
            val: S.confirmBakeTrack + " " + S.confirmBakeClip + " 0 " + _loops + " 0 " + _wrap
          });
          S.undoAvailable = true;
          S.redoAvailable = false;
          S.undoSeqArpSnapshot = null;
          showActionPopup("BAKED", _loops + "x");
          S.pendingBankRefresh = S.confirmBakeTrack;
          S.pendingStepsReread = 2;
          S.pendingStepsRereadTrack = S.confirmBakeTrack;
          S.pendingStepsRereadClip = S.confirmBakeClip;
        }
      }
      S.confirmBakeWrapPhase = false;
      S.confirmBakeDrumLoopOpen = false;
      S.confirmBake = false;
      S.screenDirty = true;
      return;
    }
    if (S.confirmBakeIsMultiLoop) {
      if (S.confirmBakeSel > 0) {
        S.confirmBakeLoops = [1, 2, 4][S.confirmBakeSel - 1];
        S.confirmBakeWrapPhase = true;
        S.confirmBakeWrapSel = 1;
        S.screenDirty = true;
        return;
      }
    } else if (!S.confirmBakeIsDrum) {
      if (S.confirmBakeSel === 0) {
        host_module_set_param("bake", S.confirmBakeTrack + " " + S.confirmBakeClip);
        S.undoAvailable = true;
        S.redoAvailable = false;
        S.undoSeqArpSnapshot = null;
        showActionPopup("BAKED");
        S.pendingBankRefresh = S.confirmBakeTrack;
        S.pendingStepsReread = 2;
        S.pendingStepsRereadTrack = S.confirmBakeTrack;
        S.pendingStepsRereadClip = S.confirmBakeClip;
      }
    } else if (S.confirmBakeDrumLoopOpen) {
      if (S.confirmBakeDrumLoopSel > 0) {
        S.confirmBakeLoops = [1, 2, 4][S.confirmBakeDrumLoopSel - 1];
        S.confirmBakeWrapPhase = true;
        S.confirmBakeWrapSel = 1;
        S.screenDirty = true;
        return;
      }
      S.confirmBakeDrumLoopOpen = false;
      S.confirmBake = false;
      S.screenDirty = true;
      return;
    } else {
      if (S.confirmBakeSel < 2) {
        S.confirmBakeDrumMode = S.confirmBakeSel === 0 ? 2 : 1;
        S.confirmBakeDrumLoopOpen = true;
        S.confirmBakeDrumLoopSel = 1;
        S.screenDirty = true;
        return;
      }
    }
    S.confirmBake = false;
    S.screenDirty = true;
    return;
  }
  if (d1 === 3 && d2 === 127 && S.tapTempoOpen) {
    closeTapTempo();
    S.screenDirty = true;
    return;
  }
  if (d1 === 3 && d2 === 127 && S.globalMenuOpen) {
    if (S.exportDoneDialog) {
      S.exportDoneDialog = false;
      S.globalMenuOpen = false;
      S.screenDirty = true;
      return;
    }
    if (S.confirmClearSession) {
      if (S.confirmClearSel === 0) doClearSession();
      else {
        S.confirmClearSession = false;
      }
      S.screenDirty = true;
      return;
    }
    if (S.confirmSaveState) {
      const yes = S.confirmSaveSel === 0;
      S.confirmSaveState = false;
      if (yes) openSaveSnapshot();
      S.screenDirty = true;
      return;
    }
    if (S.confirmConvertToDrum) {
      const _ct = S.confirmConvertTrack;
      const _yes = S.confirmConvertToDrumSel === 0;
      closeConvertConfirm();
      if (_yes) S.pendingTrackConvert = { t: _ct, toDrum: true };
      S.screenDirty = true;
      return;
    }
    if (S.confirmConvertToConduct) {
      const _ct = S.confirmConvertTrack;
      const _yes = S.confirmConvertToConductSel === 0;
      closeConvertConfirm();
      if (_yes) S.pendingConductConvert = _ct;
      S.screenDirty = true;
      return;
    }
    if (S.menuInfoLines.length > 0) {
      S.menuInfoLines = [];
      S.screenDirty = true;
      return;
    }
    if (S.confirmExportCondPhase) {
      confirmExportCondClick();
      S.screenDirty = true;
      return;
    }
    if (S.confirmExport) {
      if (S.confirmExportSel === 0) confirmExportStart();
      else S.confirmExport = false;
      S.screenDirty = true;
      return;
    }
    if (S.confirmXpose) {
      if (S.confirmXposeSel === 0) xposeCommit(S.confirmXposeKey, S.confirmXposeScale);
      else xposeCancelPreview();
      S.confirmXpose = false;
      if (S.globalMenuState) {
        S.globalMenuState.editing = false;
        S.globalMenuState.editValue = null;
      }
      S.lastSentMenuEditValue = null;
      S.bpmWasEditing = false;
      S.screenDirty = true;
      return;
    }
    {
      const _it = S.globalMenuState && S.globalMenuItems ? S.globalMenuItems[S.globalMenuState.selectedIndex] : null;
      if (_it && S.globalMenuState.editing && (_it.label === "Key" || _it.label === "Scale")) {
        const ev = S.globalMenuState.editValue !== null ? S.globalMenuState.editValue : _it.get();
        const candK = _it.label === "Key" ? ev : S.padKey;
        const candS = _it.label === "Scale" ? ev : S.padScale;
        if (candK === S.padKey && candS === S.padScale) {
          xposeCancelPreview();
          S.globalMenuState.editing = false;
          S.globalMenuState.editValue = null;
          S.lastSentMenuEditValue = null;
          S.bpmWasEditing = false;
        } else if (anyMelodicClipHasContent()) {
          S.confirmXpose = true;
          S.confirmXposeSel = 0;
          S.confirmXposeKey = candK;
          S.confirmXposeScale = candS;
        } else {
          xposeCommit(candK, candS);
          S.globalMenuState.editing = false;
          S.globalMenuState.editValue = null;
          S.lastSentMenuEditValue = null;
          S.bpmWasEditing = false;
        }
        S.screenDirty = true;
        return;
      }
    }
    {
      const _mi = S.globalMenuState && S.globalMenuItems ? S.globalMenuItems[S.globalMenuState.selectedIndex] : null;
      if (_mi && S.globalMenuState.editing && _mi.label === "Mode") {
        const t = S.activeTrack;
        const target = S.globalMenuState.editValue !== null ? S.globalMenuState.editValue : _mi.get();
        const cur = S.trackPadMode[t];
        S.globalMenuState.editing = false;
        S.globalMenuState.editValue = null;
        S.lastSentMenuEditValue = null;
        S.bpmWasEditing = false;
        if (target !== cur) {
          if (S.playing) {
            showMenuInfo("Stop playback", "to change the", "track type.");
            S.screenDirty = true;
            return;
          }
          if (target === PAD_MODE_DRUM) {
            let hasData = false;
            for (let c = 0; c < NUM_CLIPS; c++)
              if (S.clipNonEmpty[t][c]) {
                hasData = true;
                break;
              }
            if (hasData) {
              S.confirmConvertToDrum = true;
              S.confirmConvertToDrumSel = 1;
              S.confirmConvertTrack = t;
            } else {
              S.pendingTrackConvert = { t, toDrum: true };
            }
          } else if (target === PAD_MODE_CONDUCT) {
            const existingCond = conductorTrackIdx();
            if (existingCond >= 0 && existingCond !== t) {
              showMenuInfo("Conductor exists", "on T" + (existingCond + 1) + ".", "Route it back first.");
            } else {
              S.confirmConvertToConduct = true;
              S.confirmConvertToConductSel = 1;
              S.confirmConvertTrack = t;
            }
          } else {
            if (S.conductorTrack === t) S.conductorTrack = -1;
            S.pendingTrackConvert = { t, toDrum: false };
          }
        }
        S.screenDirty = true;
        return;
      }
    }
    handleMenuInput({
      cc: 3,
      value: d2,
      items: S.globalMenuItems,
      state: S.globalMenuState,
      stack: S.globalMenuStack,
      onBack: function() {
        S.globalMenuOpen = false;
      },
      shiftHeld: S.shiftHeld
    });
    S.screenDirty = true;
    return;
  }
  if (d1 === 3 && d2 === 127 && S.shiftHeld && S.deleteHeld && !S.sessionView) {
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
      const _dt = S.activeTrack, _dl = S.activeDrumLane[_dt], _dac = effectiveClip(_dt);
      resetFxBanks(_dt);
      S.drumLanePlaybackDir[_dt][_dl] = 0;
      S.drumLanePlaybackAudioReverse[_dt][_dl] = 0;
      S.bankParams[_dt][0][6] = 0;
      S.clipSeqFollow[_dt][_dac] = true;
      S.bankParams[_dt][0][7] = 1;
      S.pendingDefaultSetParams.push({ key: "t" + _dt + "_l" + _dl + "_playback_dir", val: "0" });
      S.pendingDefaultSetParams.push({ key: "t" + _dt + "_l" + _dl + "_playback_audio_reverse", val: "0" });
      showActionPopup("LANE PARAMS", "RESET");
    } else {
      const _arpTrack = S.activeTrack;
      const _arpParams = Array.from({ length: 8 }, function(_, k) {
        const pm = BANKS[4].knobs[k];
        return pm ? S.bankParams[_arpTrack][4][k] : 0;
      });
      resetFxBanks(_arpTrack);
      for (let k = 0; k < 8; k++) {
        const pm = BANKS[4].knobs[k];
        if (pm) S.bankParams[_arpTrack][4][k] = pm.def;
      }
      const _ac2 = effectiveClip(_arpTrack);
      S.trackCCAutoBits[_arpTrack][_ac2] = 0;
      S.trackCCLiveVal[_arpTrack] = new Array(8).fill(-1);
      S.clipCCVal[_arpTrack][_ac2] = new Array(8).fill(-1);
      S.clipAtHas[_arpTrack][_ac2] = false;
      S.pendingDefaultSetParams.push({ key: "t" + _arpTrack + "_cc_auto_clear", val: String(_ac2) });
      S.pendingDefaultSetParams.push({ key: "t" + _arpTrack + "_c" + _ac2 + "_at_clear", val: "1" });
      S.undoSeqArpSnapshot = { track: _arpTrack, params: _arpParams };
      const _mac = effectiveClip(_arpTrack);
      S.clipPlaybackDir[_arpTrack][_mac] = 0;
      S.clipPlaybackAudioReverse[_arpTrack][_mac] = 0;
      S.bankParams[_arpTrack][0][6] = 0;
      S.clipSeqFollow[_arpTrack][_mac] = true;
      S.bankParams[_arpTrack][0][7] = 1;
      S.pendingDefaultSetParams.push({ key: "t" + _arpTrack + "_clip_playback_dir", val: "0" });
      S.pendingDefaultSetParams.push({ key: "t" + _arpTrack + "_clip_playback_audio_reverse", val: "0" });
      showActionPopup("CLIP PARAMS", "RESET");
    }
    return;
  }
  if (d1 === 3 && d2 === 127 && S.deleteHeld && !S.sessionView) {
    if (S.activeBank === 6) {
      const _t = S.activeTrack, _c = effectiveClip(_t);
      S.trackCCAutoBits[_t][_c] = 0;
      S.trackCCLiveVal[_t] = new Array(8).fill(-1);
      S.clipCCVal[_t][_c] = new Array(8).fill(-1);
      S.clipAtHas[_t][_c] = false;
      S.pendingDefaultSetParams.push({ key: "t" + _t + "_cc_auto_clear", val: String(_c) });
      S.pendingDefaultSetParams.push({ key: "t" + _t + "_c" + _c + "_at_clear", val: "1" });
      showActionPopup("AUTOMATION", "CLEAR");
      invalidateLEDCache();
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
      if (S.drumPerformMode[S.activeTrack] > 0) {
        const _rt = S.activeTrack;
        const _rl = S.activeDrumLane[_rt];
        S.drumRepeatGate[_rt][_rl] = 255;
        S.drumRepeatGateLen[_rt][_rl] = 8;
        for (let _s = 0; _s < 8; _s++) {
          S.drumRepeatVelScale[_rt][_rl][_s] = 255;
          S.drumRepeatNudge[_rt][_rl][_s] = 0;
        }
        S.pendingDefaultSetParams.push({ key: "t" + _rt + "_l" + _rl + "_repeat_groove_reset", val: "1" });
        showActionPopup("RPT GROOVE", "RESET");
      } else {
        const REAL_TIME_BANKS = [1, 2, 3];
        if (REAL_TIME_BANKS.indexOf(S.activeBank) >= 0) {
          resetSingleFxBank(S.activeTrack, S.activeBank);
        }
        const _bt = S.activeTrack, _bl = S.activeDrumLane[_bt], _bac = effectiveClip(_bt);
        S.drumLanePlaybackDir[_bt][_bl] = 0;
        S.drumLanePlaybackAudioReverse[_bt][_bl] = 0;
        S.bankParams[_bt][0][6] = 0;
        S.clipSeqFollow[_bt][_bac] = true;
        S.bankParams[_bt][0][7] = 1;
        S.pendingDefaultSetParams.push({ key: "t" + _bt + "_l" + _bl + "_playback_dir", val: "0" });
        S.pendingDefaultSetParams.push({ key: "t" + _bt + "_l" + _bl + "_playback_audio_reverse", val: "0" });
        showActionPopup("BANK RESET");
      }
    } else if (S.activeBank === 5) {
      resetTarp(S.activeTrack);
      showActionPopup("LIVE ARP", "RESET");
    } else {
      const _mt = S.activeTrack, _mac2 = effectiveClip(_mt);
      resetFxBanks(_mt);
      S.undoSeqArpSnapshot = null;
      S.clipPlaybackDir[_mt][_mac2] = 0;
      S.clipPlaybackAudioReverse[_mt][_mac2] = 0;
      S.bankParams[_mt][0][6] = 0;
      S.clipSeqFollow[_mt][_mac2] = true;
      S.bankParams[_mt][0][7] = 1;
      S.pendingDefaultSetParams.push({ key: "t" + _mt + "_clip_playback_dir", val: "0" });
      S.pendingDefaultSetParams.push({ key: "t" + _mt + "_clip_playback_audio_reverse", val: "0" });
      showActionPopup("BANK RESET");
    }
    return;
  }
  if (d1 === 3 && d2 === 127 && !S.shiftHeld && !S.deleteHeld && !S.copyHeld && !S.muteHeld && !S.sessionView && S.trackPadMode[S.activeTrack] !== PAD_MODE_DRUM && (S.activeBank === 4 || S.activeBank === 5)) {
    S.stepIntervalMode = !S.stepIntervalMode;
    computePadNoteMap();
    S.screenDirty = true;
    forceRedraw();
    return;
  }
  if (d1 === 3 && d2 === 127 && !S.shiftHeld && !S.deleteHeld && !S.copyHeld && !S.muteHeld && !S.sessionView && bankHasAltParams(S.activeTrack, S.activeBank)) {
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 7 && !S.allLanesConfirmed) {
      S.allLanesConfirmed = true;
      S.screenDirty = true;
      forceRedraw();
      return;
    }
    S.altMode = !S.altMode;
    S.screenDirty = true;
    forceRedraw();
    return;
  }
  if (d1 === MoveMainKnob) {
    if (S.tempoSelectActive) {
      if (S.shiftHeld && S.tempoSelectWarp) {
        const u = ccKnobDelta(d2, 0);
        if (u !== 0 && typeof host_module_set_param === "function") {
          host_module_set_param(
            "t" + S.tempoSelectTrack + "_capture_fine",
            String(u * 6)
          );
          S.screenDirty = true;
        }
        return;
      }
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        const n = S.tempoSelectBpms.length;
        S.tempoSelectIdx = (S.tempoSelectIdx + (delta > 0 ? 1 : n - 1)) % n;
        if (typeof host_module_set_param === "function")
          host_module_set_param(
            "t" + S.tempoSelectTrack + "_capture_retempo",
            String(S.tempoSelectIdx)
          );
        S.screenDirty = true;
      }
      return;
    }
    if (S.stepIntervalMode) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        S.stepIntervalMode = false;
        computePadNoteMap();
        S.screenDirty = true;
        forceRedraw();
      }
      return;
    }
    if (S.pendingInheritPicker) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        const p2 = S.pendingInheritPicker;
        const total = p2.candidates.length + 1;
        p2.selectedIndex = (p2.selectedIndex + (delta > 0 ? 1 : total - 1)) % total;
        S.screenDirty = true;
      }
      return;
    }
    if (S.snapshotPicker) {
      snapshotPickerRotate(decodeDelta(d2));
      return;
    }
    if (S.clearAutoMenu) {
      clearAutoMenuRotate(decodeDelta(d2));
      return;
    }
    if (S.confirmBakeScene) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        if (S.confirmBakeSceneCondPhase)
          S.confirmBakeSceneCondSel = (S.confirmBakeSceneCondSel + (delta > 0 ? 1 : 2)) % 3;
        else if (S.confirmBakeSceneWrapPhase)
          S.confirmBakeSceneWrapSel = (S.confirmBakeSceneWrapSel + (delta > 0 ? 1 : 2)) % 3;
        else
          S.confirmBakeSceneSel = (S.confirmBakeSceneSel + (delta > 0 ? 1 : 3)) % 4;
        S.screenDirty = true;
      }
      return;
    }
    if (S.confirmStateWipe) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        S.confirmStateWipeSel = S.confirmStateWipeSel === 0 ? 1 : 0;
        S.screenDirty = true;
      }
      return;
    }
    if (S.recordBlockedDialog) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        S.recordBlockedDialogSel = S.recordBlockedDialogSel === 0 ? 1 : 0;
        S.screenDirty = true;
      }
      return;
    }
    if (S.confirmLgto) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        S.confirmLgtoSel = S.confirmLgtoSel === 0 ? 1 : 0;
        S.screenDirty = true;
      }
      return;
    }
    if (S.confirmBake && S.confirmBakeWrapPhase) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        S.confirmBakeWrapSel = (S.confirmBakeWrapSel + (delta > 0 ? 1 : 2)) % 3;
        S.screenDirty = true;
      }
      return;
    }
    if (S.confirmBake && S.confirmBakeIsDrum && S.confirmBakeDrumLoopOpen) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        S.confirmBakeDrumLoopSel = (S.confirmBakeDrumLoopSel + (delta > 0 ? 1 : 3)) % 4;
        S.screenDirty = true;
      }
      return;
    }
    if (S.confirmBake) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        if (S.confirmBakeIsDrum) {
          S.confirmBakeSel = (S.confirmBakeSel + (delta > 0 ? 1 : 2)) % 3;
        } else if (S.confirmBakeIsMultiLoop) {
          S.confirmBakeSel = (S.confirmBakeSel + (delta > 0 ? 1 : 3)) % 4;
        } else {
          S.confirmBakeSel = S.confirmBakeSel === 0 ? 1 : 0;
        }
        S.screenDirty = true;
      }
      return;
    }
    if (S.tapTempoOpen && !S.shiftHeld) {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        S.tapTempoBpm = Math.max(40, Math.min(250, S.tapTempoBpm + delta));
        host_module_set_param("bpm", String(S.tapTempoBpm));
        S.screenDirty = true;
      }
      return;
    }
    if (S.globalMenuOpen && !S.shiftHeld) {
      ensureGlobalMenuFresh();
      if (S.exportDoneDialog) {
      } else if (S.confirmClearSession) {
        const delta = decodeDelta(d2);
        if (delta !== 0) {
          S.confirmClearSel = S.confirmClearSel === 0 ? 1 : 0;
          S.screenDirty = true;
        }
      } else if (S.confirmSaveState) {
        const delta = decodeDelta(d2);
        if (delta !== 0) {
          S.confirmSaveSel = S.confirmSaveSel === 0 ? 1 : 0;
          S.screenDirty = true;
        }
      } else if (S.confirmConvertToDrum) {
        const delta = decodeDelta(d2);
        if (delta !== 0) {
          S.confirmConvertToDrumSel = S.confirmConvertToDrumSel === 0 ? 1 : 0;
          S.screenDirty = true;
        }
      } else if (S.confirmConvertToConduct) {
        const delta = decodeDelta(d2);
        if (delta !== 0) {
          S.confirmConvertToConductSel = S.confirmConvertToConductSel === 0 ? 1 : 0;
          S.screenDirty = true;
        }
      } else if (S.menuInfoLines.length > 0) {
      } else if (S.confirmExportCondPhase) {
        const delta = decodeDelta(d2);
        if (delta !== 0) {
          S.confirmExportCondSel = (S.confirmExportCondSel + (delta > 0 ? 1 : 2)) % 3;
          S.screenDirty = true;
        }
      } else if (S.confirmExport) {
        const delta = decodeDelta(d2);
        if (delta !== 0) {
          S.confirmExportSel = S.confirmExportSel === 0 ? 1 : 0;
          S.screenDirty = true;
        }
      } else if (S.confirmXpose) {
        const delta = decodeDelta(d2);
        if (delta !== 0) {
          S.confirmXposeSel = S.confirmXposeSel === 0 ? 1 : 0;
          S.screenDirty = true;
        }
      } else if (S.globalMenuState.editing) {
        const delta = decodeDelta(d2);
        if (delta !== 0) {
          const item = S.globalMenuItems[S.globalMenuState.selectedIndex];
          if (item && item.type === "value") {
            const cur = S.globalMenuState.editValue !== null ? S.globalMenuState.editValue : item.get();
            S.globalMenuState.editValue = Math.min(item.max, Math.max(item.min, cur + delta));
          } else if (item && item.type === "enum") {
            const opts = item.options || [];
            const idx = opts.indexOf(S.globalMenuState.editValue);
            const sign = delta > 0 ? 1 : -1;
            S.globalMenuState.editValue = opts[((idx + sign) % opts.length + opts.length) % opts.length];
          }
          S.screenDirty = true;
        }
      } else {
        handleMenuInput({
          cc: MoveMainKnob,
          value: d2,
          items: S.globalMenuItems,
          state: S.globalMenuState,
          stack: S.globalMenuStack,
          onBack: function() {
            S.globalMenuOpen = false;
          },
          shiftHeld: false
        });
        S.screenDirty = true;
      }
    } else {
      const delta = decodeDelta(d2);
      if (delta !== 0) {
        if (S.shiftHeld) {
          const next = Math.min(NUM_TRACKS - 1, Math.max(0, S.activeTrack + delta));
          if (next !== S.activeTrack) {
            extNoteOffAll();
            handoffRecordingToTrack(next);
            _switchActiveTrack(next);
            if (S.trackPadMode[next] === PAD_MODE_DRUM) {
              if (S.activeBank === 2 || S.activeBank === 4) S.activeBank = 0;
              resyncDrumTrack(next);
            } else {
              if (S.activeBank === 7) S.activeBank = 0;
              refreshPerClipBankParams(next);
            }
            computePadNoteMap();
            S.seqActiveNotes.clear();
            S.seqLastStep = -1;
            S.seqLastClip = -1;
            forceRedraw();
          }
        } else if (S.sessionView) {
          S.sceneRow = Math.min(NUM_CLIPS - 4, Math.max(0, S.sceneRow + delta));
          forceRedraw();
        } else if (S.loopHeld) {
          const _t = S.activeTrack;
          if (S.recordArmed && !S.recordCountingIn) {
          } else if (S.trackPadMode[_t] === PAD_MODE_DRUM && S.activeBank !== 6) {
            if (allLanesGate()) return;
            const _lane = S.activeDrumLane[_t];
            const _cur2 = S.drumLaneLength[_t];
            const _nv2 = Math.max(1, Math.min(256, _cur2 + delta));
            if (_nv2 !== _cur2) {
              S.drumLaneLength[_t] = _nv2;
              S.drumLaneLengthManuallySet[_t] = true;
              const _ls2 = S.drumLaneLoopStart[_t] | 0;
              const _maxPage = Math.max(0, Math.floor((_ls2 + _nv2 - 1) / 16));
              S.loopJogActive = true;
              S.loopJogLastTick = S.tickCount;
              S.drumStepPage[_t] = _maxPage;
              if (typeof host_module_set_param === "function") {
                if (S.activeBank === 7) {
                  host_module_set_param("t" + _t + "_all_lanes_length", String(_nv2));
                } else {
                  host_module_set_param("t" + _t + "_l" + _lane + "_clip_length", String(_nv2));
                }
              }
              forceRedraw();
            }
          } else if (S.activeBank === 6) {
            var _ac = effectiveClip(_t);
            var _ccL = S.ccActiveLane[_t];
            var _cur = S.ccLaneLength[_t][_ac][_ccL];
            if (_cur === 0) {
              var _cTps = S.clipTPS[_t][_ac] || 24;
              var _lTps = S.ccLaneTps[_t][_ac][_ccL] || _cTps;
              _cur = Math.max(1, Math.round(S.clipLength[_t][_ac] * _cTps / _lTps));
            }
            var _nv = Math.max(1, Math.min(256, _cur + delta));
            if (_nv !== _cur) {
              S.ccLaneLength[_t][_ac][_ccL] = _nv;
              S.loopJogActive = true;
              S.loopJogLastTick = S.tickCount;
              var _ls = S.ccLaneLoopStart[_t][_ac][_ccL] | 0;
              S.trackCurrentPage[_t] = Math.max(0, Math.floor((_ls + _nv - 1) / 16));
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + _t + "_c" + _ac + "_k" + _ccL + "_cc_lane_length", String(_nv));
              forceRedraw();
            }
          } else {
            const _ac2 = effectiveClip(_t);
            const _cur2 = S.clipLength[_t][_ac2];
            const _nv2 = Math.max(1, Math.min(256, _cur2 + delta));
            if (_nv2 !== _cur2) {
              S.clipLength[_t][_ac2] = _nv2;
              S.clipLengthManuallySet[_t][_ac2] = true;
              S.loopJogActive = true;
              S.loopJogLastTick = S.tickCount;
              const _ls2 = S.clipLoopStart[_t][_ac2] | 0;
              S.trackCurrentPage[_t] = Math.max(0, Math.floor((_ls2 + _nv2 - 1) / 16));
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + _t + "_clip_length", String(_nv2));
              forceRedraw();
            }
          }
        } else {
          const cur = S.activeBank;
          const isDrumJog = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM;
          const isConductJog = S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT;
          let next;
          if (isConductJog) {
            const ci = CONDUCT_BANK_CYCLE.indexOf(cur);
            const ni = Math.max(0, Math.min(CONDUCT_BANK_CYCLE.length - 1, (ci >= 0 ? ci : 0) + delta));
            next = CONDUCT_BANK_CYCLE[ni];
          } else if (isDrumJog) {
            const ci = BANK_CYCLE_DRUM.indexOf(cur);
            const ni = Math.max(0, Math.min(BANK_CYCLE_DRUM.length - 1, (ci >= 0 ? ci : 0) + delta));
            next = BANK_CYCLE_DRUM[ni];
          } else {
            next = Math.min(6, Math.max(0, cur + delta));
          }
          if (next !== cur) {
            S.activeBank = next;
            S.trackActiveBank[S.activeTrack] = next;
            if (next === 7) S.allLanesConfirmed = false;
            if (next === 6) S.schLabelFetchLane = 0;
            readBankParams(S.activeTrack, next);
            S.bankSelectTick = S.tickCount;
            writeSidecar();
            forceRedraw();
          }
        }
      }
    }
    return;
  }
}
function _onCC_buttons(d1, d2) {
  if (d1 === MoveShift) {
    S.shiftHeld = d2 === 127;
    S.shiftTrackLEDActive = d2 === 127;
    computePadNoteMap();
    if (!S.sessionView) {
      S.jogTouched = false;
      S.bankSelectTick = -1;
    }
    if (S.stepIntervalMode && !S.sessionView) forceRedraw();
    if (!S.shiftHeld && S.pendingEditEntryTrack >= 0) {
      const _t = S.pendingEditEntryTrack;
      S.pendingEditEntryTrack = -1;
      if (S.trackRoute[_t] === 1 && typeof shadow_corun_begin === "function" && typeof move_midi_inject_to_move === "function") {
        enterMoveNativeCoRun(_t);
      } else if (S.trackRoute[_t] === 0 && typeof shadow_corun_begin === "function") {
        openSchwungSlotEditor(_t);
      }
    }
    if (!S.sessionView) forceRedraw();
  }
  if (d1 !== MoveShift && d2 === 127 && S.shiftTrackLEDActive) {
    S.shiftTrackLEDActive = false;
  }
  if (d1 === MoveDelete) {
    S.deleteHeld = d2 === 127;
    if (d2 === 127 && S.loopHeld && S.activeBank === 6 && !S.sessionView) {
      var _rdt = S.activeTrack, _rdac = effectiveClip(_rdt), _rdl = S.ccActiveLane[_rdt];
      S.ccLaneLoopStart[_rdt][_rdac][_rdl] = 0;
      S.ccLaneLength[_rdt][_rdac][_rdl] = 0;
      S.ccLaneTps[_rdt][_rdac][_rdl] = 0;
      S.ccLaneResTps[_rdt][_rdac][_rdl] = 0;
      S.undoAvailable = true;
      S.redoAvailable = false;
      S.undoSeqArpSnapshot = null;
      S.pendingDefaultSetParams.push({ key: "t" + _rdt + "_c" + _rdac + "_k" + _rdl + "_cc_lane_reset", val: "1" });
      showActionPopup("LANE LOOP", "RESET");
      forceRedraw();
      computePadNoteMap();
      return;
    }
    if (d2 === 127) {
      S.deleteTapArmed = S.activeBank === 6 && !S.sessionView && !S.clearAutoMenu;
    } else if (S.deleteTapArmed) {
      S.deleteTapArmed = false;
      openClearAutoMenu();
    }
    computePadNoteMap();
  }
  if (d1 === MoveCopy) {
    S.copyHeld = d2 === 127;
    if (!S.copyHeld) {
      S.copySrc = null;
      invalidateLEDCache();
    }
    computePadNoteMap();
  }
  if (d1 === MoveMute) {
    if (S.schwungCoRunSlot >= 0) {
      S.muteHeld = false;
    } else {
      S.muteHeld = d2 === 127;
      if (d2 === 127) S.muteUsedAsModifier = false;
      if (S.sessionView) invalidateLEDCache();
      computePadNoteMap();
    }
  }
  if (d1 === MoveCapture) {
    if (d2 === 127) {
      S.captureHeld = true;
      S.captureUsedAsModifier = false;
      if (S.confirmBake) {
        S.confirmBake = false;
        S.captureUsedAsModifier = true;
        S.confirmBakeDrumLoopOpen = false;
        S.confirmBakeWrapPhase = false;
      }
      if (S.confirmBakeScene) {
        S.confirmBakeScene = false;
        S.captureUsedAsModifier = true;
      }
      computePadNoteMap();
      forceRedraw();
    } else {
      S.captureHeld = false;
      if (!S.captureUsedAsModifier && S.shiftHeld) {
        if (S.capturePending > 0) {
          S.pendingDefaultSetParams.push({
            key: "t" + S.activeTrack + "_capture_clear",
            val: "1"
          });
          S.capturePending = 0;
          showActionPopup("CAPTURE", "Input cleared");
        }
        S.captureUsedAsModifier = true;
      }
      if (!S.captureUsedAsModifier) {
        const _ct = S.activeTrack;
        const _fc = S.trackActiveClip[_ct];
        if (S.capturePending <= 0) {
          showActionPopup("CAPTURE", "Nothing buffered", "Play pads first");
        } else if (S.playing) {
          S.pendingDefaultSetParams.push({
            key: "t" + _ct + "_capture_commit",
            val: String(_fc)
          });
          S.capturePending = 0;
          S.captureCommitAwait = 40;
        } else if (!trackClipHasContent(_ct, _fc)) {
          S.pendingDefaultSetParams.push({
            key: "t" + _ct + "_capture_commit",
            val: String(_fc)
          });
          S.capturePending = 0;
          S.captureCommitAwait = 40;
        } else {
          S.capturePlaceTrack = _ct;
          if (!S.sessionView) {
            S.sessionView = true;
            S.heldStep = -1;
            S.heldStepBtn = -1;
            S.heldStepNotes = [];
            S.stepWasEmpty = false;
            S.stepWasHeld = false;
            S.sessionStepHeld = -1;
            S.sessionStepHeldCtx = 0;
          }
          invalidateLEDCache();
          S.screenDirty = true;
        }
      }
      computePadNoteMap();
      forceRedraw();
    }
    return;
  }
  if (d1 === 50 && d2 === 127) {
    if (S.schwungCoRunSlot >= 0) {
      exitSchwungCoRun();
      forceRedraw();
      return;
    }
  }
  if (d1 === MoveNoteSession) {
    if (S.moveCoRunTrack >= 0) {
      if (d2 === 127 && S.coRunOverlayScreen && typeof shadow_corun_open === "function") {
        shadow_corun_open(S.coRunOverlayScreen, DAVEBOX_PICKER_KEEP_MASK);
      }
      return;
    }
    if (d2 === 127) {
      if (S.snapshotPicker) {
        if (S.snapshotPicker.confirm) S.snapshotPicker.confirm = null;
        else closeSnapshotPicker();
        forceRedraw();
        return;
      }
      if (S.shiftHeld) {
        if (S.globalMenuOpen) {
          S.globalMenuOpen = false;
          forceRedraw();
        } else {
          openGlobalMenu();
        }
      } else if (S.tapTempoOpen) {
        closeTapTempo();
        forceRedraw();
      } else if (S.confirmStateWipe) {
        S.confirmStateWipe = false;
        removeFlagsWrap();
        clearAllLEDs();
        if (typeof host_exit_module === "function") host_exit_module();
        forceRedraw();
      } else if (S.bpmMoveInfo) {
        S.bpmMoveInfo = false;
        forceRedraw();
      } else if (S.recordBlockedDialog) {
        S.recordBlockedDialog = false;
        forceRedraw();
      } else if (S.confirmLgto) {
        S.confirmLgto = false;
        forceRedraw();
      } else if (S.confirmBake) {
        S.confirmBake = false;
        S.confirmBakeWrapPhase = false;
        forceRedraw();
      } else if (S.globalMenuOpen && S.confirmClearSession) {
        S.confirmClearSession = false;
        forceRedraw();
      } else if (S.globalMenuOpen && S.confirmSaveState) {
        S.confirmSaveState = false;
        forceRedraw();
      } else if (S.globalMenuOpen && S.confirmConvertToDrum) {
        closeConvertConfirm();
        forceRedraw();
      } else if (S.globalMenuOpen && S.confirmConvertToConduct) {
        closeConvertConfirm();
        forceRedraw();
      } else if (S.globalMenuOpen && S.menuInfoLines.length > 0) {
        S.menuInfoLines = [];
        forceRedraw();
      } else if (S.globalMenuOpen && S.exportDoneDialog) {
        S.exportDoneDialog = false;
        S.globalMenuOpen = false;
        forceRedraw();
      } else if (S.globalMenuOpen && S.confirmExportCondPhase) {
        S.confirmExportCondPhase = false;
        forceRedraw();
      } else if (S.globalMenuOpen && S.confirmExport) {
        S.confirmExport = false;
        forceRedraw();
      } else if (S.globalMenuOpen) {
        S.globalMenuOpen = false;
        S.lastSentMenuEditValue = null;
        forceRedraw();
      } else if (S.stepIntervalMode && !S.sessionView) {
        S.stepIntervalMode = false;
        computePadNoteMap();
        forceRedraw();
      } else {
        S.noteSessionPressedTick = S.tickCount;
        S.sessionViewMomentary = true;
        S.sessionView = !S.sessionView;
        _switchViewCleanup();
        invalidateLEDCache();
        S.screenDirty = true;
      }
    } else if (d2 === 0) {
      if (S.noteSessionPressedTick >= 0 && S.tickCount - S.noteSessionPressedTick < NOTE_SESSION_HOLD_TICKS) {
        S.sessionViewMomentary = false;
      } else if (S.sessionViewMomentary) {
        S.sessionViewMomentary = false;
        S.sessionView = !S.sessionView;
        _switchViewCleanup();
        invalidateLEDCache();
        forceRedraw();
      }
      S.noteSessionPressedTick = -1;
    }
  }
  if (d1 === MoveLoop && S.sessionView) {
    if (d2 === 127) {
      if (S.shiftHeld) {
        S.perfLatchMode = !S.perfLatchMode;
        forceRedraw();
        return;
      }
      S.loopPressTick = S.tickCount;
      S.loopHeld = true;
      forceRedraw();
      return;
    }
    const heldDuration = S.tickCount - S.loopPressTick;
    const wasTap = heldDuration < LOOP_TAP_TICKS;
    if (S.perfViewLocked) {
      if (wasTap) {
        S.perfViewLocked = false;
        S.loopHeld = false;
        S.loopJogActive = false;
        S.perfStack = [];
        S.perfStickyLengths = /* @__PURE__ */ new Set();
        S.perfHoldPadHeld = false;
        S.perfModsHeld = 0;
        sendPerfMods();
        if (typeof host_module_set_param === "function")
          host_module_set_param("looper_stop", "1");
        invalidateLEDCache();
        forceRedraw();
      }
      return;
    }
    if (wasTap) {
      S.perfViewLocked = true;
      S.loopHeld = true;
      forceRedraw();
      return;
    }
    S.loopHeld = false;
    S.loopJogActive = false;
    S.perfModsHeld = 0;
    if (S.perfStickyLengths.size > 0 || S.perfHoldPadHeld) {
      S.perfViewLocked = true;
      if (!S.perfHoldPadHeld)
        S.perfStack = S.perfStack.filter(function(e) {
          return S.perfStickyLengths.has(e.idx);
        });
      if (S.perfStack.length > 0 && typeof host_module_set_param === "function")
        host_module_set_param("looper_arm", String(S.perfStack[S.perfStack.length - 1].ticks));
    } else {
      if (S.perfStack.length > 0 && typeof host_module_set_param === "function")
        host_module_set_param("looper_stop", "1");
      S.perfStack = [];
    }
    sendPerfMods();
    invalidateLEDCache();
    forceRedraw();
    return;
  }
  if (d1 === MoveLoop && !S.sessionView) {
    S.loopHeld = d2 === 127;
    computePadNoteMap();
    if (S.stepIntervalMode) {
      if (!S.loopHeld && S.loopGestureStart >= 0) S.loopGestureStart = -1;
      forceRedraw();
      return;
    }
    if (S.loopHeld) {
      const _lrt = S.activeTrack;
      S.loopPressTick = S.tickCount;
      S.loopTapUnlatchTrack = -1;
      const _rpt1FreshHold = S.drumRepeatHeldPad[_lrt] >= 0 && !S.drumRepeatLatched[_lrt];
      const _rpt2FreshHold = S.drumRepeat2HeldLanes[_lrt].size > 0;
      if (S.trackPadMode[_lrt] === PAD_MODE_DRUM && !_rpt1FreshHold && !_rpt2FreshHold && S.liveActiveNotes.size === 0) {
        S.loopTapUnlatchTrack = _lrt;
      }
      if (S.deleteHeld && S.activeBank === 6) {
        var _rac = effectiveClip(_lrt);
        var _rl = S.ccActiveLane[_lrt];
        S.ccLaneLoopStart[_lrt][_rac][_rl] = 0;
        S.ccLaneLength[_lrt][_rac][_rl] = 0;
        S.ccLaneTps[_lrt][_rac][_rl] = 0;
        S.ccLaneResTps[_lrt][_rac][_rl] = 0;
        S.undoAvailable = true;
        S.redoAvailable = false;
        S.undoSeqArpSnapshot = null;
        S.pendingDefaultSetParams.push({ key: "t" + _lrt + "_c" + _rac + "_k" + _rl + "_cc_lane_reset", val: "1" });
        showActionPopup("LANE LOOP", "RESET");
        forceRedraw();
        return;
      }
      if (S.deleteHeld && S.trackPadMode[_lrt] === PAD_MODE_DRUM) {
        if (S.drumPerformMode[_lrt] === 1 && S.drumRepeatLatched[_lrt]) {
          S.drumRepeatLatched[_lrt] = false;
          S.drumRepeatHeldPad[_lrt] = -1;
          S.drumRepeatHeldPadsStack[_lrt].length = 0;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + _lrt + "_drum_repeat_stop", "1");
        } else if (S.drumPerformMode[_lrt] === 2 && S.drumRepeat2LatchedLanes[_lrt].size > 0) {
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + _lrt + "_drum_repeat2_stop", "1");
          S.drumRepeat2LatchedLanes[_lrt].clear();
        }
        forceRedraw();
        return;
      }
      if (S.trackPadMode[_lrt] !== PAD_MODE_DRUM && S.liveActiveNotes.size > 0) {
        const _latchNow = (S.bankParams[_lrt][5][7] | 0) !== 0;
        if (_latchNow) {
          S.bankParams[_lrt][5][7] = 0;
          if (typeof host_module_set_param === "function")
            S.pendingDefaultSetParams.push({ key: "t" + _lrt + "_tarp_latch", val: "0" });
        } else if ((S.bankParams[_lrt][5][0] | 0) !== 0) {
          S.bankParams[_lrt][5][7] = 1;
          if (typeof host_module_set_param === "function")
            S.pendingDefaultSetParams.push({ key: "t" + _lrt + "_tarp_latch", val: "1" });
        }
      } else if (S.trackPadMode[_lrt] !== PAD_MODE_DRUM && (S.bankParams[_lrt][5][7] | 0) !== 0 && S.tarpHeldNotes[_lrt].size > 0) {
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + _lrt + "_tarp_clear_latched", "1");
        S.tarpHeldNotes[_lrt].clear();
      }
      if (S.drumPerformMode[_lrt] === 2) {
        S.rpt2LoopPadUsed = false;
        if (S.drumRepeat2HeldLanes[_lrt].size > 0) {
          for (const _ll of S.drumRepeat2HeldLanes[_lrt]) {
            S.drumRepeat2LatchedLanes[_lrt].add(_ll);
          }
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + _lrt + "_drum_repeat2_latch_held", "1");
          S.rpt2LoopPadUsed = true;
        }
      } else if (S.drumRepeatHeldPad[_lrt] >= 0) {
        S.drumRepeatLatched[_lrt] = true;
        if (typeof host_module_set_param === "function")
          S.pendingDefaultSetParams.push({ key: "t" + _lrt + "_drum_repeat_latched", val: "1" });
      }
      S.heldStepBtn = -1;
      S.heldStep = -1;
      S.heldStepNotes = [];
      S.stepWasEmpty = false;
      S.stepWasHeld = false;
      S.stepBtnPressedTick.fill(-1);
      S.sessionStepHeld = -1;
      S.sessionStepHeldCtx = 0;
    } else {
      S.loopJogActive = false;
      if (S.loopGestureStart >= 0) {
        _resolveLoopGesture(true);
        S.loopTapUnlatchTrack = -1;
      }
      if (S.loopTapUnlatchTrack >= 0 && S.tickCount - S.loopPressTick < LOOP_TAP_TICKS) {
        const _ut = S.loopTapUnlatchTrack;
        if (S.drumRepeatLatched[_ut]) {
          S.drumRepeatLatched[_ut] = false;
          S.drumRepeatHeldPad[_ut] = -1;
          S.drumRepeatHeldPadsStack[_ut].length = 0;
          S.pendingDefaultSetParams.push({ key: "t" + _ut + "_drum_repeat_stop", val: "1" });
        }
        if (S.drumRepeat2LatchedLanes[_ut].size > 0) {
          S.drumRepeat2LatchedLanes[_ut].clear();
          S.pendingDefaultSetParams.push({ key: "t" + _ut + "_drum_repeat2_stop", val: "1" });
        }
      }
      S.loopTapUnlatchTrack = -1;
    }
    forceRedraw();
  }
}
function _suspendModule() {
  saveState();
  S.pendingSuspendManaged = true;
}
function _cancelMergeCountIn() {
  S.mergeCountingIn = false;
  S.mergeSingleTrack = -1;
  S.pendingMergeArm = false;
  S.actionPopupEndTick = -1;
  S.pendingDefaultSetParams.push({ key: "merge_cancel", val: "1" });
  setButtonLED4(MoveRec, S.recordArmed ? Red4 : LED_OFF);
  forceRedraw();
}
function backTapWouldAct() {
  if (S.confirmStateWipe || S.pendingInheritPicker) return false;
  if (S.snapshotPicker || S.clearAutoMenu || S.tempoSelectActive || S.mergeNoticePending || S.mergeCountingIn || S.pendingMergePlacement || S.mergeSoloPlacement >= 0 || S.capturePlaceTrack >= 0 || S.pendingSceneBakePicker || S.confirmBakeScene || S.confirmBakeDrumLoopOpen || S.confirmXpose || S.confirmLgto || S.confirmBake || S.recordBlockedDialog || S.bpmMoveInfo || S.tapTempoOpen || S.globalMenuOpen) return true;
  if (S.sessionView) return S.perfViewLocked;
  return S.stepIntervalMode || S.altMode || S.activeBank === 7 && S.allLanesConfirmed || S.activeBank !== 0;
}
function _backTap() {
  if (S.confirmStateWipe || S.pendingInheritPicker) return;
  if (S.snapshotPicker) {
    if (S.snapshotPicker.confirm) S.snapshotPicker.confirm = null;
    else closeSnapshotPicker();
    forceRedraw();
    return;
  }
  if (S.clearAutoMenu) {
    S.clearAutoMenu = null;
    S.deleteTapArmed = false;
    forceRedraw();
    return;
  }
  if (S.tempoSelectActive) {
    if (typeof host_module_set_param === "function")
      host_module_set_param("t" + S.tempoSelectTrack + "_capture_confirm", "");
    S.tempoSelectActive = false;
    forceRedraw();
    return;
  }
  if (S.mergeNoticePending) {
    S.mergeNoticePending = false;
    forceRedraw();
    return;
  }
  if (S.mergeCountingIn) {
    S.mergeCountingIn = false;
    S.mergeSingleTrack = -1;
    S.pendingMergeArm = false;
    S.actionPopupEndTick = -1;
    S.pendingDefaultSetParams.push({ key: "merge_cancel", val: "1" });
    setButtonLED4(MoveRec, S.recordArmed ? Red4 : LED_OFF);
    forceRedraw();
    return;
  }
  if (S.pendingMergePlacement || S.mergeSoloPlacement >= 0) {
    S.pendingMergePlacement = false;
    S.mergeSoloPlacement = -1;
    S.pendingDefaultSetParams.push({ key: "merge_cancel", val: "1" });
    forceRedraw();
    return;
  }
  if (S.capturePlaceTrack >= 0) {
    S.capturePlaceTrack = -1;
    forceRedraw();
    return;
  }
  if (S.pendingSceneBakePicker) {
    S.pendingSceneBakePicker = false;
    forceRedraw();
    return;
  }
  if (S.confirmBakeScene) {
    S.confirmBakeScene = false;
    S.confirmBakeSceneCondPhase = false;
    forceRedraw();
    return;
  }
  if (S.confirmBakeDrumLoopOpen) {
    S.confirmBakeDrumLoopOpen = false;
    forceRedraw();
    return;
  }
  if (S.confirmXpose) {
    xposeCancelPreview();
    S.confirmXpose = false;
    forceRedraw();
    return;
  }
  if (S.confirmLgto) {
    S.confirmLgto = false;
    forceRedraw();
    return;
  }
  if (S.confirmBake) {
    S.confirmBake = false;
    S.confirmBakeWrapPhase = false;
    forceRedraw();
    return;
  }
  if (S.recordBlockedDialog) {
    S.recordBlockedDialog = false;
    forceRedraw();
    return;
  }
  if (S.bpmMoveInfo) {
    S.bpmMoveInfo = false;
    forceRedraw();
    return;
  }
  if (S.tapTempoOpen) {
    closeTapTempo();
    forceRedraw();
    return;
  }
  if (S.globalMenuOpen) {
    if (S.confirmClearSession) {
      S.confirmClearSession = false;
    } else if (S.confirmSaveState) {
      S.confirmSaveState = false;
    } else if (S.confirmConvertToDrum) {
      closeConvertConfirm();
    } else if (S.confirmConvertToConduct) {
      closeConvertConfirm();
    } else if (S.menuInfoLines.length > 0) {
      S.menuInfoLines = [];
    } else if (S.exportDoneDialog) {
      S.exportDoneDialog = false;
      S.globalMenuOpen = false;
    } else if (S.confirmExportCondPhase) {
      S.confirmExportCondPhase = false;
    } else if (S.confirmExport) {
      S.confirmExport = false;
    } else {
      S.globalMenuOpen = false;
      S.lastSentMenuEditValue = null;
    }
    forceRedraw();
    return;
  }
  if (S.sessionView && S.perfViewLocked) {
    S.perfViewLocked = false;
    S.loopHeld = false;
    S.loopJogActive = false;
    S.perfStack = [];
    S.perfStickyLengths = /* @__PURE__ */ new Set();
    S.perfHoldPadHeld = false;
    S.perfModsHeld = 0;
    sendPerfMods();
    if (typeof host_module_set_param === "function") host_module_set_param("looper_stop", "1");
    invalidateLEDCache();
    forceRedraw();
    return;
  }
  if (!S.sessionView) {
    if (S.stepIntervalMode) {
      S.stepIntervalMode = false;
      computePadNoteMap();
      forceRedraw();
      return;
    }
    if (S.altMode) {
      S.altMode = false;
      forceRedraw();
      return;
    }
    if (S.activeBank === 7 && S.allLanesConfirmed) {
      S.allLanesConfirmed = false;
      forceRedraw();
      return;
    }
    if (S.activeBank !== 0) {
      S.activeBank = 0;
      S.trackActiveBank[S.activeTrack] = 0;
      readBankParams(S.activeTrack, 0);
      S.bankSelectTick = S.tickCount;
      writeSidecar();
      invalidateLEDCache();
      forceRedraw();
      return;
    }
    return;
  }
}
function _handleBack(d2) {
  if (d2 === 127) {
    if (S.shiftHeld) {
      if (S.schwungCoRunSlot >= 0) exitSchwungCoRun();
      saveState();
      S.pendingHideAfterSave = true;
      return;
    }
    S.backPressTick = S.tickCount;
    S.backHoldFired = false;
  } else if (d2 === 0) {
    if (S.backPressTick >= 0 && !S.backHoldFired) _backTap();
    S.backPressTick = -1;
    S.backHoldFired = false;
  }
}
function checkBackHold() {
  if (S.backPressTick < 0) return;
  if (S.schwungCoRunSlot >= 0 || S.moveCoRunTrack >= 0) {
    S.backPressTick = -1;
    S.backHoldFired = false;
    return;
  }
  if (S.tickCount - S.backPressTick >= BACK_HOLD_TICKS) {
    S.backHoldFired = true;
    S.backPressTick = -1;
    _suspendModule();
  }
}
function _onCC_transport(d1, d2) {
  if (d1 === MoveUndo && d2 === 127) {
    if (S.shiftHeld) {
      if (S.redoAvailable) {
        if (S.redoSeqArpSnapshot) {
          const _t = S.redoSeqArpSnapshot.track;
          S.undoSeqArpSnapshot = { track: _t, params: S.bankParams[_t][4].slice() };
        } else {
          S.undoSeqArpSnapshot = null;
        }
        if (typeof host_module_set_param === "function")
          host_module_set_param("redo_restore", "1");
        if (S.redoSeqArpSnapshot) {
          const { track, params } = S.redoSeqArpSnapshot;
          for (let k = 0; k < 8; k++) {
            const pm = BANKS[4].knobs[k];
            if (pm) S.bankParams[track][4][k] = params[k];
          }
        }
        S.undoAvailable = true;
        S.redoAvailable = false;
        S.pendingUndoSync = 5;
        showActionPopup("REDO");
      } else {
        showActionPopup("NOTHING TO", "REDO");
      }
    } else {
      if (S.undoAvailable) {
        if (S.undoSeqArpSnapshot) {
          const _t = S.undoSeqArpSnapshot.track;
          S.redoSeqArpSnapshot = { track: _t, params: S.bankParams[_t][4].slice() };
        } else {
          S.redoSeqArpSnapshot = null;
        }
        if (typeof host_module_set_param === "function")
          host_module_set_param("undo_restore", "1");
        if (S.undoSeqArpSnapshot) {
          const { track, params } = S.undoSeqArpSnapshot;
          for (let k = 0; k < 8; k++) {
            const pm = BANKS[4].knobs[k];
            if (pm) S.bankParams[track][4][k] = params[k];
          }
        }
        S.redoAvailable = true;
        S.undoAvailable = false;
        S.pendingUndoSync = 5;
        showActionPopup("UNDO");
      } else {
        showActionPopup("NOTHING TO", "UNDO");
      }
    }
    S.screenDirty = true;
  }
  if (d1 === MovePlay && d2 === 127) {
    if (S.deleteHeld) {
      if (typeof host_module_set_param === "function") {
        if (!S.playing) {
          host_module_set_param("transport", "panic");
          for (let t = 0; t < NUM_TRACKS; t++) {
            S.trackWillRelaunch[t] = false;
            S.trackQueuedClip[t] = -1;
          }
          unlatchAllTracks();
        } else {
          host_module_set_param("transport", "deactivate_all");
          unlatchAllTracks();
        }
      }
    } else if (S.muteHeld) {
      S.muteUsedAsModifier = true;
      if (S.metronomeOn !== 0) S.metronomeOnLast = S.metronomeOn;
      S.metronomeOn = S.metronomeOn === 0 ? S.metronomeOnLast : 0;
      if (typeof host_module_set_param === "function")
        host_module_set_param("metro_on", String(S.metronomeOn));
      showActionPopup("METRO " + (S.metronomeOn === 0 ? "OFF" : "ON"));
    } else if (S.loopHeld && !S.sessionView) {
      const _lpAt = S.activeTrack;
      const _lpIsDr = S.trackPadMode[_lpAt] === PAD_MODE_DRUM;
      const _lpPage = _lpIsDr ? S.drumStepPage[_lpAt] | 0 : S.trackCurrentPage[_lpAt] | 0;
      const _lpLane = _lpIsDr ? S.activeDrumLane[_lpAt] | 0 : -1;
      if (typeof host_module_set_param === "function") {
        host_module_set_param("transport", "restart_at:" + _lpAt + ":" + _lpPage + ":" + _lpLane);
      }
    } else if (S.shiftHeld) {
      if (typeof host_module_set_param === "function") {
        host_module_set_param("transport", S.playing ? "restart" : "play");
      }
    } else {
      if (S.recordCountingIn) {
        disarmRecord();
      } else if (typeof host_module_set_param === "function") {
        if (!S.playing && !S.sessionView && !S.trackClipPlaying[S.activeTrack] && !S.trackWillRelaunch[S.activeTrack]) {
          const _at = S.activeTrack;
          const _ac = S.trackActiveClip[_at];
          host_module_set_param("transport", "play_focus:" + _at + ":" + _ac);
          S.trackQueuedClip[_at] = _ac;
        } else {
          host_module_set_param("transport", S.playing ? "stop" : "play");
        }
      }
    }
  }
  if (d1 === MoveRec && d2 === 127 && S.mergeCountingIn) {
    _cancelMergeCountIn();
    return;
  }
  if (d1 === MoveRec && d2 === 127 && S.shiftHeld) {
    if (S.dspMergeState !== 0) {
      S.pendingDefaultSetParams.push({ key: "merge_stop", val: "1" });
    } else if (S.mergeNoticePending) {
    } else if (!S.playing) {
      S.mergeNoticePending = true;
      S.mergeNoticeSingleTrack = S.sessionView ? -1 : S.activeTrack;
      forceRedraw();
    }
    return;
  }
  if (d1 === MoveRec && d2 === 127 && !S.shiftHeld && S.mergeNoticePending) {
    S.mergeNoticePending = false;
    if (S.playing) {
      forceRedraw();
      return;
    }
    const _bpm = S.bpmMirror > 0 && isFinite(S.bpmMirror) ? S.bpmMirror : 120;
    S.mergeCountingIn = true;
    S.countInBeatStartTick = S.tickCount;
    S.countInQuarterTicks = Math.round(TICK_HZ * 60 / _bpm);
    const _solo = S.mergeNoticeSingleTrack;
    if (_solo < 0) {
      S.mergeSingleTrack = -1;
      S.pendingDefaultSetParams.push({ key: "merge_arm", val: "1" });
      showActionPopup("LIVE MERGE", "Count-in, then", "capturing all 8.", "Rec to stop.");
    } else {
      S.mergeSingleTrack = _solo;
      S.pendingDefaultSetParams.push({ key: "merge_arm", val: "t" + _solo });
      showActionPopup("LIVE MERGE", "Count-in, then", "this track.", "Rec to stop.");
    }
    S.pendingMergeArm = true;
    S.actionPopupEndTick = S.tickCount + 280;
    return;
  }
  if (d1 === MoveRec && d2 === 127 && !S.shiftHeld && S.dspMergeState !== 0) {
    S.pendingDefaultSetParams.push({ key: "merge_stop", val: "1" });
    return;
  }
  if (d1 === MoveRec && d2 === 127) {
    if (S.recordArmed) {
      if (S.recordCountingIn) {
        disarmRecord();
      } else {
        const _recT = S.recordArmedTrack >= 0 ? S.recordArmedTrack : S.activeTrack;
        const _recAc = S.trackActiveClip[_recT];
        if (S.clipAdaptiveMode[_recT][_recAc] && !S.recordScheduledStop && S.playing) {
          const _recDrum = S.trackPadMode[_recT] === PAD_MODE_DRUM;
          const _recStp = _recDrum ? S.drumCurrentStep[_recT] : S.trackCurrentStep[_recT];
          S.recordScheduledStop = true;
          S.recordScheduledStopTarget = (Math.floor(_recStp / 16) + 1) * 16;
        } else {
          disarmRecord();
        }
      }
    } else {
      const _at = S.activeTrack;
      const _aac = S.trackActiveClip[_at];
      const _aIsDrum = S.trackPadMode[_at] === PAD_MODE_DRUM;
      const _apd = _aIsDrum ? S.drumLanePlaybackDir[_at][S.activeDrumLane[_at]] | 0 : S.clipPlaybackDir[_at][_aac] | 0;
      if (_apd !== 0) {
        S.recordBlockedDialog = true;
        S.recordBlockedDialogSel = 0;
        forceRedraw();
      } else if (!S.playing) {
        const bpm = S.bpmMirror > 0 && isFinite(S.bpmMirror) ? S.bpmMirror : 120;
        S.recordArmed = true;
        S.recordCountingIn = true;
        S.recordArmedTrack = S.activeTrack;
        S.countInStartTick = S.tickCount;
        S.countInBeatStartTick = S.tickCount;
        S.countInQuarterTicks = Math.round(TICK_HZ * 60 / bpm);
        S.pendingPrerollNotes = [];
        S.pendingPrerollToggleQueue = [];
        if (typeof host_module_set_param === "function")
          host_module_set_param("record_count_in", String(S.activeTrack));
        S.undoAvailable = true;
        S.redoAvailable = false;
        S.undoSeqArpSnapshot = null;
        setButtonLED4(MoveRec, Red4);
      } else {
        const _at2 = S.activeTrack, _ac = S.trackActiveClip[_at2];
        const _isDrum = S.trackPadMode[_at2] === PAD_MODE_DRUM;
        const _adaptive = _isDrum ? !S.drumClipNonEmpty[_at2][_ac] && !S.drumLaneLengthManuallySet[_at2] : !S.clipNonEmpty[_at2][_ac] && !S.clipLengthManuallySet[_at2][_ac];
        S.recordArmed = true;
        S.recordCountingIn = false;
        S.recordArmedTrack = _at2;
        S.recordPendingPage = _adaptive;
        if (_adaptive) S.clipAdaptiveMode[_at2][_ac] = true;
        setButtonLED4(MoveRec, Red4);
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + _at2 + "_recording", _adaptive ? "2" : "1");
        S.undoAvailable = true;
        S.redoAvailable = false;
        S.undoSeqArpSnapshot = null;
      }
    }
  }
  if (d1 === MoveSample && d2 === 127 && !S.shiftHeld) {
    S.sampleHeld = true;
    S.sampleUsedAsModifier = false;
    if (S.pendingInheritPicker) {
      resolveInheritPicker(-1);
      S.sampleUsedAsModifier = true;
    } else if (S.confirmBakeScene) {
      S.confirmBakeScene = false;
      S.sampleUsedAsModifier = true;
      forceRedraw();
    } else if (S.confirmBake) {
      S.confirmBake = false;
      S.confirmBakeDrumLoopOpen = false;
      S.confirmBakeWrapPhase = false;
      S.sampleUsedAsModifier = true;
      forceRedraw();
    }
  }
  if (d1 === MoveSample && d2 === 0 && !S.shiftHeld) {
    S.sampleHeld = false;
    if (!S.sampleUsedAsModifier) {
      if (S.sessionView) {
        S.pendingSceneBakePicker = true;
        S.screenDirty = true;
      } else {
        const _bt = S.activeTrack, _bc = S.trackActiveClip[_bt];
        const _isDrum = S.trackPadMode[_bt] === PAD_MODE_DRUM;
        S.confirmBake = true;
        S.confirmBakeIsDrum = _isDrum;
        S.confirmBakeIsMultiLoop = !_isDrum;
        S.confirmBakeSel = _isDrum ? 2 : 1;
        S.confirmBakeTrack = _bt;
        S.confirmBakeClip = _bc;
        S.confirmBakeDrumLoopOpen = false;
        S.confirmBakeWrapPhase = false;
        S.screenDirty = true;
      }
    }
  }
  if (d1 === MoveMute && d2 === 127 && S.schwungCoRunSlot < 0) {
    if (S.deleteHeld) {
      if (!S.sessionView && S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
        S.drumLaneMute[S.activeTrack] = 0;
        S.drumLaneSolo[S.activeTrack] = 0;
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + S.activeTrack + "_drum_mute_all_clear", "1");
        S.muteUsedAsModifier = true;
        forceRedraw();
      } else {
        clearAllMuteSolo();
      }
    }
  }
  if (d1 === MoveMute && d2 === 0 && S.schwungCoRunSlot < 0) {
    if (!S.muteUsedAsModifier && !S.deleteHeld && !S.sessionView) {
      if (S.shiftHeld) setTrackSolo(S.activeTrack, !S.trackSoloed[S.activeTrack]);
      else setTrackMute(S.activeTrack, !S.trackMuted[S.activeTrack]);
    }
  }
  if ((d1 === MoveLeft || d1 === MoveRight) && d2 === 127 && !S.sessionView) {
    var _t_lr = S.activeTrack;
    if (S.loopHeld && S.activeBank === 6) {
      var RES_TPS = [12, 24, 48, 96, 384];
      var _ac_lr = effectiveClip(_t_lr);
      var _ccL_lr = S.ccActiveLane[_t_lr];
      var _dispTpsLr = S.ccLaneTps[_t_lr][_ac_lr][_ccL_lr] || (S.clipTPS[_t_lr][_ac_lr] || 24);
      var _curTps = S.ccLaneResTps[_t_lr][_ac_lr][_ccL_lr] || _dispTpsLr;
      var _ci = RES_TPS.indexOf(_curTps);
      if (_ci < 0) _ci = 1;
      if (d1 === MoveLeft && _ci > 0) _ci--;
      else if (d1 === MoveRight && _ci < RES_TPS.length - 1) _ci++;
      S.ccLaneResTps[_t_lr][_ac_lr][_ccL_lr] = RES_TPS[_ci];
      if (typeof host_module_set_param === "function")
        host_module_set_param(
          "t" + _t_lr + "_c" + _ac_lr + "_k" + _ccL_lr + "_cc_lane_res_tps",
          String(RES_TPS[_ci])
        );
      forceRedraw();
      return;
    }
    if (S.trackPadMode[_t_lr] === PAD_MODE_DRUM && S.activeBank !== 6) {
      var lsBase = S.drumLaneLoopStart[_t_lr] | 0;
      var startPage = lsBase >> 4;
      var lastPage = startPage + Math.max(1, Math.ceil(S.drumLaneLength[_t_lr] / 16)) - 1;
      if (d1 === MoveLeft)
        S.drumStepPage[_t_lr] = Math.max(startPage, S.drumStepPage[_t_lr] - 1);
      else
        S.drumStepPage[_t_lr] = Math.min(lastPage, S.drumStepPage[_t_lr] + 1);
    } else {
      var ac = effectiveClip(_t_lr);
      var lsBase, startPage, lastPage;
      if (S.activeBank === 6) {
        var _ccL2 = S.ccActiveLane[_t_lr];
        var _llen = S.ccLaneLength[_t_lr][ac][_ccL2];
        if (_llen > 0) {
          lsBase = S.ccLaneLoopStart[_t_lr][ac][_ccL2] | 0;
          startPage = lsBase >> 4;
          lastPage = startPage + Math.max(1, Math.ceil(_llen / 16)) - 1;
        }
      }
      if (lastPage === void 0) {
        lsBase = S.clipLoopStart[_t_lr][ac] | 0;
        startPage = lsBase >> 4;
        lastPage = startPage + Math.max(1, Math.ceil(S.clipLength[_t_lr][ac] / 16)) - 1;
      }
      if (d1 === MoveLeft)
        S.trackCurrentPage[_t_lr] = Math.max(startPage, S.trackCurrentPage[_t_lr] - 1);
      else
        S.trackCurrentPage[_t_lr] = Math.min(lastPage, S.trackCurrentPage[_t_lr] + 1);
    }
    const _sfAc = effectiveClip(S.activeTrack);
    if (S.clipSeqFollow[S.activeTrack][_sfAc]) {
      S.clipSeqFollow[S.activeTrack][_sfAc] = false;
      S.bankParams[S.activeTrack][0][7] = 0;
    }
    S.screenDirty = true;
  }
  if (d1 === MoveDown && d2 === 127 && (S.sessionView || S.sessionOverlayHeld) && S.sceneRow < NUM_CLIPS - 4) {
    S.sceneRow = Math.min(NUM_CLIPS - 4, S.sceneRow + 4);
    forceRedraw();
  }
  if (d1 === MoveUp && d2 === 127 && (S.sessionView || S.sessionOverlayHeld) && S.sceneRow > 0) {
    S.sceneRow = Math.max(0, S.sceneRow - 4);
    forceRedraw();
  }
  if ((d1 === MoveUp || d1 === MoveDown) && d2 > 0 && !S.sessionView && !S.sessionOverlayHeld && S.loopHeld && S.activeBank === 6) {
    var RES_TPS = [12, 24, 48, 96, 384];
    var _zt = S.activeTrack, _zac = effectiveClip(_zt), _zL = S.ccActiveLane[_zt];
    var _zOldTps = S.ccLaneTps[_zt][_zac][_zL] || (S.clipTPS[_zt][_zac] || 24);
    var _zci = RES_TPS.indexOf(_zOldTps);
    if (_zci < 0) _zci = 1;
    if (d1 === MoveDown && _zci > 0) _zci--;
    else if (d1 === MoveUp && _zci < RES_TPS.length - 1) _zci++;
    var _zNewTps = RES_TPS[_zci];
    if (_zNewTps !== _zOldTps) {
      var _zOldLen = S.ccLaneLength[_zt][_zac][_zL] || S.clipLength[_zt][_zac];
      var _zOldTicks = _zOldLen * _zOldTps;
      var _zNewLen = Math.ceil(_zOldTicks / _zNewTps);
      if (_zNewLen <= 256) {
        S.ccLaneTps[_zt][_zac][_zL] = _zNewTps;
        S.ccLaneLength[_zt][_zac][_zL] = _zNewLen;
        var _zOldRes = S.ccLaneResTps[_zt][_zac][_zL];
        if (_zOldRes > 0) {
          var _zNewRes = Math.round(_zOldRes * _zNewTps / _zOldTps);
          var _zResValid = RES_TPS.indexOf(_zNewRes) >= 0;
          S.ccLaneResTps[_zt][_zac][_zL] = _zResValid ? _zNewRes : 0;
        }
        var _zPre = "t" + _zt + "_c" + _zac + "_k" + _zL;
        S.pendingDefaultSetParams.push({ key: _zPre + "_cc_lane_tps", val: String(_zNewTps) });
        S.pendingDefaultSetParams.push({
          key: _zPre + "_cc_loop_set",
          val: String((S.ccLaneLoopStart[_zt][_zac][_zL] | 0) << 16 | _zNewLen & 65535)
        });
        if (_zOldRes > 0)
          S.pendingDefaultSetParams.push({
            key: _zPre + "_cc_lane_res_tps",
            val: String(S.ccLaneResTps[_zt][_zac][_zL])
          });
        var _zMaxPage = Math.max(0, Math.ceil(_zNewLen / 16) - 1);
        if (S.trackCurrentPage[_zt] > _zMaxPage) S.trackCurrentPage[_zt] = _zMaxPage;
        forceRedraw();
      }
    }
    return;
  }
  if (d1 === MoveUp && d2 > 0 && !S.sessionView && !S.sessionOverlayHeld) {
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
      setDrumLanePage(S.activeTrack, 1);
      syncDrumLanesMeta(S.activeTrack);
      syncDrumLaneSteps(S.activeTrack, S.activeDrumLane[S.activeTrack]);
      computePadNoteMap();
      forceRedraw();
    } else {
      for (const p2 of S.liveActiveNotes) queueLiveNoteOff(S.activeTrack, p2);
      S.liveActiveNotes.clear();
      S.trackOctave[S.activeTrack] = Math.min(4, S.trackOctave[S.activeTrack] + 1);
      computePadNoteMap();
      S.screenDirty = true;
      if (S.heldStep >= 0) forceRedraw();
    }
  }
  if (d1 === MoveDown && d2 > 0 && !S.sessionView && !S.sessionOverlayHeld) {
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
      setDrumLanePage(S.activeTrack, 0);
      syncDrumLanesMeta(S.activeTrack);
      syncDrumLaneSteps(S.activeTrack, S.activeDrumLane[S.activeTrack]);
      computePadNoteMap();
      forceRedraw();
    } else {
      for (const p2 of S.liveActiveNotes) queueLiveNoteOff(S.activeTrack, p2);
      S.liveActiveNotes.clear();
      S.trackOctave[S.activeTrack] = Math.max(-4, S.trackOctave[S.activeTrack] - 1);
      computePadNoteMap();
      S.screenDirty = true;
      if (S.heldStep >= 0) forceRedraw();
    }
  }
}
function _onCC_side(d1, d2) {
  if (d1 >= 40 && d1 <= 43 && d2 === 127) {
    const idx = d1 - 40;
    const clipIdx = S.sceneRow + (3 - idx);
    if (S.pendingSceneBakePicker) {
      S.pendingSceneBakePicker = false;
      S.confirmBakeScene = true;
      S.confirmBakeSceneWrapPhase = false;
      S.confirmBakeSceneCondPhase = false;
      S.confirmBakeSceneSel = 1;
      S.confirmBakeSceneClip = clipIdx;
      S.screenDirty = true;
      return;
    }
    if (S.pendingMergePlacement) {
      S.pendingMergePlacement = false;
      S.mergePlacing = true;
      S.mergePlacingScene = true;
      S.pendingDefaultSetParams.push({ key: "merge_place_row", val: String(clipIdx) });
      S.screenDirty = true;
      return;
    }
    if (S.copyHeld) {
      if (S.copySrc && (S.copySrc.kind === "step" || S.copySrc.kind === "cut_step")) {
      } else if (S.sessionView) {
        if (!S.copySrc) {
          S.copySrc = S.shiftHeld ? { kind: "cut_row", row: clipIdx } : { kind: "row", row: clipIdx };
          invalidateLEDCache();
          showActionPopup(S.shiftHeld ? "CUT" : "COPIED");
        } else if (S.copySrc.kind === "row") {
          copyRow(S.copySrc.row, clipIdx);
          invalidateLEDCache();
          forceRedraw();
          showActionPopup("PASTED");
        } else if (S.copySrc.kind === "cut_row") {
          cutRow(S.copySrc.row, clipIdx);
          S.copySrc = { kind: "row", row: clipIdx };
          invalidateLEDCache();
          forceRedraw();
          showActionPopup("PASTED");
        }
      } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
        if (!S.copySrc) {
          S.copySrc = S.shiftHeld ? { kind: "cut_drum_clip", track: S.activeTrack, clip: clipIdx } : { kind: "drum_clip", track: S.activeTrack, clip: clipIdx };
          invalidateLEDCache();
          showActionPopup(S.shiftHeld ? "CUT" : "COPIED");
        } else if (S.copySrc.kind === "drum_clip") {
          copyDrumClip(S.copySrc.track, S.copySrc.clip, S.activeTrack, clipIdx);
          invalidateLEDCache();
          forceRedraw();
          showActionPopup("PASTED");
        } else if (S.copySrc.kind === "cut_drum_clip") {
          cutDrumClip(S.copySrc.track, S.copySrc.clip, S.activeTrack, clipIdx);
          S.copySrc = { kind: "drum_clip", track: S.activeTrack, clip: clipIdx };
          invalidateLEDCache();
          forceRedraw();
          showActionPopup("PASTED");
        }
      } else {
        if (!S.copySrc) {
          S.copySrc = S.shiftHeld ? { kind: "cut_clip", track: S.activeTrack, clip: clipIdx } : { kind: "clip", track: S.activeTrack, clip: clipIdx };
          invalidateLEDCache();
          showActionPopup(S.shiftHeld ? "CUT" : "COPIED");
        } else if (S.copySrc.kind === "clip") {
          copyClip(S.copySrc.track, S.copySrc.clip, S.activeTrack, clipIdx);
          invalidateLEDCache();
          forceRedraw();
          showActionPopup("PASTED");
        } else if (S.copySrc.kind === "cut_clip") {
          cutClip(S.copySrc.track, S.copySrc.clip, S.activeTrack, clipIdx);
          S.copySrc = { kind: "clip", track: S.activeTrack, clip: clipIdx };
          invalidateLEDCache();
          forceRedraw();
          showActionPopup("PASTED");
        }
      }
    } else if (S.shiftHeld && S.deleteHeld) {
      if (S.sessionView) {
        for (let t = 0; t < NUM_TRACKS; t++) hardResetClip(t, clipIdx);
        forceRedraw();
        showActionPopup("CLIPS", "CLEARED");
      } else {
        hardResetClip(S.activeTrack, clipIdx);
        forceRedraw();
        showActionPopup("CLIP", "CLEARED");
      }
    } else if (S.deleteHeld) {
      if (S.sessionView) {
        clearRow(clipIdx);
        forceRedraw();
        showActionPopup("SEQUENCES", "CLEARED");
      } else {
        clearClip(S.activeTrack, clipIdx, true);
        forceRedraw();
        showActionPopup("SEQUENCE", "CLEARED");
      }
    } else if (S.captureHeld) {
      S.captureUsedAsModifier = true;
      let scooped = 0;
      for (let t = 0; t < NUM_TRACKS; t++) {
        const isLive = S.trackClipPlaying[t] && S.trackActiveClip[t] !== clipIdx || S.trackQueuedClip[t] >= 0 && S.trackQueuedClip[t] !== clipIdx;
        if (!isLive) continue;
        const srcC = S.trackQueuedClip[t] >= 0 ? S.trackQueuedClip[t] : S.trackActiveClip[t];
        if (srcC === clipIdx) continue;
        if (!trackClipHasContent(t, srcC)) continue;
        if (S.trackPadMode[t] === PAD_MODE_DRUM) {
          copyDrumClip(t, srcC, t, clipIdx);
        } else {
          copyClip(t, srcC, t, clipIdx);
        }
        scooped++;
      }
      invalidateLEDCache();
      forceRedraw();
      if (scooped > 0) showActionPopup("CAPTURED", "TO ROW " + (clipIdx + 1));
      else showActionPopup("NOTHING", "TO CAPTURE");
    } else if (S.sessionView) {
      S.sceneBtnFlashTick[idx] = S.tickCount;
      const _scKey = S.shiftHeld ? "launch_scene_quant" : "launch_scene";
      S.pendingDefaultSetParams.push({ key: _scKey, val: String(clipIdx) });
    } else {
      const t = S.activeTrack;
      const isActiveClip = S.trackActiveClip[t] === clipIdx;
      if (S.trackClipPlaying[t] && isActiveClip) {
        if (S.trackPendingPageStop[t]) {
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_launch_clip", String(clipIdx));
        } else {
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_stop_at_end", "1");
        }
      } else if (S.trackWillRelaunch[t] && isActiveClip) {
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_deactivate", "1");
      } else if (S.trackQueuedClip[t] === clipIdx) {
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_deactivate", "1");
      } else {
        S.trackActiveClip[t] = clipIdx;
        S.trackCurrentPage[t] = S.trackPadMode[t] === PAD_MODE_DRUM ? 0 : Math.floor((S.clipLoopStart[t][clipIdx] | 0) / 16);
        refreshPerClipBankParams(t);
        if (S.trackPadMode[t] === PAD_MODE_DRUM) {
          S.pendingDrumResync = 2;
          S.pendingDrumResyncTrack = t;
        }
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_launch_clip", String(clipIdx));
      }
    }
  }
}
var KNOB_PICK = 6;
var KNOB_DELIB = 12;
function knobPick(k, dir, need) {
  if (dir !== S.knobLastDir[k]) {
    S.knobAccum[k] = 0;
    S.knobLastDir[k] = dir;
  }
  S.knobAccum[k]++;
  if (S.knobAccum[k] >= need) {
    S.knobAccum[k] = 0;
    return dir;
  }
  return 0;
}
var KNOB_PICK_FMTS = [
  fmtRes,
  fmtDiq,
  fmtPlayDir,
  fmtLen,
  fmtGateMod,
  fmtDly,
  fmtArpStyle,
  fmtArpRate,
  fmtArpSteps,
  fmtArpOct
];
function knobClass(pm) {
  if (pm.lock || pm.scope === "action" || pm.fmt === fmtBool) return "delib";
  if (KNOB_PICK_FMTS.indexOf(pm.fmt) >= 0 || pm.max - pm.min <= 16) return "pick";
  return "cont";
}
function ccKnobDelta(d2, k) {
  const sign = d2 >= 1 && d2 <= 63 ? 1 : d2 >= 65 && d2 <= 127 ? -1 : 0;
  if (!sign) return 0;
  const now = Date.now();
  const gap = now - (S.knobAccelLast[k] || 0);
  S.knobAccelLast[k] = now;
  if (sign !== S.knobAccelDir[k] || gap > 180) {
    S.knobAccelRun[k] = 0;
    S.knobAccelAcc[k] = 0;
  }
  S.knobAccelDir[k] = sign;
  S.knobAccelRun[k]++;
  const run = S.knobAccelRun[k];
  const gain = run <= 12 ? 1 : run <= 24 ? 2 : run <= 36 ? 4 : 6;
  const BASE = 2;
  S.knobAccelAcc[k] += gain;
  const units = Math.floor(S.knobAccelAcc[k] / BASE);
  if (units === 0) return 0;
  S.knobAccelAcc[k] -= units * BASE;
  return sign * units;
}
function _onCC_stepedit(d1, d2) {
  if (S.heldStep >= 0 && S.activeBank === 6 && d1 >= 71 && d1 <= 78) {
    const _kIdx = d1 - 71;
    const _acc = ccKnobDelta(d2, _kIdx);
    if (_acc === 0) return;
    const _t = S.activeTrack;
    const _ac = effectiveClip(_t);
    S.knobTouched = _kIdx;
    S.knobTurnedTick[_kIdx] = S.tickCount;
    S.ccActiveLane[_t] = _kIdx;
    S.screenDirty = true;
    var _laneTps = S.ccLaneTps[_t][_ac][_kIdx];
    const _tps = _laneTps > 0 ? _laneTps : S.clipTPS[_t][_ac] || 24;
    const _tick = S.heldStep * _tps;
    const _hold = Math.min(65535, _tick + _tps - 1);
    if (!S.ccStepEditSet[_kIdx]) {
      S.ccStepEditSet[_kIdx] = true;
      const _nv0 = S.ccStepEditVal[_kIdx] + _acc;
      S.ccStepEditVal[_kIdx] = Math.max(0, Math.min(127, _nv0));
    } else {
      const _nv = S.ccStepEditVal[_kIdx] + _acc;
      if (_nv < 0) {
        S.ccStepEditSet[_kIdx] = false;
        if (typeof host_module_set_param === "function")
          host_module_set_param(
            "t" + _t + "_cc_auto_clear_range",
            _ac + " " + _kIdx + " " + _tick + " " + _hold
          );
        return;
      }
      S.ccStepEditVal[_kIdx] = Math.min(127, _nv);
    }
    if (typeof host_module_set_param === "function")
      host_module_set_param(
        "t" + _t + "_cc_auto_set2",
        _ac + " " + _kIdx + " " + _tick + " " + _hold + " " + S.ccStepEditVal[_kIdx]
      );
    S.trackCCAutoBits[_t][_ac] |= 1 << _kIdx;
    return;
  }
  if (S.heldStep >= 0 && S.heldStepNotes.length > 0 && d1 >= 71 && d1 <= 78 && S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank !== 6) {
    const knobIdx = d1 - 71;
    const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
    const t = S.activeTrack;
    const lane = S.activeDrumLane[t];
    S.knobTouched = knobIdx;
    S.knobTurnedTick[knobIdx] = S.tickCount;
    S.screenDirty = true;
    if (knobIdx === 3 || knobIdx === 7) return;
    if (knobIdx === 0) {
      const _tpsD = S.drumLaneTPS[t] || 24;
      const _gmaxD = Math.min(65535, 256 * _tpsD);
      const _acc = ccKnobDelta(d2, knobIdx);
      if (_acc === 0) return;
      const _steps = S.stepEditGate / _tpsD;
      const _inc = _steps <= 16 ? Math.round(_tpsD / 4) : _steps <= 64 ? _tpsD : _tpsD * 8;
      let _nv = S.stepEditGate + _acc * _inc;
      if (_inc > 1) _nv = Math.round(_nv / _inc) * _inc;
      S.stepEditGate = Math.max(1, Math.min(_gmaxD, _nv));
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_gate", String(S.stepEditGate));
    } else if (knobIdx === 1) {
      const _sv = ccKnobDelta(d2, knobIdx);
      if (_sv === 0) return;
      S.stepEditVel = Math.max(0, Math.min(127, S.stepEditVel + _sv));
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_vel", String(S.stepEditVel));
    } else if (knobIdx === 2) {
      const _sn = ccKnobDelta(d2, knobIdx);
      if (_sn !== 0) {
        const _tpsN1 = (S.drumLaneTPS[t] || 24) - 1;
        S.stepEditNudge = Math.max(-_tpsN1, Math.min(_tpsN1, S.stepEditNudge + _sn));
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_nudge", String(S.stepEditNudge));
      }
    } else if (knobIdx === 4) {
      S.knobAccum[knobIdx] = dir === S.knobLastDir[knobIdx] ? S.knobAccum[knobIdx] + 1 : 1;
      S.knobLastDir[knobIdx] = dir;
      if ((S._iterKd = ccKnobDelta(d2, knobIdx)) !== 0) {
        let idx = STEP_ITER_LIST.indexOf(S.stepEditIter);
        if (idx < 0) idx = 0;
        idx = Math.max(0, Math.min(STEP_ITER_LIST.length - 1, idx + S._iterKd));
        S.stepEditIter = STEP_ITER_LIST[idx];
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_iter", String(S.stepEditIter));
      }
    } else if (knobIdx === 5) {
      const acc = ccKnobDelta(d2, knobIdx);
      if (acc !== 0) {
        {
          const _eff = S.stepEditRand === 0 ? 100 : S.stepEditRand;
          const _nv = Math.max(1, Math.min(100, _eff + acc));
          S.stepEditRand = _nv === 100 ? 0 : _nv;
        }
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_rand", String(S.stepEditRand));
      }
    } else if (knobIdx === 6) {
      S.knobAccum[knobIdx] = dir === S.knobLastDir[knobIdx] ? S.knobAccum[knobIdx] + 1 : 1;
      S.knobLastDir[knobIdx] = dir;
      if (S.knobAccum[knobIdx] >= KNOB_PICK) {
        S.knobAccum[knobIdx] = 0;
        S.stepEditRatch = Math.max(0, Math.min(4, S.stepEditRatch + dir));
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_ratch", String(S.stepEditRatch));
      }
    }
    return;
  }
  if (S.heldStep >= 0 && S.heldStepNotes.length > 0 && d1 >= 71 && d1 <= 78 && S.activeBank !== 6) {
    const knobIdx = d1 - 71;
    const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
    const t = S.activeTrack;
    const ac = effectiveClip(t);
    const pfx = "t" + t + "_c" + ac + "_step_" + S.heldStep;
    S.knobTouched = knobIdx;
    S.knobTurnedTick[knobIdx] = S.tickCount;
    S.screenDirty = true;
    if (knobIdx === 0) {
      S.knobAccum[knobIdx] = dir === S.knobLastDir[knobIdx] ? S.knobAccum[knobIdx] + 1 : 1;
      S.knobLastDir[knobIdx] = dir;
      if (S.knobAccum[knobIdx] >= KNOB_PICK) {
        S.knobAccum[knobIdx] = 0;
        S.heldStepNotes = S.heldStepNotes.map(function(n) {
          return Math.max(0, Math.min(127, n + dir * 12));
        });
        if (typeof host_module_set_param === "function")
          host_module_set_param(pfx + "_set_notes", S.heldStepNotes.join(" "));
      }
    } else if (knobIdx === 1) {
      S.knobAccum[knobIdx] = dir === S.knobLastDir[knobIdx] ? S.knobAccum[knobIdx] + 1 : 1;
      S.knobLastDir[knobIdx] = dir;
      if (S.knobAccum[knobIdx] >= KNOB_PICK) {
        S.knobAccum[knobIdx] = 0;
        S.heldStepNotes = S.heldStepNotes.map(function(n) {
          return scaleNudgeNote(n, dir, S.padKey, S.padScale);
        });
        if (typeof host_module_set_param === "function")
          host_module_set_param(pfx + "_set_notes", S.heldStepNotes.join(" "));
      }
    } else if (knobIdx === 2) {
      {
        const _acD = effectiveClip(S.activeTrack);
        const _tpsD = S.clipTPS[S.activeTrack][_acD] || 24;
        const _gmaxD = Math.min(65535, 256 * _tpsD);
        const _acc = ccKnobDelta(d2, knobIdx);
        if (_acc === 0) return;
        const _steps = S.stepEditGate / _tpsD;
        const _inc = _steps <= 16 ? Math.round(_tpsD / 4) : _steps <= 64 ? _tpsD : _tpsD * 8;
        let _nv = S.stepEditGate + _acc * _inc;
        if (_inc > 1) _nv = Math.round(_nv / _inc) * _inc;
        S.stepEditGate = Math.max(1, Math.min(_gmaxD, _nv));
      }
      if (typeof host_module_set_param === "function")
        host_module_set_param(pfx + "_gate", String(S.stepEditGate));
    } else if (knobIdx === 3) {
      const _sv = ccKnobDelta(d2, knobIdx);
      if (_sv === 0) return;
      S.stepEditVel = Math.max(0, Math.min(127, S.stepEditVel + _sv));
      if (typeof host_module_set_param === "function")
        host_module_set_param(pfx + "_vel", String(S.stepEditVel));
    } else if (knobIdx === 4) {
      const _sn = ccKnobDelta(d2, knobIdx);
      if (_sn !== 0) {
        const _acN = effectiveClip(S.activeTrack);
        const _tpsN1 = (S.clipTPS[S.activeTrack][_acN] || 24) - 1;
        S.stepEditNudge = Math.max(-_tpsN1, Math.min(_tpsN1, S.stepEditNudge + _sn));
        if (typeof host_module_set_param === "function")
          host_module_set_param(pfx + "_nudge", String(S.stepEditNudge));
      }
    } else if (knobIdx === 5) {
      S.knobAccum[knobIdx] = dir === S.knobLastDir[knobIdx] ? S.knobAccum[knobIdx] + 1 : 1;
      S.knobLastDir[knobIdx] = dir;
      if ((S._iterKd = ccKnobDelta(d2, knobIdx)) !== 0) {
        let idx = STEP_ITER_LIST.indexOf(S.stepEditIter);
        if (idx < 0) idx = 0;
        idx = Math.max(0, Math.min(STEP_ITER_LIST.length - 1, idx + S._iterKd));
        S.stepEditIter = STEP_ITER_LIST[idx];
        if (typeof host_module_set_param === "function")
          host_module_set_param(pfx + "_iter", String(S.stepEditIter));
      }
    } else if (knobIdx === 6) {
      const acc = ccKnobDelta(d2, knobIdx);
      if (acc !== 0) {
        {
          const _eff = S.stepEditRand === 0 ? 100 : S.stepEditRand;
          const _nv = Math.max(1, Math.min(100, _eff + acc));
          S.stepEditRand = _nv === 100 ? 0 : _nv;
        }
        if (typeof host_module_set_param === "function")
          host_module_set_param(pfx + "_rand", String(S.stepEditRand));
      }
    } else if (knobIdx === 7) {
      S.knobAccum[knobIdx] = dir === S.knobLastDir[knobIdx] ? S.knobAccum[knobIdx] + 1 : 1;
      S.knobLastDir[knobIdx] = dir;
      if (S.knobAccum[knobIdx] >= KNOB_PICK) {
        S.knobAccum[knobIdx] = 0;
        S.stepEditRatch = Math.max(0, Math.min(4, S.stepEditRatch + dir));
        if (typeof host_module_set_param === "function")
          host_module_set_param(pfx + "_ratch", String(S.stepEditRatch));
      }
    }
    return;
  }
}
function _onCC_knobs(d1, d2) {
  if (d1 >= 71 && d1 <= 78) {
    if (S.heldStep >= 0) return;
    if (S.globalMenuOpen || S.tapTempoOpen || S.confirmBake || S.confirmClearSession || S.confirmConvertToDrum || S.confirmConvertToConduct || S.menuInfoLines.length > 0 || S.confirmExport || S.exportDoneDialog || S.recordBlockedDialog || S.confirmStateWipe || S.bpmMoveInfo) return;
    const knobIdx = d1 - 71;
    S.knobTouched = knobIdx;
    S.knobTurnedTick[knobIdx] = S.tickCount;
    S.screenDirty = true;
    const bank = S.activeBank;
    if (S.stepIntervalMode && (bank === 4 || bank === 5)) {
      const t = S.activeTrack;
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      const _kd = ccKnobDelta(d2, knobIdx);
      if (_kd !== 0) {
        if (S.shiftHeld) {
          if (bank === 4) {
            const ac = effectiveClip(t);
            const cur = S.seqArpStepVel[t][ac][knobIdx] | 0;
            const nxt = cur === 0 ? dir > 0 ? 5 : 0 : cur === 255 ? dir > 0 ? 255 : 127 : cur === 127 && dir > 0 ? 255 : Math.max(5, Math.min(127, cur + _kd));
            if (nxt !== cur) {
              S.seqArpStepVel[t][ac][knobIdx] = nxt;
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_seq_arp_step_vel", knobIdx + " " + nxt);
            }
          } else {
            const cur = S.tarpStepVel[t][knobIdx] | 0;
            const nxt = cur === 0 ? dir > 0 ? 5 : 0 : cur === 255 ? dir > 0 ? 255 : 127 : cur === 127 && dir > 0 ? 255 : Math.max(5, Math.min(127, cur + _kd));
            if (nxt !== cur) {
              S.tarpStepVel[t][knobIdx] = nxt;
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_tarp_step_vel", knobIdx + " " + nxt);
            }
          }
        } else if (bank === 4) {
          const ac = effectiveClip(t);
          const cur = S.seqArpStepInt[t][ac][knobIdx] | 0;
          const nxt = Math.max(-24, Math.min(24, cur + _kd));
          if (nxt !== cur) {
            S.seqArpStepInt[t][ac][knobIdx] = nxt;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_seq_arp_step_int", knobIdx + " " + nxt);
          }
        } else {
          const cur = S.tarpStepInt[t][knobIdx] | 0;
          const nxt = Math.max(-24, Math.min(24, cur + _kd));
          if (nxt !== cur) {
            S.tarpStepInt[t][knobIdx] = nxt;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_tarp_step_int", knobIdx + " " + nxt);
          }
        }
      }
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT && (bank === BANK_RESPONDER || bank === BANK_OCTAVE || bank === BANK_WHEN)) {
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      if (bank === BANK_OCTAVE) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_PICK) {
          S.knobAccum[knobIdx] = 0;
          applyConductGridKnob(BANK_OCTAVE, knobIdx, dir);
        }
      } else {
        if (S.knobLocked[knobIdx]) return;
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_DELIB) {
          S.knobAccum[knobIdx] = 0;
          S.knobLocked[knobIdx] = true;
          applyConductGridKnob(bank, knobIdx, dir);
        }
      }
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 0) {
      const t = S.activeTrack;
      const ac = effectiveClip(t);
      const lane = S.activeDrumLane[t];
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      if (knobIdx === 0) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_PICK) {
          S.knobAccum[knobIdx] = 0;
          const curIdx = Math.max(0, TPS_VALUES.indexOf(S.drumLaneTPS[t]));
          const nv = Math.max(0, Math.min(5, curIdx + dir));
          if (nv !== curIdx) {
            if (S.altMode) {
              const newTps = TPS_VALUES[nv];
              const newLen = Math.ceil(S.drumLaneLength[t] * S.drumLaneTPS[t] / newTps);
              if (newLen > 256) {
                showActionPopup("NOTES OUT", "OF RANGE");
                forceRedraw();
              } else if (S.heldStep >= 0) {
              } else {
                S.drumLaneTPS[t] = newTps;
                S.drumLaneLength[t] = newLen;
                S.bankParams[t][0][knobIdx] = nv;
                const maxPage = Math.max(0, Math.ceil(newLen / 16) - 1);
                if (S.drumStepPage[t] > maxPage) S.drumStepPage[t] = maxPage;
                if (typeof host_module_set_param === "function")
                  host_module_set_param("t" + t + "_l" + lane + "_clip_resolution_zoom", String(nv));
                S.pendingDrumLaneResync = 2;
                S.pendingDrumLaneResyncTrack = t;
                S.pendingDrumLaneResyncLane = lane;
                forceRedraw();
              }
            } else {
              S.drumLaneTPS[t] = TPS_VALUES[nv];
              S.bankParams[t][0][knobIdx] = nv;
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_l" + lane + "_clip_resolution", String(nv));
              S.pendingDrumResync = 2;
              S.pendingDrumResyncTrack = t;
            }
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 1) {
        if (S.knobLocked[knobIdx]) return;
        const len = S.drumLaneLength[t];
        const canFire = dir === 1 ? len * 2 <= 256 : len >= 2;
        if (!canFire) return;
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_DELIB) {
          S.knobAccum[knobIdx] = 0;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_l" + lane + "_beat_stretch", String(dir));
          S.knobLocked[knobIdx] = true;
          const blocked = host_module_get_param("t" + t + "_beat_stretch_blocked") === "1";
          if (dir === -1 && blocked) {
            S.stretchBlockedEndTick = S.tickCount + STRETCH_BLOCKED_TICKS;
          } else {
            S.drumLaneLength[t] = dir === 1 ? len * 2 : Math.floor(len / 2);
            const maxPage = Math.max(0, Math.ceil(S.drumLaneLength[t] / 16) - 1);
            if (S.drumStepPage[t] > maxPage) S.drumStepPage[t] = maxPage;
            S.bankParams[t][0][1] = dir;
            S.pendingDrumResync = 2;
            S.pendingDrumResyncTrack = t;
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 2) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= (S.altMode ? 4 : 8)) {
          S.knobAccum[knobIdx] = 0;
          if (S.altMode) {
            S.bankParams[t][0][knobIdx] += dir;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_nudge", String(dir));
          } else {
            S.clockShiftTouchDelta += dir;
            S.bankParams[t][0][knobIdx] = S.clockShiftTouchDelta;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_clock_shift", String(dir));
          }
          S.pendingDrumLaneResync = 2;
          S.pendingDrumLaneResyncTrack = t;
          S.pendingDrumLaneResyncLane = lane;
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 3) {
        if (S.knobLocked[knobIdx]) return;
        if (dir !== 1) return;
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_DELIB) {
          S.knobAccum[knobIdx] = 0;
          S.confirmLgto = true;
          S.confirmLgtoSel = 0;
          S.confirmLgtoIsDrum = true;
          S.knobLocked[knobIdx] = true;
          forceRedraw();
        }
        return;
      }
      if (knobIdx === 4) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_PICK) {
          S.knobAccum[knobIdx] = 0;
          const len = S.drumLaneLength[t];
          const prev = Math.min(S.drumLaneEuclidN[t][lane] | 0, len);
          const nv = Math.max(0, Math.min(len, prev + dir));
          if (nv !== prev) {
            const vel = stepEntryVelocity(t, -1, true);
            if (typeof host_module_set_param === "function")
              host_module_set_param(
                "t" + t + "_l" + lane + "_euclid_stamp",
                prev + " " + nv + " " + vel
              );
            S.drumLaneEuclidN[t][lane] = nv;
            S.bankParams[t][0][4] = nv;
            S.pendingDrumLaneResync = 2;
            S.pendingDrumLaneResyncTrack = t;
            S.pendingDrumLaneResyncLane = lane;
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 6) {
        S.knobAccum[knobIdx]++;
        const _k7Sens = KNOB_PICK;
        if (S.knobAccum[knobIdx] >= _k7Sens) {
          S.knobAccum[knobIdx] = 0;
          if (S.altMode) {
            const _cur = S.drumLanePlaybackAudioReverse[t][lane] | 0;
            const _nv = Math.max(0, Math.min(1, _cur + dir));
            if (_nv !== _cur) {
              S.drumLanePlaybackAudioReverse[t][lane] = _nv;
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_l" + lane + "_playback_audio_reverse", String(_nv));
            }
          } else {
            const _cur = S.drumLanePlaybackDir[t][lane] | 0;
            const _nv = Math.max(0, Math.min(3, _cur + dir));
            if (_nv !== _cur) {
              S.drumLanePlaybackDir[t][lane] = _nv;
              S.bankParams[t][0][6] = _nv;
              if (typeof host_module_set_param === "function")
                host_module_set_param("t" + t + "_l" + lane + "_playback_dir", String(_nv));
            }
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 7) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_DELIB) {
          S.knobAccum[knobIdx] = 0;
          const _cur = S.clipSeqFollow[t][ac] ? 1 : 0;
          const _nv = Math.max(0, Math.min(1, _cur + dir));
          if (_nv !== _cur) {
            S.clipSeqFollow[t][ac] = _nv !== 0;
            S.bankParams[t][0][7] = _nv;
            S.screenDirty = true;
          }
        }
        return;
      }
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 7 && !S.allLanesConfirmed) {
      S.screenDirty = true;
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 7) {
      const t = S.activeTrack;
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      if (knobIdx === 0) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_PICK) {
          S.knobAccum[knobIdx] = 0;
          const curIdx = S.bankParams[t][7][0] < 0 ? -1 : S.bankParams[t][7][0];
          const nv = Math.max(0, Math.min(5, curIdx + dir));
          if (nv !== curIdx) {
            S.bankParams[t][7][0] = nv;
            S.drumLaneTPS[t] = TPS_VALUES[nv];
            host_module_set_param("t" + t + "_all_lanes_clip_resolution", String(nv));
            S.pendingDrumResync = 2;
            S.pendingDrumResyncTrack = t;
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 1) {
        if (S.knobLocked[knobIdx]) return;
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_DELIB) {
          S.knobAccum[knobIdx] = 0;
          host_module_set_param("t" + t + "_all_lanes_beat_stretch", String(dir));
          S.knobLocked[knobIdx] = true;
          S.bankParams[t][7][1] += dir;
          S.pendingAllLanesStretchCheck = t;
          S.pendingDrumResync = 2;
          S.pendingDrumResyncTrack = t;
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 2) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= (S.altMode ? 1 : KNOB_PICK)) {
          S.knobAccum[knobIdx] = 0;
          if (S.altMode) {
            S.bankParams[t][7][2] += dir;
            host_module_set_param("t" + t + "_all_lanes_nudge", String(dir));
          } else {
            S.clockShiftTouchDelta += dir;
            S.bankParams[t][7][2] = S.clockShiftTouchDelta;
            host_module_set_param("t" + t + "_all_lanes_clock_shift", String(dir));
          }
          S.pendingDrumResync = 2;
          S.pendingDrumResyncTrack = t;
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 3) {
        const _q = ccKnobDelta(d2, knobIdx);
        if (_q !== 0) {
          const cur7q = S.bankParams[t][7][3] < 0 ? 0 : S.bankParams[t][7][3];
          const nv = Math.max(0, Math.min(100, cur7q + _q));
          if (nv !== cur7q) {
            S.bankParams[t][7][3] = nv;
            S.drumLaneQnt[t] = nv;
            S.bankParams[t][1][2] = nv;
            host_module_set_param("t" + t + "_drum_lanes_qnt", String(nv));
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 4) {
        const _v5 = ccKnobDelta(d2, knobIdx);
        if (_v5 === 0) return;
        const cur7v = S.trackVelOverride[t];
        const nv = Math.max(0, Math.min(127, cur7v + _v5));
        if (nv !== cur7v) applyTrackConfig(t, "track_vel_override", nv);
        S.screenDirty = true;
        return;
      }
      if (knobIdx === 5) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_PICK) {
          S.knobAccum[knobIdx] = 0;
          const nv = Math.max(0, Math.min(8, S.drumInpQuant[t] + dir));
          if (nv !== S.drumInpQuant[t]) {
            S.drumInpQuant[t] = nv;
            S.bankParams[t][7][5] = nv;
            host_module_set_param("t" + t + "_diq", String(nv));
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 6) {
        S.knobAccum[knobIdx]++;
        const _k7Sens = KNOB_PICK;
        if (S.knobAccum[knobIdx] >= _k7Sens) {
          S.knobAccum[knobIdx] = 0;
          if (S.altMode) {
            const curRv = S.bankParams[t][7][6] < 0 ? -1 : S.bankParams[t][7][6];
            const nvRv = Math.max(0, Math.min(1, curRv + dir));
            if (nvRv !== curRv) {
              S.bankParams[t][7][6] = nvRv;
              host_module_set_param("t" + t + "_all_lanes_playback_audio_reverse", String(nvRv));
            }
          } else {
            const curDir = S.bankParams[t][7][6] < 0 ? -1 : S.bankParams[t][7][6];
            const nvDir = Math.max(0, Math.min(3, curDir + dir));
            if (nvDir !== curDir) {
              S.bankParams[t][7][6] = nvDir;
              host_module_set_param("t" + t + "_all_lanes_playback_dir", String(nvDir));
            }
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 7) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_DELIB) {
          S.knobAccum[knobIdx] = 0;
          const cur7s = S.bankParams[t][7][7] | 0;
          const nv = Math.max(0, Math.min(1, cur7s + dir));
          if (nv !== cur7s) {
            S.bankParams[t][7][7] = nv;
            host_module_set_param("t" + t + "_drum_repeat_sync", String(nv));
          }
          S.screenDirty = true;
        }
        return;
      }
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 1) {
      if (knobIdx >= 6) return;
      const t = S.activeTrack;
      const lane = S.activeDrumLane[t];
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      if (knobIdx === 0 || knobIdx === 1) {
        const delta = knobIdx === 0 ? knobPick(knobIdx, dir, KNOB_PICK) * 12 : ccKnobDelta(d2, knobIdx);
        if (delta !== 0) {
          const nv = Math.max(0, Math.min(127, S.drumLaneNote[t][lane] + delta));
          if (nv !== S.drumLaneNote[t][lane]) {
            S.drumLaneNote[t][lane] = nv;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_lane_note", String(nv));
            if (t === S.activeTrack) computePadNoteMap();
            S.screenDirty = true;
          }
        }
        return;
      }
      if (knobIdx === 2) {
        const _d3 = ccKnobDelta(d2, knobIdx);
        if (_d3 !== 0) {
          const nv = Math.max(-127, Math.min(127, (S.bankParams[t][1][1] | 0) + _d3));
          if (nv !== S.bankParams[t][1][1]) {
            S.bankParams[t][1][1] = nv;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_pfx_set", "velocity_offset " + nv);
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 3) {
        const _d4 = ccKnobDelta(d2, knobIdx);
        if (_d4 !== 0) {
          const nv = Math.max(0, Math.min(100, S.drumLaneQnt[t] + _d4));
          if (nv !== S.drumLaneQnt[t]) {
            S.drumLaneQnt[t] = nv;
            S.bankParams[t][1][2] = nv;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_pfx_set", "quantize " + nv);
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 4) {
        S.knobAccum[knobIdx]++;
        if (S.knobAccum[knobIdx] >= KNOB_PICK) {
          S.knobAccum[knobIdx] = 0;
          const cur = S.drumLaneLenMode[t][lane] | 0;
          const nv = Math.max(0, Math.min(8, cur + dir));
          if (nv !== cur) {
            S.drumLaneLenMode[t][lane] = nv;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_pfx_set", "note_length_mode " + nv);
          }
          S.screenDirty = true;
        }
        return;
      }
      if (knobIdx === 5) {
        const _d6 = ccKnobDelta(d2, knobIdx);
        if (_d6 !== 0) {
          const nv = Math.max(0, Math.min(400, (S.bankParams[t][1][0] | 0) + _d6));
          if (nv !== S.bankParams[t][1][0]) {
            S.bankParams[t][1][0] = nv;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_pfx_set", "gate_time " + nv);
          }
          S.screenDirty = true;
        }
        return;
      }
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 5) {
      const t = S.activeTrack;
      const lane = S.activeDrumLane[t];
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      const _kd = ccKnobDelta(d2, knobIdx);
      if (_kd !== 0) {
        const step = knobIdx;
        if (S.altMode) {
          const nv = Math.max(-50, Math.min(50, (S.drumRepeatNudge[t][lane][step] | 0) + _kd));
          if (nv !== S.drumRepeatNudge[t][lane][step]) {
            S.drumRepeatNudge[t][lane][step] = nv;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_repeat_nudge", step + " " + nv);
          }
        } else {
          const cv = S.drumRepeatVelScale[t][lane][step] | 0;
          const nv = cv === 255 ? dir > 0 ? 255 : 127 : cv === 127 && dir > 0 ? 255 : Math.max(1, Math.min(127, cv + _kd));
          if (nv !== S.drumRepeatVelScale[t][lane][step]) {
            S.drumRepeatVelScale[t][lane][step] = nv;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + t + "_l" + lane + "_repeat_vel_scale", step + " " + nv);
          }
        }
        S.screenDirty = true;
      }
      return;
    }
    if (bank === 6) {
      const t = S.activeTrack;
      const ac = effectiveClip(t);
      const _setp = (k, v) => {
        if (typeof host_module_set_param === "function") host_module_set_param("t" + t + "_" + k, v);
      };
      S.ccActiveLane[t] = knobIdx;
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      S.knobAccum[knobIdx]++;
      if (S.altMode) {
        if (S.knobAccum[knobIdx] >= KNOB_PICK) {
          S.knobAccum[knobIdx] = 0;
          const hasSch = typeof shadow_set_param === "function";
          const cur2 = S.trackCCType[t][knobIdx] === 2 ? -(S.trackCCAssign[t][knobIdx] + 1) : S.trackCCType[t][knobIdx] === 1 ? -1 : S.trackCCAssign[t][knobIdx];
          const minVal = hasSch ? -9 : -1;
          const nx = Math.max(minVal, Math.min(127, cur2 + dir));
          if (nx <= -2) {
            const schKnob = -(nx + 1);
            S.trackCCType[t][knobIdx] = 2;
            S.trackCCAssign[t][knobIdx] = schKnob;
            S.schLabel[t][knobIdx] = null;
            _setp("cc_type_assign", knobIdx + " 2 " + schKnob);
          } else if (nx === -1) {
            S.trackCCType[t][knobIdx] = 1;
            _setp("cc_type_assign", knobIdx + " 1 " + S.trackCCAssign[t][knobIdx]);
          } else {
            S.trackCCType[t][knobIdx] = 0;
            S.trackCCAssign[t][knobIdx] = nx;
            _setp("cc_type_assign", knobIdx + " 0 " + nx);
          }
          S.screenDirty = true;
        }
        return;
      }
      if (S.heldStep >= 0) return;
      if (S.deleteHeld) {
        S.trackCCAutoBits[t][ac] &= ~(1 << knobIdx);
        S.trackCCLiveVal[t][knobIdx] = -1;
        S.clipCCVal[t][ac][knobIdx] = -1;
        _setp("cc_auto_clear_k", ac + " " + knobIdx);
        showActionPopup("CC", "CLEAR");
        invalidateLEDCache();
        return;
      }
      const accel = ccKnobDelta(d2, knobIdx);
      if (accel === 0) return;
      const armed = S.recordArmed && S.recordArmedTrack === t && S.playing;
      const hasAuto = S.trackCCAutoBits[t][ac] >> knobIdx & 1;
      if (armed) {
        const base = S.trackCCLiveVal[t][knobIdx] >= 0 ? S.trackCCLiveVal[t][knobIdx] : S.clipCCVal[t][ac][knobIdx] >= 0 ? S.clipCCVal[t][ac][knobIdx] : 0;
        const nv2 = Math.max(0, Math.min(127, base + accel));
        S.trackCCLiveVal[t][knobIdx] = nv2;
        _setp("cc_send", knobIdx + " " + nv2);
        S.trackCCAutoBits[t][ac] |= 1 << knobIdx;
        S.screenDirty = true;
        return;
      }
      if (S.playing && hasAuto) {
        const base = S.trackCCLiveVal[t][knobIdx] >= 0 ? S.trackCCLiveVal[t][knobIdx] : 0;
        const nv2 = Math.max(0, Math.min(127, base + accel));
        S.trackCCLiveVal[t][knobIdx] = nv2;
        _setp("cc_send", knobIdx + " " + nv2);
        S.screenDirty = true;
        return;
      }
      const cur = S.clipCCVal[t][ac][knobIdx];
      let nv;
      if (cur < 0) nv = accel > 0 ? accel - 1 : -1;
      else {
        nv = cur + accel;
        if (nv < 0) nv = -1;
      }
      nv = Math.max(-1, Math.min(127, nv));
      if (nv === cur) return;
      S.clipCCVal[t][ac][knobIdx] = nv;
      S.trackCCLiveVal[t][knobIdx] = nv;
      _setp("cc_rest", ac + " " + knobIdx + " " + (nv < 0 ? 255 : nv));
      S.screenDirty = true;
      return;
    }
    if (S.altMode && S.trackPadMode[S.activeTrack] !== PAD_MODE_DRUM && (bank === 1 && knobIdx === 7 || bank === 3 && knobIdx === 7)) {
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      S.knobAccum[knobIdx]++;
      if (S.knobAccum[knobIdx] >= KNOB_PICK) {
        S.knobAccum[knobIdx] = 0;
        const t = S.activeTrack;
        const isMidi = bank === 3;
        const cur = isMidi ? S.midiDlyRandomMode[t] || 0 : S.noteFXRandomMode[t] || 0;
        const nv = ((cur + dir) % 3 + 3) % 3;
        if (isMidi) {
          S.midiDlyRandomMode[t] = nv;
        } else {
          S.noteFXRandomMode[t] = nv;
        }
        if (typeof host_module_set_param === "function")
          host_module_set_param(isMidi ? "delay_pitch_random_mode" : "noteFX_random_mode", String(nv));
        S.screenDirty = true;
      }
      return;
    }
    if (S.altMode && S.trackPadMode[S.activeTrack] !== PAD_MODE_DRUM && bank === 3 && knobIdx === 0) {
      const t = S.activeTrack;
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      const _q = ccKnobDelta(d2, knobIdx);
      if (_q !== 0) {
        const nv = Math.max(-100, Math.min(100, (S.delayClockFb[t] | 0) + _q));
        if (nv !== S.delayClockFb[t]) {
          S.delayClockFb[t] = nv;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_delay_clock_fb", String(nv));
        }
        S.screenDirty = true;
      }
      return;
    }
    if (S.trackPadMode[S.activeTrack] !== PAD_MODE_DRUM && bank === 0 && knobIdx === 4) {
      const t = S.activeTrack;
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      S.knobAccum[knobIdx]++;
      if (S.knobAccum[knobIdx] >= KNOB_PICK) {
        S.knobAccum[knobIdx] = 0;
        const nv = Math.max(0, Math.min(8, S.drumInpQuant[t] + dir));
        if (nv !== S.drumInpQuant[t]) {
          S.drumInpQuant[t] = nv;
          S.bankParams[t][0][4] = nv;
          if (typeof host_module_set_param === "function")
            host_module_set_param("t" + t + "_diq", String(nv));
        }
        S.screenDirty = true;
      }
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT && bank === 0 && knobIdx === 5) {
      if (S.knobLocked[knobIdx]) return;
      const t = S.activeTrack;
      const ac = S.trackActiveClip[t] | 0;
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      if (dir !== S.knobLastDir[knobIdx]) {
        S.knobAccum[knobIdx] = 0;
        S.knobLastDir[knobIdx] = dir;
      }
      S.knobAccum[knobIdx]++;
      if (S.knobAccum[knobIdx] >= KNOB_DELIB) {
        S.knobAccum[knobIdx] = 0;
        S.knobLocked[knobIdx] = true;
        S.condLock[ac] = S.condLock[ac] ? 0 : 1;
        if (typeof host_module_set_param === "function")
          host_module_set_param("t" + t + "_c" + ac + "_cond_lock", String(S.condLock[ac]));
        S.screenDirty = true;
      }
      return;
    }
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT && bank === 1 && (knobIdx === 2 || knobIdx === 3 || knobIdx === 4 || knobIdx === 5)) {
      return;
    }
    const pm = BANKS[bank].knobs[knobIdx];
    if (pm && pm.abbrev && pm.scope !== "stub" && !S.knobLocked[knobIdx]) {
      const dir = d2 >= 1 && d2 <= 63 ? 1 : -1;
      let _cls = knobClass(pm);
      if (pm.dspKey === "clock_shift") _cls = "pick";
      const _delta = _cls === "cont" ? ccKnobDelta(d2, knobIdx) : knobPick(knobIdx, dir, _cls === "delib" ? KNOB_DELIB : KNOB_PICK);
      if (_delta !== 0) {
        S.screenDirty = true;
        if (pm.scope === "action") {
          const t = S.activeTrack;
          const ac = S.trackActiveClip[t];
          const len = S.clipLength[t][ac];
          if (pm.dspKey === "lgto_apply") {
            if (dir !== 1) return;
            S.confirmLgto = true;
            S.confirmLgtoSel = 0;
            S.confirmLgtoIsDrum = false;
            S.knobLocked[knobIdx] = true;
            forceRedraw();
            return;
          }
          if (pm.lock) {
            const canFire = dir === 1 ? len * 2 <= 256 : len >= 2;
            if (canFire && typeof host_module_set_param === "function") {
              host_module_set_param("t" + t + "_" + pm.dspKey, String(dir));
              S.knobLocked[knobIdx] = true;
              if (dir === -1 && host_module_get_param("t" + t + "_beat_stretch_blocked") === "1") {
                S.stretchBlockedEndTick = S.tickCount + STRETCH_BLOCKED_TICKS;
              } else {
                const steps = S.clipSteps[t][ac];
                if (dir === 1) {
                  for (let si = len - 1; si >= 1; si--) {
                    steps[si * 2] = steps[si];
                    steps[si] = 0;
                  }
                  for (let si = 1; si < len * 2; si += 2) steps[si] = 0;
                  S.clipLength[t][ac] = len * 2;
                } else {
                  const halfLen = len >> 1;
                  const tmp = new Array(halfLen).fill(0);
                  for (let si = 0; si < len; si++) {
                    if (steps[si] === 1 && !tmp[si >> 1]) tmp[si >> 1] = 1;
                  }
                  for (let si = 0; si < len; si++) {
                    if (steps[si] === 2 && !tmp[si >> 1]) tmp[si >> 1] = 2;
                  }
                  for (let si = 0; si < len; si++) steps[si] = 0;
                  for (let si = 0; si < halfLen; si++) steps[si] = tmp[si];
                  S.clipLength[t][ac] = halfLen;
                }
                const newPages = Math.max(1, Math.ceil(S.clipLength[t][ac] / 16));
                if (S.trackCurrentPage[t] >= newPages)
                  S.trackCurrentPage[t] = newPages - 1;
                S.bankParams[t][bank][knobIdx] = dir;
              }
            }
          } else if (pm.dspKey === "clock_shift") {
            if (S.altMode) {
              if (typeof host_module_set_param === "function") {
                host_module_set_param("t" + t + "_nudge", String(dir));
                S.bankParams[t][bank][knobIdx] += dir;
                S.pendingStepsReread = 2;
                S.pendingStepsRereadTrack = t;
                S.pendingStepsRereadClip = ac;
              }
            } else if (len >= 2 && typeof host_module_set_param === "function") {
              host_module_set_param("t" + t + "_" + pm.dspKey, String(dir));
              const steps = S.clipSteps[t][ac];
              if (dir === 1) {
                const last = steps[len - 1];
                for (let si = len - 1; si > 0; si--) steps[si] = steps[si - 1];
                steps[0] = last;
              } else {
                const first = steps[0];
                for (let si = 0; si < len - 1; si++) steps[si] = steps[si + 1];
                steps[len - 1] = first;
              }
              S.clockShiftTouchDelta += dir;
              S.bankParams[t][bank][knobIdx] = S.clockShiftTouchDelta;
            }
          }
        } else if (S.altMode && pm && pm.dspKey === "clip_playback_dir" && S.trackPadMode[S.activeTrack] !== PAD_MODE_DRUM) {
          const _t = S.activeTrack;
          const _ac = effectiveClip(_t);
          const _cur = S.clipPlaybackAudioReverse[_t][_ac] | 0;
          const _nv = Math.max(0, Math.min(1, _cur + dir));
          if (_nv !== _cur) {
            S.clipPlaybackAudioReverse[_t][_ac] = _nv;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + _t + "_clip_playback_audio_reverse", String(_nv));
          }
        } else {
          const cur = S.bankParams[S.activeTrack][bank][knobIdx];
          let nv = Math.max(pm.min, Math.min(pm.max, cur + _delta));
          if (nv !== cur) {
            if (S.altMode && pm.dspKey === "clip_resolution") {
              const _t = S.activeTrack;
              const _ac = effectiveClip(_t);
              const _old_tps = S.clipTPS[_t][_ac];
              const _new_tps = TPS_VALUES[nv];
              const _old_ticks = S.clipLength[_t][_ac] * _old_tps;
              const _new_len = Math.ceil(_old_ticks / _new_tps);
              if (_new_len > 256) {
                showActionPopup("NOTES OUT", "OF RANGE");
                forceRedraw();
              } else if (S.heldStep >= 0 || S.recordArmed && !S.recordCountingIn && S.recordArmedTrack === _t) {
              } else {
                S.bankParams[S.activeTrack][bank][knobIdx] = nv;
                S.clipTPS[_t][_ac] = _new_tps;
                S.clipLength[_t][_ac] = _new_len;
                const _maxPage = Math.max(0, Math.ceil(_new_len / 16) - 1);
                if (S.trackCurrentPage[_t] > _maxPage) S.trackCurrentPage[_t] = _maxPage;
                if (typeof host_module_set_param === "function")
                  host_module_set_param("t" + _t + "_clip_resolution_zoom", String(nv));
                S.pendingStepsReread = 2;
                S.pendingStepsRereadTrack = _t;
                S.pendingStepsRereadClip = _ac;
                refreshPerClipBankParams(_t);
                forceRedraw();
              }
            } else {
              S.bankParams[S.activeTrack][bank][knobIdx] = nv;
              applyBankParam(S.activeTrack, bank, knobIdx, nv);
              if (bank === 5 && knobIdx === 0 && nv !== 0)
                S.lastTarpStyle[S.activeTrack] = nv;
            }
          }
        }
      }
    }
  }
}
function _switchViewCleanup() {
  S.heldStepBtn = -1;
  S.heldStep = -1;
  S.heldStepNotes = [];
  S.stepWasEmpty = false;
  S.stepWasHeld = false;
  S.stepBtnPressedTick.fill(-1);
  S.sessionStepHeld = -1;
  S.sessionStepHeldCtx = 0;
  if (!S.sessionView && (S.perfViewLocked || S.perfStack.length > 0)) {
    const _hadLoop = S.perfStack.length > 0;
    S.perfStack = [];
    S.perfStickyLengths = /* @__PURE__ */ new Set();
    S.perfHoldPadHeld = false;
    S.perfViewLocked = false;
    S.loopHeld = false;
    S.loopJogActive = false;
    S.perfModsHeld = 0;
    sendPerfMods();
    if (_hadLoop && typeof host_module_set_param === "function")
      host_module_set_param("looper_stop", "1");
  }
  if (S.sessionView) {
    for (let i = 0; i < 16; i++) setLED3(16 + i, LED_OFF);
    for (let t = 0; t < 8; t++) setLED3(TRACK_PAD_BASE + t, LED_OFF);
  } else {
    for (let row = 0; row < 4; row++)
      for (let t = 0; t < 8; t++) setLED3(92 - row * 8 + t, LED_OFF);
  }
}
function _onCCMsg(d1, d2) {
  if (S._modalSwallowCC >= 0 && d1 === S._modalSwallowCC) {
    if (d2 === 0) S._modalSwallowCC = -1;
    return;
  }
  if (d1 === MoveBack && S.schwungCoRunSlot < 0 && S.moveCoRunTrack < 0) {
    _handleBack(d2);
    return;
  }
  if (S.mergeNoticePending && d1 !== MoveRec && d1 !== MoveBack && d1 !== MoveShift) {
    return;
  }
  if (S.pendingSceneBakePicker && d2 === 127) {
    const _pick = d1 >= 40 && d1 <= 43 || d1 >= 16 && d1 <= 31;
    const _nonBtn = d1 >= 71 && d1 <= 78 || d1 >= 102 && d1 <= 109 || d1 === MoveMainKnob || d1 === MoveMainTouch || d1 === MoveMainButton || d1 === 79 || d1 === MoveShift;
    if (!_pick && !_nonBtn) {
      S.pendingSceneBakePicker = false;
      S._modalSwallowCC = d1;
      forceRedraw();
      return;
    }
  }
  if (S.capturePlaceTrack >= 0 && d2 === 127 && d1 === MoveRec) {
    S.capturePlaceTrack = -1;
    S._modalSwallowCC = d1;
    forceRedraw();
    return;
  }
  _onCC_jog(d1, d2);
  _onCC_buttons(d1, d2);
  _onCC_transport(d1, d2);
  _onCC_side(d1, d2);
  _onCC_stepedit(d1, d2);
  _onCC_knobs(d1, d2);
}

// ui/ui_tick.mjs
import {
  MoveShift as MoveShift2,
  MovePlay as MovePlay2,
  MoveLeft as MoveLeft2,
  MoveRight as MoveRight2,
  MoveUp as MoveUp2,
  MoveDown as MoveDown2,
  MoveMute as MoveMute2,
  MoveDelete as MoveDelete2,
  MoveBack as MoveBack2
} from "/data/UserData/schwung/shared/constants.mjs";
import {
  Red as Red5,
  VividYellow as VividYellow3,
  Green as Green3,
  DarkGrey as DarkGrey3,
  White as White3
} from "/data/UserData/schwung/shared/constants.mjs";
import { setLED as setLED4, setButtonLED as setButtonLED5 } from "/data/UserData/schwung/shared/input_filter.mjs";

// ui/ui_movy.mjs
var MV_HDR_H = 8;
var MV_BAR_Y = 9;
var MV_ROW0_Y = 14;
var MV_LBL0_Y = 30;
var MV_ROW1_Y = 41;
var MV_LBL1_Y = 57;
var MV_CELL_W = 32;
var MV_KW = 20;
var MV_KH = 16;
var MV_LBL_H = 7;
var SCREEN_W = 128;
var HDR_G = [
  [7],
  [7, 12, 12, 12, 12, 0, 12],
  null,
  null,
  null,
  [7, 51, 48, 12, 12, 3, 51],
  null,
  null,
  [4, 6, 3, 3, 3, 3, 6],
  [4, 3, 6, 6, 6, 6, 3],
  null,
  [7, 0, 12, 63, 63, 12, 0],
  [7, 0, 0, 0, 0, 12, 4],
  [7, 0, 0, 30, 30, 0, 0],
  [7, 0, 0, 0, 0, 12, 12],
  [7, 48, 48, 12, 12, 3, 3],
  [7, 30, 51, 59, 55, 51, 30],
  [7, 12, 14, 12, 12, 12, 30],
  [7, 30, 51, 48, 30, 3, 63],
  [7, 30, 48, 28, 48, 51, 30],
  [7, 24, 28, 30, 27, 63, 24],
  [7, 31, 3, 31, 48, 51, 30],
  [7, 30, 3, 31, 51, 51, 30],
  [7, 63, 51, 48, 24, 12, 12],
  [7, 30, 51, 30, 51, 51, 30],
  [7, 30, 51, 51, 62, 48, 30],
  [7, 12, 12, 0, 0, 12, 12],
  null,
  [7, 48, 12, 3, 3, 12, 48],
  null,
  [7, 3, 12, 48, 48, 12, 3],
  [7, 30, 51, 24, 12, 0, 12],
  null,
  [7, 30, 51, 51, 63, 51, 51],
  [7, 31, 51, 31, 51, 51, 31],
  [7, 30, 51, 3, 3, 51, 30],
  [7, 31, 51, 51, 51, 51, 31],
  [7, 63, 3, 31, 3, 3, 63],
  [7, 63, 3, 3, 31, 3, 3],
  [7, 30, 51, 3, 59, 51, 62],
  [7, 51, 51, 63, 51, 51, 51],
  [7, 30, 12, 12, 12, 12, 30],
  [7, 56, 48, 48, 48, 51, 30],
  [7, 51, 27, 15, 15, 27, 51],
  [7, 3, 3, 3, 3, 3, 63],
  [7, 35, 55, 63, 43, 35, 35],
  [7, 35, 39, 47, 59, 51, 35],
  [7, 30, 51, 51, 51, 51, 30],
  [7, 31, 51, 51, 31, 3, 3],
  [7, 30, 51, 51, 59, 19, 46],
  [7, 31, 51, 51, 31, 51, 51],
  [7, 30, 3, 30, 48, 51, 30],
  [7, 63, 12, 12, 12, 12, 12],
  [7, 51, 51, 51, 51, 51, 30],
  [7, 51, 51, 51, 51, 30, 12],
  [7, 35, 35, 43, 63, 55, 35],
  [7, 51, 51, 30, 30, 51, 51],
  [7, 51, 51, 51, 30, 12, 12],
  [7, 63, 56, 28, 14, 7, 63],
  null,
  null,
  null,
  null,
  null,
  null,
  [7, 30, 51, 51, 63, 51, 51],
  [7, 31, 51, 31, 51, 51, 31],
  [7, 30, 51, 3, 3, 51, 30],
  [7, 31, 51, 51, 51, 51, 31],
  [7, 63, 3, 31, 3, 3, 63],
  [7, 63, 3, 3, 31, 3, 3],
  [7, 30, 51, 3, 59, 51, 62],
  [7, 51, 51, 63, 51, 51, 51],
  [7, 30, 12, 12, 12, 12, 30],
  [7, 56, 48, 48, 48, 51, 30],
  [7, 51, 27, 15, 15, 27, 51],
  [7, 3, 3, 3, 3, 3, 63],
  [7, 35, 55, 63, 43, 35, 35],
  [7, 35, 39, 47, 59, 51, 35],
  [7, 30, 51, 51, 51, 51, 30],
  [7, 31, 51, 51, 31, 3, 3],
  [7, 30, 51, 51, 59, 19, 46],
  [7, 31, 51, 51, 31, 51, 51],
  [7, 30, 3, 30, 48, 51, 30],
  [7, 63, 12, 12, 12, 12, 12],
  [7, 51, 51, 51, 51, 51, 30],
  [7, 51, 51, 51, 51, 30, 12],
  [7, 35, 35, 43, 63, 55, 35],
  [7, 51, 51, 30, 30, 51, 51],
  [7, 51, 51, 51, 30, 12, 12],
  [7, 63, 56, 28, 14, 7, 63],
  null,
  null,
  null,
  null
];
function hdrGlyph(cp) {
  return cp < 32 || cp > 126 ? null : HDR_G[cp - 32];
}
function hdrWidth(text) {
  const s = String(text);
  let w = 0;
  for (let i = 0; i < s.length; i++) {
    const g = hdrGlyph(s.charCodeAt(i));
    w += g ? g[0] : 7;
  }
  return Math.max(0, w - 1);
}
function hdrPrint(x, y, text, color) {
  const s = String(text);
  let cx = Math.round(x);
  const oy = Math.round(y), v = color ? 1 : 0;
  for (let i = 0; i < s.length; i++) {
    const g = hdrGlyph(s.charCodeAt(i));
    if (!g) {
      cx += 7;
      continue;
    }
    for (let r = 0; r < 6; r++) {
      const bits = g[1 + r] || 0;
      for (let c = 0; c < 15; c++) if (bits & 1 << c) set_pixel(cx + c, oy + r, v);
    }
    cx += g[0];
  }
}
function fitHdr(text, maxW) {
  let t = String(text).toUpperCase();
  while (t.length > 0 && hdrWidth(t) > maxW) t = t.slice(0, -1);
  return t;
}
var MV_G = [
  [6, 0, 0, 0],
  [3, 0, 3, 5, 2, 2, 2, 0, 2],
  [5, 0, 5, 2, 10, 10],
  [7, 0, 7, 5, 20, 62, 20, 62, 20],
  [7, 0, 7, 5, 60, 10, 28, 40, 30],
  [5, 0, 5, 5, 10, 8, 4, 2, 10],
  [5, 0, 5, 5, 4, 10, 4, 10, 12],
  [3, 0, 3, 2, 2, 2],
  [4, 0, 4, 5, 4, 2, 2, 2, 4],
  [4, 0, 4, 5, 2, 4, 4, 4, 2],
  [5, 1, 5, 3, 10, 4, 10],
  [5, 2, 5, 3, 4, 14, 4],
  [4, 4, 4, 3, 6, 4, 2],
  [5, 3, 5, 1, 14],
  [3, 4, 3, 1, 2],
  [5, 0, 5, 5, 8, 8, 4, 2, 2],
  [6, 0, 6, 5, 30, 18, 18, 18, 30],
  [5, 0, 5, 5, 6, 4, 4, 4, 14],
  [6, 0, 6, 5, 30, 16, 30, 2, 30],
  [6, 0, 6, 5, 30, 16, 28, 16, 30],
  [6, 0, 6, 5, 18, 18, 30, 16, 16],
  [6, 0, 6, 5, 30, 2, 30, 16, 30],
  [6, 0, 6, 5, 30, 2, 30, 18, 30],
  [6, 0, 6, 5, 30, 16, 8, 4, 4],
  [6, 0, 6, 5, 30, 18, 30, 18, 30],
  [6, 0, 6, 5, 30, 18, 30, 16, 30],
  [4, 1, 4, 3, 4, 0, 4],
  [4, 1, 4, 4, 4, 0, 4, 2],
  [5, 0, 5, 5, 8, 4, 2, 4, 8],
  [5, 2, 5, 3, 14, 0, 14],
  [5, 0, 5, 5, 2, 4, 8, 4, 2],
  [5, -1, 5, 6, 6, 8, 4, 4, 0, 4],
  [7, 0, 7, 5, 28, 32, 44, 42, 28],
  [6, 0, 6, 5, 12, 18, 30, 18, 18],
  [6, 0, 6, 5, 14, 18, 14, 18, 14],
  [6, 0, 6, 5, 12, 18, 2, 18, 12],
  [6, 0, 6, 5, 14, 18, 18, 18, 14],
  [6, 0, 6, 5, 30, 2, 14, 2, 30],
  [6, 0, 6, 5, 30, 2, 14, 2, 2],
  [6, 0, 6, 5, 12, 2, 26, 18, 12],
  [6, 0, 6, 5, 18, 18, 30, 18, 18],
  [3, 0, 3, 5, 2, 2, 2, 2, 2],
  [5, 0, 5, 5, 8, 8, 8, 10, 6],
  [5, 0, 5, 5, 10, 10, 6, 10, 10],
  [6, 0, 6, 5, 2, 2, 2, 2, 30],
  [7, 0, 7, 5, 30, 42, 42, 34, 34],
  [6, 0, 6, 5, 12, 18, 18, 18, 18],
  [6, 0, 6, 5, 12, 18, 18, 18, 12],
  [6, 0, 6, 5, 14, 18, 18, 14, 2],
  [6, 0, 6, 5, 12, 18, 18, 26, 28],
  [6, 0, 6, 5, 14, 18, 18, 14, 18],
  [6, 0, 6, 5, 28, 2, 12, 16, 14],
  [5, 0, 5, 5, 14, 4, 4, 4, 4],
  [6, 0, 6, 5, 18, 18, 18, 18, 12],
  [6, 0, 6, 5, 18, 18, 18, 10, 6],
  [7, 0, 7, 5, 34, 34, 42, 42, 30],
  [5, 0, 5, 5, 10, 10, 4, 10, 10],
  [6, 0, 6, 5, 18, 18, 28, 16, 14],
  [6, 0, 6, 5, 30, 16, 12, 2, 30],
  [4, 0, 4, 5, 6, 2, 2, 2, 6],
  [5, 0, 5, 5, 2, 2, 4, 8, 8],
  [4, 0, 4, 5, 6, 4, 4, 4, 6],
  [5, 0, 5, 2, 4, 10],
  [6, 5, 6, 1, 30],
  [4, 0, 4, 2, 2, 4],
  [6, 0, 6, 5, 12, 18, 30, 18, 18],
  [6, 0, 6, 5, 14, 18, 14, 18, 14],
  [6, 0, 6, 5, 12, 18, 2, 18, 12],
  [6, 0, 6, 5, 14, 18, 18, 18, 14],
  [6, 0, 6, 5, 30, 2, 14, 2, 30],
  [6, 0, 6, 5, 30, 2, 14, 2, 2],
  [6, 0, 6, 5, 12, 2, 26, 18, 12],
  [6, 0, 6, 5, 18, 18, 30, 18, 18],
  [3, 0, 3, 5, 2, 2, 2, 2, 2],
  [5, 0, 5, 5, 8, 8, 8, 10, 6],
  [5, 0, 5, 5, 10, 10, 6, 10, 10],
  [6, 0, 6, 5, 2, 2, 2, 2, 30],
  [7, 0, 7, 5, 30, 42, 42, 34, 34],
  [6, 0, 6, 5, 12, 18, 18, 18, 18],
  [6, 0, 6, 5, 12, 18, 18, 18, 12],
  [6, 0, 6, 5, 14, 18, 18, 14, 2],
  [6, 0, 6, 5, 12, 18, 18, 26, 28],
  [6, 0, 6, 5, 14, 18, 18, 14, 18],
  [6, 0, 6, 5, 28, 2, 12, 16, 14],
  [5, 0, 5, 5, 14, 4, 4, 4, 4],
  [6, 0, 6, 5, 18, 18, 18, 18, 12],
  [6, 0, 6, 5, 18, 18, 18, 10, 6],
  [7, 0, 7, 5, 34, 34, 42, 42, 30],
  [5, 0, 5, 5, 10, 10, 4, 10, 10],
  [6, 0, 6, 5, 18, 18, 28, 16, 30],
  [6, 0, 6, 5, 30, 16, 12, 2, 30],
  [5, 0, 5, 5, 12, 4, 2, 4, 12],
  [3, 0, 3, 5, 2, 2, 2, 2, 2],
  [5, 0, 5, 5, 6, 4, 8, 4, 6],
  [6, 0, 6, 2, 20, 10]
];
function mvGlyph(cp) {
  return cp < 32 || cp > 126 ? null : MV_G[cp - 32];
}
function mvWidth(text) {
  const s = String(text);
  let w = 0;
  for (let i = 0; i < s.length; i++) {
    const g = mvGlyph(s.charCodeAt(i));
    w += g ? g[0] : 5;
    if (i < s.length - 1) w -= 1;
  }
  return w;
}
function mvPrint(x, y, text, color) {
  const s = String(text);
  let cx = Math.round(x);
  const oy = Math.round(y), v = color ? 1 : 0;
  for (let i = 0; i < s.length; i++) {
    const g = mvGlyph(s.charCodeAt(i));
    if (!g) {
      cx += 5;
      continue;
    }
    const yOff = g[1], w = g[2], h = g[3];
    for (let r = 0; r < h; r++) {
      const bits = g[4 + r];
      for (let c = 0; c < w; c++) if (bits & 1 << c) set_pixel(cx + c, oy + yOff + r, v);
    }
    cx += g[0];
    if (i < s.length - 1) cx -= 1;
  }
}
var PF3_CHARS = ` !"'()+,-./:0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ%<>=?*`;
var PF3_G = [
  [4, 0, 0, 0],
  [4, 0, 3, 5, 1, 1, 1, 0, 1],
  [4, 0, 3, 5, 5, 5, 0, 0, 0],
  [4, 0, 3, 5, 2, 2, 0, 0, 0],
  [4, 0, 3, 5, 2, 1, 1, 1, 2],
  [4, 0, 3, 5, 1, 2, 2, 2, 1],
  [4, 0, 3, 5, 2, 7, 2, 0, 0],
  [4, 0, 3, 5, 0, 0, 3, 3, 2],
  [4, 0, 3, 5, 0, 0, 7, 0, 0],
  [4, 0, 3, 5, 0, 0, 0, 3, 3],
  [4, 0, 3, 5, 4, 4, 2, 1, 1],
  [4, 0, 3, 5, 3, 3, 0, 3, 3],
  [4, 0, 3, 5, 7, 5, 5, 5, 7],
  [4, 0, 3, 5, 2, 3, 2, 2, 7],
  [4, 0, 3, 5, 7, 4, 7, 1, 7],
  [4, 0, 3, 5, 7, 4, 6, 4, 7],
  [4, 0, 3, 5, 5, 5, 7, 4, 4],
  [4, 0, 3, 5, 7, 1, 7, 4, 7],
  [4, 0, 3, 5, 7, 1, 7, 5, 7],
  [4, 0, 3, 5, 7, 4, 4, 4, 4],
  [4, 0, 3, 5, 7, 5, 7, 5, 7],
  [4, 0, 3, 5, 7, 5, 7, 4, 7],
  [4, 0, 3, 5, 2, 7, 5, 5, 5],
  [4, 0, 3, 5, 7, 5, 3, 5, 7],
  [4, 0, 3, 5, 7, 1, 1, 1, 7],
  [4, 0, 3, 5, 3, 5, 5, 5, 3],
  [4, 0, 3, 5, 7, 1, 3, 1, 7],
  [4, 0, 3, 5, 7, 1, 3, 1, 1],
  [4, 0, 3, 5, 7, 1, 5, 5, 7],
  [4, 0, 3, 5, 5, 5, 7, 5, 5],
  [4, 0, 3, 5, 7, 2, 2, 2, 7],
  [4, 0, 3, 5, 4, 4, 4, 5, 7],
  [4, 0, 3, 5, 5, 5, 3, 5, 5],
  [4, 0, 3, 5, 1, 1, 1, 1, 7],
  [4, 0, 3, 5, 5, 7, 5, 5, 5],
  [4, 0, 3, 5, 5, 3, 5, 5, 5],
  [4, 0, 3, 5, 7, 5, 5, 5, 7],
  [4, 0, 3, 5, 7, 5, 7, 1, 1],
  [4, 0, 3, 5, 3, 5, 5, 7, 2],
  [4, 0, 3, 5, 7, 5, 3, 5, 5],
  [4, 0, 3, 5, 6, 1, 2, 4, 3],
  [4, 0, 3, 5, 7, 2, 2, 2, 2],
  [4, 0, 3, 5, 5, 5, 5, 5, 7],
  [4, 0, 3, 5, 5, 5, 5, 5, 2],
  [4, 0, 3, 5, 5, 5, 5, 7, 7],
  [4, 0, 3, 5, 5, 5, 2, 5, 5],
  [4, 0, 3, 5, 5, 5, 7, 2, 2],
  [4, 0, 3, 5, 7, 4, 2, 1, 7],
  [4, 0, 3, 5, 5, 4, 2, 1, 5],
  [4, 0, 3, 5, 4, 2, 1, 2, 4],
  [4, 0, 3, 5, 1, 2, 4, 2, 1],
  [4, 0, 3, 5, 7, 0, 7, 0, 0],
  [4, 0, 3, 5, 7, 4, 6, 0, 2],
  [4, 0, 3, 5, 2, 7, 2, 5, 0]
];
function pf3Glyph(ch) {
  const i = PF3_CHARS.indexOf(ch);
  return i >= 0 ? PF3_G[i] : null;
}
function pf3Width(text) {
  const s = String(text).toUpperCase();
  let w = 0;
  for (let i = 0; i < s.length; i++) {
    const g = pf3Glyph(s[i]);
    w += g ? g[0] : 4;
  }
  return w;
}
function pf3Print(x, y, text, color) {
  const s = String(text).toUpperCase();
  let cx = Math.round(x);
  const oy = Math.round(y), v = color ? 1 : 0;
  for (let i = 0; i < s.length; i++) {
    const g = pf3Glyph(s[i]);
    if (!g) {
      cx += 4;
      continue;
    }
    const yOff = g[1], w = g[2], h = g[3];
    for (let r = 0; r < h; r++) {
      const bits = g[4 + r];
      for (let c = 0; c < w; c++) if (bits & 1 << c) set_pixel(cx + c, oy + yOff + r, v);
    }
    cx += g[0];
  }
}
function plotLine(x1, y1, x2, y2, fg) {
  const dx = x2 - x1, dy = y2 - y1;
  const steps = Math.max(1, Math.round(Math.max(Math.abs(dx), Math.abs(dy))));
  for (let s = 0; s <= steps; s++) {
    const t = s / steps;
    set_pixel(Math.round(x1 + dx * t), Math.round(y1 + dy * t), fg);
  }
}
function rectOutline(x, y, w, h, fg) {
  fill_rect(x, y, w, 1, fg);
  fill_rect(x, y + h - 1, w, 1, fg);
  fill_rect(x, y, 1, h, fg);
  fill_rect(x + w - 1, y, 1, h, fg);
}
function drawCircleBorder(cx, cy, r) {
  let x = r, y = 0, err = 0;
  while (x >= y) {
    if (y === 0) {
      set_pixel(cx + x - 1, cy, 1);
      set_pixel(cx - x + 1, cy, 1);
      set_pixel(cx, cy + x - 1, 1);
      set_pixel(cx, cy - x + 1, 1);
    } else {
      set_pixel(cx + x, cy + y, 1);
      set_pixel(cx + y, cy + x, 1);
      set_pixel(cx - y, cy + x, 1);
      set_pixel(cx - x, cy + y, 1);
      set_pixel(cx - x, cy - y, 1);
      set_pixel(cx - y, cy - x, 1);
      set_pixel(cx + y, cy - x, 1);
      set_pixel(cx + x, cy - y, 1);
    }
    y++;
    if (err <= 0) err += 2 * y + 1;
    if (err > 0) {
      x--;
      err -= 2 * x + 1;
    }
  }
}
function drawArcKnob(kx, ky, norm, bipolar) {
  const cx = kx + 10, cy = ky + 7, r = 7;
  drawCircleBorder(cx, cy, r);
  if (bipolar) fill_rect(cx, cy - r + 1, 1, 2, 1);
  const rad = (210 + norm * 300) * Math.PI / 180;
  const ex = Math.round(cx + (r - 1) * Math.sin(rad));
  const ey = Math.round(cy - (r - 1) * Math.cos(rad));
  plotLine(cx, cy, ex, ey, 1);
}
function drawHBar(kx, ky, norm) {
  fill_rect(kx + 1, ky + 4, 18, 1, 1);
  fill_rect(kx + 1, ky + 10, 18, 1, 1);
  fill_rect(kx + 1, ky + 4, 1, 7, 1);
  fill_rect(kx + 18, ky + 4, 1, 7, 1);
  const fillW = Math.round(norm * 16);
  if (fillW > 0) fill_rect(kx + 2, ky + 5, fillW, 5, 1);
}
function sqLines(text) {
  const t = String(text).toUpperCase();
  if (pf3Width(t) <= MV_KW - 2) return [t, ""];
  const m = t.match(/^(\d+\/\d+)(.+)$/);
  if (m && pf3Width(m[1]) <= MV_KW - 2 && pf3Width(m[2]) <= MV_KW - 2) return [m[1], m[2]];
  const parts = t.replace(/[_\-]/g, " ").trim().split(/\s+/);
  if (parts.length >= 2) return [parts[0].substring(0, 4), parts[1].substring(0, 4)];
  return [t.substring(0, 4), t.substring(4, 8)];
}
function drawEnumSquare(kx, ky, text, sq) {
  rectOutline(kx, ky, MV_KW, MV_KH, 1);
  const lines = sq != null ? [String(sq), ""] : sqLines(text);
  const inner = MV_KW - 2;
  const totalH = lines[1].length > 0 ? 11 : 5;
  const startY = ky + 1 + Math.floor((MV_KH - 2 - totalH) / 2);
  pf3Print(kx + 1 + Math.floor((inner - pf3Width(lines[0])) / 2), startY, lines[0], 1);
  if (lines[1].length > 0)
    pf3Print(kx + 1 + Math.floor((inner - pf3Width(lines[1])) / 2), startY + 6, lines[1], 1);
}
function drawValSquare(kx, ky, text) {
  rectOutline(kx, ky, MV_KW, MV_KH, 1);
  const w = pf3Width(text);
  pf3Print(kx + 1 + Math.floor((MV_KW - 2 - w) / 2), ky + 1 + Math.floor((MV_KH - 2 - 5) / 2), text, 1);
}
function drawActionSquare(kx, ky, text, oneWay, touched) {
  rectOutline(kx, ky, MV_KW, MV_KH, 1);
  const t = touched && !oneWay ? String(text) : "< >";
  const w = pf3Width(t);
  pf3Print(kx + 1 + Math.floor((MV_KW - 2 - w) / 2), ky + 1 + Math.floor((MV_KH - 2 - 5) / 2), t, 1);
}
function drawDirSquare(kx, ky, mode) {
  rectOutline(kx, ky, MV_KW, MV_KH, 1);
  const cy = ky + Math.floor(MV_KH / 2);
  const tri = (x, dir) => {
    for (let c = 0; c < 4; c++) {
      const h = dir > 0 ? 7 - 2 * c : 1 + 2 * c;
      fill_rect(x + c, cy - (h >> 1), 1, h, 1);
    }
  };
  const mid = kx + Math.floor(MV_KW / 2);
  if (mode === 0) tri(mid - 2, 1);
  else if (mode === 1) tri(mid - 2, -1);
  else if (mode === 2) {
    tri(mid - 7, -1);
    tri(mid + 3, 1);
  } else {
    tri(mid - 7, 1);
    tri(mid + 3, -1);
  }
}
function drawKitHeader(text, invert) {
  const t = fitHdr(text, SCREEN_W - 4);
  if (invert) {
    hdrPrint(2, 1, t, 1);
  } else {
    fill_rect(0, 0, SCREEN_W, MV_HDR_H, 1);
    hdrPrint(2, 1, t, 0);
  }
}
function drawKitTouchedHeader(name) {
  const t = fitHdr(name, SCREEN_W - 4);
  hdrPrint(Math.max(2, Math.round((SCREEN_W - hdrWidth(t)) / 2)), 1, t, 1);
  fill_rect(0, MV_BAR_Y, SCREEN_W, 1, 1);
}
function drawKitPageBar(idx, count) {
  if (count <= 1) {
    fill_rect(0, MV_BAR_Y, SCREEN_W, 1, 1);
    return;
  }
  const blinkOn = Math.floor(Date.now() / 375) % 2 === 0;
  const usable = SCREEN_W - (count - 1);
  const base = Math.floor(usable / count), rem = usable % count;
  for (let b = 0, sx = 0; b < count; b++) {
    const sw = base + (b < rem ? 1 : 0);
    if (b !== idx || blinkOn) {
      fill_rect(sx, MV_BAR_Y, sw, 1, 1);
    } else {
      for (let x = sx; x < sx + sw; x += 2) set_pixel(x, MV_BAR_Y, 1);
    }
    sx += sw + 1;
  }
}
function drawCellWidget(col, rowY, cell, touched) {
  const kx = col * MV_CELL_W + Math.floor((MV_CELL_W - MV_KW) / 2);
  switch (cell.kind) {
    case "arc":
      return drawArcKnob(kx, rowY, cell.norm || 0, false);
    case "arcbip":
      return drawArcKnob(kx, rowY, 0.5 + (cell.signed || 0) / 2, true);
    case "hbar":
      return drawHBar(kx, rowY, cell.norm || 0);
    case "enumsq":
      return drawEnumSquare(kx, rowY, cell.text, cell.sq);
    case "valsq":
      return drawValSquare(kx, rowY, cell.sq != null ? cell.sq : cell.text);
    case "action":
      return drawActionSquare(kx, rowY, cell.text, cell.oneWay, touched);
    case "dirsq":
      return drawDirSquare(kx, rowY, cell.sel | 0);
    default:
      return;
  }
}
function drawCellLabel(col, lblY, cell, touched) {
  let text = String(touched && cell.text != null ? cell.text : cell.label || "");
  if (!text) return;
  while (text.length > 0 && mvWidth(text) > MV_CELL_W - 2) text = text.slice(0, -1);
  const tw = mvWidth(text);
  const tx = Math.round(col * MV_CELL_W + MV_CELL_W / 2 - tw / 2);
  if (touched) {
    fill_rect(col * MV_CELL_W, lblY, MV_CELL_W, MV_LBL_H, 1);
    mvPrint(tx, lblY + 1, text, 0);
  } else {
    mvPrint(tx, lblY + 1, text, 1);
  }
}
function drawKitCells(cells, touchedIdx) {
  for (let k = 0; k < 8; k++) {
    const cell = cells[k];
    if (!cell) continue;
    const col = k % 4;
    const rowY = k < 4 ? MV_ROW0_Y : MV_ROW1_Y;
    const lblY = k < 4 ? MV_LBL0_Y : MV_LBL1_Y;
    drawCellWidget(col, rowY, cell, k === touchedIdx);
    drawCellLabel(col, lblY, cell, k === touchedIdx);
  }
}
function drawKitEnumOverlay(cells, touchedIdx) {
  const cell = touchedIdx >= 0 ? cells[touchedIdx] : null;
  if (!cell || cell.kind !== "enumsq" && cell.kind !== "dirsq" || !cell.options || cell.options.length <= 2) return;
  const sel = cell.sel | 0;
  if (sel < 0) return;
  const ovX = touchedIdx % 4 < 2 ? SCREEN_W - 3 * MV_CELL_W : 0;
  const ovW = 3 * MV_CELL_W, ovY = MV_ROW0_Y, ovH = MV_LBL1_Y + MV_LBL_H - MV_ROW0_Y;
  fill_rect(ovX, ovY, ovW, ovH, 0);
  rectOutline(ovX, ovY, ovW, ovH, 1);
  const ROW_H = 8, n = cell.options.length;
  const VISIBLE = Math.min(n, Math.floor((ovH - 2) / ROW_H));
  const half = Math.floor(VISIBLE / 2);
  const start = Math.max(0, Math.min(sel - half, n - VISIBLE));
  const listTop = ovY + Math.floor((ovH - VISIBLE * ROW_H) / 2);
  for (let i = 0; i < VISIBLE; i++) {
    const idx = start + i;
    if (idx >= n) break;
    const y = listTop + i * ROW_H;
    if (idx === sel) {
      fill_rect(ovX + 2, y, ovW - 4, ROW_H, 1);
      mvPrint(ovX + 4, y + 1, cell.options[idx], 0);
    } else {
      mvPrint(ovX + 4, y + 1, cell.options[idx], 1);
    }
  }
  if (n > VISIBLE) {
    const trackH = VISIBLE * ROW_H;
    const thumbH = Math.max(3, Math.round(trackH * VISIBLE / n));
    const thumbY = listTop + Math.round((trackH - thumbH) * start / Math.max(1, n - VISIBLE));
    fill_rect(ovX + ovW - 2, listTop, 1, trackH, 1);
    fill_rect(ovX + ovW - 3, thumbY, 2, thumbH, 1);
  }
}
function drawKitAltArrow(x, onFill, on, blinkHidden) {
  if (on && blinkHidden) return;
  const fg = onFill ? 0 : 1;
  fill_rect(x, 2, 5, 1, fg);
  fill_rect(x + 1, 3, 3, 1, fg);
  fill_rect(x + 2, 4, 1, 1, fg);
}

// ui/ui_splash.mjs
var HEX_FRAMES = [
  /* Original dAVEBOx splash (Untitled - May 20, 2026 at 14.49.53.bmp). */
  "00ffffffffffffffffffffffffffffc001ffffffffffffffffffffffffffffe003ffe7ffffffffffffffffffffffffe007ffc3ffffffffe01ffffffffffffff00fff80ffffffffe01ffffffffffffff81fff003fffffffe01ffffffffffffffc3ffe000ffff3ffe03ffffffffffffffe7ffc0007ffe3ffe03ffffffffffffffffff80001ffc7fffffffffffffffffffffff00000ff8ffffffffffffffffffffffff00000ff8fffe07ffffffffffffffffffe0003e7efffe003ffffffffffffffffffc007c387fffc01ffff0ffffffffffffff80f8183ffe000fffc07ffffffffffffff1f0003ffe000fff003fffffffffffffffe00c1fff8007ff801fffffffffffffffe01c0fff8007f1c01ffffffffffffffffc3003ffa00fc0e1ffffffffffffffffffe0007f071e607ffffffffffefffffffff1000001be10ffffffffffffffffffffff0000007f1ffffffffffffffffffffffff000003ffffffffffffffffffffffffffc00003ff39dec31f8fffffffffffffffe00441ff319c830707fffffffffffffff870f0f830cd9f36726ffffffffffffff8c0087234c98306730efffffffffffffcd08c7320498722731ffffffffffffffc81b27320639f32731ffffffffffffffc8012702e638307064ffffffffffffffc80067dffffff7fdffffffffffffffff8c5843ffffffffffffffffffffffe7ff8c1943f87ffffffffffffffffffc47ff890183f863fffffffffffffffff047ff8c0183f860fffffffffffffffe304fff8cf1c3fe60e1fffffffffffff0307fff8c02c3ffe0e01fffffffffffc031ffff8fbac1fff8e00fffffffffffc037ffffdf1ec1ffffe00fffffffffc7c03fffffddfcc1ffffe00ffffffffc07c07ffffffdee41fffff80fffffffe007c1ffffffff2e61ffffff0ffffffe0007c7ffffffcf3e61ffffffcffffff00007ffffffffc07a63fffffffffffff00007ffffffdfc000677ffffffffffff00007ffffff8fe000603ffffffffffff0000fffffff07e000401ffffffffffff0003fffffff8fe000603ffffffffffff000ffffffffcff0007f77fffffffffff003fffffffc7ff000ffe3fffffffffff01ffffffff83ff800ffc1fffffffffff07ffffffff03ff800ffc0fffffffffff1fffffffff07ff800ffe0fffffffffffffffffffff87ff800fff1fffffffffffffffffffffcfff800fff3ffffffffffffffffffff9ffff800ffff8fffffffffffffffffff0ffffc01ffff07ffffffffffffffffff03fffc01fffe03fffffffffffffffffe03fffc01fffe01fffffffffffffffffc07fffc01ffff00fffffffffffffffff807fffe01ffff807ffffffffffffffff80ffffe03ffffc03ffffffffffffffff80ffffe03ffffc07ffffffffffffffffc1ffffe03ffffe1ffffffffffffffffff1ffffe03fffff3fffffffff",
  /* dbBruce.bmp */
  "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003f0000000000000001ff41fe000000000000000000000000000007ff00000000000000003000000000000fffc000000000000001f8000000000001eff001c30000000007fc000000000001fff00de3800000000ffe000000000001e3f00ff3810000001ffe000000000001f1f00ff38fc000001fff000000000001f1f8ff7f9fc100001fffc00000000001e0f8ff7f9fe000003fffffa000000000e0f9ff3fbe6c00003ffffe3000000000e0fbc73f3ee000001ffffc7800000000e0fb871f3fc000000ffff0f800000000e0f3838f3fe0000007ffe0dc00000000e0f3c3833fc000000780e00c04000000f1f33f801e0000200700f03e00000000e1e1ff801f00000007c0fcfe0000000043c038000fe000000781ffff000000007fc018000ff000000603ffff000000007fc0000007f00000061fffff800000007f00000001f8000007fff3ffc0000000fe0000000000000007ff81ffc0000000f0043ffc0000000007ff01ffe00000000003ffff8000000007ff07ffe0000000000fffffe000000007ffffffe0000000003fe07ff800000007ffffffe0000000007e0001fc0000003fffe00f8000000000f800007c0000003fff803f80000000006000001e0000007ffc07ff8000000000000000000000003ffc7cff8000000000000000000000003ffdf0ff8000000000780000000000001ffff0ff000000000fff0000000000001fffffff000000001fff00000000000000fffffc000000001e07200183800000007ffff980000000060e0181cf800000002fff8180800000061c0781de000000000ff003c1e00000077c0f80fc00000000000003fff0000007fc1f807800000000180007fff8000007f81fe07800000000180007fe380000037839f07c000000000e000ffc0c0000033c3870fe000000000f8c1ffc1f8000039e3030fe000000000ffd3ff81fe000038f3031e7000040407ffffffffff8000387b9f1c780000000ffffc7fffffe0003819ff1838000000043ff87ffffff000381cfc0800000000003ffbbffffff000181c0000000000000f3fffcffffff000181c00000000000007ffffe3fffff0001ff800000800000007efffe0fffff0001ff80000000000001bff7ff07ffff0001fe00000000000003ffffffcfffff0000000010800000000fffffffffffff0000000000000000001f7fffffffffff000001000000000000373dfff0ffffff000000000400000000673dfff07f87ff000000000000000000ce7fffe07f87ff000000008000000001cf7fffe0ff87ff",
  /* dlrDB.bmp */
  "ffffffe3ffef8000007fffffffff8000fffffffffffff8000007ffffffffc000ffdffffffffffc000003fffffffffc00ff9e39e4181e0e01e061fffffffffc00ff9e39ccf88c47fff031fffffffffc00fe9e1cccf9c8f3373313fffffffff600f81c9ccc181993061bfffffffffffe80f99c8c9c1819f38c1bffffffffffffc0f9980e1cf9c9f38c1dffffffffffffc0f9980e1cf9cc67861cffffffffffffe0fc11e63c081e07221fffffffffffffa0fefbff7e1c7fbf7f9ffbfffffffffff0ffffffffffffffff9efffffffffffff9fffff87fffffffff9f7ffffffffffff9fffff07fffffffff0ffffffffffffffffffff0efdfffffff8ffffffffffffffefffff6cfcfffffff8ffbfffffffffffffffff61ec13fffff9efffffffffffff9fffffe7c877fff839ffafffffffffff9fffffcf80ffffff99be87ffffffffffbffffffb81ffffffc0fe83ffffffffffbffffff781c1fffff0be63ffffffffffbfffffef01787ff1f89e21ffffffffffbfffffdd020c3f07b89e0dffffffffffbffffffa02021e1fdc1e0ffffffffffbfffffff30647fff81c1007fffffffffbffffffe70f7ffff89c1007ffffffffffffffffa71fffffffbe5a07ffffffffffffffff8f1ffffffffe5e03ffffffffffffffff9f1fffffffff7f83ffffffffffffffff9e0fffffffff7fc1ffffffffffeffff7de5fffffffff7fe0fffffffffffffff7ffffffffffff7ff0ffffffffffffffe3ffffffffffff3ffcffffffffffffffe7ffffffffffff3ffcffffffffffffffe7fdbfffffffff3ffeffffffffffffffe3ffbfff3fffff1efffffffffffffffff3ffbfff1cffff0e3fffffffffffffffffff3fffc1ffff0f3fffffffffffffffffff9fffe3fffe079dffffffffffffffffff9ffffffffe07dcffffffffffffffffff9ffffffffe03feffffffffffffffffffc7fffffffc017ffffffffffffffffbffc7fffffffc010ffffffffffffffff3fec3fffffff0008fffffffffffffffe7fee3fe00ffe000c7ffffffffffffffe7fee1fc007fe00047fffffffffffffffffff1f8001fe0006bfffffffffecfffcebfe1f8001fc00031fffffffff98fffdfff60f8001fc00039ffffffff838fffffffa0fc001f80001feffffffc0fdfffffffc0fe001f80000fffffffe0ffdfffffffc07e103f800007fffffe03ffcffff7ff707f7f3f000003fffffe3fffcfffe7e7381fffff000001ffffffffffcfffefe3181ffffe000000fffffffffeffffdec318dffffe000000fffffffffefffffec31c1ffffe000001fffffffffefffffcc31e1dfffe000000bfffff3ffffffffc03df0cff9c0000003fffff03f87fffdc03e38e7f3c0000001fffff40007ffcd81067ce3e380000001fffff80007ff8681c0fc700780000000fffff88007fb8200e0fc781f00000002fffff84007",
  /* bowiedb-dithered.png */
  "0000000000000200000000000000000124924924924928aa492444422222222000000000000000000000001000000005108884492488a80a80842200891111104200200000020000242100440000000100440222224891000000100040888880241110808004000092108222080200250080001012228000008400000240440000402020100809008922000000049048480902024402200020000488124000010240109001108000021120024002122120090002200a0000a0800040022080080900491089000820101224111008048100480040000a000141000100010040044802480924808200004488088844112102400240000410028800008000010000201240092400480001244424442012120900124001112a228000000000888081404900092000bd000092220220000408040049200a04de8104008090090440412090000480037da02044140100201101040492402241df9200000c882082001040400012080bffc80127ff77be7c48851209248081015b500003ffffffff02004909124400882200400fb1323091ff1100204001242d5624025c35b4e6bd6e0424040924008aaf510019258631399c410121200092177aea0119a0cce6bd9c0848080492004bdf5e881c2cce20830e21024120004916f674011eefeebdefff01400809240003bb3a004fffffffffff101241000129516ea824035aab55355585000849240006f42901000000000000004921000092037d200048844890800042000424920082b6b408002000041248114a4080004823d5400249024900400200001212a40500a0120000100049042089490040012041ea201248822400110001009209240801508400020801224012404800800122c2ea2055204120000440124002000955c9af915502408000022510124094800b216880ab48102491208005001400525d41d2097581041004080880550149002ead68412ed441b12080802100480025f5caf40412aaad500012120822009202bb4f5a9000155b6049000041089200954d9bed00000aada00044880440004800069d76a885bafde09200222112490557972fdf4152bd4ea0002200000000404ad53b7ac8d75af5a1110844924aa416abbb3fffe5caef5ec00000000110015556d52edfd5775fab409244922042292ad7ba3ff6eaab7cfdc8001000090880b6ab6d377fed57572ec1248244814012ab6fb45fffeaabaeeb4000000010150056d6ea3bdb6d55d73d8111244902040115b76a7ef7eaadd2ab4492202210414836dbd85fff6555d5d69000888005100217af56fbbdca5a7b5b024802124044908af5a87fffc49155d28001200011020425aedabfef902456ab012004910150a10376a8f77f951048490808800424040848ad5c7ffb104102ac00822480812102025aaabfdf84a8d52c9040002208",
  /* dbcoulier.png */
  "00000000fe000000000000000000000000000001f00496c8000000000041000000000003d080206a000900240210400000000002c0210f0900200081208440000000000680004826490000100401100000000000b20200860002440410482000000000086000001390881020820280000000000109100001840100800090100000000018100301014842011044412000000000040039882121fffffe3c4888200000003c0086e68820ffffffff02200000000030002672c88bdffedde7ff0000000000c000335a6447d99a1083fe4000000003000099dd331618d2f6b84c410800000448000ca5988e9ad610bd1d100000000480006680ccccd046f6999c8000000002000072427506176610c35c804000000200009b013047fffffffffe040000000007dad8608213ffffffffff200800000400126d62c9800000000001004000000202cdb78d80290224820008410000000803249e85c608588424b24a00000000000192dbf760c20111080820080400000001da65bee830a44042432400400000000064db6de1495181048490080800000000149bcd704842104044942020000008001364f016120804321244008000000001894f3d8092a48108912002000000048064b3cc2220926cc04499100400000c0246b4d2608c497b944244002000000b00909d97842324cffc2924220000002601324b2000009097ee8490008400001c024966cd489202532f92484410000018424912714000c249b5e248004000002301b219988204082cdbf9221000000001842485b7884025964af920421200000c04cc246f0011911367fc9808800000081933035b9104146d99f682202000000436649052804046acb678608204000004009900040809099247fb08084000000130489000208404444bb820800200000002369004080101853eea0812400000210896609082200031b7680240100000030105244020880246ed112009040000064405924208000a48ff3009204000001c0020c9888210003bf86240041200009041012980108414877ff012410000006030009204402004c9f7f100104800014d800053010402601bdff8490402002490c0400d2811100346fff800412004822644002528804400a6fec9921008201271260213392c9100a1b7f8498922090e0007d08f31432407fdbf3e4864900069202708050130c807fffbe326164c121930a0820309a4988fffde9931916200c0ca0050010859240fffd694c8c9122103b74fc0408332989fffe94b23262508969a066600040d849ffff29198d1240224e84ef1204104647fffffa4c6191210032009b3ec1083333fffffce31a4c90001001358e0060910cdfffffb2c64242000007ad980026334e7fffcffc319240c0480dae242006c2663ffdffff24b134000010800c2442ec3b8defffff4c8c0",
  /* dbdavethomas.png */
  "55bf2556c0000001ffffffffffc00000a92d54aa00000001ffffffffffe000005aac929506fd8001fffffffffff10400955ea554364b7001ffffffffffffff00a4a754a8a0003e07e739c820607ffe006db2aa490df6039fe6198860603ffc34525d92ca6913c15f061999e64f267800b649524995b27c3e0e9c98604fb0f80095aaaa64680d271ce4cc18624f98f000b25d132587d918dce40c39e76738f0006d4964963a2be23e0086382060307824d93693290000028ffffffffffffffc00ad926a24000000dffffffffffffffe40a5a54ca000120023ffffffff9fffff00f4b4a4900880c800e0dbffb7000000009b16b2004000241c4034bf2580000000ab64968000120101001edeec90000010f4db5002c0024880800bfe5580000000d692b60070000400080577920000000076db24153c888000000ef6da400000007959ac034c002244800dbcd200000024fea56804ee210020000bd5b2100000006f7614096f840800020dea980200000075b4801335c00100100db546000000807dac0005bb729048800fa6a2400000106ed804094ff484000006d490000000006b700096db6ec890000ddb5204000000f6d80004ff7d4000000792480010004076d802052ddb09180087b600000004006fb80026d6d40008800e6a9000000000fb6c010164ba426404075542000000005bec400801342468000eda00000000086f560420007d36e8001b69200400048077fb0005243fd1da001b6d84000020007adf800267dcffe4107b2ca4800000007fb78081b5deeee900f6e6a0001000086dfac00b2adedf7200ddf652100000807edfc00bdfddbbac03ed33480000400037efe005f76edfd48ff7b6a9000000001efdb00afebf7eea0f7bd952210000401ebff0855faedb690fbcdb24000810081fdbf803b7f69fb41def6db6000100003bfefc017b6e1ba607edac92804080007f6ffe095f8036d901fbdb508010000037ffbfe4adc15ed900dedb6c100200003ffbfff2dbf4edac0036d926800001107dbff7f85b7adb68001bdb41000000003ffefffe4fb692ec0006db792100000093dfdf7f69db456480036a1400042000edfbfbfe36c809302000fdca800000006fffffff1690b69400004da950000000d9bedfefa6dfedc85000364812000000ff6ffffd92b616c028901b4680000088fff7ff80025bff006800024000400000db2ef600026b6c204c90031600008800df3cfe00015fed246802018090000000fd99f800025b7402480010c202000000ed0bd00020152880d920006480000000dcbfe000008b4010d208823000200000f8b900000040a4893200101400010040e536004448291213d824008122000000c90c020000042020c900040100000004d2c8100088928924d90840248000020084540001121144971004090050000000",
  /* dbdavid-dithered.png */
  "495557400000b55555554424aa49444422556a8b04440aa0ab6ab28915549292089554744812500455dfdd624122492902280028122800005576eed95c955484508848d10005240055bb75b6a549225254a0111444900200aa82a555555554a493a0808012021011525455555556aa525542a2528400008055490a552aaaaa94ab490000414002001ab4211256d5555556848291240080008b6d00a4aaaa7554abd20044105420220db5045225252aab4a0089004001480012bd515aaa909529542400210a9550080aa5294aaaaa48844d80a404055555002a92aaaab5aaa52a5a9401102aaaaa00156cad5296d55480554024080aab05005552b5295555255a50000268b5a01080ab555552549114928122a2a6de950440b5fbadadaaaa4a48408802bb75d041254afffffffdfd5202921134d5df571000abdffffffffeaaa840121356b5ed85620bcc67010607ff5200454d5beeb49010d7dc664f2667fea9012c25a6bbdd4148ae0d324b24f24d4a04240eab6d5608a2bc9932c104f31d2a1354457db6db46909cd838cf32f73aaa0aaa53abdb6aa9644c8399c506061d5255296d56b6adb7a06e1799d12f1ccea90a42dbbb6d6daee857fefffff9ffff292284a56fb6b6b5b0484aa4090a4252aa02012bfadbdaa55921252924d55aaaaa049005576d5556ea4894a8925555492a642257fdb6db552d5452550955552aa921500aab5b6d6812aaa928a52552a4145552adddedb5a8095554a428912952a24d4956b6b6d6b5656aab5544089449151aa2eb6b5b5aad055555b522a522aa48a80b5added6a95155556d5aa94892002502575ab5ab5dc5152abf7febdab5002a517d5555556a28a29555d574afdaaa89692baaaadbae9214456dbd5d756da82d10fd54aaad7689492a22d726dbb6eb444b2faa55555b4525454aadd3556aa8a120d5694a5557eab4a94257e95eba5654147fb6a9555aa492aa912abea5aab52150aad5554aab5549150495db54aa908abadf7bed29094a2442a143edaa544a55056baeb4a4a4aad554043ebee9492102515df7db551215555b2bdbd7baa548a551bbdfdd550495559576d35fbb552aa48ad6eab6845222aaaadaadeaef48a551237f7fdb6925495556aad65fbdaa94a40aabaab6d09125555d616db56fd2aa92a5dd77ddaa4a9492b554dfdff5eaa14546b7dd77742452aa4a8375655f749422abdab6add512a9254a51bebbf5da4a99556fdbdaaaa49492850ea7d6af6d20044fb56d6eaa0022aa91555afadada94429556dbbb54a209550c356b57576d49152bbb76d5aa50800442abbddaaab5a5428ebb6dab49254aa9452bb76b2aaaa90155d6dadd65b4a9509224b9aaaad552542eb76f6b5a4a25524a9aaeaaa52aa9010bdadabd55a555405254aab2aaa954a4556d775556b554892ab555daaaa4aa4",
  /* dbgnome.png */
  "80003ffffffffffffffff81007d8000180003ffffffffffffffff853243badb28000fdffffffffffeffff93305e800088001fdccc84183fff00f3c2395f852498001fd8ecbcd99fff9907e3301b112448003c18658413da7c6213fb849b089328003cdb618413d8f64fe8f2819ca64888003cd031bccb98f1b5f3e43a36204898001c1733841832791db879605c492448001ffffffffefffc67bb193ed8488128201ffffffffffffe6eec180631244228000ffffffffffffe5bb09c81d92508980003ffffffffffffc6fe1c0930909308000000005bff780273485840c24a246840000000ca65ec299838181202490908000000002ef6fc89c41c0100249122580000000013336d37c84e040849649128000000100a6b7a28020a4082240092482000010005d99229618e48309098489800000000015cfd0da5ce01044241048800000001014fed26d1cc8101290662482000000000b36f26711c224824fce8480000000000323b139c31080491efac090000002000249f00eee2002043b1ec88000000001419ed8c69084489077f7428220000020f8b7e833fd810103e6f7c08000000001f86939096c18304ba6bc898020000007fc7df844dc008606c6cf0880000000020eadcc067242009796fa06904000000bfccd7491001048018cb640804000003fa3667600d924424d2edd19800000be7da9db98622001108800da04848000fdef61feaf0842480420c800849008007bbb5ab72d0140024324252422800800f69e83f6c8f4049048d2244129810000ff2fbdd93fdffd0536da9252498010016a2d7c0f13dbdffdb7ad921244a49000db8fde7fb5fef7f7edb52d8930810400fd86f6ff78273d6e79b664e486801001a5d5b5fffc8841dbb5f79b3699920000fd6b7dfefe6b9247ed36df36ed808a0347eb07fdfe64ec915dcfdbcb778822f37a34fff3ff362da4db3b79bf768101ffa7cfffcfff99a66c38efffbddd8411b7bddff83ffda6d29b73cff7ffdf8007b5f65ff8bffeb259a27f9dbef6ff8843495bbff0ffff999b3a3e7defdfb88011dd7bbfe45fffc664cdb601edfde08204e5b6ffdfdfffe993363bf9deff04a010fb49ffb33ffff13249da039ff23080449f07ff7c7ffff46cc95e7f8fca00800473fffefffffffa4936777f9f644280213b27fbfffffffb1224ed9f2dc70382080fbfe7fffffff993c9b3ef2f991f842097f03ffffffff8cfe2cce71f001d8881f7fffffffffffb27f67f374760498802fffffffffffffa65b777ef06100e91203fffffffffffead6c9ccff269032800bfffffffffffff99bdeebffa22440a001efffcffffffff263561bfb8a4900840067ffdffffffff32ddedfbf911220c00416ffb7fffffff9a8c9effc651206820186ffb3fffffffccb777be12c4010800233ff4bfffffffb34d75f8d821109",
  /* dbletterman.png */
  "0000038067037ffac0212442000480008000018063007ffff0e003333330c000204000000002effb10f04000924d2444000000000000cffff860300000006608000000100000defe9900d080024b0092600080000001fffff8003800000780008180800300013fff6901b2c493430020c00000001001fffffc0030000000000001008c121001b7fedc90828493841a1000000f0000017ffffc70001f8000332020006e004001aef74cfc490893202130c3c0100000013ffffcf800c600010000592b6d640081a7ff6e0128116db4b32067b13999ff3f3ffcf33333e600000000525b56d61349ce4d1b595822db6da692cfccf999fefee7cffec9b3cc000c000040490ca64925b87cd66d3449b7a6dbb40000000001998fefff80c98c000c0000042100211000f6f6f210000091009249c000330c010ccfff3c01800000000000092500224922ed9f94905524924911000000300c000c6ff0fc098000000000184db3094b6da5327b99926dad6da95521800060180018cf9f38030000000000c0020002429200138ef3212d956932482400260000000807f9f80000000000000005214008000004ef631525b24920008003000c333000133ff1800c00930000004c0a6412400806edd84da359116a410008000c330000079ff800000004000000581a048960080729380d0000045b260000060626000007f07800000000000000c00c0318000003f0f800000003000200e0020086d00003f8380000000f20224cc40c0118000003f3780000000700300020040126800003e07000000000001054e01e018c000001f8f8000000000030008438039e000001fcf00000100700c23ac018038c000001fc700000180701f03800000004000001fc700000100200c0b000000000000001f8380000000000000000000034000000f8300000000000000000000000000000f2b00000000000000000000000000000f0100000000000000000000000000000fd300000000000000012492730000000f010000002491000000000033800002070100000000000c00024203b980024207250000002492412400000198c00fffffffffc00000000000000001d9c007fffffffff000200000000000001cc00e7ffffffffc001001c000020018edc03e78e3c8181fffff81980000000c6cc07e78f388181fffff031a0000000c6ee1f6787399f99efbef0227000000073fe3e0727318799c189e0336000000032de7c472393818188c1c066800000003bff7ce633939f989ce38076e00000001f6dbc6601839f9c94c3c066c40000000ffffc0471c7818080c1c1ff8e0000040f6dae0479c78181c198e3929400000007ffeffffffffffffffff31f3800000027bf47fffffffffffffffec76000000003ffc1ffdffffffe3fffff71e00000000bed400000008000000007b98000",
  /* dbnothere.png */
  "ffffbff7fffffa000009249000000000fffe478c7bfffe0000040003fe000000fffdfa10b7fff800002aaaa800aaaaaaffff00000bfff4000000000600000000fffa000007ffe0000002000000000000ff6400000bfff40000acaaaaa5244888fff0000003ffe8000002000000000000fd80000ad57fe00000b5555529492222fff0000420fff0000048a00000000000fd000052953fc00001554a92a4924888fe000001403ff0000002000000000000f800012a957fc00002b5555249241000e00080aad28fa0000555520022424240fc000000000f80000020000000000000f000036aaaae68000b55a40008888004f8000010000000000000000000000000e1254aa41000800016aab55040220820f8000301c000000000007ffc00000000f050a855120000002b4bfd522000008afc000202c00000001003ffff00000000780003000c0000000007fffd80000000057b2df433400000aa1ffeaa440000aa1004060847800000000fffff800000100a95fab199200000901fffd5108295450060c00c07800000000fffffc00000300291a23b75400001291ffeda800456a60001d01d0f800000001fffff0000010002288d7ab5500000081fffb5405156aa00815f76b4a00a00101ffeea412aaa560000fdff02000000001fff9db00001200000ffffb5401580002b5052a2a95aaa00003fff00000240001ce0a94000050005007fdd010017b400157746b2aaaaaa00003fee00000fca001cf9c3e00001000a401adc40001d75801fef6eabaaaa0503000ffc00003ffee01ff7fff0c00100030007fc6000ffffe01fe7ffb0c00000002006c00801add5143fdffd45000102000003703003ffffe01ff8ffb2c0000002400085e0057fe52a3febfe41800202000000738007fffed41e41ffa000000000100085020aea9552948ffe5300020200000000001bfdffa8185fffa0000101008401128017aaaaaa91f5ff5400020600142a40402ef7eae510eaaeb20006b000080800001fbffe3841ff1fc1c00bcc1030dd920876bffdca89fe9d2b400d213f802600003f7ffde0407fefc00806184b20d0d20168fff7da9bd75aaaf41b453f800ee0007ffff3e4207fff07ff0e024951e9a905d1ffcffaa9ffd44fffaa8a83d8b1f000e7fffff438ffe81ffffc01dffffffffffffffff7ffe0007ffffe01dffffffffffbffffeffeebfffffffeda7ce67018787fdffffffefffffffffffdfcc77251323fdfffff3cffffffffffffe1c326f9279658f0e31e1ce23fc06387c8d324186790f1f2482c19449f916927cd838e7927b9f8f24dbec02c1fdb21b3cc818cd2b330fe764d3cdb6cfbd92d37fffefffffdf7fdfff7dffeefb7ff7f777fffffffffffffffffffffffffffffff2edbb7f7effffffffffedbfffffffffe0c0005e3fffe1e0e383801fffffffff1"
];
var SPLASH_W = 128;
var SPLASH_H = 64;
var SPLASH_COUNT = HEX_FRAMES.length;
var SPLASH_FRAMES = HEX_FRAMES.map(function(hex) {
  const arr = new Uint8Array(1024);
  for (let i = 0; i < 1024; i++)
    arr[i] = parseInt(hex.substr(i * 2, 2), 16);
  return arr;
});
var SPLASH_BITS = SPLASH_FRAMES[0];
function pickSplashIdx() {
  return Math.floor(Math.random() * 3);
}

// ui/ui_render.mjs
function drawBankHeaderRight(showTrack, hdrFilled) {
  if (S.sessionView) return;
  const pos = bankCyclePos();
  drawKitPageBar(pos.idx, pos.count);
  if (bankHasAltParams(S.activeTrack, S.activeBank)) {
    drawAltArrow(121, hdrFilled, altIndicatorActive(S.activeTrack, S.activeBank));
  }
}
function drawBankHeading(name, showTrack) {
  if (S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT && name.charAt(0) === "C" && name.charAt(1) === "-") {
    drawKitHeader((S._altBlinkPhase !== 1 ? "C-" : "  ") + name.slice(2), false);
  } else {
    drawKitHeader(name, false);
  }
  drawBankHeaderRight(showTrack, true);
}
function drawBankHeadingInverted(name, showTrack) {
  drawBankHeading(name, showTrack);
}
function drawConductTrackGrid(header, valFn, inertLabel) {
  const cells = [];
  for (let i = 0; i < 8; i++) {
    if (i === S.activeTrack) {
      cells.push({ kind: "blank", label: inertLabel });
    } else {
      cells.push({
        kind: "valsq",
        label: "Tr" + (i + 1),
        name: "Track " + (i + 1),
        text: String(valFn(i))
      });
    }
  }
  drawKitPage(header, cells, false);
}
function drawConductToggleGrid(header, onFn) {
  const cells = [];
  for (let i = 0; i < 8; i++) {
    if (i === S.activeTrack) {
      cells.push({ kind: "blank", label: "Cndct" });
    } else if (S.trackPadMode[i] === PAD_MODE_DRUM) {
      cells.push({ kind: "blank", label: "Tr" + (i + 1) });
    } else {
      const on = !!onFn(i);
      cells.push({
        kind: "hbar",
        norm: on ? 1 : 0,
        label: "Tr" + (i + 1),
        name: "Track " + (i + 1),
        text: on ? "ON" : "off"
      });
    }
  }
  drawKitPage(header, cells, false);
}
function drawThruBar(x, w, top, bot) {
  for (let yy = top; yy <= bot; yy++)
    for (let xx = x + (x + yy & 1); xx < x + w; xx += 2)
      set_pixel(xx, yy, 1);
}
function drawStepEditKitPage(title, cells, noteBox) {
  const t = S.knobTouched;
  const touched = cells && t >= 0 && cells[t] && cells[t].name ? cells[t] : null;
  if (touched) {
    drawKitTouchedHeader(touched.name);
  } else {
    drawKitHeader(title, false);
    fill_rect(0, 9, 128, 1, 1);
  }
  if (!cells) {
    mvPrint(4, 30, "Empty step", 1);
    return;
  }
  drawKitCells(cells, t);
  if (noteBox != null) {
    const hiOP = t === 0 || t === 1;
    const BX = 6, BW = 52, BY = MV_ROW0_Y, BH = MV_KH;
    if (hiOP) fill_rect(BX, BY, BW, BH, 1);
    else rectOutline(BX, BY, BW, BH, 1);
    mvPrint(
      BX + Math.round((BW - mvWidth(noteBox)) / 2),
      BY + Math.floor((BH - 5) / 2),
      noteBox,
      hiOP ? 0 : 1
    );
  }
  drawKitEnumOverlay(cells, t);
}
function drawKitPage(name, cells, inverted) {
  const t = S.knobTouched;
  const touched = t >= 0 && cells[t] && cells[t].name ? cells[t] : null;
  if (touched) drawKitTouchedHeader(touched.name);
  else (inverted ? drawBankHeadingInverted : drawBankHeading)(name, false);
  drawKitCells(cells, t);
  drawKitEnumOverlay(cells, t);
}
function drawAltArrow(x, hdrBgWhite, on) {
  drawKitAltArrow(x, hdrBgWhite, on, S._altBlinkPhase === 1);
}
function formatStepIter(raw) {
  if (!raw) return "--";
  return (raw & 15) + "/" + (raw >> 4 & 15);
}
function drawMetroIndicator() {
  const METRO_LABELS = [null, "Cnt-In", "Play", "Always"];
  const label = METRO_LABELS[S.metronomeOn];
  if (label) {
    const tx = 8;
    const tw = label.length * 6;
    fill_rect(4, 23, 2, 2, 1);
    pixelPrint(tx, 22, label, 1);
    fill_rect(tx + tw + 2, 23, 2, 2, 1);
  }
  if (!S.sessionView) {
    const t = S.activeTrack;
    const ac = !S.playing && S.trackQueuedClip[t] >= 0 ? S.trackQueuedClip[t] : S.trackActiveClip[t];
    const _isDrum7 = S.trackPadMode[t] === PAD_MODE_DRUM;
    const _isEmpty7 = _isDrum7 ? !S.drumClipNonEmpty[t][ac] : !S.clipNonEmpty[t][ac];
    const _manualL7 = _isDrum7 ? S.drumLaneLengthManuallySet[t] : S.clipLengthManuallySet[t][ac];
    pixelPrint(67, 22, fmtVelOverride(S.trackVelOverride[t]), 1);
    if (_isEmpty7 && !_manualL7) {
      pixelPrint(103, 22, "Adap", 1);
    } else {
      pixelPrint(109, 22, "Fix", 1);
    }
  }
}
var PERF_MOD_NAMES = [
  "Oct\u2191",
  "Oct\u2193",
  "Sc\u2191",
  "Sc\u2193",
  "5th",
  "Triton",
  "Drift",
  "Storm",
  "Decrsc",
  "Swell",
  "Cresc",
  "Pulse",
  "Sdchn",
  "Stac",
  "Lgto",
  "RmpG",
  "\xBDtime",
  "3Skip",
  "Phnm",
  "Sprs",
  "Gltch",
  "Stggr",
  "Shfl",
  "Back"
];
function fmtCCLabel(cc) {
  const n = cc | 0;
  return n >= 100 ? "C" + n : "CC" + n;
}
function midiNoteName(n) {
  const names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  return names[n % 12] + (Math.floor(n / 12) - 1);
}
function bankHeaderName(t, bank) {
  if (S.trackPadMode[t] === PAD_MODE_CONDUCT)
    return "C-" + (bank === 0 ? "CONDUCT" : BANKS[bank].name);
  return BANKS[bank].name;
}
var KIT_ENUM_FMTS = [
  fmtRes,
  fmtDiq,
  fmtPlayDir,
  fmtLen,
  fmtGateMod,
  fmtDly,
  fmtArpStyle,
  fmtArpRate,
  fmtArpSteps,
  fmtRevStyle
];
var KIT_DIR_NAMES = ["Forward", "Backward", "Ping Pong", "Rev Ping Pong"];
var KIT_ARP_STYLE_NAMES = [
  "Off",
  "Up",
  "Down",
  "Up/Down",
  "Down/Up",
  "Converge",
  "Diverge",
  "Ordered",
  "Random",
  "Rnd Order"
];
function kitCellForKnob(knob, val) {
  if (!knob || !knob.abbrev) return { kind: "blank", label: "" };
  const v = val | 0;
  const text = knob.fmt(v);
  const base = { label: knob.abbrev, name: knob.full, text };
  if (knob.fmt === fmtBool) {
    base.kind = "hbar";
    base.norm = v ? 1 : 0;
    return base;
  }
  if (knob.fmt === fmtLgto) {
    base.kind = "action";
    base.oneWay = true;
    return base;
  }
  if (knob.scope === "action") {
    base.kind = "action";
    return base;
  }
  if (knob.fmt === fmtPlayDir) {
    base.kind = "dirsq";
    base.options = KIT_DIR_NAMES;
    base.sel = v;
    return base;
  }
  if (KIT_ENUM_FMTS.indexOf(knob.fmt) >= 0) {
    base.kind = "enumsq";
    if (knob.fmt === fmtArpStyle) {
      base.options = KIT_ARP_STYLE_NAMES;
    } else {
      base.options = [];
      for (let i = knob.min; i <= knob.max; i++) base.options.push(knob.fmt(i));
    }
    base.sel = v - knob.min;
    return base;
  }
  if (knob.min < 0) {
    if (knob.max <= 24) {
      base.kind = "valsq";
      return base;
    }
    base.kind = "arcbip";
    const halfR = Math.max(1, Math.max(knob.max, -knob.min));
    base.signed = Math.max(-1, Math.min(1, v / halfR));
    return base;
  }
  if (knob.fmt === fmtPlain && knob.max <= 16) {
    base.kind = "valsq";
    return base;
  }
  if (knob.fmt === fmtPitchRnd) {
    base.kind = "valsq";
    return base;
  }
  base.kind = "arc";
  base.norm = Math.max(0, Math.min(1, (v - knob.min) / (knob.max - knob.min || 1)));
  return base;
}
function drawSessionOverview() {
  fill_rect(0, 0, 128, 64, 1);
  const bandY = Math.floor(S.sceneRow / 4) * 16;
  fill_rect(0, bandY, 128, 16, 0);
  for (let s = 0; s < NUM_CLIPS; s++) {
    const ly = s * 4;
    fill_rect(0, ly, 128, 1, ly >= bandY && ly < bandY + 16 ? 1 : 0);
  }
  for (let t = 0; t < NUM_TRACKS; t++) {
    const lx = t * 16;
    if (bandY > 0) fill_rect(lx, 0, 1, bandY, 0);
    fill_rect(lx, bandY, 1, 16, 1);
    if (bandY + 16 < 64) fill_rect(lx, bandY + 16, 1, 64 - bandY - 16, 0);
  }
  const blinkOn = S.flashEighth;
  for (let t = 0; t < NUM_TRACKS; t++) {
    const x = t * 16 + 1;
    const ac = S.trackActiveClip[t];
    for (let s = 0; s < NUM_CLIPS; s++) {
      const y = s * 4 + 1;
      const color = s >= S.sceneRow && s < S.sceneRow + 4 ? 1 : 0;
      const hasData = S.clipNonEmpty[t][s];
      const isActive = s === ac;
      const isPlaying = isActive && S.trackClipPlaying[t];
      if (isPlaying && hasData) {
        if (blinkOn) fill_rect(x + 1, y + 1, 13, 1, color);
      } else if (isActive && hasData) {
        fill_rect(x + 1, y + 1, 13, 1, color);
      } else if (S.overviewCache[t][s]) {
        fill_rect(x + 6, y + 1, 2, 1, color);
      }
    }
  }
}
function drawTrackRow(y) {
  const soloBlinkOn = Math.floor(S.tickCount / 24) % 2 === 0;
  for (let _t = 0; _t < NUM_TRACKS; _t++) {
    const cx = _t * 16 + 5;
    const bx = _t * 16 + 3;
    const by = y - 2;
    const bw = 10, bh = 12;
    const isActive = _t === S.activeTrack;
    if (S.trackMuted[_t]) {
      if (soloBlinkOn) print(cx, y, String(_t + 1), 1);
      if (isActive) {
        fill_rect(bx, by, bw, 1, 1);
        fill_rect(bx, by + bh - 1, bw, 1, 1);
        fill_rect(bx, by, 1, bh, 1);
        fill_rect(bx + bw - 1, by, 1, bh, 1);
      }
    } else if (S.trackSoloed[_t]) {
      fill_rect(bx, by, bw, bh, 1);
      print(cx, y, String(_t + 1), 0);
    } else {
      print(cx, y, String(_t + 1), 1);
      if (isActive) {
        fill_rect(bx, by, bw, 1, 1);
        fill_rect(bx, by + bh - 1, bw, 1, 1);
        fill_rect(bx, by, 1, bh, 1);
        fill_rect(bx + bw - 1, by, 1, bh, 1);
      }
    }
  }
}
function _modAscii(name) {
  return name.replace("\u2191", "+").replace("\u2193", "-").replace("\xBD", "Hf");
}
function _perfChip(x, y, label, active) {
  const w = label.length * 6 + 3;
  if (active) {
    fill_rect(x, y, w, 9, 1);
    pixelPrint(x + 2, y + 2, label, 0);
  } else {
    fill_rect(x, y, w, 1, 1);
    fill_rect(x, y + 8, w, 1, 1);
    fill_rect(x, y, 1, 9, 1);
    fill_rect(x + w - 1, y, 1, 9, 1);
    pixelPrint(x + 2, y + 2, label, 1);
  }
  return w;
}
function drawPerfModeOled() {
  clear_screen();
  const activeMods = S.perfModsToggled | S.perfModsHeld;
  fill_rect(0, 0, 128, 12, 1);
  let title;
  if (S.perfRecalledSlot >= 0) {
    const fp = PERF_FACTORY_PRESETS[S.perfRecalledSlot];
    title = fp ? fp.name : "SLOT " + (S.perfRecalledSlot + 1);
  } else {
    title = "PERFORMANCE";
  }
  print(4, 3, title, 0);
  if (S.actionPopupEndTick >= 0 && S.tickCount <= S.actionPopupEndTick && S.actionPopupLines.length > 0) {
    const _n = S.actionPopupLines.length;
    if (_n >= 4) {
      print(4, 14, S.actionPopupLines[0], 1);
      print(4, 25, S.actionPopupLines[1], 1);
      print(4, 36, S.actionPopupLines[2], 1);
      print(4, 47, S.actionPopupLines[3], 1);
    } else if (_n === 3) {
      print(4, 17, S.actionPopupLines[0], 1);
      print(4, 29, S.actionPopupLines[1], 1);
      print(4, 41, S.actionPopupLines[2], 1);
    } else if (_n === 2) {
      print(4, 20, S.actionPopupLines[0], 1);
      print(4, 32, S.actionPopupLines[1], 1);
    } else {
      print(4, 26, S.actionPopupLines[0], 1);
    }
  } else if (S.perfModPopupEndTick >= 0 && S.tickCount <= S.perfModPopupEndTick && S.perfModPopupName) {
    const px = Math.floor((128 - S.perfModPopupName.length * 6) / 2);
    print(px < 0 ? 0 : px, 26, S.perfModPopupName, 1);
  } else {
    S.perfModPopupEndTick = -1;
    const activeNames = [];
    for (let i = 0; i < PERF_MOD_NAMES.length; i++)
      if (activeMods >> i & 1) activeNames.push(_modAscii(PERF_MOD_NAMES[i]));
    if (activeNames.length === 0) {
      pixelPrint(4, 24, "no mods active", 1);
      pixelPrint(4, 34, "tap pad to engage", 1);
    } else {
      const MAX_CHARS = 20;
      const MAX_LINES = 4;
      const lines = [];
      let cur = "";
      for (let i = 0; i < activeNames.length; i++) {
        const sep = cur ? "  " : "";
        const next = cur + sep + activeNames[i];
        if (next.length > MAX_CHARS && cur) {
          lines.push(cur);
          if (lines.length >= MAX_LINES) {
            cur = "";
            break;
          }
          cur = activeNames[i];
        } else {
          cur = next;
        }
      }
      if (cur && lines.length < MAX_LINES) lines.push(cur);
      for (let li = 0; li < lines.length; li++) {
        pixelPrint(4, 16 + li * 8, lines[li], 1);
      }
    }
  }
  const fy = 53;
  let fx = 2;
  fx += _perfChip(fx, fy, "Hold", S.perfHoldPadHeld || S.perfStickyLengths.size > 0) + 3;
  fx += _perfChip(fx, fy, "Sync", S.perfSync) + 3;
  fx += _perfChip(fx, fy, "Latch", S.perfLatchMode) + 3;
  if (S.perfStack.length > 0) {
    const RATE_LABELS = ["1/32", "1/16", "1/8", "1/4", "1/2"];
    const top = S.perfStack[S.perfStack.length - 1];
    const lab = RATE_LABELS[top.idx];
    const w = lab.length * 6 + 3;
    const rx = 128 - w - 2;
    fill_rect(rx, fy, w, 9, 1);
    pixelPrint(rx + 2, fy + 2, lab, 0);
  }
}
function drawTempoSelect() {
  clear_screen();
  const t = S.tempoSelectTrack;
  const c = S.tempoSelectClip;
  const idx = S.tempoSelectIdx | 0;
  const bpms = S.tempoSelectBpms;
  const isDrum = S.trackPadMode[t] === PAD_MODE_DRUM;
  drawBpmLine(64, 6, bpms[idx], S.tempoSelectWarp ? "bars" : "bpm");
  if (S.tempoSelectWarp) pixelPrintC(64, 22, "Shift = Fine adjust", 1);
  const BX = 4, BW = 120, BY = 28, BH = 19;
  const len = Math.max(1, (isDrum ? S.drumLaneLength[t] | 0 : S.clipLength[t][c] | 0) || 16);
  const bars = Math.max(1, Math.round(len / 16));
  rectOutline(BX, BY, BW, BH, 1);
  for (let s = 4; s < len; s += 4) {
    const x = BX + Math.round(s / len * BW);
    if (s % 16 === 0) for (let yy = BY; yy < BY + BH; yy++) set_pixel(x, yy, 1);
    else for (let yy = BY + 2; yy < BY + BH - 2; yy += 3) set_pixel(x, yy, 1);
  }
  if (BW / bars >= 10) {
    for (let bi = 0; bi < bars; bi++) {
      const x = BX + Math.round(bi * 16 / len * BW) + 2;
      print(x, BY + 1, String(bi + 1), 1);
    }
  }
  const steps = isDrum ? S.drumLaneSteps[t][S.activeDrumLane[t]] : S.clipSteps[t][c];
  if (steps) {
    for (let s = 0; s < len && s < steps.length; s++) {
      if (!steps[s] || steps[s] === "0") continue;
      const x = BX + Math.round(s / len * BW);
      fill_rect(Math.min(x, BX + BW - 2), BY + BH - 6, 2, 4, 1);
    }
  }
  const cur = isDrum ? S.drumCurrentStep[t] | 0 : S.trackCurrentStep[t] | 0;
  const ph = (cur % len + len) % len;
  const px = BX + Math.round(ph / len * BW);
  for (let yy = BY; yy < BY + BH; yy++) set_pixel(Math.min(px, BX + BW - 1), yy, 1);
  pixelPrintC(64, 56, "Click to set", 1);
}
function drawUI() {
  if (S.schwungCoRunSlot >= 0) return;
  if (S.moveCoRunTrack >= 0) {
    const _coRunCh = S.trackChannel[S.moveCoRunTrack] | 0;
    const _litMask = _coRunCh >= 1 && _coRunCh <= 4 ? 1 << _coRunCh - 1 : 0;
    paintCoRunSideButtons(_litMask, S.tickCount % POLL_INTERVAL === 0);
    return;
  }
  if (S.altMode && (S.sessionView || /* session view can be entered via a button after altMode was set */
  S.activeBank !== S._altPrevBank || S.activeTrack !== S._altPrevTrack)) {
    S.altMode = false;
  }
  S._altPrevBank = S.activeBank;
  S._altPrevTrack = S.activeTrack;
  if (S.sessionOverlayHeld) {
    drawSessionOverview();
    return;
  }
  if (S.pendingInheritPicker) {
    drawInheritPicker();
    return;
  }
  if (S.snapshotPicker) {
    drawSnapshotPicker();
    return;
  }
  if (S.clearAutoMenu) {
    drawClearAutoMenu();
    return;
  }
  if (S.pendingSceneBakePicker) {
    clear_screen();
    print(4, 8, "BAKE SCENE", 1);
    print(4, 22, "Tap row or scene step", 1);
    print(4, 34, "to pick the scene", 1);
    print(4, 50, "Any other btn cancels", 1);
    return;
  }
  if (S.mergePlacing) {
    clear_screen();
    print(4, 20, "PLACING MERGED", 1);
    print(4, 34, S.mergePlacingScene ? "CLIPS..." : "CLIP...", 1);
    return;
  }
  if (S.mergeNoticePending) {
    clear_screen();
    print(4, 8, "LIVE MERGE", 1);
    print(4, 22, S.mergeNoticeSingleTrack < 0 ? "Capture all 8." : "Capture this track.", 1);
    print(4, 36, "Rec to start,", 1);
    print(4, 50, "Back to cancel", 1);
    return;
  }
  if (S.pendingMergePlacement) {
    clear_screen();
    print(4, 8, "PLACE MERGED CLIPS", 1);
    print(4, 22, "Tap row or scene step", 1);
    print(4, 34, "to pick destination", 1);
    print(4, 50, "Back cancels", 1);
    return;
  }
  if (S.tempoSelectActive) {
    drawTempoSelect();
    return;
  }
  if (S.mergeSoloPlacement >= 0) {
    clear_screen();
    print(4, 8, "MERGED TAKE", 1);
    print(4, 22, "Tap a blinking clip", 1);
    print(4, 34, "on track " + (S.mergeSoloPlacement + 1) + " to save", 1);
    print(4, 50, "Back cancels", 1);
    return;
  }
  if (S.capturePlaceTrack >= 0) {
    clear_screen();
    print(4, 8, "CAPTURED TAKE", 1);
    print(4, 22, "Tap a blinking clip", 1);
    print(4, 34, "on track " + (S.capturePlaceTrack + 1) + " to save", 1);
    print(4, 50, "Rec cancels", 1);
    return;
  }
  if (S.confirmStateWipe) {
    drawStateWipeConfirm();
    return;
  }
  if (S.bpmMoveInfo) {
    drawBpmMoveInfo();
    return;
  }
  if (S.recordBlockedDialog) {
    drawRecordBlockedDialog();
    return;
  }
  if (S.confirmLgto) {
    drawLgtoConfirm();
    return;
  }
  if (S.confirmXpose) {
    drawXposeConfirm();
    return;
  }
  if (S.confirmBakeScene) {
    drawBakeSceneConfirm();
    return;
  }
  if (S.confirmBake) {
    drawBakeConfirm();
    return;
  }
  if (S.globalMenuOpen || S.tapTempoOpen) {
    ensureGlobalMenuFresh();
    drawGlobalMenu();
    return;
  }
  if (S.sessionView && (S.loopHeld || S.perfViewLocked)) {
    drawPerfModeOled();
    return;
  }
  if (S.stateLoading || S.bootSplashTicks > 0) {
    if (!S.splashWasVisible) {
      S.currentSplashIdx = pickSplashIdx();
      S.splashWasVisible = true;
    }
    clear_screen();
    const _frame = SPLASH_FRAMES[S.currentSplashIdx % SPLASH_COUNT];
    const rowBytes = SPLASH_W >> 3;
    for (let y = 0; y < SPLASH_H; y++) {
      let runStart = -1;
      const rowOff = y * rowBytes;
      for (let x = 0; x < SPLASH_W; x++) {
        const bit = _frame[rowOff + (x >> 3)] >> 7 - (x & 7) & 1;
        if (bit) {
          if (runStart < 0) runStart = x;
        } else if (runStart >= 0) {
          fill_rect(runStart, y, x - runStart, 1, 1);
          runStart = -1;
        }
      }
      if (runStart >= 0) fill_rect(runStart, y, SPLASH_W - runStart, 1, 1);
    }
    return;
  }
  if (S.splashWasVisible) S.splashWasVisible = false;
  clear_screen();
  if (S.sessionView) {
    if (S.actionPopupEndTick >= 0) {
      const _n = S.actionPopupLines.length;
      if (_n >= 4) {
        print(4, 14, S.actionPopupLines[0], 1);
        print(4, 25, S.actionPopupLines[1], 1);
        print(4, 36, S.actionPopupLines[2], 1);
        print(4, 47, S.actionPopupLines[3], 1);
      } else if (_n === 3) {
        print(4, 17, S.actionPopupLines[0], 1);
        print(4, 29, S.actionPopupLines[1], 1);
        print(4, 41, S.actionPopupLines[2], 1);
      } else if (_n === 2) {
        print(4, 22, S.actionPopupLines[0], 1);
        print(4, 34, S.actionPopupLines[1], 1);
      } else {
        print(4, 28, S.actionPopupLines[0], 1);
      }
      return;
    }
    fill_rect(0, 0, 128, 12, 1);
    let dA, dE, dO;
    if (S.playing) {
      dA = Math.floor(S.masterPos / 96) % 2 === 0 ? "A" : "@";
      dE = Math.floor(S.masterPos / 48) % 2 === 0 ? "3" : "E";
      dO = Math.floor(S.masterPos / 192) % 2 === 0 ? "O" : "o";
    } else {
      dA = "A";
      dE = "E";
      dO = "O";
    }
    const banner = "d" + dA + "V" + dE + "B" + dO + "x";
    print(43, 2, banner, 0);
    drawMetroIndicator();
    drawTrackRow(35);
    for (let t = 0; t < NUM_TRACKS; t++) {
      const cx = t * 16 + 5;
      const ac = S.trackActiveClip[t];
      const hasData = S.trackPadMode[t] === PAD_MODE_DRUM ? S.drumClipNonEmpty[t][ac] : S.clipNonEmpty[t][ac];
      const isActive = (S.trackClipPlaying[t] || S.trackWillRelaunch[t] || S.trackQueuedClip[t] >= 0) && hasData;
      if (isActive) {
        fill_rect(cx - 1, 46, 9, 7, 1);
        pixelPrint(cx, 47, SCENE_LETTERS[ac], 0);
      } else {
        pixelPrint(cx, 47, SCENE_LETTERS[ac], 1);
      }
    }
    return;
  }
  const bank = S.activeBank;
  const inTimeout = S.bankSelectTick >= 0 || S.jogTouched;
  if (S.stretchBlockedEndTick >= 0) {
    print(4, 10, "[CLIP       ]", 1);
    print(4, 22, "Beat Stretch", 1);
    print(4, 34, "COMPRESS LIMIT", 1);
    return;
  }
  if (S.actionPopupEndTick >= 0 && S.heldStep < 0 && S.knobTouched < 0) {
    if (S.actionPopupHighlight >= 0 && S.actionPopupLines.length >= 3) {
      const _title = S.actionPopupLines[0];
      const _tw = _title.length * 6;
      const _tx = Math.floor((128 - _tw) / 2);
      print(_tx, 4, _title, 1);
      fill_rect(_tx, 13, _tw, 1, 1);
      for (let _li = 1; _li < S.actionPopupLines.length; _li++) {
        const _ly = 12 + _li * 14;
        const _lw = S.actionPopupLines[_li].length * 6;
        const _lx = Math.floor((128 - _lw) / 2);
        if (_li === S.actionPopupHighlight) {
          fill_rect(0, _ly - 1, 128, 13, 1);
          print(_lx, _ly, S.actionPopupLines[_li], 0);
        } else {
          print(_lx, _ly, S.actionPopupLines[_li], 1);
        }
      }
    } else if (S.actionPopupLines.length >= 2) {
      print(4, 22, S.actionPopupLines[0], 1);
      print(4, 34, S.actionPopupLines[1], 1);
    } else {
      print(4, 28, S.actionPopupLines[0], 1);
    }
    return;
  }
  if (S.noNoteFlashEndTick >= 0 && S.activeBank !== 6) {
    print(4, 22, "NO NOTE", 1);
    print(4, 34, "Play a pad first", 1);
    return;
  }
  if (S.heldStep >= 0) {
    if (S.activeBank === 6) {
      var _t6s = S.activeTrack, _ac6s = effectiveClip(_t6s);
      var _gLane6 = S.ccActiveLane[_t6s];
      var _gEffLen6 = S.ccLaneLength[_t6s][_ac6s][_gLane6] || S.clipLength[_t6s][_ac6s];
      var _gLTps6 = S.ccLaneTps[_t6s][_ac6s][_gLane6] || (S.clipTPS[_t6s][_ac6s] || 24);
      var _sgBarY = 60, _sgBarH = 3;
      var _sgH = 12, _sgY = _sgBarY - _sgH - 2;
      var _sgPages = Math.ceil(_gEffLen6 / 16);
      var _sgKey = "sg_" + _t6s + "_" + _ac6s + "_" + _gLane6 + "_" + _gEffLen6;
      if (_sgKey !== S.ccGraphOvKey || S.tickCount % POLL_INTERVAL === 0) {
        S.ccGraphOvData = [];
        for (var _sgp = 0; _sgp < _sgPages; _sgp++) {
          var _sgRaw = typeof host_module_get_param === "function" ? host_module_get_param("t" + _t6s + "_c" + _ac6s + "_ccsv_" + _gLane6 + "_" + _sgp) : null;
          if (_sgRaw) {
            var _sgParts = _sgRaw.split(" ");
            for (var _sgs = 0; _sgs < 16 && _sgp * 16 + _sgs < _gEffLen6; _sgs++)
              S.ccGraphOvData.push(_sgs < _sgParts.length ? parseInt(_sgParts[_sgs], 10) : 255);
          }
        }
        S.ccGraphOvKey = _sgKey;
      }
      fill_rect(0, _sgY, 128, 1, 1);
      fill_rect(0, _sgY + _sgH - 1, 128, 1, 1);
      fill_rect(0, _sgY, 1, _sgH, 1);
      fill_rect(127, _sgY, 1, _sgH, 1);
      var _sgDLen = S.ccGraphOvData.length || 1;
      var _sgDrawY = _sgY + 2, _sgDrawH = _sgH - 4;
      var _sgPrevPy = -1;
      for (var _sgc = 1; _sgc < 127; _sgc++) {
        var _sgIdx = Math.floor(_sgc * _sgDLen / 128);
        var _sgv = _sgIdx < S.ccGraphOvData.length ? S.ccGraphOvData[_sgIdx] : -1;
        if (_sgv >= 0 && _sgv <= 127) {
          var _sgpy = _sgDrawY + _sgDrawH - 1 - Math.round(_sgv * (_sgDrawH - 1) / 127);
          if (_sgPrevPy >= 0 && _sgPrevPy !== _sgpy) {
            var _sgyMin = Math.min(_sgPrevPy, _sgpy);
            var _sgyMax = Math.max(_sgPrevPy, _sgpy);
            fill_rect(_sgc, _sgyMin, 1, _sgyMax - _sgyMin + 1, 1);
          } else {
            fill_rect(_sgc, _sgpy, 1, 1, 1);
          }
          _sgPrevPy = _sgpy;
        } else {
          _sgPrevPy = -1;
        }
      }
      var _sgSx = Math.min(126, Math.max(1, Math.floor(S.heldStep * 126 / _sgDLen) + 1));
      fill_rect(_sgSx, _sgY + 1, 1, _sgH - 2, 1);
      pixelPrint(1, 1, "Step " + (S.heldStep + 1), 1);
      var _pnLbl = "";
      var _pnK = S.knobTouched >= 0 ? S.knobTouched : _gLane6;
      if (S.trackCCType[_t6s][_pnK] === 2)
        _pnLbl = S.schLabel[_t6s][_pnK] || "Sch" + S.trackCCAssign[_t6s][_pnK];
      if (_pnLbl) pixelPrint(128 - _pnLbl.length * 6 - 1, 1, _pnLbl, 1);
      fill_rect(0, 7, 128, 1, 1);
      for (var _k6 = 0; _k6 < 8; _k6++) {
        var _col6 = _k6 % 4, _row6 = Math.floor(_k6 / 4);
        var _x6 = 4 + _col6 * 31, _y6 = 11 + _row6 * 18;
        var _hi6 = S.knobTouched === _k6 || S.ccActiveLane[_t6s] === _k6;
        if (_hi6) fill_rect(_x6 - 1, _y6 - 1, 29, 18, 1);
        var _lbl6 = S.trackCCType[_t6s][_k6] === 2 ? "Sch" + S.trackCCAssign[_t6s][_k6] : S.trackCCType[_t6s][_k6] === 1 ? "AT" : S.trackCCAssign[_t6s][_k6] > 0 ? "C" + S.trackCCAssign[_t6s][_k6] : "--";
        var _vs6;
        if (S.ccStepEditSet[_k6]) {
          _vs6 = String(S.ccStepEditVal[_k6]);
        } else {
          var _cv6 = S.ccStepEditComputed[_k6];
          _vs6 = _cv6 >= 0 && _cv6 <= 127 ? "(" + _cv6 + ")" : "--";
        }
        print(_x6, _y6, col4(_lbl6), _hi6 ? 0 : 1);
        print(_x6, _y6 + 9, col5(_vs6), _hi6 ? 0 : 1);
      }
      var _sgWP = Math.max(1, Math.ceil(_gEffLen6 / 16));
      var _sgVP = Math.max(0, Math.min(S.trackCurrentPage[_t6s], _sgWP - 1));
      var _sgSG = 1, _sgSW = Math.max(2, Math.floor((120 - (_sgWP - 1) * _sgSG) / _sgWP));
      var _sgPP = -1;
      if (S.playing) {
        var _sgProg = S.masterPos % (_gEffLen6 * _gLTps6) / (_gEffLen6 * _gLTps6);
        _sgPP = Math.floor(_sgProg * _sgWP);
      }
      for (var _sgPg = 0; _sgPg < _sgWP; _sgPg++) {
        var _sgx = 4 + _sgPg * (_sgSW + _sgSG);
        if (_sgPg === _sgVP) fill_rect(_sgx, _sgBarY, _sgSW, _sgBarH, 1);
        else if (_sgPg === _sgPP) {
          fill_rect(_sgx, _sgBarY, _sgSW, 1, 1);
          fill_rect(_sgx, _sgBarY + _sgBarH - 1, _sgSW, 1, 1);
          fill_rect(_sgx, _sgBarY, 1, _sgBarH, 1);
          fill_rect(_sgx + _sgSW - 1, _sgBarY, 1, _sgBarH, 1);
        } else fill_rect(_sgx, _sgBarY + _sgBarH - 1, _sgSW, 1, 1);
      }
      if (S.playing) {
        var _sgBW = _sgWP * (_sgSW + _sgSG) - _sgSG;
        var _sgDX = 4 + Math.floor(_sgProg * _sgBW);
        var _sgVS = 4 + _sgVP * (_sgSW + _sgSG);
        fill_rect(_sgDX, _sgBarY, 1, _sgBarH, _sgDX >= _sgVS && _sgDX < _sgVS + _sgSW ? 0 : 1);
      }
      return;
    } else {
      const _dash = (s) => s === "\u2014" ? "--" : s;
      const _stepTitle = "Step " + (S.heldStep + 1);
      if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
        const t = S.activeTrack;
        if (S.heldStepNotes.length > 0) {
          const tps = S.drumLaneTPS[t] || 24;
          const _gateSteps = S.stepEditGate / tps;
          const cells = [
            {
              kind: "valsq",
              label: "Leng",
              name: "Length",
              text: _gateSteps % 1 === 0 ? _gateSteps.toFixed(0) : _gateSteps.toFixed(2)
            },
            {
              kind: "arc",
              label: "Vel",
              name: "Velocity",
              text: String(S.stepEditVel),
              norm: Math.max(0, Math.min(1, S.stepEditVel / 127))
            },
            {
              kind: "arcbip",
              label: "Nudg",
              name: "Nudge",
              text: (S.stepEditNudge >= 0 ? "+" : "") + S.stepEditNudge,
              signed: Math.max(-1, Math.min(1, S.stepEditNudge / Math.max(1, tps - 1)))
            },
            { kind: "blank", label: "" },
            {
              kind: "enumsq",
              label: "Iter",
              name: "Iteration",
              text: _dash(formatStepIter(S.stepEditIter)),
              options: STEP_ITER_LIST.map((v) => _dash(formatStepIter(v))),
              sel: Math.max(0, STEP_ITER_LIST.indexOf(S.stepEditIter))
            },
            {
              kind: "arc",
              label: "Prob",
              name: "Probability",
              text: (S.stepEditRand === 0 ? 100 : S.stepEditRand) + "%",
              norm: (S.stepEditRand === 0 ? 100 : S.stepEditRand) / 100
            },
            {
              kind: "valsq",
              label: "Ratch",
              name: "Ratchet",
              text: S.stepEditRatch <= 1 ? "--" : String(S.stepEditRatch)
            },
            { kind: "blank", label: "" }
          ];
          drawStepEditKitPage(_stepTitle, cells, null);
        } else {
          drawStepEditKitPage(_stepTitle, null, null);
        }
        return;
      }
      const ac = effectiveClip(S.activeTrack);
      if (S.heldStepNotes.length > 0) {
        const root = S.heldStepNotes[0];
        const noteLabel = S.heldStepNotes.length > 1 ? midiNoteName(root) + "+" + (S.heldStepNotes.length - 1) : midiNoteName(root);
        const tps = S.clipTPS[S.activeTrack][ac] || 24;
        const _gateSteps = S.stepEditGate / tps;
        const cells = [
          { kind: "blank", label: "Oct", name: "Note" },
          { kind: "blank", label: "Note", name: "Note" },
          {
            kind: "valsq",
            label: "Leng",
            name: "Length",
            text: _gateSteps % 1 === 0 ? _gateSteps.toFixed(0) : _gateSteps.toFixed(2)
          },
          {
            kind: "arc",
            label: "Vel",
            name: "Velocity",
            text: String(S.stepEditVel),
            norm: Math.max(0, Math.min(1, S.stepEditVel / 127))
          },
          {
            kind: "arcbip",
            label: "Nudg",
            name: "Nudge",
            text: (S.stepEditNudge >= 0 ? "+" : "") + S.stepEditNudge,
            signed: Math.max(-1, Math.min(1, S.stepEditNudge / Math.max(1, tps - 1)))
          },
          {
            kind: "enumsq",
            label: "Iter",
            name: "Iteration",
            text: _dash(formatStepIter(S.stepEditIter)),
            options: STEP_ITER_LIST.map((v) => _dash(formatStepIter(v))),
            sel: Math.max(0, STEP_ITER_LIST.indexOf(S.stepEditIter))
          },
          {
            kind: "arc",
            label: "Prob",
            name: "Probability",
            text: (S.stepEditRand === 0 ? 100 : S.stepEditRand) + "%",
            norm: (S.stepEditRand === 0 ? 100 : S.stepEditRand) / 100
          },
          {
            kind: "valsq",
            label: "Ratch",
            name: "Ratchet",
            text: S.stepEditRatch <= 1 ? "--" : String(S.stepEditRatch)
          }
        ];
        drawStepEditKitPage(_stepTitle, cells, noteLabel);
        return;
      } else if (S.stepWasEmpty) {
        drawStepEditKitPage(_stepTitle, null, null);
        return;
      }
    }
  }
  if (S.loopHeld && !(S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 7 && !S.allLanesConfirmed)) {
    let _drawLoopSteps = function(steps) {
      const _l4 = "Steps: " + steps + "/256";
      const _l4x = Math.floor((128 - _l4.length * 6) / 2);
      const _nvX = _l4x + 7 * 6;
      const _nvW = (_l4.length - 7) * 6;
      fill_rect(_nvX - 1, 50, _nvW + 2, 14, 1);
      print(_l4x, 52, "Steps: ", 1);
      print(_nvX, 52, steps + "/256", 0);
    };
    const _loopL2 = "STEP BTN=by page";
    const _loopL3 = "JOG TURN=by step";
    const _loopX2 = Math.floor((128 - _loopL2.length * 6) / 2);
    const _loopX3 = Math.floor((128 - _loopL3.length * 6) / 2);
    if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank !== 6) {
      const t = S.activeTrack;
      const len = S.drumLaneLength[t];
      if (S.activeBank === 7) {
        const _allBlink = Math.floor(S.tickCount / 24) % 2 === 0;
        const _l1 = "Clip length-" + (_allBlink ? "ALL" : "   ") + " lanes";
        print(Math.floor((128 - 21 * 6) / 2), 4, _l1, 1);
      } else {
        print(Math.floor((128 - 11 * 6) / 2), 4, "Lane length", 1);
      }
      fill_rect(0, 15, 128, 1, 1);
      print(_loopX2, 22, _loopL2, 1);
      print(_loopX3, 34, _loopL3, 1);
      _drawLoopSteps(len);
    } else if (S.activeBank === 6) {
      var _t_l = S.activeTrack;
      var _ac_l = effectiveClip(_t_l);
      var _ccL_l = S.ccActiveLane[_t_l];
      var _llen_l = S.ccLaneLength[_t_l][_ac_l][_ccL_l];
      var _ltps_l = S.ccLaneResTps[_t_l][_ac_l][_ccL_l] || S.ccLaneTps[_t_l][_ac_l][_ccL_l];
      var _lbl_l = S.trackCCType[_t_l][_ccL_l] === 2 ? "Sch" + S.trackCCAssign[_t_l][_ccL_l] : fmtCCLabel(S.trackCCAssign[_t_l][_ccL_l]);
      var _resN = _ltps_l === 12 ? "1/32" : _ltps_l === 48 ? "1/8" : _ltps_l === 96 ? "1/4" : _ltps_l === 384 ? "1bar" : "1/16";
      var _lcHdr = "Lane config: K" + (_ccL_l + 1) + "-" + _lbl_l;
      pixelPrint(Math.floor((128 - _lcHdr.length * 6) / 2), 4, _lcHdr, 1);
      fill_rect(0, 15, 128, 1, 1);
      pixelPrint(1, 18, "STEP BTN=Leng by page", 1);
      pixelPrint(1, 25, "JOG TURN=Leng by step", 1);
      var _zoomTps_l = S.ccLaneTps[_t_l][_ac_l][_ccL_l] || (S.clipTPS[_t_l][_ac_l] || 24);
      var _zoomN = _zoomTps_l === 12 ? "1/32" : _zoomTps_l === 48 ? "1/8" : _zoomTps_l === 96 ? "1/4" : _zoomTps_l === 384 ? "1bar" : "1/16";
      var _resLabel = "Resolution: <";
      var _resValX = 1 + _resLabel.length * 6;
      var _resValW = _resN.length * 6 + 2;
      pixelPrint(1, 34, _resLabel, 1);
      fill_rect(_resValX - 1, 33, _resValW, 7, 1);
      pixelPrint(_resValX, 34, _resN, 0);
      pixelPrint(_resValX + _resValW, 34, ">", 1);
      var _zoomLabel = "Zoom: +";
      var _zoomValX = 1 + _zoomLabel.length * 6;
      var _zoomValW = _zoomN.length * 6 + 2;
      pixelPrint(1, 41, _zoomLabel, 1);
      fill_rect(_zoomValX - 1, 40, _zoomValW, 7, 1);
      pixelPrint(_zoomValX, 41, _zoomN, 0);
      pixelPrint(_zoomValX + _zoomValW, 41, "-", 1);
      _drawLoopSteps(_llen_l > 0 ? _llen_l : S.clipLength[_t_l][_ac_l]);
    } else {
      const ac_l = effectiveClip(S.activeTrack);
      const steps_l = S.clipLength[S.activeTrack][ac_l];
      print(Math.floor((128 - 11 * 6) / 2), 4, "Clip Length", 1);
      fill_rect(0, 15, 128, 1, 1);
      print(_loopX2, 22, _loopL2, 1);
      print(_loopX3, 34, _loopL3, 1);
      _drawLoopSteps(steps_l);
    }
    return;
  }
  if (bank >= 0 && S.stepIntervalMode && !S.sessionView && (bank === 4 || bank === 5)) {
    const t = S.activeTrack;
    const isSeq = bank === 4;
    const _ac = effectiveClip(t);
    const _velPage = S.shiftHeld;
    const arr = _velPage ? isSeq ? S.seqArpStepVel[t][_ac] : S.tarpStepVel[t] : isSeq ? S.seqArpStepInt[t][_ac] : S.tarpStepInt[t];
    const _llRaw = isSeq ? S.seqArpStepLoopLen[t][_ac] | 0 : S.tarpStepLoopLen[t] | 0;
    const _ll = _llRaw >= 1 && _llRaw <= 8 ? _llRaw : 8;
    const _tk = S.knobTouched;
    if (_tk >= 0 && _tk < _ll) {
      const _v = arr[_tk] | 0;
      if (_velPage) drawKitTouchedHeader("Velocity: " + (_v === 0 ? "Off" : _v > 127 ? "Thru" : _v));
      else drawKitTouchedHeader("Pitch: " + (_v > 0 ? "+" : "") + _v);
    } else {
      drawBankHeading(_velPage ? "Step Vel" : "Step Pitch");
      if (!_velPage) {
        pf3Print(118 - pf3Width("SHIFT"), 2, "SHIFT", 0);
      }
    }
    const _colW = 16, _barW = 10, _top = 14, _bot = 54, _numY = 57;
    const _cy = Math.floor((_top + _bot) / 2);
    if (_velPage) fill_rect(0, _bot + 1, 128, 1, 1);
    else for (let x = 0; x < 128; x += 2) set_pixel(x, _cy, 1);
    for (let k = 0; k < 8; k++) {
      const _x = k * _colW + 3;
      if (k >= _ll) {
        fill_rect(_x + 3, _bot - 1, 4, 1, 1);
        continue;
      }
      const _v = arr[k] | 0;
      if (_velPage) {
        if (_v > 127) {
          drawThruBar(_x, _barW, _top, _bot);
        } else if (_v > 0) {
          const _h = Math.max(1, Math.round(_v / 127 * (_bot - _top)));
          fill_rect(_x, _bot - _h, _barW, _h, 1);
        }
      } else {
        const _mag = Math.round(Math.abs(_v) / 24 * (_cy - _top));
        if (_v === 0) fill_rect(_x, _cy - 1, _barW, 3, 1);
        else if (_v > 0) fill_rect(_x, _cy - _mag, _barW, Math.max(1, _mag), 1);
        else fill_rect(_x, _cy + 1, _barW, Math.max(1, _mag), 1);
      }
      const _num = String(k + 1);
      const _nw = mvWidth(_num);
      const _nx = Math.round(k * _colW + _colW / 2 - _nw / 2);
      if (k === _tk) {
        fill_rect(k * _colW + 2, _numY - 1, _colW - 4, 7, 1);
        mvPrint(_nx, _numY, _num, 0);
      } else {
        mvPrint(_nx, _numY, _num, 1);
      }
    }
    return;
  }
  if (bank === 6 && !S.loopHeld && S.knobTouched < 0 && !inTimeout) {
    var _gt = S.activeTrack;
    var _gac = effectiveClip(_gt);
    var _gLane = S.ccActiveLane[_gt];
    var _gLbl = S.trackCCType[_gt][_gLane] === 2 ? "Sch" + S.trackCCAssign[_gt][_gLane] : fmtCCLabel(S.trackCCAssign[_gt][_gLane]);
    var _gParam = S.trackCCType[_gt][_gLane] === 2 ? S.schLabel[_gt][_gLane] || "" : "";
    var _gEffLen = S.ccLaneLength[_gt][_gac][_gLane] || S.clipLength[_gt][_gac];
    var _gDispTps = S.ccLaneTps[_gt][_gac][_gLane] || (S.clipTPS[_gt][_gac] || 24);
    var _gLTps = S.ccLaneResTps[_gt][_gac][_gLane] || _gDispTps;
    var _gResN = _gLTps === 12 ? "1/32" : _gLTps === 48 ? "1/8" : _gLTps === 96 ? "1/4" : _gLTps === 384 ? "1bar" : "1/16";
    drawBankHeadingInverted(BANKS[6].name);
    var _gVal = S.playing ? S.trackCCLiveVal[_gt][_gLane] : S.clipCCVal[_gt][_gac][_gLane];
    var _gValStr = _gVal >= 0 && _gVal <= 127 ? String(_gVal) : "--";
    var _gLine1L = "K" + (_gLane + 1) + " " + _gLbl + ": ";
    mvPrint(4, 13, _gLine1L, 1);
    var _gValX = 4 + mvWidth(_gLine1L) + 1;
    mvPrint(_gValX, 13, _gValStr, 1);
    fill_rect(_gValX, 19, mvWidth(_gValStr), 1, 1);
    if (_gParam) {
      var _gPTrunc = _gParam.length > 12 ? _gParam.substring(0, 12) : _gParam;
      mvPrint(128 - mvWidth(_gPTrunc) - 2, 13, _gPTrunc, 1);
    }
    var _gZoomTps = S.ccLaneTps[_gt][_gac][_gLane] || (S.clipTPS[_gt][_gac] || 24);
    var _gZoomN = _gZoomTps === 12 ? "1/32" : _gZoomTps === 48 ? "1/8" : _gZoomTps === 96 ? "1/4" : _gZoomTps === 384 ? "1bar" : "1/16";
    var _gResStr = "Res: " + _gResN;
    var _gZoomStr = "Zoom: " + _gZoomN;
    mvPrint(4, 23, _gResStr, 1);
    mvPrint(128 - mvWidth(_gZoomStr) - 4, 23, _gZoomStr, 1);
    var _gBarY = 60, _gBarH = 3;
    var _gH = 24, _gY = _gBarY - _gH - 3;
    var _gPages = Math.ceil(_gEffLen / 16);
    var _gCTps = S.clipTPS[_gt][_gac] || 24;
    var _gTotalSteps = _gEffLen;
    var _gKey = "g_" + _gt + "_" + _gac + "_" + _gLane + "_" + _gEffLen;
    if (_gKey !== S.ccGraphOvKey || S.tickCount % POLL_INTERVAL === 0) {
      S.ccGraphOvData = [];
      for (var _gp = 0; _gp < _gPages; _gp++) {
        var _gRaw = typeof host_module_get_param === "function" ? host_module_get_param("t" + _gt + "_c" + _gac + "_ccsv_" + _gLane + "_" + _gp) : null;
        if (_gRaw) {
          var _gParts = _gRaw.split(" ");
          for (var _gs = 0; _gs < 16 && _gp * 16 + _gs < _gTotalSteps; _gs++)
            S.ccGraphOvData.push(_gs < _gParts.length ? parseInt(_gParts[_gs], 10) : 255);
        }
      }
      S.ccGraphOvKey = _gKey;
    }
    fill_rect(0, _gY, 128, 1, 1);
    fill_rect(0, _gY + _gH - 1, 128, 1, 1);
    fill_rect(0, _gY, 1, _gH, 1);
    fill_rect(127, _gY, 1, _gH, 1);
    var _gDataLen = S.ccGraphOvData.length || 1;
    var _gDrawY = _gY + 2, _gDrawH = _gH - 4;
    var _gPrevPy = -1;
    for (var _gc = 1; _gc < 127; _gc++) {
      var _gIdx = Math.floor(_gc * _gDataLen / 128);
      var _gv = _gIdx < S.ccGraphOvData.length ? S.ccGraphOvData[_gIdx] : -1;
      if (_gv >= 0 && _gv <= 127) {
        var _gpy = _gDrawY + _gDrawH - 1 - Math.round(_gv * (_gDrawH - 1) / 127);
        if (_gPrevPy >= 0 && _gPrevPy !== _gpy) {
          var _gyMin = Math.min(_gPrevPy, _gpy);
          var _gyMax = Math.max(_gPrevPy, _gpy);
          fill_rect(_gc, _gyMin, 1, _gyMax - _gyMin + 1, 1);
        } else {
          fill_rect(_gc, _gpy, 1, 1, 1);
        }
        _gPrevPy = _gpy;
      } else {
        _gPrevPy = -1;
      }
    }
    if (S.playing) {
      var _gPhDen = _gEffLen * _gLTps;
      var _gPhFrac = _gPhDen > 0 ? S.masterPos % _gPhDen / _gPhDen : 0;
      var _gPhX = Math.max(1, Math.min(126, Math.round(_gPhFrac * 128)));
      fill_rect(_gPhX, _gY + 1, 1, _gH - 2, 1);
    }
    if (S.heldStep >= 0) {
      var _gSx = Math.floor(S.heldStep * 128 / _gDataLen);
      if (_gSx > 127) _gSx = 127;
      fill_rect(_gSx, _gY, 1, _gH, 0);
    }
    var _gWinPages = Math.max(1, Math.ceil(_gEffLen / 16));
    var _gViewPage = Math.max(0, Math.min(S.trackCurrentPage[_gt], _gWinPages - 1));
    var _gSegGap = 1;
    var _gSegW = Math.max(2, Math.floor((120 - (_gWinPages - 1) * _gSegGap) / _gWinPages));
    var _gPlayPage = -1;
    if (S.playing) {
      var _gProg2 = S.masterPos % (_gEffLen * _gLTps) / (_gEffLen * _gLTps);
      _gPlayPage = Math.floor(_gProg2 * _gWinPages);
    }
    for (var _gPg = 0; _gPg < _gWinPages; _gPg++) {
      var _gx = 4 + _gPg * (_gSegW + _gSegGap);
      if (_gPg === _gViewPage) {
        fill_rect(_gx, _gBarY, _gSegW, _gBarH, 1);
      } else if (_gPg === _gPlayPage) {
        fill_rect(_gx, _gBarY, _gSegW, 1, 1);
        fill_rect(_gx, _gBarY + _gBarH - 1, _gSegW, 1, 1);
        fill_rect(_gx, _gBarY, 1, _gBarH, 1);
        fill_rect(_gx + _gSegW - 1, _gBarY, 1, _gBarH, 1);
      } else {
        fill_rect(_gx, _gBarY + _gBarH - 1, _gSegW, 1, 1);
      }
    }
    if (S.playing) {
      var _gBarW = _gWinPages * (_gSegW + _gSegGap) - _gSegGap;
      var _gDotX = 4 + Math.floor(_gProg2 * _gBarW);
      var _gViewStart = 4 + _gViewPage * (_gSegW + _gSegGap);
      var _gOnSolid = _gDotX >= _gViewStart && _gDotX < _gViewStart + _gSegW;
      fill_rect(_gDotX, _gBarY, 1, _gBarH, _gOnSolid ? 0 : 1);
    }
    return;
  }
  if (S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT && (bank === BANK_RESPONDER || bank === BANK_OCTAVE || bank === BANK_WHEN) && (S.knobTouched >= 0 || inTimeout)) {
    const _ch = bankHeaderName(S.activeTrack, bank);
    if (bank === BANK_RESPONDER) {
      const _cc = S.trackActiveClip[S.activeTrack] | 0;
      drawConductToggleGrid(_ch, function(k) {
        return S.condResp[_cc][k];
      });
    } else if (bank === BANK_OCTAVE) {
      drawConductTrackGrid(_ch, function(k) {
        if (S.trackPadMode[k] === PAD_MODE_DRUM) return "--";
        const o = S.condOct[S.trackActiveClip[S.activeTrack] | 0][k];
        return o === 0 ? "--" : o > 0 ? "+" + o : "" + o;
      }, "Cndct");
    } else {
      drawConductTrackGrid(_ch, function(k) {
        return S.trackPadMode[k] === PAD_MODE_DRUM ? "--" : S.condWhen[S.trackActiveClip[S.activeTrack] | 0][k] ? "Now" : "Next";
      }, "Cndct");
    }
    return;
  }
  if (bank >= 0 && (S.knobTouched >= 0 || inTimeout || S.altMode && bankHasAltParams(S.activeTrack, bank) || S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 7 && !S.allLanesConfirmed)) {
    const isDrumLaneBank = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 0;
    if (isDrumLaneBank) {
      const t = S.activeTrack;
      const ac = effectiveClip(t);
      const lane = S.activeDrumLane[t];
      const len = S.drumLaneLength[t];
      const tpsIdx = Math.max(0, TPS_VALUES.indexOf(S.drumLaneTPS[t]));
      const sqfl = S.clipSeqFollow[t][ac] ? 1 : 0;
      const eucN = Math.min(S.drumLaneEuclidN[t][lane] | 0, len);
      const _dlRev = S.drumLanePlaybackAudioReverse[t][lane] | 0;
      const _dlDir = S.drumLanePlaybackDir[t][lane] | 0;
      const cells = [
        {
          kind: "enumsq",
          label: S.altMode ? "Zoom" : "Res",
          name: S.altMode ? "Zoom" : "Resolution",
          text: fmtRes(tpsIdx),
          options: [0, 1, 2, 3, 4, 5].map(fmtRes),
          sel: tpsIdx
        },
        {
          kind: "action",
          label: "Strch",
          name: "Beat Stretch",
          text: fmtStretch(S.bankParams[t][0][1])
        },
        {
          kind: "action",
          label: S.altMode ? "Nudge" : "Shift",
          name: S.altMode ? "Nudge" : "Clock Shift",
          text: fmtSign(S.bankParams[t][0][2])
        },
        { kind: "action", oneWay: true, label: "Lgto", name: "Apply Legato", text: "->" },
        { kind: "valsq", label: "Eucld", name: "Euclid Fill", text: String(eucN) },
        { kind: "blank", label: "" },
        S.altMode ? {
          kind: "hbar",
          label: "Revrs",
          name: "Reverse Style",
          text: fmtRevStyle(_dlRev),
          norm: _dlRev ? 1 : 0
        } : {
          kind: "dirsq",
          label: "Dir",
          name: "Playback Dir",
          text: fmtPlayDir(_dlDir),
          options: KIT_DIR_NAMES,
          sel: _dlDir
        },
        {
          kind: "hbar",
          label: "SeqFl",
          name: "Seq Follow",
          text: fmtBool(sqfl),
          norm: sqfl ? 1 : 0
        }
      ];
      drawKitPage("DRUM LANE", cells, false);
    } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 7 && !S.allLanesConfirmed) {
      drawKitHeader((Math.floor(S.tickCount / 24) % 2 === 0 ? "ALL" : "   ") + " LANES", false);
      const _alPos = bankCyclePos();
      drawKitPageBar(_alPos.idx, _alPos.count);
      print(10, 18, "Edits will affect", 1);
      print(10, 28, "all lanes. Proceed?", 1);
      fill_rect(40, 44, 48, 16, 1);
      print(52, 48, "OK", 0);
    } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 7) {
      const t = S.activeTrack;
      const rv = S.bankParams[t][7][0];
      const qv = S.bankParams[t][7][3];
      const dv = S.bankParams[t][7][6];
      const DIQ_LABELS = ["Off", "1/64", "1/32", "1/16", "1/16T", "1/8", "1/8T", "1/4", "1/4T"];
      const _inq = S.drumInpQuant[t] | 0;
      const cells = [
        rv < 0 ? { kind: "valsq", label: "Res", name: "Resolution", text: "--" } : {
          kind: "enumsq",
          label: "Res",
          name: "Resolution",
          text: fmtRes(rv),
          options: [0, 1, 2, 3, 4, 5].map(fmtRes),
          sel: rv
        },
        {
          kind: "action",
          label: "Strch",
          name: "Beat Stretch",
          text: fmtStretch(S.bankParams[t][7][1])
        },
        {
          kind: "action",
          label: S.altMode ? "Nudge" : "Shift",
          name: S.altMode ? "Nudge" : "Clock Shift",
          text: fmtSign(S.bankParams[t][7][2])
        },
        qv <= 0 ? { kind: "valsq", label: "Quant", name: "Quantize", text: "--" } : {
          kind: "arc",
          label: "Quant",
          name: "Quantize",
          text: fmtPct(qv),
          norm: Math.min(1, qv / 100)
        },
        {
          kind: "valsq",
          label: "VelIn",
          name: "Velocity Input",
          text: fmtVelOverride(S.trackVelOverride[t])
        },
        {
          kind: "enumsq",
          label: "InQnt",
          name: "Input Quantize",
          text: DIQ_LABELS[_inq] || "Off",
          options: DIQ_LABELS,
          sel: _inq
        },
        dv < 0 ? {
          kind: "valsq",
          label: S.altMode ? "Revrs" : "Dir",
          name: S.altMode ? "Reverse Style" : "Playback Dir",
          text: "--"
        } : S.altMode ? {
          kind: "hbar",
          label: "Revrs",
          name: "Reverse Style",
          text: fmtRevStyle(dv),
          norm: dv ? 1 : 0
        } : {
          kind: "dirsq",
          label: "Dir",
          name: "Playback Dir",
          text: fmtPlayDir(dv),
          options: KIT_DIR_NAMES,
          sel: dv
        },
        {
          kind: "hbar",
          label: "RSync",
          name: "Repeat Sync",
          text: fmtBool(S.bankParams[t][7][7]),
          norm: S.bankParams[t][7][7] ? 1 : 0
        }
      ];
      drawKitPage((Math.floor(S.tickCount / 24) % 2 === 0 ? "ALL" : "   ") + " LANES", cells, false);
    } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 1) {
      const t = S.activeTrack;
      const vals = S.bankParams[t][1];
      const _lane = S.activeDrumLane[t];
      const _dlNote = S.drumLaneNote[t][_lane];
      const _noteStr = midiNoteName(_dlNote) + " " + _dlNote;
      const _lenMode = S.drumLaneLenMode[t][_lane] | 0;
      const LEN_OPTS = [0, 1, 2, 3, 4, 5, 6, 7, 8].map(fmtLen);
      const cells = [
        { kind: "blank", label: "Oct", name: "Lane Note" },
        { kind: "blank", label: "Note", name: "Lane Note" },
        {
          kind: "arcbip",
          label: "Vel",
          name: "Velocity Offset",
          text: fmtSign(vals[1]),
          signed: Math.max(-1, Math.min(1, (vals[1] | 0) / 127))
        },
        {
          kind: "arc",
          label: "Quant",
          name: "Quantize",
          text: fmtPct(vals[2]),
          norm: Math.max(0, Math.min(1, (vals[2] | 0) / 100))
        },
        {
          kind: "enumsq",
          label: "Len>",
          name: "Note Length",
          text: fmtLen(_lenMode),
          options: LEN_OPTS,
          sel: _lenMode
        },
        {
          kind: "arc",
          label: ">Gate",
          name: "Gate Time",
          text: fmtPct(vals[0]),
          norm: Math.max(0, Math.min(1, (vals[0] | 0) / 400))
        },
        { kind: "blank", label: "" },
        { kind: "blank", label: "" }
      ];
      {
        const _tch = S.knobTouched;
        const _tcell = _tch >= 0 && cells[_tch] && cells[_tch].name ? cells[_tch] : null;
        if (_tcell) drawKitTouchedHeader(_tcell.name);
        else drawBankHeading("NOTE FX", false);
        drawKitCells(cells, _tch);
        const hiLane = _tch === 0 || _tch === 1;
        const BX = 6, BW = 52, BY = MV_ROW0_Y, BH = MV_KH;
        if (hiLane) fill_rect(BX, BY, BW, BH, 1);
        else rectOutline(BX, BY, BW, BH, 1);
        mvPrint(
          BX + Math.round((BW - mvWidth(_noteStr)) / 2),
          BY + Math.floor((BH - 5) / 2),
          _noteStr,
          hiLane ? 0 : 1
        );
        drawKitEnumOverlay(cells, _tch);
      }
    } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 5) {
      const t = S.activeTrack;
      const lane = S.activeDrumLane[t];
      syncDrumRepeatState(t, lane);
      const _gLen = S.drumRepeatGateLen[t][lane];
      const _tk = S.knobTouched;
      if (_tk >= 0 && _tk < _gLen) {
        const _ndg = S.drumRepeatNudge[t][lane][_tk];
        const _tv = S.drumRepeatVelScale[t][lane][_tk] | 0;
        const _val = S.altMode ? (_ndg > 0 ? "+" : "") + _ndg + "%" : _tv > 127 ? "Thru" : String(_tv);
        drawKitTouchedHeader((S.altMode ? "Nudge" : "Velocity") + ": " + _val);
      } else {
        drawBankHeadingInverted("REPEAT GROOVE");
      }
      const _colW = 16, _barW = 10, _top = 14, _bot = 54, _numY = 57;
      if (S.altMode) {
        const _cy = Math.floor((_top + _bot) / 2);
        for (let x = 0; x < 128; x += 2) set_pixel(x, _cy, 1);
      } else {
        fill_rect(0, _bot + 1, 128, 1, 1);
      }
      for (let k = 0; k < 8; k++) {
        const _x = k * _colW + 3;
        if (k >= _gLen) {
          fill_rect(_x + 3, _bot - 1, 4, 1, 1);
          continue;
        }
        const gateOn = !!(S.drumRepeatGate[t][lane] & 1 << k);
        if (S.altMode) {
          const _cy = Math.floor((_top + _bot) / 2);
          const _n = S.drumRepeatNudge[t][lane][k] | 0;
          const _mag = Math.round(Math.abs(_n) / 50 * (_cy - _top));
          const _y = _n >= 0 ? _cy - _mag : _cy + 1;
          const _h = Math.max(1, _mag);
          if (_n === 0) fill_rect(_x, _cy - 1, _barW, 3, 1);
          else if (gateOn) fill_rect(_x, _y, _barW, _h, 1);
          else rectOutline(_x, _y, _barW, Math.max(2, _h), 1);
        } else {
          const _v = S.drumRepeatVelScale[t][lane][k] | 0;
          if (_v > 127) {
            if (gateOn) drawThruBar(_x, _barW, _top, _bot);
            else rectOutline(_x, _top, _barW, _bot - _top + 1, 1);
          } else {
            const _h = Math.max(1, Math.round(_v / 127 * (_bot - _top)));
            const _y = _bot - _h;
            if (gateOn) fill_rect(_x, _y, _barW, _h, 1);
            else rectOutline(_x, _y, _barW, Math.max(2, _h), 1);
          }
        }
        const _num = String(k + 1);
        const _nw = mvWidth(_num);
        const _nx = Math.round(k * _colW + _colW / 2 - _nw / 2);
        if (k === _tk) {
          fill_rect(k * _colW + 2, _numY - 1, _colW - 4, 7, 1);
          mvPrint(_nx, _numY, _num, 0);
        } else {
          mvPrint(_nx, _numY, _num, 1);
        }
      }
    } else if (bank === 6) {
      const t = S.activeTrack;
      const ac = effectiveClip(t);
      drawBankHeadingInverted(S.altMode ? "ASSIGN" : BANKS[6].name);
      const _ovLane = S.knobTouched >= 0 ? S.knobTouched : S.ccActiveLane[t];
      for (let k = 0; k < 8; k++) {
        const colX = 4 + k % 4 * 31;
        const rowY = 11 + (k < 4 ? 0 : 18);
        const touchedHi = S.knobTouched === k || S.ccActiveLane[t] === k;
        const lbl = S.trackCCType[t][k] === 2 ? "Sch" + S.trackCCAssign[t][k] : S.trackCCType[t][k] === 1 ? "AT" : fmtCCLabel(S.trackCCAssign[t][k]);
        const rawV = S.playing ? S.trackCCLiveVal[t][k] : S.clipCCVal[t][ac][k];
        const val = rawV >= 0 && rawV <= 127 ? String(rawV) : "--";
        if (S.altMode) {
          fill_rect(colX - 1, rowY - 1, 29, 9, 1);
          if (touchedHi) fill_rect(colX - 1, rowY + 8, 29, 9, 1);
          mvPrint(colX, rowY + 1, lbl, 0);
          mvPrint(colX, rowY + 10, val, touchedHi ? 0 : 1);
        } else {
          if (touchedHi) fill_rect(colX - 1, rowY - 1, 29, 18, 1);
          mvPrint(colX, rowY + 1, lbl, touchedHi ? 0 : 1);
          mvPrint(colX, rowY + 10, val, touchedHi ? 0 : 1);
        }
      }
      {
        const _gEffLen2 = S.ccLaneLength[t][ac][_ovLane] || S.clipLength[t][ac];
        const _gY2 = 46, _gH2 = 12;
        const _gPages2 = Math.ceil(_gEffLen2 / 16);
        const _gKey2 = "sg_" + t + "_" + ac + "_" + _ovLane + "_" + _gEffLen2;
        if (_gKey2 !== S.ccGraphOvKey || S.tickCount % POLL_INTERVAL === 0) {
          S.ccGraphOvData = [];
          for (let _gp2 = 0; _gp2 < _gPages2; _gp2++) {
            const _gRaw2 = typeof host_module_get_param === "function" ? host_module_get_param("t" + t + "_c" + ac + "_ccsv_" + _ovLane + "_" + _gp2) : null;
            if (_gRaw2) {
              const _gParts2 = _gRaw2.split(" ");
              for (let _gs2 = 0; _gs2 < 16 && _gp2 * 16 + _gs2 < _gEffLen2; _gs2++)
                S.ccGraphOvData.push(_gs2 < _gParts2.length ? parseInt(_gParts2[_gs2], 10) : 255);
            }
          }
          S.ccGraphOvKey = _gKey2;
        }
        fill_rect(0, _gY2, 128, 1, 1);
        fill_rect(0, _gY2 + _gH2 - 1, 128, 1, 1);
        fill_rect(0, _gY2, 1, _gH2, 1);
        fill_rect(127, _gY2, 1, _gH2, 1);
        const _dLen = S.ccGraphOvData.length || 1;
        const _dY = _gY2 + 2, _dH = _gH2 - 4;
        let _prevPy = -1;
        for (let _gc2 = 1; _gc2 < 127; _gc2++) {
          const _idx = Math.floor(_gc2 * _dLen / 128);
          const _gv2 = _idx < S.ccGraphOvData.length ? S.ccGraphOvData[_idx] : -1;
          if (_gv2 >= 0 && _gv2 <= 127) {
            const _py = _dY + _dH - 1 - Math.round(_gv2 * (_dH - 1) / 127);
            if (_prevPy >= 0 && _prevPy !== _py)
              fill_rect(_gc2, Math.min(_prevPy, _py), 1, Math.abs(_py - _prevPy) + 1, 1);
            else
              fill_rect(_gc2, _py, 1, 1, 1);
            _prevPy = _py;
          } else {
            _prevPy = -1;
          }
        }
        if (S.playing) {
          const _pvSpeed = S.ccLaneResTps[t][ac][_ovLane] || S.ccLaneTps[t][ac][_ovLane] || (S.clipTPS[t][ac] || 24);
          const _pvDen = _gEffLen2 * _pvSpeed;
          const _pvFrac = _pvDen > 0 ? S.masterPos % _pvDen / _pvDen : 0;
          const _pvX = Math.max(1, Math.min(126, Math.round(_pvFrac * 128)));
          fill_rect(_pvX, _gY2 + 1, 1, _gH2 - 2, 1);
        }
      }
    } else if (S.trackPadMode[S.activeTrack] !== PAD_MODE_DRUM && bank === 1) {
      const t = S.activeTrack;
      const knobs = BANKS[1].knobs;
      const vals = S.bankParams[t][1];
      const RND_ALG_NAMES_NFX = ["Pure", "Gaus", "Walk"];
      const _conductNfx = S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT;
      const cells = [];
      for (let k = 0; k < 8; k++) {
        if (k === 6) {
          cells.push({ kind: "blank", label: "" });
          continue;
        }
        if (_conductNfx && (k === 2 || k === 3 || k === 4 || k === 5)) {
          cells.push({ kind: "blank", label: "-" });
          continue;
        }
        if (S.altMode && k === 7) {
          const _md = S.noteFXRandomMode[t] || 0;
          cells.push({
            kind: "enumsq",
            label: "Algo",
            name: "Random Algo",
            text: RND_ALG_NAMES_NFX[_md],
            options: RND_ALG_NAMES_NFX,
            sel: _md
          });
          continue;
        }
        cells.push(kitCellForKnob(knobs[k], vals[k]));
      }
      drawKitPage(BANKS[1].name, cells, false);
    } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && bank === 3) {
      const t = S.activeTrack;
      const vals = S.bankParams[t][3];
      const knobs = BANKS[3].knobs;
      const cells = [
        kitCellForKnob(knobs[0], vals[0]),
        kitCellForKnob(knobs[1], vals[1]),
        kitCellForKnob(knobs[2], vals[2]),
        kitCellForKnob(knobs[3], vals[3]),
        {
          kind: "enumsq",
          label: "Gate",
          name: "Gate",
          text: fmtGateMod(vals[4]),
          options: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(fmtGateMod),
          sel: vals[4] | 0
        },
        {
          kind: "arcbip",
          label: "ClkFb",
          name: "Clock Feedback",
          text: fmtSign(vals[5]),
          signed: Math.max(-1, Math.min(1, (vals[5] | 0) / 127))
        },
        {
          kind: "hbar",
          label: "Retrg",
          name: "Retrig",
          text: fmtBool(vals[6]),
          norm: vals[6] ? 1 : 0
        },
        { kind: "blank", label: "" }
      ];
      drawKitPage(BANKS[3].name, cells, false);
    } else {
      const knobs = BANKS[bank].knobs;
      const vals = S.bankParams[S.activeTrack][bank];
      const _isDrum = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM;
      const RND_ALG_NAMES = ["Pure", "Gaus", "Walk"];
      const cells = [];
      for (let k = 0; k < 8; k++) {
        if (bank === 0 && k === 5 && S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT) {
          const _cdc = S.trackActiveClip[S.activeTrack] | 0;
          const _lk = S.condLock[_cdc] ? 1 : 0;
          cells.push({
            kind: "hbar",
            label: "CdLk",
            name: "Conduct Lock",
            text: _lk ? "Lock" : "Off",
            norm: _lk
          });
          continue;
        }
        const _delayShiftClkF = S.altMode && !_isDrum && bank === 3 && k === 0;
        const _clipDirAlt = S.altMode && !_isDrum && knobs[k].dspKey === "clip_playback_dir";
        const _rndAltAlgo = S.altMode && !_isDrum && (bank === 1 || bank === 3) && k === 7;
        if (_rndAltAlgo) {
          const _md = bank === 3 ? S.midiDlyRandomMode[S.activeTrack] || 0 : S.noteFXRandomMode[S.activeTrack] || 0;
          cells.push({
            kind: "enumsq",
            label: "Algo",
            name: "Random Algo",
            text: RND_ALG_NAMES[_md],
            options: RND_ALG_NAMES,
            sel: _md
          });
          continue;
        }
        if (_delayShiftClkF) {
          const _cv = S.delayClockFb[S.activeTrack] | 0;
          cells.push({
            kind: "arcbip",
            label: "ClkFb",
            name: "Clock Feedback",
            text: fmtSign(_cv),
            signed: Math.max(-1, Math.min(1, _cv / 127))
          });
          continue;
        }
        if (_clipDirAlt) {
          const _rv = S.clipPlaybackAudioReverse[S.activeTrack][effectiveClip(S.activeTrack)] | 0;
          cells.push({
            kind: "hbar",
            label: "Revrs",
            name: "Reverse Style",
            text: fmtRevStyle(_rv),
            norm: _rv ? 1 : 0
          });
          continue;
        }
        const cell = kitCellForKnob(knobs[k], vals[k]);
        if (S.altMode) {
          if (knobs[k].dspKey === "clock_shift") {
            cell.label = "Nudge";
            cell.name = "Nudge";
          } else if (knobs[k].dspKey === "clip_resolution") {
            cell.label = "Zoom";
            cell.name = "Zoom";
          }
        }
        cells.push(cell);
      }
      drawKitPage(bankHeaderName(S.activeTrack, bank), cells, false);
    }
  } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
    const t = S.activeTrack;
    const lane = S.activeDrumLane[t];
    const pg = S.drumLanePage[t];
    const note = S.drumLaneNote[t][lane];
    const oct = Math.floor(note / 12) - 2;
    const name = NOTE_KEYS[note % 12];
    const bankGroup = pg === 0 ? "Bank:A" : "Bank:B";
    const bankName = S.activeBank === 0 ? "DRUM LANE" : S.activeBank === 1 ? "NOTE FX" : S.activeBank === 5 ? "REPEAT GROOVE" : S.activeBank === 6 ? BANKS[6].name : S.activeBank === 7 ? (Math.floor(S.tickCount / 24) % 2 === 0 ? "ALL" : "   ") + " LANES" : BANKS[S.activeBank] ? BANKS[S.activeBank].name : "?";
    (S.activeBank === 5 || S.activeBank === 6 ? drawBankHeadingInverted : drawBankHeading)(bankName, false);
    pixelPrint(4, 12, bankGroup + "  Pad:" + name + oct + " (" + note + ")", 1);
    const laneBit = 1 << lane;
    if (S.drumLaneSolo[t] & laneBit) {
      pixelPrint(128 - 4 - 6 * 6, 22, "SOLOED", 1);
    } else if (S.drumLaneMute[t] & laneBit) {
      if (Math.floor(S.tickCount / 50) % 2 === 0)
        pixelPrint(128 - 4 - 5 * 6, 22, "MUTED", 1);
    }
    drawMetroIndicator();
    drawTrackRow(35);
    for (let _t = 0; _t < NUM_TRACKS; _t++) {
      const _cx = _t * 16 + 5;
      const _ac = S.trackActiveClip[_t];
      const _hasData = S.trackPadMode[_t] === PAD_MODE_DRUM ? S.drumClipNonEmpty[_t][_ac] : S.clipNonEmpty[_t][_ac];
      const _isActive = (S.trackClipPlaying[_t] || S.trackWillRelaunch[_t] || S.trackQueuedClip[_t] >= 0) && _hasData;
      if (_isActive) {
        fill_rect(_cx - 1, 46, 9, 7, 1);
        pixelPrint(_cx, 47, SCENE_LETTERS[_ac], 0);
      } else {
        pixelPrint(_cx, 47, SCENE_LETTERS[_ac], 1);
      }
    }
    drawDrumPositionBar(t);
  } else {
    const recTag = S.recordArmed && !S.recordCountingIn && S.recordArmedTrack === S.activeTrack ? " REC" : "";
    const oct = S.trackOctave[S.activeTrack];
    const octStr = "Oct:" + (oct >= 0 ? "+" : "") + oct;
    const keyScl = NOTE_KEYS[S.padKey] + " " + (SCALE_DISPLAY[S.padScale] || "?");
    const CHAR_W = 6;
    const keySclX = 128 - 4 - keyScl.length * CHAR_W;
    (S.activeBank === 5 || S.activeBank === 6 ? drawBankHeadingInverted : drawBankHeading)(bankHeaderName(S.activeTrack, S.activeBank) + recTag, false);
    pixelPrint(4, 12, octStr, 1);
    if (S.bankParams[S.activeTrack][5][0]) {
      if (S.bankParams[S.activeTrack][5][7]) {
        fill_rect(51, 11, 19, 7, 1);
        pixelPrint(52, 12, "Arp", 0);
      } else {
        pixelPrint(52, 12, "Arp", 1);
      }
    }
    pixelPrint(keySclX, 12, keyScl, 1);
    if (S.scaleAware) fill_rect(keySclX, 17, keyScl.length * CHAR_W, 1, 1);
    drawMetroIndicator();
    drawTrackRow(35);
    for (let t = 0; t < NUM_TRACKS; t++) {
      const _cx = t * 16 + 5;
      const _ac = S.trackActiveClip[t];
      const _hasData = S.trackPadMode[t] === PAD_MODE_DRUM ? S.drumClipNonEmpty[t][_ac] : S.clipNonEmpty[t][_ac];
      const _isActive = (S.trackClipPlaying[t] || S.trackWillRelaunch[t] || S.trackQueuedClip[t] >= 0) && _hasData;
      if (_isActive) {
        fill_rect(_cx - 1, 46, 9, 7, 1);
        pixelPrint(_cx, 47, SCENE_LETTERS[_ac], 0);
      } else {
        pixelPrint(_cx, 47, SCENE_LETTERS[_ac], 1);
      }
    }
    drawPositionBar(S.activeTrack);
  }
}
function drawDrumPositionBar(t) {
  const lsBase = S.drumLaneLoopStart[t] | 0;
  const len = S.drumLaneLength[t];
  const startPage = lsBase >> 4;
  const winPages = Math.max(1, Math.ceil(len / 16));
  const viewPage = Math.max(0, Math.min(S.drumStepPage[t] - startPage, winPages - 1));
  const cs = S.drumCurrentStep[t];
  const playPage = S.playing && S.trackClipPlaying[t] && cs >= lsBase && cs < lsBase + len ? Math.floor((cs - lsBase) / 16) : -1;
  const barY = 57, barH = 5, segGap = 1;
  const segW = Math.max(2, Math.floor((120 - (winPages - 1) * segGap) / winPages));
  const startX = 4;
  for (let pg = 0; pg < winPages; pg++) {
    const x = startX + pg * (segW + segGap);
    if (pg === viewPage) {
      fill_rect(x, barY, segW, barH, 1);
    } else if (pg === playPage) {
      fill_rect(x, barY, segW, 1, 1);
      fill_rect(x, barY + barH - 1, segW, 1, 1);
      fill_rect(x, barY, 1, barH, 1);
      fill_rect(x + segW - 1, barY, 1, barH, 1);
    } else {
      fill_rect(x, barY + barH - 1, segW, 1, 1);
    }
  }
  if (S.playing && S.trackClipPlaying[t] && cs >= lsBase && cs < lsBase + len) {
    const winPxW = winPages * (segW + segGap) - segGap;
    const dotX = startX + Math.floor((cs - lsBase) * winPxW / Math.max(1, len));
    const viewSegStart = startX + viewPage * (segW + segGap);
    const onSolid = dotX >= viewSegStart && dotX < viewSegStart + segW;
    fill_rect(dotX, barY, 1, barH, onSolid ? 0 : 1);
  }
  const lane = S.activeDrumLane[t];
  const steps = S.drumLaneSteps[t][lane];
  let hasLeft = false, hasRight = false;
  for (let s = 0; s < lsBase; s++) if (steps[s] !== "0") {
    hasLeft = true;
    break;
  }
  for (let s = lsBase + len; s < 256; s++) if (steps[s] !== "0") {
    hasRight = true;
    break;
  }
  if (hasLeft) fill_rect(startX - 2, barY + 1, 1, barH - 2, 1);
  if (hasRight) {
    const xRight = startX + winPages * (segW + segGap) - segGap + 1;
    fill_rect(xRight, barY + 1, 1, barH - 2, 1);
  }
}

// ui/ui_tick.mjs
var BANK_DISPLAY_TICKS = 94;
var KNOB_TURN_HIGHLIGHT_TICKS = 56;
var STEP_HOLD_TICKS = 19;
var STEP_SAVE_HOLD_TICKS = 70;
var STEP_SAVE_FLASH_TICKS = 40;
function playMetronomeClick() {
}
function trackHasAnyData(t) {
  for (let c = 0; c < NUM_CLIPS; c++)
    if (S.clipNonEmpty[t][c] || S.drumClipNonEmpty[t][c]) return true;
  return false;
}
function convertTrackType(t, toDrum) {
  if (typeof host_module_set_param !== "function") return;
  host_module_set_param("t" + t + (toDrum ? "_convert_to_drum" : "_convert_to_melodic"), "1");
  S.trackPadMode[t] = toDrum ? PAD_MODE_DRUM : PAD_MODE_MELODIC_SCALE;
  if (trackHasAnyData(t)) syncClipsFromDsp();
  else host_module_get_param("t" + t + "_pad_mode");
  if (toDrum) {
    if (t === S.activeTrack && (S.activeBank === 2 || S.activeBank === 4)) S.activeBank = 0;
  } else {
    if (t === S.activeTrack && S.activeBank === 7) S.activeBank = 0;
    S.drumVelZoneArmed[t] = false;
    S.drumLastVelZone[t] = 0;
  }
  computePadNoteMap();
  invalidateLEDCache();
  forceRedraw();
}
function convertTrackToConduct(t) {
  if (typeof host_module_set_param !== "function") return;
  const prevMode = S.trackPadMode[t];
  host_module_set_param("t" + t + "_convert_to_conduct", "1");
  S.trackPadMode[t] = PAD_MODE_CONDUCT;
  S.pendingConductReadback = { t, prevMode };
  if (trackHasAnyData(t)) syncClipsFromDsp();
  else host_module_get_param("t" + t + "_pad_mode");
  computePadNoteMap();
  invalidateLEDCache();
  forceRedraw();
}
function applyExtMidiRemap() {
  const t = S.activeTrack;
  const isMove = S.trackRoute[t] === 1;
  const hasRemap = typeof host_ext_midi_remap_enable === "function";
  if (!hasRemap) return;
  if (!isMove) {
    host_ext_midi_remap_clear();
    for (var _i = 0; _i < 16; _i++) {
      host_ext_midi_remap_set(_i, 254);
    }
    host_ext_midi_remap_enable(1);
    S.extMidiRemapActive = false;
    return;
  }
  const outCh = S.trackChannel[t] - 1;
  host_ext_midi_remap_clear();
  if (S.midiInChannel === 0) {
    for (var _i = 0; _i < 16; _i++) {
      if (_i !== outCh) host_ext_midi_remap_set(_i, outCh);
    }
  } else {
    const inCh = S.midiInChannel - 1;
    if (inCh !== outCh) host_ext_midi_remap_set(inCh, outCh);
  }
  host_ext_midi_remap_enable(1);
  S.extMidiRemapActive = true;
}
function sceneAllPlaying(sceneIdx) {
  let hasAny = false;
  if (S.playing) {
    for (let t = 0; t < NUM_TRACKS; t++) {
      if (!S.trackClipPlaying[t]) continue;
      if (S.trackActiveClip[t] !== sceneIdx) return false;
      hasAny = true;
    }
  } else {
    for (let t = 0; t < NUM_TRACKS; t++) {
      if (!S.trackWillRelaunch[t] && S.trackQueuedClip[t] < 0) continue;
      if (effectiveClip(t) !== sceneIdx) return false;
      hasAny = true;
    }
  }
  return hasAny;
}
function sceneAnyPlaying(sceneIdx) {
  for (let t = 0; t < NUM_TRACKS; t++) {
    if (S.trackClipPlaying[t] && S.trackActiveClip[t] === sceneIdx) return true;
  }
  return false;
}
var _lastSessionView = false;
function _tickImpl() {
  S.tickCount++;
  if (S.bootSplashTicks > 0) S.bootSplashTicks--;
  checkBackHold();
  if (typeof host_module_get_param !== "function" || typeof host_module_set_param !== "function") return;
  pollPendingExport();
  if (S.pendingTrackConvert) {
    const _pc = S.pendingTrackConvert;
    S.pendingTrackConvert = null;
    convertTrackType(_pc.t, _pc.toDrum);
  }
  if (S.pendingConductConvert !== null) {
    const _cct = S.pendingConductConvert;
    S.pendingConductConvert = null;
    convertTrackToConduct(_cct);
  }
  if (S.pendingConductReadback !== null && typeof host_module_get_param === "function") {
    const _rb = S.pendingConductReadback;
    S.pendingConductReadback = null;
    const _raw = host_module_get_param("conductor_track");
    const _ct = parseInt(_raw, 10);
    const _val = isNaN(_ct) ? -1 : _ct;
    if (_val === _rb.t) {
      S.conductorTrack = _val;
    } else if (_val >= 0) {
      S.conductorTrack = _val;
      S.trackPadMode[_rb.t] = _rb.prevMode;
      computePadNoteMap();
      invalidateLEDCache();
      forceRedraw();
      showMenuInfo("Conductor exists", "on T" + (_val + 1) + ".", "Route it back first.");
      S.screenDirty = true;
    } else {
      S.conductorTrack = _val;
      S.trackPadMode[_rb.t] = _rb.prevMode;
      computePadNoteMap();
      invalidateLEDCache();
      forceRedraw();
    }
  }
  if (S.pendingPadNoteMapRecompute && S.pendingDefaultSetParams.length === 0 && S.clearDrainHold === 0) {
    S.pendingPadNoteMapRecompute = false;
    computePadNoteMap();
  }
  if (S.dspInboundEnabled) {
    const _muted = _padDispatchMutedNow();
    if (_muted !== S.lastPushedMuted) computePadNoteMap();
    if (S.tickCount % 5 === 0 && typeof host_module_get_param === "function") {
      const _dspM = host_module_get_param("pad_dispatch_muted");
      if (_dspM !== null && _dspM !== void 0) {
        const _dspMi = parseInt(_dspM, 10);
        const _jsM = _muted ? 1 : 0;
        if (_dspMi !== _jsM) computePadNoteMap();
      }
      const _dspMap0 = host_module_get_param("pad_note_map_0");
      if (_dspMap0 !== null && _dspMap0 !== void 0) {
        const _dspMap0i = parseInt(_dspMap0, 10);
        const _jsMap0 = _muted && S.sessionView ? 255 : Math.max(0, Math.min(127, (S.padNoteMap[0] | 0) + (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM ? 0 : (S.trackOctave[S.activeTrack] | 0) * 12)));
        const _expect = S.padNoteMap[0] === 255 ? 255 : _jsMap0;
        if (_dspMap0i !== _expect) computePadNoteMap();
      }
    }
  }
  _drainLiveNotes();
  {
    const _rt = S.activeTrack;
    const _rr = S.trackRoute[_rt];
    const _rc = S.trackChannel[_rt];
    const _rm = S.midiInChannel;
    if (_rt !== S.lastRemapTrack || _rr !== S.lastRemapRoute || _rc !== S.lastRemapChannel || _rm !== S.lastRemapMidiIn) {
      flushHeldMoveExtNotes();
      applyExtMidiRemap();
      S.lastRemapTrack = _rt;
      S.lastRemapRoute = _rr;
      S.lastRemapChannel = _rc;
      S.lastRemapMidiIn = _rm;
    }
  }
  if (S.sessionView && !_lastSessionView) {
    const _t = S.activeTrack;
    if (S.bankParams[_t][5][7] | 0) {
      S.bankParams[_t][5][7] = 0;
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + _t + "_tarp_latch", "0");
    }
  }
  if (S.sessionView !== _lastSessionView) {
    computePadNoteMap();
  }
  _lastSessionView = S.sessionView;
  const isSuspended = S._origClearScreen && clear_screen !== S._origClearScreen;
  if (isSuspended && !S._wasSuspended) {
    saveState();
    removeFlagsWrap();
    if (typeof host_ext_midi_remap_enable === "function") host_ext_midi_remap_enable(0);
  }
  if (!isSuspended && S._wasSuspended) {
    installFlagsWrap();
    applyExtMidiRemap();
    S.shiftHeld = false;
    S.deleteHeld = false;
    S.muteHeld = false;
    S.copyHeld = false;
    S.loopHeld = false;
    S.loopJogActive = false;
    S.captureHeld = false;
    S.shiftTrackLEDActive = false;
    S.heldStep = -1;
    S.heldStepBtn = -1;
    S.heldStepNotes = [];
    S.stepWasEmpty = false;
    S.stepWasHeld = false;
    assertOvertakeSysexSuppress();
    const _as = readActiveSet();
    const _dspUuid = typeof host_module_get_param === "function" ? host_module_get_param("state_uuid") || "" : "";
    if (_as.uuid && _dspUuid !== _as.uuid) {
      S.currentSetUuid = _as.uuid;
      S.currentSetName = _as.name;
      const _r = maybeShowInheritPicker(_as.uuid, _as.name);
      if (_r !== "picker") S.pendingSetLoad = true;
    }
    S.ledInitComplete = false;
    invalidateLEDCache();
    S.ledInitQueue = buildLedInitQueue();
    S.ledInitIndex = 0;
    forceRedraw();
  }
  S._wasSuspended = isSuspended;
  if (S.metroNoteOffTick >= 0 && S.tickCount >= S.metroNoteOffTick) {
    S.metroNoteOffTick = -1;
    if (typeof move_midi_inject_to_move === "function")
      move_midi_inject_to_move([9, 128, 108, 0]);
  }
  for (let _t = 0; _t < NUM_TRACKS; _t++) {
    if (pendingDrumNoteOffs[_t].length === 0) continue;
    const offs = pendingDrumNoteOffs[_t].splice(0);
    for (const pitch of offs) liveSendNote(_t, 128, pitch, 0);
  }
  if (S.ccStepEditActive && S.heldStep < 0)
    S.ccStepEditActive = false;
  if (S.pendingCCBitsRefresh >= 0 && typeof host_module_get_param === "function") {
    const _rt = S.activeTrack, _rc = S.pendingCCBitsRefresh;
    S.pendingCCBitsRefresh = -1;
    const _bits = host_module_get_param("t" + _rt + "_c" + _rc + "_cc_auto_bits");
    if (_bits !== null) S.trackCCAutoBits[_rt][_rc] = parseInt(_bits, 10) || 0;
    const _rest = host_module_get_param("t" + _rt + "_c" + _rc + "_cc_rest");
    if (_rest) {
      const _rp = _rest.split(" ");
      for (let _k = 0; _k < 8; _k++) {
        const _rv = parseInt(_rp[_k], 10);
        S.clipCCVal[_rt][_rc][_k] = _rv >= 0 && _rv <= 127 ? _rv : -1;
      }
    }
    invalidateLEDCache();
  }
  if (S.activeBank === 6 && S.playing && !S.sessionView && !S.ccStepEditActive) {
    const _lv = host_module_get_param("t" + S.activeTrack + "_cc_cur_vals");
    if (_lv) {
      const _lp = _lv.split(" ");
      for (let _k = 0; _k < 8 && _k < _lp.length; _k++) {
        const _v = parseInt(_lp[_k], 10);
        S.trackCCLiveVal[S.activeTrack][_k] = _v >= 0 && _v <= 127 ? _v : -1;
      }
    }
  }
  if (S.schLabelFetchLane >= 0 && S.schLabelFetchLane < 8 && typeof shadow_get_param === "function") {
    const _ft = S.activeTrack;
    const _fk = S.schLabelFetchLane;
    S.schLabelFetchLane++;
    if (S.trackCCType[_ft][_fk] === 2) {
      const _slot = schSlotForTrack(_ft);
      if (_slot >= 0) {
        const _name = shadow_get_param(_slot, "knob_" + S.trackCCAssign[_ft][_fk] + "_param");
        S.schLabel[_ft][_fk] = _name || null;
      }
    }
    if (S.schLabelFetchLane >= 8) S.schLabelFetchLane = -1;
    S.screenDirty = true;
  }
  if (S.activeBank === 6 && !S.sessionView && S.ccGradPaletteTrack !== S.activeTrack) {
    S.ccGradPaletteTrack = S.activeTrack;
    for (let _l = 0; _l < CC_GRADIENT_LEVELS; _l++) {
      const _w = Math.round(255 * CC_GRADIENT_SCALARS[_l]);
      setPaletteEntryRGB(CC_GRADIENT_BASE + _l, _w, _w, _w);
    }
    reapplyPalette();
    setButtonLED5(MovePlay2, S.playing ? Green3 : LED_OFF, true);
    setButtonLED5(MoveRec, S.recordArmed || S.recordScheduledStop ? Red5 : S.dspMergeState === 2 || S.dspMergeState === 3 ? Green3 : S.dspMergeState === 1 ? Red5 : LED_OFF, true);
    setButtonLED5(MoveSample, DarkGrey3, true);
    setButtonLED5(
      MoveBack2,
      S.schwungCoRunSlot < 0 && S.moveCoRunTrack < 0 && backTapWouldAct() ? White3 : LED_OFF,
      true
    );
    S._forceKnobReemit = true;
    invalidateLEDCache();
  }
  if (S.pendingSetLoad && !S.pendingInheritPicker && typeof host_module_set_param === "function") {
    S.pendingSetLoad = false;
    S.stateLoading = true;
    disarmRecord();
    S.heldStep = -1;
    S.heldStepBtn = -1;
    S.heldStepNotes = [];
    S.stepWasEmpty = false;
    S.stepWasHeld = false;
    S.seqActiveNotes.clear();
    S.seqLastStep = -1;
    S.seqLastClip = -1;
    S.pendingDspSync = 5;
    host_module_set_param("state_load", S.currentSetUuid || "");
  }
  if (S.clearDrainHold > 0) S.clearDrainHold--;
  else if (S.pendingDefaultSetParams.length > 0 && !S.pendingSetLoad && S.pendingDspSync === 0 && typeof host_module_set_param === "function") {
    const _dp = S.pendingDefaultSetParams.shift();
    host_module_set_param(_dp.key, _dp.val);
    if (_dp._local) S.localRevSuppressUntil = S.tickCount + 12;
  }
  if (S.tickCount % 100 === 0 && typeof host_module_get_param === "function" && typeof host_module_set_param === "function") {
    const newInstanceId = host_module_get_param("instance_id");
    if (newInstanceId && S.lastDspInstanceId !== "" && newInstanceId !== S.lastDspInstanceId) {
      pollDSP();
      for (let _t = 0; _t < NUM_TRACKS; _t++)
        S.trackCurrentPage[_t] = Math.max(0, Math.floor(S.trackCurrentStep[_t] / 16));
      syncClipsFromDsp();
      syncMuteSoloFromDsp();
      computePadNoteMap();
      invalidateLEDCache();
      forceRedraw();
    }
    if (newInstanceId) S.lastDspInstanceId = newInstanceId;
  }
  if (S.pendingDspSync > 0) {
    S.pendingDspSync--;
    if (S.pendingDspSync === 0) {
      pollDSP();
      for (let _t = 0; _t < NUM_TRACKS; _t++)
        S.trackCurrentPage[_t] = Math.max(0, Math.floor(S.trackCurrentStep[_t] / 16));
      syncClipsFromDsp();
      syncMuteSoloFromDsp();
      if (typeof host_module_get_param === "function") {
        const _ct = parseInt(host_module_get_param("conductor_track"), 10);
        if (!isNaN(_ct) && _ct >= 0 && _ct < NUM_TRACKS) {
          S.conductorTrack = _ct;
          S.trackPadMode[_ct] = PAD_MODE_CONDUCT;
          S.condActiveClip = S.trackActiveClip[_ct] | 0;
          for (let _c = 0; _c < NUM_CLIPS; _c++) {
            const _resp = host_module_get_param("t" + _ct + "_c" + _c + "_cond_resp");
            const _when = host_module_get_param("t" + _ct + "_c" + _c + "_cond_when");
            const _oct = host_module_get_param("t" + _ct + "_c" + _c + "_cond_oct");
            if (typeof _resp === "string" && _resp.length >= NUM_TRACKS) {
              for (let _k = 0; _k < NUM_TRACKS; _k++)
                S.condResp[_c][_k] = _resp.charAt(_k) === "1" ? 1 : 0;
            }
            if (typeof _when === "string" && _when.length >= NUM_TRACKS) {
              for (let _k = 0; _k < NUM_TRACKS; _k++)
                S.condWhen[_c][_k] = _when.charAt(_k) === "1" ? 1 : 0;
            }
            if (typeof _oct === "string" && _oct.length > 0) {
              const _op = _oct.split(" ");
              for (let _k = 0; _k < NUM_TRACKS && _k < _op.length; _k++) {
                const _ov = parseInt(_op[_k], 10);
                if (!isNaN(_ov)) S.condOct[_c][_k] = _ov;
              }
            }
            const _clk = host_module_get_param("t" + _ct + "_c" + _c + "_cond_lock");
            S.condLock[_c] = _clk === "1" || _clk === 1 ? 1 : 0;
          }
        } else {
          S.conductorTrack = -1;
        }
      }
      restoreUiSidecar(true);
      computePadNoteMap();
      S.stateLoading = false;
      invalidateLEDCache();
      forceRedraw();
    }
  }
  if (S.pendingMoveCoRunInject > 0) {
    S.pendingMoveCoRunInject--;
    if (S.pendingMoveCoRunInject === 0 && S.moveCoRunTrack >= 0) {
      const ch = S.trackChannel[S.moveCoRunTrack] | 0;
      if (ch >= 1 && ch <= 4) {
        const coCC = 44 - ch;
        const nb = coCC === 43 ? 42 : 43;
        S.moveCoRunPressQueue = [nb, coCC, nb, coCC];
        S.moveCoRunPressGap = 0;
      }
    }
  }
  if (S.moveCoRunPressQueue && S.moveCoRunPressQueue.length > 0 && typeof move_midi_inject_to_move === "function") {
    if (S.moveCoRunPressGap > 0) {
      S.moveCoRunPressGap--;
    } else {
      const cc = S.moveCoRunPressQueue.shift();
      move_midi_inject_to_move([11, 176, 49, 0]);
      move_midi_inject_to_move([11, 176, cc, 127]);
      move_midi_inject_to_move([11, 176, cc, 0]);
      S.moveCoRunPressGap = 5;
    }
  }
  if (S.pendingUndoSync > 0) {
    S.pendingUndoSync--;
    if (S.pendingUndoSync === 0) {
      const _info = host_module_get_param("last_restore");
      syncClipsTargeted(_info);
      if (S.recordArmed && !S.recordCountingIn && S.recordArmedTrack >= 0) {
        _recordingNoteTrack.clear();
        S._recNoteOns.length = 0;
        S._recNoteOffs.length = 0;
        _drumRecNoteOns.length = 0;
        _drumRecNoteOffs.length = 0;
        host_module_set_param("t" + S.recordArmedTrack + "_recording", "1");
      }
      invalidateLEDCache();
      forceRedraw();
    }
  }
  if (S.pendingAllLanesStretchCheck >= 0) {
    const _sat = S.pendingAllLanesStretchCheck;
    S.pendingAllLanesStretchCheck = -1;
    const _res = host_module_get_param("t" + _sat + "_all_lanes_stretch_result");
    if (_res !== null && parseInt(_res, 10) === -1) {
      showActionPopup("NO ROOM");
      S.bankParams[_sat][7][1] -= S.knobLastDir[1] || 1;
    }
  }
  if (S.allLanesQntResetTick >= 0 && S.tickCount >= S.allLanesQntResetTick) {
    S.bankParams[S.allLanesQntResetTrack][7][3] = -1;
    S.allLanesQntResetTick = -1;
    S.allLanesQntResetTrack = -1;
    S.screenDirty = true;
  }
  if (S.allLanesResResetTick >= 0 && S.tickCount >= S.allLanesResResetTick) {
    S.bankParams[S.allLanesResResetTrack][7][0] = -1;
    S.allLanesResResetTick = -1;
    S.allLanesResResetTrack = -1;
    S.screenDirty = true;
  }
  if (S.allLanesDirResetTick >= 0 && S.tickCount >= S.allLanesDirResetTick) {
    S.bankParams[S.allLanesDirResetTrack][7][6] = -1;
    S.allLanesDirResetTick = -1;
    S.allLanesDirResetTrack = -1;
    S.screenDirty = true;
  }
  if (S.pendingDrumResync > 0) {
    S.pendingDrumResync--;
    if (S.pendingDrumResync === 0) {
      syncDrumClipContent(S.pendingDrumResyncTrack);
      syncDrumLanesMeta(S.pendingDrumResyncTrack);
      syncDrumLaneSteps(S.pendingDrumResyncTrack, S.activeDrumLane[S.pendingDrumResyncTrack]);
      forceRedraw();
    }
  }
  if (S.recOffTicks > 0 && S.recOffTrack >= 0) {
    if (S.recordArmed) {
      S.recOffTicks = 0;
      S.recOffTrack = -1;
    } else {
      S.recOffTicks--;
      if (typeof host_module_set_param === "function")
        host_module_set_param("t" + S.recOffTrack + "_recording", "0");
      if (S.recOffTicks <= 0) S.recOffTrack = -1;
    }
  }
  if (S.pendingDrumLaneResync > 0) {
    S.pendingDrumLaneResync--;
    if (S.pendingDrumLaneResync === 0) {
      const _drT = S.pendingDrumLaneResyncTrack;
      const _drL = S.pendingDrumLaneResyncLane;
      syncDrumLaneSteps(_drT, _drL);
      refreshDrumLaneBankParams(_drT, _drL);
      forceRedraw();
    }
  }
  if (S.pendingStepsReread > 0) {
    S.pendingStepsReread--;
    if (S.pendingStepsReread === 0) {
      const prt = S.pendingStepsRereadTrack;
      const prac = S.pendingStepsRereadClip;
      const bulk = host_module_get_param("t" + prt + "_c" + prac + "_steps");
      if (bulk && bulk.length >= NUM_STEPS) {
        for (let rs = 0; rs < NUM_STEPS; rs++)
          S.clipSteps[prt][prac][rs] = bulk[rs] === "1" ? 1 : bulk[rs] === "2" ? 2 : 0;
        S.clipNonEmpty[prt][prac] = clipHasContent(prt, prac);
      }
      const _plen = host_module_get_param("t" + prt + "_c" + prac + "_length");
      if (_plen !== null && _plen !== void 0) S.clipLength[prt][prac] = parseInt(_plen, 10) || 16;
      const _ptps = host_module_get_param("t" + prt + "_c" + prac + "_tps");
      if (_ptps !== null && _ptps !== void 0) {
        const _tv = parseInt(_ptps, 10);
        S.clipTPS[prt][prac] = TPS_VALUES.indexOf(_tv) >= 0 ? _tv : 24;
      }
      if (prac === S.trackActiveClip[prt]) refreshPerClipBankParams(prt);
      forceRedraw();
    }
  }
  if (S.pendingSceneBakeResync > 0) {
    S.pendingSceneBakeResync--;
    if (S.pendingSceneBakeResync === 0) {
      const sc = S.pendingSceneBakeClip;
      for (let _t = 0; _t < NUM_TRACKS; _t++) {
        if (S.trackPadMode[_t] === PAD_MODE_DRUM) {
          if (S.trackActiveClip[_t] === sc) {
            syncDrumClipContent(_t);
            syncDrumLanesMeta(_t);
            syncDrumLaneSteps(_t, S.activeDrumLane[_t]);
          }
        } else {
          const bulk = host_module_get_param("t" + _t + "_c" + sc + "_steps");
          if (bulk && bulk.length >= NUM_STEPS) {
            for (let rs = 0; rs < NUM_STEPS; rs++)
              S.clipSteps[_t][sc][rs] = bulk[rs] === "1" ? 1 : bulk[rs] === "2" ? 2 : 0;
            S.clipNonEmpty[_t][sc] = clipHasContent(_t, sc);
          }
          const _plen = host_module_get_param("t" + _t + "_c" + sc + "_length");
          if (_plen !== null && _plen !== void 0) S.clipLength[_t][sc] = parseInt(_plen, 10) || 16;
          const _ptps = host_module_get_param("t" + _t + "_c" + sc + "_tps");
          if (_ptps !== null && _ptps !== void 0) {
            const _tv = parseInt(_ptps, 10);
            S.clipTPS[_t][sc] = TPS_VALUES.indexOf(_tv) >= 0 ? _tv : 24;
          }
          if (sc === S.trackActiveClip[_t]) refreshPerClipBankParams(_t);
        }
      }
      forceRedraw();
    }
  }
  if (S.recordArmed && S.playing && !S.sessionView && S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && (S.drumRepeatHeldPad[S.activeTrack] >= 0 || S.drumRepeat2HeldLanes[S.activeTrack].size > 0 || S.drumRepeat2LatchedLanes[S.activeTrack].size > 0)) {
    syncDrumLaneSteps(S.activeTrack, S.activeDrumLane[S.activeTrack]);
    forceRedraw();
  }
  if (S.globalMenuOpen && S.globalMenuState && S.globalMenuItems) {
    const item = S.globalMenuItems[S.globalMenuState.selectedIndex];
    if (item && S.globalMenuState.editing && S.globalMenuState.editValue !== null) {
      if (item.set && S.globalMenuState.editValue !== S.lastSentMenuEditValue) {
        item.set(S.globalMenuState.editValue);
        S.lastSentMenuEditValue = S.globalMenuState.editValue;
        S.screenDirty = true;
      }
      S.bpmWasEditing = true;
    } else if (S.bpmWasEditing && !S.globalMenuState.editing) {
      if (item && item.set && item.get) item.set(item.get());
      S.bpmWasEditing = false;
      S.lastSentMenuEditValue = null;
    }
  }
  if (S.xposePrevKey !== null || S.confirmXpose) {
    const _it = S.globalMenuOpen && S.globalMenuState && S.globalMenuItems ? S.globalMenuItems[S.globalMenuState.selectedIndex] : null;
    const _onKeyScale = !!(_it && S.globalMenuState.editing && (_it.label === "Key" || _it.label === "Scale"));
    if (S.confirmXpose) {
      if (!_onKeyScale) {
        S.confirmXpose = false;
        xposeCancelPreview();
      }
    } else if (!_onKeyScale) {
      xposeCancelPreview();
    }
  }
  if (!S.ledInitComplete) {
    drainLedInit();
  } else {
    if (S.bankSelectTick >= 0 && S.tickCount - S.bankSelectTick >= BANK_DISPLAY_TICKS) {
      S.bankSelectTick = -1;
      S.screenDirty = true;
    }
    if (S.stretchBlockedEndTick >= 0 && S.tickCount >= S.stretchBlockedEndTick) {
      S.stretchBlockedEndTick = -1;
      S.screenDirty = true;
    }
    if (S.actionPopupEndTick >= 0 && S.tickCount >= S.actionPopupEndTick) {
      S.actionPopupEndTick = -1;
      S.screenDirty = true;
    }
    if (S.knobTouched >= 0 && S.knobTurnedTick[S.knobTouched] >= 0 && S.tickCount - S.knobTurnedTick[S.knobTouched] >= KNOB_TURN_HIGHLIGHT_TICKS) {
      S.knobTouched = -1;
      S.screenDirty = true;
    }
    if (S.noNoteFlashEndTick >= 0 && S.tickCount >= S.noNoteFlashEndTick) {
      S.noNoteFlashEndTick = -1;
      S.screenDirty = true;
    }
    if (S.stepSaveFlashEndTick >= 0 && S.tickCount >= S.stepSaveFlashEndTick) {
      S.stepSaveFlashEndTick = -1;
      S.stepSaveFlashStartTick = -1;
    }
    if (S.sessionStepHeld >= 0) {
      const _ssh = S.sessionStepHeld;
      if (S.tickCount - S.stepBtnPressedTick[_ssh] >= STEP_SAVE_HOLD_TICKS) {
        const _ctx = S.sessionStepHeldCtx;
        S.sessionStepHeld = -1;
        S.sessionStepHeldCtx = 0;
        S.stepBtnPressedTick[_ssh] = -1;
        if (_ctx === 1) {
          S.perfSnapshots[_ssh] = S.perfModsToggled | S.perfModsHeld;
          showActionPopup("PERF PRESET", "SAVED");
        } else {
          const drumEffMutes = [];
          for (let _t = 0; _t < NUM_TRACKS; _t++) {
            const mMask = S.drumLaneMute[_t];
            const sMask = S.drumLaneSolo[_t];
            let effMask = mMask;
            if (sMask) {
              let notSoloed = 0;
              for (let _l = 0; _l < DRUM_LANES; _l++) {
                if (!(sMask & 1 << _l)) notSoloed |= 1 << _l;
              }
              effMask = (mMask | notSoloed) >>> 0;
            }
            drumEffMutes.push(effMask >>> 0);
          }
          S.snapshots[_ssh] = { mute: S.trackMuted.slice(), solo: S.trackSoloed.slice(), drumEffMute: drumEffMutes };
          const mStr = S.trackMuted.map(function(m) {
            return m ? "1" : "0";
          }).join(" ");
          const sStr = S.trackSoloed.map(function(s) {
            return s ? "1" : "0";
          }).join(" ");
          const dStr = drumEffMutes.join(" ");
          if (typeof host_module_set_param === "function")
            host_module_set_param("snap_save", _ssh + " " + mStr + " " + sStr + " " + dStr);
          showActionPopup("MUTE STATE", "SAVED");
        }
        S.stepSaveFlashStartTick = S.tickCount;
        S.stepSaveFlashEndTick = S.tickCount + STEP_SAVE_FLASH_TICKS;
        forceRedraw();
      }
    }
    if (S.tickCount % POLL_INTERVAL === 0) {
      pollDSP();
      S.screenDirty = true;
    }
    if (S.schwungCoRunSlot >= 0 && S.tickCount % POLL_INTERVAL === 0) {
      S._coRunChanSlots = schSlotsForTrack(S.activeTrack);
    }
    if (S.pendingSchwungCoRunTrack >= 0) {
      const _t = S.pendingSchwungCoRunTrack;
      if (S.schwungCoRunSlot >= 0 || _t !== S.activeTrack) {
        S.pendingSchwungCoRunTrack = -1;
        S.pendingSchwungCoRunDelay = 0;
      } else if (S.pendingSchwungCoRunDelay > 0) {
        if (--S.pendingSchwungCoRunDelay === 0) {
          S.pendingSchwungCoRunTrack = -1;
          enterSchwungCoRun(_t, 0);
        }
      } else {
        const _msk = schSlotsForTrack(_t);
        if (_msk === 0) {
          showActionPopup("NO SLOT", "CH " + (S.trackChannel[_t] | 0));
          S.pendingSchwungCoRunDelay = ACTION_POPUP_TICKS;
        } else {
          S.pendingSchwungCoRunTrack = -1;
          S._coRunChanSlots = _msk;
          let _slot = 0;
          while (_slot < 4 && !(_msk & 1 << _slot)) _slot++;
          enterSchwungCoRun(_t, _slot);
        }
      }
    }
    if (S.metronomeOn > 0) {
      const _mbcRaw = host_module_get_param("metro_beat_count");
      if (_mbcRaw !== null && _mbcRaw !== void 0) {
        const _mbc = parseInt(_mbcRaw, 10) | 0;
        if (_mbc !== S.metroPrevBeat) {
          S.metroPrevBeat = _mbc;
          playMetronomeClick();
          if (S.recordCountingIn) S.countInBeatStartTick = S.tickCount;
        }
      }
    }
    if (S.heldStep >= 0 && S.heldStepBtn >= 0 && S.stepBtnPressedTick[S.heldStepBtn] >= 0 && S.tickCount - S.stepBtnPressedTick[S.heldStepBtn] >= STEP_HOLD_TICKS) {
      S.stepBtnPressedTick[S.heldStepBtn] = -1;
      S.stepWasHeld = true;
      if (S.activeBank === 6) {
        const _t6 = S.activeTrack, _c6 = effectiveClip(_t6);
        const _info = typeof host_module_get_param === "function" ? host_module_get_param("t" + _t6 + "_c" + _c6 + "_ccstepinfo_" + S.heldStep) : null;
        const _ip = _info ? _info.split(" ") : [];
        for (let _ck = 0; _ck < 8; _ck++) {
          const _pv = _ip.length > _ck ? parseInt(_ip[_ck], 10) : -1;
          const _cv = _ip.length > _ck + 8 ? parseInt(_ip[_ck + 8], 10) : -1;
          S.ccStepEditSet[_ck] = _pv >= 0;
          S.ccStepEditComputed[_ck] = _cv >= 0 && _cv <= 127 ? _cv : -1;
          const _rest = S.clipCCVal[_t6][_c6][_ck];
          S.ccStepEditVal[_ck] = _pv >= 0 ? _pv : _cv >= 0 && _cv <= 127 ? _cv : _rest >= 0 ? _rest : 0;
        }
        S.screenDirty = true;
      } else if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
        if (S.stepWasEmpty && S.heldStepNotes.length === 0 && typeof host_module_set_param === "function") {
          const t = S.activeTrack;
          const lane = S.activeDrumLane[t];
          host_module_set_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_toggle", String(S.stepEditVel));
          S.drumLaneSteps[t][lane][S.heldStep] = "1";
          S.drumLaneHasNotes[t][lane] = true;
          S.heldStepNotes = [S.drumLaneNote[t][lane]];
          if (typeof host_module_get_param === "function") {
            const rv = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_vel");
            const rg = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_gate");
            const rn = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_nudge");
            const ri = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_iter");
            const rr = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_rand");
            const rx = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_ratch");
            S.stepEditVel = rv !== null ? parseInt(rv, 10) : S.stepEditVel;
            S.stepEditGate = rg !== null ? parseInt(rg, 10) : S.drumLaneTPS[t] || 24;
            S.stepEditNudge = rn !== null ? parseInt(rn, 10) : 0;
            S.stepEditIter = ri !== null ? parseInt(ri, 10) : 0;
            S.stepEditRand = rr !== null ? parseInt(rr, 10) : 0;
            S.stepEditRatch = rx !== null ? parseInt(rx, 10) : 0;
          }
        } else if (S.drumHeldReadPending && typeof host_module_get_param === "function") {
          const t = S.activeTrack;
          const lane = S.activeDrumLane[t];
          const rv = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_vel");
          const rg = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_gate");
          const rn = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_nudge");
          const ri = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_iter");
          const rr = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_rand");
          const rx = host_module_get_param("t" + t + "_l" + lane + "_step_" + S.heldStep + "_ratch");
          S.stepEditVel = rv !== null ? parseInt(rv, 10) : S.stepEditVel;
          S.stepEditGate = rg !== null ? parseInt(rg, 10) : S.stepEditGate;
          S.stepEditNudge = rn !== null ? parseInt(rn, 10) : S.stepEditNudge;
          S.stepEditIter = ri !== null ? parseInt(ri, 10) : S.stepEditIter;
          S.stepEditRand = rr !== null ? parseInt(rr, 10) : S.stepEditRand;
          S.stepEditRatch = rx !== null ? parseInt(rx, 10) : S.stepEditRatch;
          S.drumHeldReadPending = false;
        }
        S.screenDirty = true;
      } else if (!S.stepWasEmpty && S.heldStepNotes.length === 0) {
        const ac_h2 = effectiveClip(S.activeTrack);
        const raw_h2 = typeof host_module_get_param === "function" ? host_module_get_param("t" + S.activeTrack + "_c" + ac_h2 + "_step_" + S.heldStep + "_notes") : null;
        S.heldStepNotes = raw_h2 && raw_h2.trim().length > 0 ? raw_h2.trim().split(" ").map(Number).filter(function(n) {
          return n >= 0 && n <= 127;
        }) : [];
        const rv2 = typeof host_module_get_param === "function" ? host_module_get_param("t" + S.activeTrack + "_c" + ac_h2 + "_step_" + S.heldStep + "_vel") : null;
        const rg2 = typeof host_module_get_param === "function" ? host_module_get_param("t" + S.activeTrack + "_c" + ac_h2 + "_step_" + S.heldStep + "_gate") : null;
        const rn2 = typeof host_module_get_param === "function" ? host_module_get_param("t" + S.activeTrack + "_c" + ac_h2 + "_step_" + S.heldStep + "_nudge") : null;
        const ri2 = typeof host_module_get_param === "function" ? host_module_get_param("t" + S.activeTrack + "_c" + ac_h2 + "_step_" + S.heldStep + "_iter") : null;
        const rr2 = typeof host_module_get_param === "function" ? host_module_get_param("t" + S.activeTrack + "_c" + ac_h2 + "_step_" + S.heldStep + "_rand") : null;
        const rx2 = typeof host_module_get_param === "function" ? host_module_get_param("t" + S.activeTrack + "_c" + ac_h2 + "_step_" + S.heldStep + "_ratch") : null;
        S.stepEditVel = rv2 !== null ? parseInt(rv2, 10) : 100;
        S.stepEditGate = rg2 !== null ? parseInt(rg2, 10) : 12;
        S.stepEditNudge = rn2 !== null ? parseInt(rn2, 10) : 0;
        S.stepEditIter = ri2 !== null ? parseInt(ri2, 10) : 0;
        S.stepEditRand = rr2 !== null ? parseInt(rr2, 10) : 0;
        S.stepEditRatch = rx2 !== null ? parseInt(rx2, 10) : 0;
        S.screenDirty = true;
      } else if (S.stepWasEmpty && S.heldStepNotes.length === 0) {
        if (S.activeBank === 6) {
        } else if (S.lastPlayedNote >= 0 && typeof host_module_set_param === "function") {
          const ac_he = effectiveClip(S.activeTrack);
          const assignNote = S.lastPlayedNote;
          const assignVel = stepEntryVelocity(S.activeTrack, -1, false);
          host_module_set_param(
            "t" + S.activeTrack + "_c" + ac_he + "_step_" + S.heldStep + "_toggle",
            assignNote + " " + assignVel
          );
          S.clipSteps[S.activeTrack][ac_he][S.heldStep] = 1;
          S.clipNonEmpty[S.activeTrack][ac_he] = true;
          S.heldStepNotes = [assignNote];
          S.stepEditVel = assignVel;
          S.stepWasEmpty = false;
          refreshSeqNotesIfCurrent(S.activeTrack, ac_he, S.heldStep);
        } else {
          S.noNoteFlashEndTick = S.tickCount + NO_NOTE_FLASH_TICKS;
        }
        S.screenDirty = true;
      }
    }
    if (S.pendingChordPhase2 !== null) {
      const _cp2 = S.pendingChordPhase2;
      if (_cp2.pitches.length > 1 && typeof host_module_set_param === "function") {
        host_module_set_param(
          "t" + _cp2.t + "_c" + _cp2.ac + "_step_" + _cp2.step + "_set_notes",
          _cp2.pitches.join(" ")
        );
      }
      S.heldStepNotes = _cp2.pitches.slice();
      refreshSeqNotesIfCurrent(_cp2.t, _cp2.ac, _cp2.step);
      S.screenDirty = true;
      S.pendingChordPhase2 = null;
    }
    if (S.pendingChordToStep !== null && S.activeBank !== 6) {
      const _cp1 = S.pendingChordToStep;
      if (_cp1.wasEmpty) {
        if (typeof host_module_set_param === "function")
          host_module_set_param(
            "t" + _cp1.t + "_c" + _cp1.ac + "_step_" + _cp1.step + "_toggle",
            _cp1.pitches[0] + " " + _cp1.vel
          );
        S.clipSteps[_cp1.t][_cp1.ac][_cp1.step] = 1;
        S.clipNonEmpty[_cp1.t][_cp1.ac] = true;
      }
      S.pendingChordPhase2 = _cp1;
      S.pendingChordToStep = null;
    }
    for (let _i = 0; _i < 16; _i++) {
      S.cachedSceneAllPlaying[_i] = sceneAllPlaying(_i);
      S.cachedSceneAllQueued[_i] = sceneAllQueued(_i);
      S.cachedSceneAnyPlaying[_i] = sceneAnyPlaying(_i);
    }
    setButtonLED5(MovePlay2, S.playing ? Green3 : LED_OFF);
    if (S.schwungCoRunSlot >= 0 || S.moveCoRunTrack >= 0) {
      setButtonLED5(MoveRec, LED_OFF, S.tickCount % POLL_INTERVAL === 0);
    } else if (S.recordScheduledStop || S.recordPendingPage) {
      setButtonLED5(MoveRec, Math.floor(S.tickCount / 8) % 2 === 0 ? Red5 : LED_OFF);
    } else if (S.mergeNoticePending) {
      setButtonLED5(MoveRec, Math.floor(S.tickCount / 12) % 2 === 0 ? Red5 : LED_OFF);
    } else if (S.dspMergeState === 2 || S.dspMergeState === 3) {
      setButtonLED5(MoveRec, Green3);
    } else if (S.dspMergeState === 1) {
      setButtonLED5(MoveRec, Red5);
    } else {
      setButtonLED5(MoveRec, S.recordArmed ? Red5 : LED_OFF);
    }
    setButtonLED5(MoveSample, DarkGrey3);
    setButtonLED5(
      MoveBack2,
      S.schwungCoRunSlot < 0 && S.moveCoRunTrack < 0 && backTapWouldAct() ? White3 : LED_OFF
    );
    {
      let loopColor = LED_OFF;
      const _lt = S.activeTrack;
      const _rptLatched = S.drumRepeatLatched[_lt] || S.drumRepeat2LatchedLanes[_lt].size > 0;
      let _tarpBlinkActive = false;
      let _tarpBlinkOn = false;
      if (!(S.sessionView && S.perfViewLocked) && !_rptLatched) {
        const _tarpOn = parseInt(host_module_get_param("t" + _lt + "_tarp_on"), 10) === 1;
        const _tarpLatch = parseInt(host_module_get_param("t" + _lt + "_tarp_latch"), 10) === 1;
        if (_tarpOn && _tarpLatch) {
          const _fc = parseInt(host_module_get_param("t" + _lt + "_tarp_fc"), 10) || 0;
          _tarpBlinkActive = true;
          _tarpBlinkOn = _fc % 2 === 0;
        }
      }
      if (S.sessionView && S.perfViewLocked) {
        loopColor = flashAtRate(48) ? White3 : LED_OFF;
      } else if (_rptLatched) {
        loopColor = flashAtRate(48) ? White3 : LED_OFF;
      } else if (_tarpBlinkActive) {
        loopColor = _tarpBlinkOn ? trackColor(_lt) : LED_OFF;
      } else if (S.sessionView && S.perfLatchMode) {
        loopColor = VividYellow3;
      } else {
        loopColor = 60;
      }
      setButtonLED5(MoveLoop, loopColor);
    }
    setButtonLED5(
      MoveCapture,
      S.captureArmed ? Math.floor(S.tickCount / 24) % 2 ? White3 : LED_OFF : DarkGrey3
    );
    {
      const _muted = S.trackMuted[S.activeTrack];
      const _soloed = S.trackSoloed[S.activeTrack];
      const _muteBlink = Math.floor(S.tickCount / 24) % 2;
      setButtonLED5(MoveMute2, _muted ? 124 : _soloed ? _muteBlink ? 124 : 0 : 16);
    }
    setButtonLED5(MoveShift2, 16);
    setButtonLED5(MoveNoteSession, 16);
    if (S.schwungCoRunSlot >= 0) {
      setButtonLED5(MoveNoteSession, White3, S.tickCount % POLL_INTERVAL === 0);
    } else if (S.moveCoRunTrack >= 0) {
      setButtonLED5(MoveNoteSession, LED_OFF, S.tickCount % POLL_INTERVAL === 0);
    } else if (S.globalMenuOpen) {
      setButtonLED5(MoveNoteSession, White3);
    } else if (S.tapTempoOpen) {
      const _exitBlink = Math.floor(S.tickCount / 24) % 2 ? 16 : LED_OFF;
      setButtonLED5(MoveNoteSession, _exitBlink);
    }
    setButtonLED5(MoveUndo, 16);
    setButtonLED5(MoveDelete2, 16);
    setButtonLED5(MoveCopy, 16);
    setButtonLED5(MoveUp2, 16);
    setButtonLED5(MoveDown2, 16);
    setButtonLED5(MoveLeft2, S.sessionView ? LED_OFF : 16);
    setButtonLED5(MoveRight2, S.sessionView ? LED_OFF : 16);
    if (S.shiftHeld) {
      const _sf = Math.floor(S.tickCount / 24) % 2 ? 16 : LED_OFF;
      setButtonLED5(MoveNoteSession, _sf);
      if (S.dspMergeState === 0 && !S.recordArmed)
        setButtonLED5(MoveRec, Math.floor(S.tickCount / 24) % 2 ? Red5 : LED_OFF);
      setButtonLED5(MoveUndo, _sf);
      setButtonLED5(MoveCopy, _sf);
      if (S.sessionView) setButtonLED5(MoveLoop, _sf);
      if (!S.sessionView) setButtonLED5(MoveMute2, _sf);
    }
    if (S.sessionView) {
      updateSessionLEDs();
      if (S.loopHeld || S.perfViewLocked) updatePerfModeLEDs();
      else updateSceneMapLEDs();
      if (S.mergeCountingIn && S.countInQuarterTicks > 0) {
        const elapsed = S.tickCount - S.countInBeatStartTick;
        const flashOn = elapsed % S.countInQuarterTicks < S.countInQuarterTicks >> 3;
        const flashClr = flashOn ? White3 : LED_OFF;
        for (let _i = 0; _i < 16; _i++) setLED4(16 + _i, flashClr);
      }
    } else {
      updateStepLEDs();
      if ((S.recordArmed && S.recordCountingIn || S.mergeCountingIn) && S.countInQuarterTicks > 0) {
        const elapsed = S.tickCount - S.countInBeatStartTick;
        const flashOn = elapsed % S.countInQuarterTicks < S.countInQuarterTicks >> 3;
        const flashClr = flashOn ? White3 : LED_OFF;
        for (let _i = 0; _i < 16; _i++) setLED4(16 + _i, flashClr);
      }
    }
    updateTrackLEDs();
    if (S.sessionOverlayHeld) {
      const blinkOn = S.flashEighth;
      if (blinkOn !== S.lastBlinkOn) {
        S.lastBlinkOn = blinkOn;
        S.screenDirty = true;
      }
    } else {
      S.lastBlinkOn = null;
    }
    if (S.trackSoloed.some(function(s) {
      return s;
    })) {
      const _sb = Math.floor(S.tickCount / 24) % 2;
      if (_sb !== S.lastSoloBlink) {
        S.lastSoloBlink = _sb;
        S.screenDirty = true;
      }
    } else {
      S.lastSoloBlink = null;
    }
    if (S.loopJogActive && S.loopHeld && S.loopJogLastTick !== void 0) {
      if (S.tickCount - S.loopJogLastTick > 70) {
        S.loopJogActive = false;
        S.screenDirty = true;
      }
    }
    if (S.activeBank === 7 && S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM) {
      const _ab = Math.floor(S.tickCount / 24) % 2;
      if (_ab !== S.lastAllLanesBlink) {
        S.lastAllLanesBlink = _ab;
        S.screenDirty = true;
      }
    } else {
      S.lastAllLanesBlink = null;
    }
  }
  if (S.recordArmed && !S.recordCountingIn && typeof host_module_set_param === "function") {
    if (S._recNoteOns.length > 0) {
      const rt = S._recNoteOns[0].rt;
      const pairs = S._recNoteOns.map(function(n) {
        return (n.ext ? "e" : "") + n.pitch + " " + n.vel;
      }).join(" ");
      host_module_set_param("t" + rt + "_record_note_on", pairs);
      S._recNoteOns.length = 0;
    } else if (_drumRecNoteOns.length > 0) {
      const rt = _drumRecNoteOns[0].track;
      const pairs = _drumRecNoteOns.map(function(n) {
        return (n.ext ? "e" : "") + n.laneNote + " " + n.vel;
      }).join(" ");
      host_module_set_param("t" + rt + "_drum_record_note_on", pairs);
      _drumRecNoteOns.length = 0;
    } else if (S._recNoteOffs.length > 0) {
      const rt = S._recNoteOffs[0].rt;
      const pitches = S._recNoteOffs.map(function(n) {
        return (n.ext ? "e" : "") + n.pitch;
      }).join(" ");
      host_module_set_param("t" + rt + "_record_note_off", pitches);
      S._recNoteOffs.length = 0;
    } else if (_drumRecNoteOffs.length > 0) {
      const rt = _drumRecNoteOffs[0].track;
      const pitches = _drumRecNoteOffs.map(function(n) {
        return (n.ext ? "e" : "") + n.laneNote;
      }).join(" ");
      host_module_set_param("t" + rt + "_drum_record_note_off", pitches);
      _drumRecNoteOffs.length = 0;
    } else if (S.pendingPrerollGate !== null) {
      const pg = S.pendingPrerollGate;
      S.pendingPrerollGate = null;
      if (pg.isDrum) {
        const _ls = S.drumLaneLoopStart[pg.track] | 0;
        host_module_set_param("t" + pg.track + "_l" + pg.lane + "_step_" + _ls + "_gate", String(pg.gate));
      } else {
        const _ls = S.clipLoopStart[pg.track][pg.clip] | 0;
        host_module_set_param("t" + pg.track + "_c" + pg.clip + "_step_" + _ls + "_gate", String(pg.gate));
      }
    } else if (S.pendingPrerollToggleQueue.length > 0) {
      const _ptq = S.pendingPrerollToggleQueue.shift();
      const _ls = S.clipLoopStart[_ptq.track][_ptq.clip] | 0;
      host_module_set_param("t" + _ptq.track + "_c" + _ptq.clip + "_step_" + _ls + "_toggle", _ptq.pitch + " " + _ptq.vel);
      if (_ptq.last)
        S.pendingPrerollGate = { isDrum: false, track: _ptq.track, clip: _ptq.clip, gate: _ptq.gate };
    } else if (S.pendingPrerollNote !== null && S.playing) {
      const pr = S.pendingPrerollNote;
      const _prLive = S.liveActiveNotes.has(pr.laneNote);
      if (pr.isDrum) {
        const tps = S.drumLaneTPS[pr.track] || 24;
        const elapsed = S.tickCount - S.transportStartTick;
        if (!_prLive && elapsed >= tps) {
          S.pendingPrerollNote = null;
          const _ls = S.drumLaneLoopStart[pr.track] | 0;
          if (S.drumLaneSteps[pr.track][pr.lane][_ls] === "0") {
            const countInDur = S.transportStartTick - pr.countInStart;
            const dspPerJs = countInDur > 0 ? 384 / countInDur : 4;
            const pressedDur = (pr.releasedAtTick || S.tickCount) - pr.pressedAtTick;
            const gate = Math.max(1, Math.min(tps * 16, Math.round(pressedDur * dspPerJs)));
            host_module_set_param("t" + pr.track + "_l" + pr.lane + "_step_" + _ls + "_toggle", String(pr.vel));
            S.pendingPrerollGate = { isDrum: true, track: pr.track, lane: pr.lane, gate };
            S.drumLaneSteps[pr.track][pr.lane][_ls] = "1";
            S.drumLaneHasNotes[pr.track][pr.lane] = true;
            invalidateLEDCache();
            forceRedraw();
          }
        }
      }
    } else if (S.pendingPrerollNotes.length > 0 && S.playing) {
      const pns = S.pendingPrerollNotes;
      const pr = pns[0];
      const _tarpOn = parseInt(host_module_get_param("t" + pr.track + "_tarp_on"), 10) === 1;
      if (_tarpOn) {
        S.pendingPrerollNotes = [];
        S.pendingPrerollToggleQueue = [];
        S.pendingPrerollGate = null;
      } else {
        const _prLive = pns.some(function(n) {
          return S.liveActiveNotes.has(n.pitch);
        });
        const tps = S.clipTPS[pr.track] && S.clipTPS[pr.track][pr.clip] || 24;
        const elapsed = S.tickCount - S.transportStartTick;
        if (!_prLive && elapsed >= tps) {
          S.pendingPrerollNotes = [];
          const _ls = S.clipLoopStart[pr.track][pr.clip] | 0;
          if (S.clipSteps[pr.track][pr.clip][_ls] === 0) {
            const countInDur = S.transportStartTick - pr.countInStart;
            const dspPerJs = countInDur > 0 ? 384 / countInDur : 4;
            const lastRel = pns.reduce(function(m, n) {
              return Math.max(m, n.releasedAtTick || S.tickCount);
            }, 0);
            const pressedDur = lastRel - pr.pressedAtTick;
            const gate = Math.max(1, Math.min(tps * 16, Math.round(pressedDur * dspPerJs)));
            host_module_set_param("t" + pr.track + "_c" + pr.clip + "_step_" + _ls + "_toggle", pr.pitch + " " + pr.vel);
            if (pns.length === 1) {
              S.pendingPrerollGate = { isDrum: false, track: pr.track, clip: pr.clip, gate };
            } else {
              for (let _qi = 1; _qi < pns.length; _qi++) {
                S.pendingPrerollToggleQueue.push({
                  track: pns[_qi].track,
                  clip: pns[_qi].clip,
                  pitch: pns[_qi].pitch,
                  vel: pns[_qi].vel,
                  gate,
                  last: _qi === pns.length - 1
                });
              }
            }
            S.clipSteps[pr.track][pr.clip][_ls] = 1;
            S.clipNonEmpty[pr.track][pr.clip] = true;
            invalidateLEDCache();
            forceRedraw();
          }
        }
      }
    } else {
      const _art = S.recordArmedTrack >= 0 ? S.recordArmedTrack : S.activeTrack;
      const _arac = S.trackActiveClip[_art];
      const _arDrum = S.trackPadMode[_art] === PAD_MODE_DRUM;
      if (S.pendingScheduledDisarm) {
        S.pendingScheduledDisarm = false;
        disarmRecord();
      } else if (S.recordScheduledStop) {
        const _sStp = _arDrum ? S.drumCurrentStep[_art] : S.trackCurrentStep[_art];
        if (_sStp >= 0 && _sStp >= S.recordScheduledStopTarget - 1) {
          const _lockLen = S.recordScheduledStopTarget;
          if (_arDrum) {
            S.drumLaneLength[_art] = _lockLen;
            host_module_set_param("t" + _art + "_all_lanes_length", String(_lockLen));
          } else {
            S.clipLength[_art][_arac] = _lockLen;
            host_module_set_param("t" + _art + "_c" + _arac + "_length", String(_lockLen));
          }
          S.clipAdaptiveMode[_art][_arac] = false;
          S.recordScheduledStop = false;
          S.recordScheduledStopTarget = -1;
          S.pendingScheduledDisarm = true;
        }
      } else if (S.clipAdaptiveMode[_art][_arac]) {
        if (_arDrum) {
          const _adCur = S.drumLaneLength[_art];
          const _adStp = S.drumCurrentStep[_art];
          if (_adStp >= 0 && _adCur > 0 && _adCur < 256 && _adStp >= _adCur - 4) {
            const _adNew = _adCur + 16;
            S.drumLaneLength[_art] = _adNew;
            host_module_set_param("t" + _art + "_all_lanes_length", String(_adNew));
          }
        } else {
          const _adCur = S.clipLength[_art][_arac];
          const _adStp = S.trackCurrentStep[_art];
          if (_adStp >= 0 && _adCur > 0 && _adCur < 256 && _adStp >= _adCur - 4) {
            const _adNew = _adCur + 16;
            S.clipLength[_art][_arac] = _adNew;
            host_module_set_param("t" + _art + "_c" + _arac + "_length", String(_adNew));
          }
        }
      }
    }
  }
  if (S.pendingSuspendSave && typeof host_module_set_param === "function") {
    S.pendingSuspendSave = false;
    updateNameIndex();
    host_module_set_param("save", "1");
  } else if (S.pendingExitAfterSave) {
    S.pendingExitAfterSave = false;
    removeFlagsWrap();
    S.ledInitComplete = false;
    invalidateLEDCache();
    clearAllLEDs();
    for (let _i = 0; _i < 4; _i++) setButtonLED5(40 + _i, LED_OFF);
    if (typeof host_exit_module === "function") host_exit_module();
  } else if (S.pendingHideAfterSave) {
    S.pendingHideAfterSave = false;
    removeFlagsWrap();
    S.ledInitComplete = false;
    invalidateLEDCache();
    clearAllLEDs();
    for (let _i = 0; _i < 4; _i++) setButtonLED5(40 + _i, LED_OFF);
    if (typeof host_hide_module === "function") host_hide_module();
  } else if (S.pendingSuspendManaged) {
    S.pendingSuspendManaged = false;
    removeFlagsWrap();
    S.ledInitComplete = false;
    invalidateLEDCache();
    clearAllLEDs();
    for (let _i = 0; _i < 4; _i++) setButtonLED5(40 + _i, LED_OFF);
    if (typeof host_suspend_overtake === "function") host_suspend_overtake();
    else if (typeof host_hide_module === "function") host_hide_module();
  } else if (S.pendingSnapshotCopy) {
    const _sc = S.pendingSnapshotCopy;
    S.pendingSnapshotCopy = null;
    commitSnapshot(S.currentSetUuid, _sc.id, _sc.label);
  }
  if (S.pendingPruneOrphans && !S.pendingSetLoad && S.pendingDspSync === 0 && typeof host_module_set_param === "function") {
    S.pendingPruneOrphans = false;
    host_module_set_param("prune_orphan_states", "1");
    if (!S.nameIndexCache) S.nameIndexCache = loadNameIndex();
    let _dropped = false;
    for (const _nm in S.nameIndexCache) {
      const _u = S.nameIndexCache[_nm];
      if (_u && typeof host_file_exists === "function" && !host_file_exists(uuidToStatePath(_u))) {
        delete S.nameIndexCache[_nm];
        _dropped = true;
      }
    }
    if (_dropped) saveNameIndex(S.nameIndexCache);
  }
  if (altIndicatorActive(S.activeTrack, S.activeBank) || !S.sessionView && S.trackPadMode[S.activeTrack] === PAD_MODE_CONDUCT) {
    const _ph = Math.floor(S.tickCount / 24) % 2;
    if (_ph !== S._altBlinkPhase) {
      S._altBlinkPhase = _ph;
      S.screenDirty = true;
    }
  }
  if (S.screenDirty && !isSuspended) {
    S.screenDirty = false;
    drawUI();
  }
}

// ui/ui.js
var _jsErrSeen = {};
var _jsErrBuf = "";
function captureError(where, e) {
  try {
    const msg = e && e.message ? e.message : String(e);
    const key = where + "|" + msg;
    if (_jsErrSeen[key]) return;
    _jsErrSeen[key] = 1;
    const stack = e && e.stack ? "\n" + e.stack : "";
    _jsErrBuf += "[tick=" + (S.tickCount | 0) + " sv=" + (S.sessionView ? 1 : 0) + " loop=" + (S.loopHeld ? 1 : 0) + " lock=" + (S.perfViewLocked ? 1 : 0) + " susp=" + (S.pendingSuspendSave ? 1 : 0) + "] " + where + ": " + msg + stack + "\n\n";
    if (typeof host_write_file === "function")
      host_write_file("/data/UserData/schwung/seq8-jserr.log", _jsErrBuf);
  } catch (_e) {
  }
}
globalThis.init = function() {
  installConsoleOverride("SEQ8");
  S.schwungCoRunSlot = -1;
  S.moveCoRunTrack = -1;
  if (typeof shadow_corun_end === "function") shadow_corun_end();
  assertOvertakeSysexSuppress();
  if (S.bankParams === null)
    S.bankParams = Array.from({ length: NUM_TRACKS }, function() {
      return BANKS.map(function(bank) {
        return bank.knobs.map(function(k) {
          return k.def;
        });
      });
    });
  const p2 = typeof host_module_get_param === "function" ? host_module_get_param("playing") : null;
  const dspSurvived = p2 !== null && p2 !== void 0;
  console.log("SEQ8 init: " + (p2 === "1" ? "RESUMED playing" : "FRESH/stopped"));
  {
    const _as = readActiveSet();
    S.currentSetUuid = _as.uuid;
    S.currentSetName = _as.name;
  }
  const inheritResult = maybeShowInheritPicker(S.currentSetUuid, S.currentSetName);
  const currentDspNonce = typeof host_module_get_param === "function" ? host_module_get_param("instance_id") : null;
  const dspUuid = typeof host_module_get_param === "function" ? host_module_get_param("state_uuid") || "" : "";
  if (currentDspNonce) S.lastDspInstanceId = currentDspNonce;
  const _svMismatch = typeof host_module_get_param === "function" ? host_module_get_param("state_version_mismatch") : null;
  if (_svMismatch && parseInt(_svMismatch, 10) === 1) {
    S.confirmStateWipe = true;
    S.confirmStateWipeSel = 1;
    S.pendingSetLoad = false;
    S.screenDirty = true;
  } else if (inheritResult === "auto") {
    S.pendingSetLoad = true;
  } else if (inheritResult === "picker") {
  } else if (S.currentSetUuid && dspUuid !== S.currentSetUuid) {
    S.pendingSetLoad = true;
  } else if (S.currentSetUuid && typeof host_file_exists === "function") {
    const sp = "/data/UserData/schwung/set_state/" + S.currentSetUuid + "/seq8-state.json";
    if (!host_file_exists(sp)) S.pendingSetLoad = true;
  }
  S.pendingPruneOrphans = true;
  if (typeof host_module_get_param === "function") {
    S.playing = dspSurvived;
    for (let t = 0; t < NUM_TRACKS; t++) {
      const ac = host_module_get_param("t" + t + "_active_clip");
      if (ac !== null && ac !== void 0) S.trackActiveClip[t] = parseInt(ac, 10) | 0;
      const cs = host_module_get_param("t" + t + "_current_step");
      const csVal = cs !== null && cs !== void 0 ? parseInt(cs, 10) | 0 : -1;
      S.trackCurrentStep[t] = csVal;
      S.trackCurrentPage[t] = csVal >= 0 ? Math.floor(csVal / 16) : 0;
      const qc = host_module_get_param("t" + t + "_queued_clip");
      S.trackQueuedClip[t] = qc !== null && qc !== void 0 ? parseInt(qc, 10) | 0 : -1;
    }
    syncClipsFromDsp();
    syncMuteSoloFromDsp();
  }
  extHeldNotes.clear();
  if (!S.hasInitedOnce) {
    S.sessionView = true;
    S.hasInitedOnce = true;
    S._forceSessionCold = true;
  }
  restoreUiSidecar(!S.pendingSetLoad);
  S.dspInboundEnabled = typeof shadow_inbound_pad_midi_active === "function";
  computePadNoteMap();
  S.lastRemapTrack = -1;
  applyExtMidiRemap();
  S.ledInitComplete = false;
  invalidateLEDCache();
  S.ledInitQueue = buildLedInitQueue();
  S.ledInitIndex = 0;
  installFlagsWrap();
  S._origClearScreen = clear_screen;
  S._wasSuspended = false;
};
globalThis.tick = function() {
  try {
    _tickImpl();
  } catch (e) {
    captureError("tick", e);
  }
};
globalThis.onMidiMessageInternal = function(data) {
  try {
    _onMidiInternalImpl(data);
  } catch (e) {
    captureError("onMidiInternal", e);
  }
};
function _onMidiInternalImpl(data) {
  const status = data[0] | 0;
  const d1 = (data[1] ?? 0) | 0;
  const d2 = (data[2] ?? 0) | 0;
  if ((status & 240) === 160) {
    if (d1 >= TRACK_PAD_BASE && d1 < TRACK_PAD_BASE + 32) _onPadAftertouch(d1, d2);
    return;
  }
  if (isNoiseMessage(data)) return;
  if ((status & 240) === 176 && d1 === 79) return;
  if (((status & 240) === 144 || (status & 240) === 128) && d1 === 8) return;
  if (S.deleteTapArmed && status & 128 && !((status & 240) === 176 && d1 === MoveDelete3))
    S.deleteTapArmed = false;
  if (S.snapshotPicker) {
    const _ccPick = (status & 240) === 176 && (d1 === 3 || d1 === MoveMainKnob || d1 === MoveNoteSession);
    if (!_ccPick) return;
  }
  if (S.clearAutoMenu) {
    if ((status & 240) === 176 && d2 === 127 && (d1 === MoveNoteSession || d1 === MoveDelete3)) {
      closeClearAutoMenu();
      return;
    }
    const _ccMenu = (status & 240) === 176 && (d1 === 3 || d1 === MoveMainKnob);
    if (!_ccMenu) return;
  }
  if (S.sessionOverlayHeld) {
    const isRelease = status === 176 && d1 === MoveNoteSession && d2 === 0;
    const isScroll = status === 176 && (d1 === MoveUp3 || d1 === MoveDown3) && d2 === 127;
    if (!isRelease && !isScroll) return;
  }
  if (d1 >= 0 && d1 <= 9) {
    if ((status & 240) === 144) {
      if (d2 === 127) {
        if (d1 <= 7 && S.activeBank >= 0) {
          S.knobTouched = d1;
          S.knobTurnedTick[d1] = -1;
          S.screenDirty = true;
          if (S.activeBank === 6) {
            S.ccActiveLane[S.activeTrack] = d1;
            invalidateLEDCache();
          }
          if (S.perfViewLocked) {
            const _lt = d1;
            const _newLooper = S.trackLooper[_lt] !== 0 ? 0 : 1;
            S.trackLooper[_lt] = _newLooper;
            applyTrackConfig(_lt, "track_looper", _newLooper);
            showActionPopup("LOOPER " + (_newLooper ? "ON" : "OFF"), "TRACK " + (_lt + 1));
            setButtonLED6(71 + _lt, _newLooper ? trackColor(_lt) : LED_OFF, true);
          }
          if (S.activeBank === 6 && S.deleteHeld && !S.shiftHeld) {
            const _dt = S.activeTrack, _dac = effectiveClip(_dt);
            S.trackCCAutoBits[_dt][_dac] &= ~(1 << d1);
            S.trackCCLiveVal[_dt][d1] = -1;
            S.clipCCVal[_dt][_dac][d1] = -1;
            if (typeof host_module_set_param === "function")
              host_module_set_param("t" + _dt + "_cc_auto_clear_k", _dac + " " + d1);
            showActionPopup("CC", "CLEAR");
            invalidateLEDCache();
          }
          if (S.activeBank === 4 && d1 === 4 || S.activeBank === 5 && d1 === 4) forceRedraw();
        }
        if (d1 === MoveMainTouch && !S.globalMenuOpen && !S.shiftHeld) {
          S.jogTouched = true;
          forceRedraw();
        }
      } else if (d2 < 64) {
        if (d1 <= 7) {
          if (S.activeBank >= 0 && BANKS[S.activeBank].knobs[d1]) {
            const relPm = BANKS[S.activeBank].knobs[d1];
            if (relPm.dspKey === "nudge") {
              S.bankParams[S.activeTrack][S.activeBank][d1] = 0;
              if (typeof host_module_set_param === "function") {
                const _isAllLanesNdg = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 7;
                const _isDrumNdg = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 0;
                if (_isAllLanesNdg)
                  host_module_set_param("t" + S.activeTrack + "_all_lanes_nudge", "0");
                else if (_isDrumNdg)
                  host_module_set_param("t" + S.activeTrack + "_l" + S.activeDrumLane[S.activeTrack] + "_nudge", "0");
                else
                  host_module_set_param("t" + S.activeTrack + "_nudge", "0");
              }
            } else if (relPm.dspKey === "clock_shift" || relPm.dspKey === "beat_stretch") {
              S.clockShiftTouchDelta = 0;
              S.bankParams[S.activeTrack][S.activeBank][d1] = 0;
              if (relPm.dspKey === "clock_shift" && typeof host_module_set_param === "function") {
                const _isAllLanes = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 7;
                const _isDrum = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 0;
                if (_isAllLanes)
                  host_module_set_param("t" + S.activeTrack + "_all_lanes_nudge", "0");
                else if (_isDrum)
                  host_module_set_param("t" + S.activeTrack + "_l" + S.activeDrumLane[S.activeTrack] + "_nudge", "0");
                else
                  host_module_set_param("t" + S.activeTrack + "_nudge", "0");
              }
            }
            if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 7) {
              if (d1 === 0) {
                S.allLanesResResetTick = S.tickCount + 47;
                S.allLanesResResetTrack = S.activeTrack;
              }
              if (d1 === 3) {
                S.allLanesQntResetTick = S.tickCount + 47;
                S.allLanesQntResetTrack = S.activeTrack;
              }
              if (d1 === 6) {
                S.allLanesDirResetTick = S.tickCount + 47;
                S.allLanesDirResetTrack = S.activeTrack;
              }
            }
          }
          if (S.activeBank === 4 && d1 === 4 || S.activeBank === 5 && d1 === 4) forceRedraw();
          S.knobTouched = -1;
          S.knobLocked[d1] = false;
          S.knobAccum[d1] = 0;
          S.screenDirty = true;
        }
        if (d1 === MoveMainTouch && S.jogTouched) {
          S.jogTouched = false;
          S.bankSelectTick = -1;
          forceRedraw();
        }
      }
      return;
    }
    if ((status & 240) === 128) {
      if (d1 <= 7) {
        if (S.activeBank >= 0 && BANKS[S.activeBank].knobs[d1]) {
          const relPm = BANKS[S.activeBank].knobs[d1];
          if (relPm.dspKey === "nudge") {
            S.bankParams[S.activeTrack][S.activeBank][d1] = 0;
            if (typeof host_module_set_param === "function") {
              const _isAllLanesNdg = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 7;
              const _isDrumNdg = S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 0;
              if (_isAllLanesNdg)
                host_module_set_param("t" + S.activeTrack + "_all_lanes_nudge", "0");
              else if (_isDrumNdg)
                host_module_set_param("t" + S.activeTrack + "_l" + S.activeDrumLane[S.activeTrack] + "_nudge", "0");
              else
                host_module_set_param("t" + S.activeTrack + "_nudge", "0");
            }
          } else if (relPm.dspKey === "clock_shift" || relPm.dspKey === "beat_stretch") {
            S.clockShiftTouchDelta = 0;
            S.bankParams[S.activeTrack][S.activeBank][d1] = 0;
          }
          if (S.trackPadMode[S.activeTrack] === PAD_MODE_DRUM && S.activeBank === 7 && d1 === 3) {
            S.allLanesQntResetTick = S.tickCount + 47;
            S.allLanesQntResetTrack = S.activeTrack;
          }
        }
        if (S.activeBank === 4 && d1 === 4 || S.activeBank === 5 && d1 === 4) forceRedraw();
        S.knobTouched = -1;
        S.knobLocked[d1] = false;
        S.knobAccum[d1] = 0;
        S.screenDirty = true;
      }
      if (d1 === MoveMainTouch && S.jogTouched) {
        S.jogTouched = false;
        S.bankSelectTick = -1;
        forceRedraw();
      }
      return;
    }
  }
  if (status === 176) {
    _onCCMsg(d1, d2);
    return;
  }
  if ((status & 240) === 144 && d1 >= 16 && d1 <= 31 && d2 > 0) {
    _onStepButtons(d1, d2);
    return;
  }
  if ((status & 240) === 144 && d2 > 0) {
    _onPadPress(status, d1, d2);
    return;
  }
  if ((status & 240) === 128 || (status & 240) === 144 && d2 === 0) {
    _onPadRelease(status, d1, d2);
    return;
  }
}
globalThis.onMidiMessageExternal = function(data) {
  try {
    _onMidiExternalImpl(data);
  } catch (e) {
    captureError("onMidiExternal", e);
  }
};
function _onMidiExternalImpl(data) {
  const status = data[0] | 0;
  const d1 = (data[1] ?? 0) | 0;
  const d2 = (data[2] ?? 0) | 0;
  const msgType = status & 240;
  const msgCh = (status & 15) + 1;
  const t = S.activeTrack;
  const routeIsMove = S.trackRoute[t] === 1;
  if (S.extMidiRemapActive && routeIsMove) {
    if (msgCh !== S.trackChannel[t]) return;
  } else {
    if (S.midiInChannel !== 0 && msgCh !== S.midiInChannel) return;
  }
  if (S.trackPadMode[t] === PAD_MODE_DRUM) {
    if (msgType === 144 && d2 > 0) {
      const vel = effectiveVelocity(d2);
      S.lastPadVelocity = vel;
      if (!routeIsMove) liveSendNote(t, 144, d1, vel, false, true);
      const isSeqEcho = routeIsMove && S.seqActiveNotes.has(d1);
      const isRec = !isSeqEcho && S.recordArmed && t === S.recordArmedTrack;
      const recCap = isRec && extCountInCapture();
      if (recCap) {
        _drumRecNoteOns.push({ track: t, laneNote: d1, vel, ext: true });
        const recLane = S.drumLaneNote[t].indexOf(d1);
        if (recLane >= 0) {
          S.pendingDrumLaneResync = 3;
          S.pendingDrumLaneResyncTrack = t;
          S.pendingDrumLaneResyncLane = recLane;
        }
      }
      extHeldNotes.set(d1, { track: t, recording: recCap });
    } else if (msgType === 128 || msgType === 144 && d2 === 0) {
      const info = extHeldNotes.get(d1);
      const noteTrack = info ? info.track : t;
      if (S.trackRoute[noteTrack] !== 1) liveSendNote(noteTrack, 128, d1, 0, false, true);
      if (info && info.recording && S.recordArmed)
        _drumRecNoteOffs.push({ track: noteTrack, laneNote: d1, ext: true });
      extHeldNotes.delete(d1);
    } else if (msgType === 176 || msgType === 208 || msgType === 160 || msgType === 224) {
      if (!routeIsMove) liveSendNote(t, msgType, d1, d2);
    }
    return;
  }
  if (msgType === 144 && d2 > 0) {
    const vel = effectiveVelocity(d2);
    S.lastPlayedNote = d1;
    S.lastPadVelocity = vel;
    if (!routeIsMove) liveSendNote(t, 144, d1, vel, false, true);
    const isSeqEcho = routeIsMove && S.seqActiveNotes.has(d1);
    const isRec = !isSeqEcho && S.recordArmed && t === S.recordArmedTrack;
    const recCap = isRec && extCountInCapture();
    if (recCap) recordNoteOn(d1, vel, t, true);
    const prevInfo = extHeldNotes.get(d1);
    if (!prevInfo || !prevInfo.recording || !isSeqEcho) {
      extHeldNotes.set(d1, { track: t, recording: recCap });
    }
    if (S.heldStep >= 0 && !S.shiftHeld && !S.sessionView) {
      const ac = effectiveClip(t);
      if (typeof host_module_set_param === "function")
        if (S.stepWasEmpty && S.heldStepNotes.length > 0)
          host_module_set_param("t" + t + "_c" + ac + "_step_" + S.heldStep + "_set_notes", String(d1));
        else
          host_module_set_param("t" + t + "_c" + ac + "_step_" + S.heldStep + "_toggle", d1 + " " + vel);
      const raw = typeof host_module_get_param === "function" ? host_module_get_param("t" + t + "_c" + ac + "_step_" + S.heldStep + "_notes") : null;
      S.heldStepNotes = raw && raw.trim().length > 0 ? raw.trim().split(" ").map(Number).filter(function(n) {
        return n >= 0 && n <= 127;
      }) : [];
      S.clipSteps[t][ac][S.heldStep] = S.heldStepNotes.length > 0 ? 1 : 0;
      if (S.heldStepNotes.length > 0) {
        S.clipNonEmpty[t][ac] = true;
      } else if (S.clipNonEmpty[t][ac]) {
        S.clipNonEmpty[t][ac] = clipHasContent(t, ac);
      }
      refreshSeqNotesIfCurrent(t, ac, S.heldStep);
      forceRedraw();
    }
  } else if (msgType === 128 || msgType === 144 && d2 === 0) {
    const info = extHeldNotes.get(d1);
    const noteTrack = info ? info.track : t;
    if (S.trackRoute[noteTrack] !== 1) liveSendNote(noteTrack, 128, d1, 0, false, true);
    if (info && info.recording) recordNoteOff(d1, true);
    extHeldNotes.delete(d1);
  } else if (msgType === 176 || msgType === 208 || msgType === 160 || msgType === 224) {
    if (!routeIsMove) liveSendNote(t, msgType, d1, d2);
  }
}
